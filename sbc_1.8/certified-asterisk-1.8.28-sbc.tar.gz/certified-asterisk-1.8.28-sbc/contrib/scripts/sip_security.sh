#!/bin/bash
iptables=`which iptables`
sbcblock="SBCBLOCK"
sbcblockdropmsg="SBC LIST DROP"
echo "$1" >> /var/log/asterisk/sip_security.log
cut -d: -f 1 /var/log/asterisk/sip_security.log | sort | uniq > /etc/asterisk/blocked.ips
$iptables -N $sbcblock
for atacante in `cat /etc/asterisk/blocked.ips`
 do
   $iptables -A $sbcblock -s $atacante -m comment --comment "Log Criado pelo SBC Asterisk »»»BRUTE FORCE«««" -j LOG --log-prefix "$sbcblockdropmsg"
   $iptables -A $sbcblock -s $atacante -m comment --comment "Regra Criada pelo SBC Asterisk »»»BRUTE FORCE«««" -j DROP
 done

$iptables -I INPUT -m comment --comment "Regra Criada pelo SBC Asterisk »»»BRUTE FORCE«««" -j $sbcblock
$iptables -I OUTPUT -m comment --comment "Regra Criada pelo SBC Asterisk »»»BRUTE FORCE«««" -j $sbcblock
$iptables -I FORWARD -m comment --comment "Regra Criada pelo SBC Asterisk »»»BRUTE FORCE«««" -j $sbcblock
exit