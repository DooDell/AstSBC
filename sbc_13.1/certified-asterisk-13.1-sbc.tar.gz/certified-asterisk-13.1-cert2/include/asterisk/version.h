#error "Do not include 'asterisk/version.h'; use 'asterisk/ast_version.h' instead."
