
#include "SIPUserAgent.h"
#include "SIPSession.h"
#include "SIPSessionManager.h"

using namespace SIP;
using namespace UACORE;

/************ START OF USERAGENT CLASS ***************/

class UA : public SIPUserAgent
{
  PCLASSINFO( UA, SIPUserAgent );
public:
  UA();
  ~UA();
  void ProcessEvent( 
    SIPStackEvent * event 
  );

  SIPSessionManager * m_SM;
};

UA::UA() : SIPUserAgent( "Sample UA" )
{
  m_SM = NULL;
}

UA::~UA()
{
  delete m_SM;
}

void UA::ProcessEvent( SIPStackEvent * event )
{
  m_SM->ProcessStackEvent( event );
}

/************ END OF USERAGENT CLASS ***************/


class SessionManager : public SIPSessionManager 
{
  PCLASSINFO( SessionManager, SIPSessionManager );
public:
  SessionManager( UA & ua );
  
  SIPSession * OnCreateClientSession(
    const ProfileUA & /*profile*/,
    const OString & /*sessionId*/
  );

  SIPSession::GCRef OnCreateServerSession(
    SIPMessage & request
  );
};

/************ START OF CLIENTSESSION CLASS ***************/
class ClientSession : public SIPSession
{
  PCLASSINFO( ClientSession, SIPSession );
public:

  ClientSession(
    SessionManager & sessionManager,
    const OString & sessionId,
    const ProfileUA & profile
  );

  virtual void OnTimerExpire(
    SIPTimerExpire & timerEvent
  );


  virtual void OnIncomingSIPMessage(
      SIPMessageArrival & messageEvent
  );

};

ClientSession::ClientSession( 
  SessionManager & sessionManager,
  const OString & sessionId,
  const ProfileUA & profile
) : SIPSession( sessionManager, sessionId, profile )
{
}

void ClientSession::OnTimerExpire( SIPTimerExpire & )
{
  /// The target UA did not respnd in time
  Destroy();
}

void ClientSession::OnIncomingSIPMessage(
  SIPMessageArrival & messageEvent
)
{
  SIPMessage message = messageEvent.GetMessage();
  if( message.IsResponse() )
  {
    LOG( LogInfo(), "Got SIP Reponse" );
    if( !message.Is1xx() ) 
    {
      Destroy();  /// got a final response.  destroy this session
    }
  }else
  {
    LOG( LogInfo(), "Got SIP Request" )
    SIPMessage response;
    message.CreateResponse( response, SIPMessage::Code200_Ok );
    SendRequest( response );
  }
  
}
/************ END OF CLIENTSESSION CLASS ***************/
/************ START OF SERVERSESSION CLASS ***************/
class ServerSession : public SIPSession
{
  PCLASSINFO( ServerSession, SIPSession );
public:

  ServerSession(
    SessionManager & manager,
    const SIPMessage & reqeust,
    const OString & sessionId
  );

  virtual void OnTimerExpire(
    SIPTimerExpire & timerEvent
  );

  virtual void OnIncomingSIPMessage(
      SIPMessageArrival & messageEvent
  );

};

ServerSession::ServerSession( 
  SessionManager & sessionManager,
  const SIPMessage & reqeust,
    const OString & sessionId
) : SIPSession( sessionManager, reqeust, sessionId )
{
}

void ServerSession::OnTimerExpire( SIPTimerExpire & )
{
  /// The target UA did not respond in time
  Destroy();
}

void ServerSession::OnIncomingSIPMessage(
  SIPMessageArrival & messageEvent
)
{
  SIPMessage message = messageEvent.GetMessage();
  if( message.IsResponse() )
  {
    LOG( LogInfo(), "Got SIP Reponse" );
  }else
  {
    LOG( LogInfo(), "Got SIP Request" )
    SIPMessage response;
    message.CreateResponse( response, SIPMessage::Code200_Ok );
    SendRequest( response );
    Destroy();
  }
  
}
/************ END OF SERVERSESSION CLASS ***************/

/************ START OF SESSIONMANAGER CLASS ***************/
SessionManager::SessionManager( UA &ua ) : SIPSessionManager( ua )
{
}
SIPSession * SessionManager::OnCreateClientSession(
  const ProfileUA & profile,
  const OString & sessionId
)
{
  return new ClientSession( *this, sessionId, profile );
}

SIPSession::GCRef  SessionManager::OnCreateServerSession(
  SIPMessage & request
)
{
  CallId callId;
  request.GetCallId( callId );
  OString sessionId = callId.GetHeaderBody();
  ServerSession * session = new ServerSession( *this, request, sessionId );
  return GCCREATEREF( session, "SessionManager::OnCreateServerSession", "ServerSession" );
}
/************ END OF SESSIONMANAGER CLASS ***************/




/************ START OF PROCESS CLASS ***************/
class Process : public PProcess
{
  PCLASSINFO( Process, PProcess );
public:
  void Main();
  void TerminateProc();

  UA * m_UAC;
  UA * m_UAS;
  PSyncPoint m_ExitSync;
};

void Process::TerminateProc()
{
  m_ExitSync.Signal();
}

#ifdef WIN32
  static BOOL WINAPI Win32SignalHandler(DWORD dwCtrlType) 
  {
    switch( dwCtrlType )
    {
      case CTRL_C_EVENT:
      case CTRL_BREAK_EVENT:
      case CTRL_CLOSE_EVENT:
      case CTRL_LOGOFF_EVENT:
      case CTRL_SHUTDOWN_EVENT:
        dynamic_cast<Process&>(PProcess::Current()).TerminateProc();
        return TRUE;
      default:
        return FALSE;
    }
  }
#endif

void Process::Main()
{
  #if WIN32
    SetConsoleCtrlHandler(Win32SignalHandler, TRUE);
  #endif

  /// Create the server and and bind it to port 5060
  m_UAS = new UA();
  m_UAS->GetDefaultProfile().GetTransportProfile().EnableUDP( 0, 5060 );
  m_UAS->Initialize();
  m_UAS->StartTransportThreads();
  m_UAS->m_SM = new SessionManager( *m_UAS );

  /// Create the client and bind it to 5070
  m_UAC = new UA();
  m_UAC->GetDefaultProfile().GetTransportProfile().EnableUDP( 0, 5070 );
  m_UAC->Initialize();
  m_UAC->StartTransportThreads();
  m_UAC->m_SM = new SessionManager( *m_UAC );

  OString sesionId = ParserTools::GenGUID();
  ClientSession * session = dynamic_cast<ClientSession *>(m_UAC->m_SM->CreateClientSession(  m_UAC->GetDefaultProfile(), sesionId )); 
  SIPURI target( "sip:test_account@localhost:5060" );
  SIPURI localURI( "sip:test_notify@opensipstack.org" );
  Via localVia;
  m_UAC->ConstructVia( target.GetAddress(), localVia, SIPTransport::UDP );
  
  session->SetTargetURI( target );
  session->SetRemoteURI( target );
  session->SetLocalURI( localURI );
  session->SetLocalVia( localVia );
  
  /// Create a notify and send a test message to the server UA
  SIPMessage notify;
  if( session->CreateRequestOutOfDialog( SIPMessage::Method_NOTIFY, notify ) )
  {
    Event event( "message-summary" );
    notify.SetEvent( event );

    ContentType ct( "application/simple-message-summary" );
    notify.SetContentType( ct );

    OStringStream body;
    body << "Messages-Waiting: " << "yes" << "\r\n";
    body << "Message-Account: " << "sip:test_account@localhost" << "\r\n";
    body << "Voice-Message: " << "1/1" << "\r\n";
    notify.SetBody( body.str() );

    session->SendRequest( notify );
  }
  
  Sleep( 5000 );

  m_UAC->Terminate();
  m_UAS->Terminate();

  delete m_UAC;
  delete m_UAS;
}

PCREATE_PROCESS( Process );
/************ END OF PROCESS CLASS ***************/