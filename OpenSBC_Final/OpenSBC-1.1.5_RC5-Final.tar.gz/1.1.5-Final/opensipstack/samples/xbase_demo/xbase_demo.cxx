#include "ptlib.h"
#include "XBase.h"

using namespace Tools;

class Process : public PProcess
{
public:
  XBaseSchema m_Schema;
  int m_FName;
  int m_LName;
  int m_DOB;
  int m_SD;
  int m_Amt;
  int m_ZIP;
  int m_Paid;
  int m_Comment;

  void Main()
  {
    PTrace::SetLevel( 1 );
    XBase::InitEngine(); /// intialize the XBase engine
    
    CreateXBase();
    AppendData();
    ReadRecords();
    DeleteRecords();
    TestIndices();

    m_Schema.CloseDataBase();
    XBase::DeinitEngine();  
  }

  void CreateXBase()
  {
    m_Schema.SetDBPath( "MyDB.dbf" );
    m_Schema.AddField( "FIRSTNAME", XBaseSchema::CHAR_FLD,     15    );
    m_Schema.AddField( "LASTNAME",  XBaseSchema::CHAR_FLD,     20    );
    m_Schema.AddField( "BIRTHDATE", XBaseSchema::DATE_FLD,      8    );
    m_Schema.AddField( "STARTDATE", XBaseSchema::DATE_FLD,      8    );
    m_Schema.AddField( "ZIPCODE",   XBaseSchema::INTEGER_FLD,   5    );
    m_Schema.AddField( "AMOUNT",    XBaseSchema::INTEGER_FLD,   9, 2 );
    m_Schema.AddField( "PAID",      XBaseSchema::BOOLEAN_FLD,   1    );
    m_Schema.AddField( "COMMENT",   XBaseSchema::MEMO_FLD,     10    );

    m_Schema.AddIndex( "MyNdx1", "LASTNAME", FALSE );
    m_Schema.AddIndex( "MyNdx2", "LASTNAME-FIRSTNAME", FALSE );
    m_Schema.AddIndex( "MyNdx3", "ZIPCODE", FALSE );

    int rc =  m_Schema.CreateDatabase( TRUE );
    std::cout << "schema.CreateDatabase() - " << XBase::GetErrorMessage( rc ) << endl;

    rc =  m_Schema.OpenDatabase();
    std::cout <<  "schema.OpenDatabase() - " << XBase::GetErrorMessage( rc ) << endl;

    XBase * xBase = m_Schema.GetDB();
    m_FName     = xBase->FieldGetContext( "FIRSTNAME" ); 
    m_LName     = xBase->FieldGetContext( "LASTNAME" );
    m_DOB = xBase->FieldGetContext( "BIRTHDATE" ); 
    m_SD = xBase->FieldGetContext( "STARTDATE" );
    m_Amt    = xBase->FieldGetContext( "AMOUNT" );
    m_ZIP   = xBase->FieldGetContext( "ZIPCODE" );
    m_Paid      = xBase->FieldGetContext( "PAID" );
    m_Comment   = xBase->FieldGetContext( "COMMENT" );
  }

  void AppendData()
  {
    XBase * xBase = m_Schema.GetDB();
    PTime sdate;

    xBase->RecordAppendBlank();  /// insert a blank record in the record buffer
    xBase->FieldSetString( m_FName, "John" );
    xBase->FieldSetString( m_LName, "Doe" );
    PTime bdate = PTime( 0, 0, 0, 18, 1, 1982 );
    xBase->FieldSetDate( m_DOB, bdate );
    xBase->FieldSetDate( m_SD, sdate );
    xBase->FieldSetFloat( m_Amt, 656.50f );
    xBase->FieldSetInteger( m_ZIP, 1900 );
    xBase->FieldSetLogical( m_Paid, TRUE );
    xBase->FieldSetMemo( m_Comment, "This is a sample comment for account of Jane Doe" );
    xBase->RecordCommitAppend();
    
    xBase->RecordAppendBlank();  /// insert a blank record in the record buffer
    xBase->FieldSetString( m_FName, "John" );
    xBase->FieldSetString( m_LName, "Smith" );
    bdate = PTime( 0, 0, 0, 24, 3, 1970 );
    xBase->FieldSetDate( m_DOB, bdate );
    
    xBase->FieldSetDate( m_SD, sdate );
    xBase->FieldSetFloat( m_Amt, 999.99f );
    xBase->FieldSetInteger( m_ZIP, 1500 );
    xBase->FieldSetLogical( m_Paid, TRUE );
    xBase->FieldSetMemo( m_Comment, "This is a sample comment for account of John Doe" );
    xBase->RecordCommitAppend();

    xBase->RecordAppendBlank();  /// insert a blank record in the record buffer
    xBase->FieldSetString( m_FName, "Jane" );
    xBase->FieldSetString( m_LName, "Doe" );
    bdate = PTime( 0, 0, 0, 18, 1, 1983 );
    xBase->FieldSetDate( m_DOB, bdate );
    xBase->FieldSetDate( m_SD, sdate );
    xBase->FieldSetFloat( m_Amt, 756.23f );
    xBase->FieldSetInteger( m_ZIP, 1800 );
    xBase->FieldSetLogical( m_Paid, TRUE );
    xBase->FieldSetMemo( m_Comment, "This is a sample comment for account of Jane Doe" );
    xBase->RecordCommitAppend();

    

    xBase->RecordAppendBlank();  /// insert a blank record in the record buffer
    xBase->FieldSetString( m_FName, "Homer" );
    xBase->FieldSetString( m_LName, "Simpson" );
    bdate = PTime( 0, 0, 0, 12, 5, 1991 );
    xBase->FieldSetDate( m_DOB, bdate );
    xBase->FieldSetDate( m_SD, sdate );
    xBase->FieldSetFloat( m_Amt, 300.50f );
    xBase->FieldSetInteger( m_ZIP, 1900 );
    xBase->FieldSetLogical( m_Paid, FALSE );
    xBase->FieldSetMemo( m_Comment, "This is a sample comment for account of Homer Simpson" );
    xBase->RecordCommitAppend();
  }

  void ReadRecords()
  {
    XBase * xBase = m_Schema.GetDB();
    XBase::RecordPointer rec( xBase );

    while( !rec.IsEOF() )
    {
      std::cout << "Name: " << rec->FieldGetString( m_FName ) << " " << rec->FieldGetString( m_LName ) << ", ";
      std::cout << "DOB: " << rec->FieldGetDate( m_DOB ) << ", ";
      std::cout << "ZIP: " << rec->FieldGetInteger( m_ZIP ) << ", ";
      std::cout << "Paid: " << rec->FieldGetFloat( m_Amt ) << endl;
      rec++;
    }

    std::cout << endl;
  }

  void DeleteRecords()
  {
    XBase * xBase = m_Schema.GetDB();
    XBase::RecordPointer rec( xBase );
    
    ///delete record number 4
    rec = 4;
    rec->DeleteRecord();
    rec->DeleteCommit();
  }

  void TestIndices()
  {
    XBase * rec = m_Schema.GetDB();
    XBaseIndex * myNdx1 = m_Schema.GetIndex( "MyNdx1" );
    XBaseIndex * myNdx2 = m_Schema.GetIndex( "MyNdx2" );
    XBaseIndex * myNdx3 = m_Schema.GetIndex( "MyNdx3" );

    std::cout << endl;

    if( myNdx1->FindStringKey( "Doe" ) == XBase::XBASE_FOUND )
    {
      std::cout << "NDX Find alpha key - Found Record #" << myNdx1->GetCurrentRecordNumber() << endl;
      std::cout << "Name: " << rec->FieldGetString( m_FName ) << " " << rec->FieldGetString( m_LName ) << endl;
      std::cout << "DOB: " << rec->FieldGetDate( m_DOB ) << endl;
      std::cout << "ZIP: " << rec->FieldGetInteger( m_ZIP ) << endl;
      std::cout << "Paid: " << rec->FieldGetFloat( m_Amt ) << endl << endl;
    }

    if( myNdx1->GetNextKey( ) == XBase::XBASE_NO_ERROR && rec->FieldGetString( m_LName ) == "Doe" )
    {
      std::cout << "NDX Get Next Key - Found Record #" << myNdx1->GetCurrentRecordNumber() << endl;
      std::cout << "Name: " << rec->FieldGetString( m_FName ) << " " << rec->FieldGetString( m_LName ) << endl;
      std::cout << "DOB: " << rec->FieldGetDate( m_DOB ) << endl;
      std::cout << "ZIP: " << rec->FieldGetInteger( m_ZIP ) << endl;
      std::cout << "Paid: " << rec->FieldGetFloat( m_Amt ) << endl << endl;
    }

    if( myNdx2->FindStringKey( "SmithJohn" ) == XBase::XBASE_FOUND )
    {
      std::cout << "NDX Find alpha key - Found Record #" << myNdx2->GetCurrentRecordNumber() << endl;
      std::cout << "Name: " << rec->FieldGetString( m_FName ) << " " << rec->FieldGetString( m_LName ) << endl;
      std::cout << "DOB: " << rec->FieldGetDate( m_DOB ) << endl;
      std::cout << "ZIP: " << rec->FieldGetInteger( m_ZIP ) << endl;
      std::cout << "Paid: " << rec->FieldGetFloat( m_Amt ) << endl << endl;
    }

    if( myNdx2->FindStringKey( "SimpsonHomer" ) == XBase::XBASE_FOUND )
    {
      std::cout << "NDX Find alpha key - Found Record #" << myNdx2->GetCurrentRecordNumber() << endl;
      std::cout << "Name: " << rec->FieldGetString( m_FName ) << " " << rec->FieldGetString( m_LName ) << endl;
      std::cout << "DOB: " << rec->FieldGetDate( m_DOB ) << endl;
      std::cout << "ZIP: " << rec->FieldGetInteger( m_ZIP ) << endl;
      std::cout << "Paid: " << rec->FieldGetFloat( m_Amt ) << endl << endl;
    }

    if( myNdx3->FindNumericKey( 1800 ) == XBase::XBASE_FOUND )
    {
      std::cout << "NDX Find numeric key - Found Record #" << myNdx3->GetCurrentRecordNumber() << endl;
      std::cout << "Name: " << rec->FieldGetString( m_FName ) << " " << rec->FieldGetString( m_LName ) << endl;
      std::cout << "DOB: " << rec->FieldGetDate( m_DOB ) << endl;
      std::cout << "ZIP: " << rec->FieldGetInteger( m_ZIP ) << endl;
      std::cout << "Paid: " << rec->FieldGetFloat( m_Amt ) << endl << endl;
    }
  }
};

PCREATE_PROCESS( Process );