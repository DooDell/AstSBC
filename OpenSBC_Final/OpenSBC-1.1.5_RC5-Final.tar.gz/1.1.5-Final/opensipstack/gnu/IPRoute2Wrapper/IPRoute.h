#ifndef IPROUTE_H
#define IPROUTE_H

#include <ptlib.h>
#include <ptlib/sockets.h>
#include "OString.h"

using namespace Tools;



class IPRoute
{
public:
	
	static PString IPRouteGet(
		const PIPSocket::Address & address
  );
  
  static BOOL GetRoute(
    const PIPSocket::Address & dst,
  	PIPSocket::Address & via,
  	OString & dev,
  	PIPSocket::Address & src
  );
  
};

#endif
