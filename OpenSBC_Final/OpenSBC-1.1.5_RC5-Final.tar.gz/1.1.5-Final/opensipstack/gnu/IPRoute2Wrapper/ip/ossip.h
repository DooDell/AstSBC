#ifndef OSSIP_H_
#define OSSIP_H_

extern int DoIPRoute(int argc, char **argv, void * hparams);

#endif /*OSSIP_H_*/
