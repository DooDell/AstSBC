#ifndef IPROUTE_H_
#define IPROUTE_H_

typedef struct rheaders
{
	char * via;
	char * dev;
	char * src;
}route_params;

extern int iproute_get_ex(int argc, char **argv, route_params * hparams);

#endif /*IPROUTE_H_*/
