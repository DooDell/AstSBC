static char SNAPSHOT[] = "070313";
