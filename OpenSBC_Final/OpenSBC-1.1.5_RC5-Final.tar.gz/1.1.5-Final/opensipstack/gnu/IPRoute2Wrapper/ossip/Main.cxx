#include "IPRoute.h"

#define new PNEW

class ossip : public PProcess
{
	PCLASSINFO( ossip, PProcess );
public:
	ossip()
	{
	}
	
	void Main()
	{
		//for( PINDEX i = 0; i < 100; i++ )
		//IPRoute::IPRouteGet( PIPSocket::Address("64.243.115.5") );
		
	cout << PTimer::Tick() << endl;
	 
	 for( PINDEX i = 0; i < 1000; i++ )
	 {
		PString dev;
		PIPSocket::Address via, src;
		IPRoute::GetRoute( 
			PIPSocket::Address("192.168.0.1"), via, dev, src );
			
		cout << via << " : " << dev << " : " << src << endl;

	 }
		
		cout << PTimer::Tick() << endl;
	}
	
};

PCREATE_PROCESS( ossip );
	
