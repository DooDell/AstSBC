



#include "IPRoute.h"

extern "C"
{
	 #include "ossip.h"
	 #include "iproute.h"
};

PString IPRoute::IPRouteGet(
	const PIPSocket::Address & address
)
{
	
	return PString::Empty();
}

static void free_rparams( route_params & param )
{
	if( param.dev != 0 )
		free( param.dev );
		
	if( param.src != 0 )
		free( param.src );
		
	if( param.via != 0 )
	  free( param.via );
}

BOOL IPRoute::GetRoute(
  const PIPSocket::Address & dst,
	PIPSocket::Address & via,
	OString & dev,
	PIPSocket::Address & src
)
{
	route_params hparams;
	
	OString ip = (const char *)dst.AsString();
	int len = ip.GetSize();
	char * buff = (char*)malloc(len);
	memcpy( buff, static_cast<const char *>(ip.GetPointer(len)), len  );
	char * argv[4]={ "ip", "route", "get", buff };
	
	
  DoIPRoute( 4, &argv[0],  &hparams);

	if( hparams.src != 0 )
		src = static_cast<const char  *>(hparams.src);
	if( hparams.dev != 0)
		dev = static_cast<const char  *>(hparams.dev);
	if( hparams.via != 0 )
		via = static_cast<const char  *>(hparams.via);
	
	BOOL ok = hparams.src != 0;
	free_rparams( hparams );
		
	free( buff );	
	
	return ok;
}
