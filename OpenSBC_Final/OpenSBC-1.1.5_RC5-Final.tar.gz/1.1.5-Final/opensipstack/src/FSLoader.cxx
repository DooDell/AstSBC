#include "FSLoader.h"

#ifdef HAS_FREE_SWITCH

#undef strcasecmp
#undef strncasecmp

#include "switch.h"
#include "private/switch_core_pvt.h"

using namespace FS;

FSLoader::FSLoader() : PThread( 10240 )
{
  Resume();
}

FSLoader::~FSLoader()
{
}

void FSLoader::Main()
{
  switch_core_flag_t flags = SCF_USE_SQL;
  switch_memory_pool_t *pool = NULL;
  BOOL nc=TRUE; /* this is for 'no console' mode, FALSE console is there, TRUE it isnt */
  const char *err = NULL;     /* error value for return from freeswitch initialization */
  #define LOGFILE "freeswitch.log"
  static char *lfile = LOGFILE; /* if NULL no logfile is generated */
  if (apr_initialize() != SWITCH_STATUS_SUCCESS) {
		fprintf(stderr, "FATAL ERROR! Could not initialize APR\n");
		return;
	}
  switch_core_setrlimits();
  switch_core_set_globals();
  apr_pool_create(&pool, NULL);

  switch_core_init_and_modload(flags, nc ? SWITCH_FALSE : SWITCH_TRUE, &err);
  switch_core_runtime_loop(nc);
  switch_core_destroy();
}

void FSLoader::StartRunTimeLoop()
{
  new FSLoader();
}


#endif //HAS_FREE_SWITCH
