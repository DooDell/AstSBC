/*
 *
 * SIPTransactionManager.cxx
 *
 * Open SIP Stack ( OSS )
 *
 * Copyright (C) 2006 Joegen E. Baclor. All Rights Reserved.
 *
 * Version: MPL 1.1/GPL 2.0/LGPL 2.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is OpenSIPStack Library.
 *
 * The Initial Developer of the Original Code is Joegen E. Baclor.
 *
 * Contributor(s):
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * $Log: SIPTransactionManager.cxx,v $
 * Revision 1.67  2009/06/15 01:05:22  joegenbaclor
 * implemented event rewind on deadlock in various places
 *
 * Revision 1.66  2009/05/04 23:52:33  joegenbaclor
 * Minor bug fixes in handling reinvite media where OnIncomingSDPOffer() is not called
 *  when dialog state is connected
 *
 * Revision 1.65  2009/05/01 02:43:53  joegenbaclor
 * - Added Event queue to transaction manager to handle transaction removal
 * - Added check in creating server session if the sip message is an invite
 *
 * Revision 1.64  2009/04/28 00:38:18  joegenbaclor
 * Added SIPSession as a apramater to FindTransactionAndAddEvent() so that SIPTransaction can instantiate a reference to the owning session
 *
 * Revision 1.63  2009/04/14 03:30:24  joegenbaclor
 * Added yield in findTransactionAndAddEvent
 *
 * Revision 1.62  2009/03/17 02:26:27  joegenbaclor
 * Changed FindTransactionAndAddEvent function param to not include the transaction id.  Sof far, we have not used it so its kinda useless
 *
 * Revision 1.61  2009/03/16 01:38:56  joegenbaclor
 * made transaction pool dictianaries as separate lsit for faster lookup and less mutex collisions.
 *
 * Revision 1.60  2009/02/14 06:48:06  joegenbaclor
 * Maximized use of timed mutex for transaction and session list mutex to avoid deadlocks
 *
 * Revision 1.59  2009/01/30 11:33:25  joegenbaclor
 * During the last few days I have been working on trying to make OpenSIPStack more resilient to DoS.
 * This is typically encountered when application users use the stack for transaction intensive
 * purposes like call center dialers.  Sudden influx of simultaneous INVITEs just 1 or two milliseconds
 * away from each other may put the application to its knees.  To circumvent this, we needed to at
 * least distribute load evenly so as not to overwhelm the stack.  Thus we introduced a new state
 * timer for IST called IST Pending Timer.  When an IST has detected that the previous IST ceation was
 * just less than 100 ms prior, it enters a pending state using a random wait time from 500 ms to 3 seconds.
 * Only after this timer expires would IST report the event to the TU.
 *
 * Revision 1.58  2009/01/29 05:56:50  joegenbaclor
 * Bug fixes.  See last revision in buildindex.h  (Jan. 29, 2009)
 *
 * Revision 1.57  2008/11/20 11:03:31  joegenbaclor
 * Depcrecated old SIPMessage URI accessors
 *
 * Revision 1.56  2008/11/02 02:34:53  joegenbaclor
 * Added autodelte parameter to SetBypass handler to allow applications to override the
 *  m_AutoDelete property of the handler in cases where the bypass handler might be shared
 *  by multiple transactions.
 *
 * Revision 1.55  2008/10/16 04:09:20  joegenbaclor
 * Added InviteCleintCancelTransaction bypass handler
 *
 * Revision 1.54  2008/10/06 02:03:47  joegenbaclor
 * Commented out some extra verbose logs
 *
 * Revision 1.53  2008/09/26 07:26:53  joegenbaclor
 * Made Timer B configurable
 *
 * Revision 1.52  2008/09/02 09:29:56  joegenbaclor
 * Added OnTermiante to transaction  bypass handler
 *
 * Revision 1.51  2008/06/04 02:55:34  joegenbaclor
 * Reverting previous accidental merge
 *
 * Revision 1.49  2008/05/27 03:15:41  joegenbaclor
 * More work on leak free process termination
 *
 * Revision 1.48  2008/05/07 11:01:19  joegenbaclor
 * Added support for NULL Server Transactions.
 *
 * Revision 1.47  2008/02/19 06:56:36  rcolobong
 * Add modifiers for SIP Timer H
 *
 * Revision 1.46  2007/12/21 07:19:35  joegenbaclor
 * Added ability to preserve the transaction via the incoming SIP message.  This pointer may be provided to SendRequest so that responses can avoid another search of the transaction from the transaction db.
 *
 * Revision 1.45  2007/12/04 14:30:23  joegenbaclor
 * Adding AccessList classes
 *
 * Revision 1.44  2007/12/04 07:12:38  ijpinzon
 * Additional modifications for 100rel support
 *
 * Revision 1.43  2007/12/03 08:01:31  joegenbaclor
 * completing initial patch for 100rel support
 *
 * Revision 1.42  2007/12/01 08:28:16  joegenbaclor
 * Preserved AckID in IST to avoid recomputation of the same when removing ACK transactions
 *
 * Revision 1.41  2007/11/30 04:27:02  joegenbaclor
 * Commiting Initial methods and objects for 100rel support
 *
 * Revision 1.40  2007/11/12 04:36:35  joegenbaclor
 * Added ability to configure default max-forwards
 *
 * Revision 1.39  2007/11/11 14:22:07  joegenbaclor
 * *** empty log message ***
 *
 * Revision 1.38  2007/07/14 07:50:33  joegenbaclor
 * Migrated code to use new STL based string class
 *
 * Revision 1.37  2007/06/13 14:13:34  joegenbaclor
 * Fixed bug in DoDNSFailover where the attempt count is not propagated to the new transaction
 *
 * Revision 1.36  2007/06/01 09:23:17  joegenbaclor
 * Fixed FindAckTransactonAndAddEvent race condition
 *
 * Revision 1.35  2007/05/25 08:38:09  joegenbaclor
 * Introduced GCVERIFYREF and GCCREATEREF Macro
 * Transfered B2BUAConnection::OnIncomingCall to be called in B2BUAEndPoint::OnIncomingSIPMessage
 *
 * Revision 1.34  2007/05/08 12:49:28  joegenbaclor
 * Corrected memory leaks in SIPMessage.
 *
 * Revision 1.33  2007/04/10 06:13:08  joegenbaclor
 * Added new Encryption Mode
 *
 * Revision 1.32  2007/04/09 08:06:20  joegenbaclor
 * Fixed bug in ACK transaction matching
 *
 * Revision 1.31  2007/03/29 03:11:49  joegenbaclor
 * Made sure we use SIPMessage::GetToTag() and SIPMessage::GetFromTag() when fetching
 *  the tag parameter to be sure that we catch header with and without the angle bracket
 *  <> enclosures.
 *
 * Revision 1.30  2007/03/28 09:09:24  joegenbaclor
 * Logging enhancements
 *
 * Revision 1.29  2007/03/22 09:09:54  joegenbaclor
 * Some logging aesthetics
 *
 * Revision 1.28  2007/03/05 09:29:26  joegenbaclor
 * Some thread optimizations
 *
 * Revision 1.27  2007/03/02 06:22:46  joegenbaclor
 * Corrected some bug in GC.
 * Added CPU Throttle mechanism during heavy load to avoid denial of service
 * Made sure lists are Made unique in SIPHeade clone function
 *
 * Revision 1.26  2007/02/09 03:47:35  joegenbaclor
 * 1. Added MaxForwards handling for B2B calls
 * 2. #defined SIP_DEFAULT_MAX_FORWARDS constant
 *
 * Revision 1.25  2007/02/04 15:04:10  joegenbaclor
 * Completed transaction layer TCP support
 *
 * Revision 1.24  2007/01/12 10:49:10  joegenbaclor
 * minor proxy bug fixes
 * more launcher code
 *
 * Revision 1.23  2007/01/01 05:12:53  joegenbaclor
 * Introduced termiantion flag to avoid crashes on exit.
 * TO DO: Maybe the best thing to do here is to have a WaitForTermination()
 * function exposed for the SIPStack
 *
 * Revision 1.22  2006/12/20 08:57:40  joegenbaclor
 * More cleanup beautification
 *
 * Revision 1.21  2006/12/19 23:38:34  joegenbaclor
 * Fixed bug in softphone proxy authentication where passwords <= 3 in length may not be properly handled
 *
 * Revision 1.20  2006/11/30 08:19:38  joegenbaclor
 * Relicensed opensipstack to MPL/GPL/LGPL triple license scheme
 *
 * Revision 1.19  2006/11/17 03:28:45  rcolobong
 * Update Method in Adding, removing and Finding an ACK Transaction to remove checking of To Tag
 *
 * Revision 1.18  2006/09/01 03:12:26  joegenbaclor
 * Bulk Commit:
 *
 * 1.  A bug is discovered in SIP Transaction Destructor where destruction of the SIPTimers may cause a deadlock on the timer manager effectivily freezing the entire message Queue System.  This was fixed by introducing a separate function to destroy the timers on receipt of the final event just before the transaction is queued for deletion.
 *
 * 2.  There is bug in Invite Server Transaction where ACK transaction is added to the Ack Transaction Pool after sending og none 2xx final response.  This new transaction is never removed from the pool after Timer_H has fired.  this may result to a bad pointer if ACK is received after the timer expired since the transaction may have been deleted by then.
 *
 * 3.  A few tweaks in GC GetName func to return the Class Name if GC NAme is empty.
 *
 * Revision 1.17  2006/08/28 07:18:35  joegenbaclor
 * Bulk Commit: Logging overhaul and Call Session callback changes to reflect SIPMessage eg:  OnAlerting(), OnProgress(), etc
 *
 * Revision 1.16  2006/08/15 15:42:09  joegenbaclor
 * 1. Added Instant Messaging functions to OPAL
 *
 * Revision 1.15  2006/08/14 01:29:09  joegenbaclor
 * Introduced separate provisions for UAS/UAC Current Request/Reponse.  Previousely the current request/response can be accessed via a single provision SIPSession::Get/Set/CurrentRequest()
 *
 * Revision 1.14  2006/07/06 05:38:11  joegenbaclor
 * Final last minute changes to CBCOM hash support
 *
 * Revision 1.13  2006/04/07 07:47:20  joegenbaclor
 * More work on OpenPhone/OPAL
 *
 * Revision 1.12  2006/04/05 00:26:04  joegenbaclor
 * 1.  Completed support for STUN NAT traversal method and OPAL style address translation
 * 2.  More bug fixes to ProxySession
 * 3.  Fixed bug in messages where zero size list headers may be interpreted by the parser as a valid header
 * 4.  Started work on OPAL outbound
 *
 * Revision 1.11  2006/03/24 15:42:18  joegenbaclor
 * Some bug fixes including possible deadlocks between Session Destruction and ProcessStackEvent
 *
 * Revision 1.10  2006/03/21 03:29:56  joegenbaclor
 * Added Logger functionality to log to PTrace
 *
 * Revision 1.9  2006/03/14 03:53:53  joegenbaclor
 * Initial source upload for BETA Release Candidate
 *
 *
 *
 */

#include "SIPTransactionManager.h"
#include "SIPTransactionStage.h"
#include "SIPTransportManager.h"
#include "InviteServerTransaction.h"
#include "SIPStack.h"
#include "SIPSession.h"
#include "ossbuildopts.h"

#define new PNEW

using namespace SIP;
using namespace SIPTransactions;
using namespace SIPTransports;

SIPTransactionManager::SIPTransactionManager(
  PINDEX threadCount
)
{
  m_IsTerminating = FALSE;
  m_AckTransactionPool.DisallowDeleteObjects();
  m_PrackTransactionPool.DisallowDeleteObjects();
  m_DefaultTimer_H = SIP_TIMER_H;
  m_DefaultTimer_B = SIP_TIMER_B;
  m_TransactionStage = new SIPTransactionStage( threadCount, threadCount );
  
  m_ICTPool.DisallowDeleteObjects();
  m_ISTPool.DisallowDeleteObjects();
  m_NICTPool.DisallowDeleteObjects();
  m_NISTPool.DisallowDeleteObjects();

  m_ManagerEventQueue = new EventQueue( PCREATE_NOTIFIER( OnTransactionManagerEvent ), 1, 1024000, P_MAX_INDEX, "SIPTransactionManager" );
}

SIPTransactionManager::~SIPTransactionManager()
{
  ForceTerminateTransactions();
  delete m_TransactionStage;
}

void SIPTransactionManager::ForceTerminateTransactions()
{
  TerminateTimers();
  
  for( PINDEX i = 0; i < m_ICTPool.GetSize(); i++ )
  {
    SIPTransaction & trn = m_ICTPool.GetDataAt(i);
    /// process pending events if any
    trn.ProcessEvents();
    trn.OnFinalEvent();
    /// allow descendants to cleanup before deletion
    trn.Cleanup();
    trn.GCCollect();
  }

  for( PINDEX i = 0; i < m_ISTPool.GetSize(); i++ )
  {
    SIPTransaction & trn = m_ISTPool.GetDataAt(i);
    /// process pending events if any
    trn.ProcessEvents();
    trn.OnFinalEvent();
    /// allow descendants to cleanup before deletion
    trn.Cleanup();
    trn.GCCollect();
  }

  for( PINDEX i = 0; i < m_NISTPool.GetSize(); i++ )
  {
    SIPTransaction & trn = m_NISTPool.GetDataAt(i);
    /// process pending events if any
    trn.ProcessEvents();
    trn.OnFinalEvent();
    /// allow descendants to cleanup before deletion
    trn.Cleanup();
    trn.GCCollect();
  }

  for( PINDEX i = 0; i < m_NICTPool.GetSize(); i++ )
  {
    SIPTransaction & trn = m_NICTPool.GetDataAt(i);
    /// process pending events if any
    trn.ProcessEvents();
    trn.OnFinalEvent();
    /// allow descendants to cleanup before deletion
    trn.Cleanup();
    trn.GCCollect();
  }
}


BOOL SIPTransactionManager::CreateNullServerTransaction(
  const SIPMessage & event
)
{
  return CreateTransaction(event, TRUE, 0, TRUE );
}

BOOL SIPTransactionManager::CreateTransaction(
  const SIPMessage & event,
  BOOL fromTransport,
  int failoverAttempt,
  BOOL isNullTransaction,
  SIPTransactionBypass * bypassHandler,
  UACORE::SIPSession * sipSession
)
{
  
  if( m_IsTerminating )
    return FALSE;

  OString idPrefix;
  SIPTransaction::Type type;
  PTimedMutex * trnMutex = NULL;
  SIPTransaction::Dictionary * trnPool = NULL;

  if( fromTransport )
  {
    ///type = SIPTransaction::Server;
    if( event.IsInvite() )
    {
      type = SIPTransaction::IST;
      idPrefix = "IST";
      trnMutex = &m_ISTPoolMutex;
      trnPool = &m_ISTPool;
    }else
    {
      type = SIPTransaction::NIST;
      idPrefix = "NIST";
      trnMutex = &m_NISTPoolMutex;
      trnPool = &m_NISTPool;
    }
  }else
  {
    if( event.IsInvite() )
    {
      type = SIPTransaction::ICT;
      idPrefix = "ICT";
      trnMutex = &m_ICTPoolMutex;
      trnPool = &m_ICTPool;
    }else
    {
      type = SIPTransaction::NICT;
      idPrefix = "NICT";
      trnMutex = &m_NICTPoolMutex;
      trnPool = &m_NICTPool;
    }
  }

  if( !trnMutex->Wait( 100 ) )
  {
    LOG( LogError(), "!!! UNABLE TO ACQUIRE TRANSACTION LIST MUTEX - SIPTransactionManager::CreateTransaction!!!" );
    return FALSE;
  }
  PAutoSignal lock( *trnMutex );

  
  TransactionId id = event.GetTransactionId();

  if( id.AsString().IsEmpty() )
  {
    LOG_IF_DEBUG( LogInfo(), "CreateTransaction() - Unable to create transaction because transaction-id is empty" );
    return FALSE;
  }

  id.SetStateMachine( idPrefix );
  SIPTransaction * transaction = OnCreateTransaction( event, id, type );
  if( transaction != NULL )
  {
    if( sipSession != NULL )
      transaction->AttachSIPSession( sipSession );
    
    transaction->SetFailOverAttempts( failoverAttempt );
    transaction->SetNullServerTransaction( isNullTransaction );
    
    if( bypassHandler != NULL )
      transaction->SetBypassHandler( bypassHandler, bypassHandler->m_AutoDeleteBypass );

    trnPool->SetAt( id.AsString().c_str(), transaction );
    SIPMessage * msg = new SIPMessage( event );
    transaction->EnqueueEvent( new SIPEvent( msg ) );
  }

  return TRUE;
}

SIPTransaction * SIPTransactionManager::OnCreateTransaction(
  const SIPMessage & /*event*/,
  const TransactionId & transactionId,
  SIPTransaction::Type type,
  Logger * logger
)
{
  if( m_IsTerminating )
    return NULL;

  return new SIPTransaction( transactionId, type, *this );
}

class TransactionEventRetry_1 : public PThread
{
public:
    TransactionEventRetry_1(
      SIPTransactionManager * manager,
      const SIPMessage & event,
      SIPTransaction * trn,
      int rewindCounter
      ) : PThread( 1024 * 2 )
    {
      m_Manager = manager;
      m_Event = event;
      m_Trn = trn;
      m_RewindCounter = rewindCounter;
      Resume();
    }

    void Main()
    {
      m_Manager->FindTransactionAndAddEvent( m_Event, m_Trn, m_RewindCounter );
    }

    SIPMessage m_Event;
    SIPTransaction * m_Trn;
    SIPTransactionManager * m_Manager;
    int m_RewindCounter;
};

BOOL SIPTransactionManager::FindTransactionAndAddEvent(
  SIPMessage & event,
  SIPTransaction * trn,
  int rewindCounter
)
{
  if( trn == NULL )
    return FALSE;

  PTimedMutex * trnMutex = NULL;
  switch( trn->GetType() )
  {
    case SIPTransaction::IST:
      trnMutex = &m_ISTPoolMutex;
      break;
    case SIPTransaction::NIST:
      trnMutex = &m_NISTPoolMutex;
      break;
    case SIPTransaction::ICT:
      trnMutex = &m_ICTPoolMutex;
      break;
    case SIPTransaction::NICT:
      trnMutex = &m_NICTPoolMutex;
      break;
  }
  
  if( !trnMutex->Wait( 100 ) )
  {
    
    if( rewindCounter <= 5 )
      new TransactionEventRetry_1( this, event, trn, rewindCounter + 1 );
    else
    {
      LOG( LogError(), "!!! CRITICAL: UNABLE TO ACQUIRE TRANSACTION LIST MUTEX - SIPTransactionManager::FindTransactionAndAddEvent!!!" );
      _exit( -1 );
    }
    return TRUE;
  }

  PAutoSignal lock( *trnMutex );

  if( !event.IsValid() || m_IsTerminating )
    return FALSE;

  OString callId = event.GetCallId();
  LOG_CONTEXT_IF_DEBUG( LogDetail(), callId, "Found " << trn->GetIdentifier() << " for " << event.GetStartLine() );
  trn->EnqueueEvent( new SIPEvent( new SIPMessage( event ) ) );
  return TRUE;
}

class TransactionEventRetry_2 : public PThread
{
public:
    TransactionEventRetry_2(
      SIPTransactionManager * manager,
      SIPMessage event,
      BOOL fromTransport,
      int failOverAttempts,
      SIPTransactionBypass * bypassHandler,
      UACORE::SIPSession  * sipSession,
      int rewindCounter
      ) : PThread( 1024 * 2 )
    {
      m_Manager = manager;
      m_Event = event;
      m_FromTransport = fromTransport;
      m_FailOverAttempts = failOverAttempts;
      m_BypassHandler = bypassHandler;
      m_SipSession = sipSession;
      m_RewindCounter = rewindCounter;
      Resume();
    }

    void Main()
    {
      m_Manager->FindTransactionAndAddEvent( m_Event, m_FromTransport, m_FailOverAttempts, m_BypassHandler, m_SipSession, m_RewindCounter );
    }

    SIPTransactionManager * m_Manager;
    SIPMessage m_Event;
    BOOL m_FromTransport;
    int m_FailOverAttempts;
    SIPTransactionBypass * m_BypassHandler;
    UACORE::SIPSession  * m_SipSession;
    int m_RewindCounter;
};


BOOL SIPTransactionManager::FindTransactionAndAddEvent(
  SIPMessage & event,
  BOOL fromTransport,
  int failOverAttempts,
  SIPTransactionBypass * bypassHandler,
  UACORE::SIPSession * sipSession,
  int rewindCounter
)
{
  if( !event.IsValid() || m_IsTerminating )
    return FALSE;

  TransactionId transactionId;
  OString callId = event.GetCallId();
  LOG_CONTEXT_IF_DEBUG( LogDebugVeryHigh(), callId, "Finding transaction for " << event.GetStartLine() );


  //OString id = event.GetTransactionId();
  OString idPrefix;
  SIPTransaction::Type type;

  PTimedMutex * trnMutex = NULL;
  SIPTransaction::Dictionary * trnPool = NULL;

  if( fromTransport )
  {
    //LOG_IF_DEBUG( logger->LogDebugHigh(), "Detected event is from Transport" );
    if( event.IsRequest() )
    {
      //LOG_IF_DEBUG( logger->LogDebugHigh(), "Detected event is an incoming request" );
      if( event.IsInvite() )
      {
        //LOG_IF_DEBUG( logger->LogDebugHigh(), "Detected event is an INVITE.  Setting state machine to IST" );
        type = SIPTransaction::IST;
        idPrefix = "IST";
        trnMutex = &m_ISTPoolMutex;
        trnPool = &m_ISTPool;
      }else if( event.IsAck() )
      {
        //LOG_IF_DEBUG( logger->LogDebugHigh(), "Detected event is an ACK." );
        if( FindAckTransactionAndAddEvent( event, transactionId ) )
          return TRUE;
        trnMutex = &m_ISTPoolMutex;
        trnPool = &m_ISTPool;
      }else if( event.IsPrack() )
      {
        /// always hijack PRACK
        FindPrackTransactionAndAddEvent( event, transactionId );
        type = SIPTransaction::NIST;
        idPrefix = "NIST";
        trnMutex = &m_NISTPoolMutex;
        trnPool = &m_NISTPool;
      }else
      {
        //LOG_IF_DEBUG( logger->LogDebugHigh(), "Detected event is neither an ACK nor an INVITE. .  Setting state machine to IST" );
        type = SIPTransaction::NIST;
        idPrefix = "NIST";
        trnMutex = &m_NISTPoolMutex;
        trnPool = &m_NISTPool;
      }
    }else
    {
      //LOG_IF_DEBUG( logger->LogDebugHigh(), "Detected event is an incoming response" );
      ///check if this is a response to an INVITE
      CSeq cseq;

      if( !event.GetCSeq( cseq ) )
      {
        LOG_CONTEXT_IF_DEBUG( LogWarning(), callId, "Unable to match transaction because CSeq is empty or malformed" );
        return FALSE;
      }
      if( cseq.GetMethod() *= "INVITE" )
      {
        //LOG_IF_DEBUG( logger->LogDebugHigh(), "Detected event is a response to INVITE.  Setting state machine to ICT" );
        type = SIPTransaction::ICT;
        idPrefix = "ICT";
        trnMutex = &m_ICTPoolMutex;
        trnPool = &m_ICTPool;
      }else
      {
        //LOG_IF_DEBUG( logger->LogDebugHigh(), "Detected event is a response to none-INVITE.  Setting state machine to NICT" );
        type = SIPTransaction::NICT;
        idPrefix = "NICT";
        trnMutex = &m_NICTPoolMutex;
        trnPool = &m_NICTPool;
      }
    }
  }else
  {
    //LOG_IF_DEBUG( logger->LogDebugHigh(), "Detected none-transport event" );
    if( event.IsRequest() )
    {
      if( event.IsInvite() )
      {
        //LOG_IF_DEBUG( logger->LogDebugHigh(), "Detected event is an Invite Request.  Setting state machine to ICT" );
        type = SIPTransaction::ICT;
        idPrefix = "ICT";
        trnMutex = &m_ICTPoolMutex;
        trnPool = &m_ICTPool;
      }else
      {
        //LOG_IF_DEBUG( logger->LogDebugHigh(), "Detected event is a none-INVITE Request.  Setting state machine to NICT" );
        type = SIPTransaction::NICT;
        idPrefix = "NICT";
        trnMutex = &m_NICTPoolMutex;
        trnPool = &m_NICTPool;
      }
    }else
    {
      ///check if this is a response to an INVITE
      CSeq cseq;
      if( !event.GetCSeq( cseq ) )
      {
        LOG_CONTEXT_IF_DEBUG( LogWarning(), callId, "Unable to match transaction because CSeq is empty or malformed" );
        return FALSE;
      }
      if( cseq.GetMethod() *= "INVITE" )
      {
        //LOG_IF_DEBUG( logger->LogDebugHigh(), "Detected event is a response to INVITE.  Setting state machine to IST" );
        type = SIPTransaction::IST;
        idPrefix = "IST";
        trnMutex = &m_ISTPoolMutex;
        trnPool = &m_ISTPool;
      }else
      {
        //LOG_IF_DEBUG( logger->LogDebugHigh(), "Detected event is a response to none-INVITE.  Setting state machine to NIST" );
        type = SIPTransaction::NIST;
        idPrefix = "NIST";
        trnMutex = &m_NISTPoolMutex;
        trnPool = &m_NISTPool;
      }
    }
  }

  if( !trnMutex->Wait( 100 ) )
  {
    
    if( rewindCounter <= 5 )
    {
      new TransactionEventRetry_2( 
        this,
        event,
        fromTransport,
        failOverAttempts,
        bypassHandler,
        sipSession,
        rewindCounter + 1);
    }else
    {
      LOG( LogError(), "!!! UNABLE TO ACQUIRE TRANSACTION LIST MUTEX - SIPTransactionManager::FindTransactionAndAddEvent!!!" );
      _exit( -1 );
    }
    return TRUE;
  }
  PAutoSignal lock( *trnMutex );

  OString id = event.GetTransactionId().AsString();

  LOG_CONTEXT_IF_DEBUG( LogDebugVeryHigh(), callId, "Setting Transaction ID to " << id );

  if( id.IsEmpty() )
  {
    LOG_CONTEXT_IF_DEBUG( LogWarning(), callId, "CreateTransaction() - Unable to create transaction because transaction-id is empty" );
    return FALSE;
  }

  id = idPrefix + "|" + id;


  transactionId = id;

  SIPTransaction * transaction = trnPool->GetAt( id.c_str() );

  //LOG_IF_DEBUG( logger->LogDebugHigh(), "Transaction Pool Critical Section Acquired" );

  if( transaction == NULL )
  {
    
    if( event.IsRequest() && !event.IsAck() )
    {
      /// lets make sure that if this is a send status message
      /// that it does not create a new transaction
      if( event.GetInternalHeader( "SEND-EVENT" ).IsEmpty() )
      {
        //LOG_CONTEXT_IF_DEBUG( LogDebug(), callId,"*** CREATING TRANSACTION (" << idPrefix << ") ***" <<
        //  endl << "Message: " << event.GetStartLine() << 
        //  endl << "Call-Id: " << transactionId.GetCallId() 
        //);
        return CreateTransaction( event, fromTransport, failOverAttempts, FALSE, bypassHandler, sipSession );
      }else if( event.GetInternalHeader( "SEND-EVENT" ) *= "FALSE" )
      {
        //LOG_CONTEXT_IF_DEBUG( LogDebug(), callId, "*** CREATING TRANSACTION (" << idPrefix << ") ***" <<
        //  endl << "Message: " << event.GetStartLine() << 
        //  endl << "Call-Id: " << transactionId.GetCallId() 
        //);
        return CreateTransaction( event, fromTransport, failOverAttempts, FALSE, bypassHandler, sipSession  );
      }
    }else
    {
      //LOG_CONTEXT_IF_DEBUG( LogDebug(), callId, "*** TRANSACTION DOES NOT EXIST ***" <<
      //  endl << "Message: " << event.GetStartLine() << 
      //  endl << "Call-Id: " << transactionId.GetCallId() 
      //);

      OnUnknownTransaction( event, fromTransport );
      return FALSE;
    }
  }else
  {
    LOG_CONTEXT_IF_DEBUG( LogDetail(), callId, "Found " << id << " for " << event.GetStartLine() );
   
    SIPMessage * msg = new SIPMessage( event );
    transaction->EnqueueEvent( new SIPEvent( msg ) );
  }

  return TRUE;
}

class TransactionEventRetry_3 : public PThread
{
public:
  SIPTransactionManager * m_Manager;
  TransactionId m_Id;
  SIPEvent * m_Event;
  int m_RewindCounter;
  TransactionEventRetry_3(
    SIPTransactionManager * manager,
    const TransactionId & id,
    SIPEvent * event,
    int rewindCounter
    ) : PThread( 1024 * 2 )
  {
    m_Manager = manager;
    m_Id = id;
    m_Event = event;
    m_RewindCounter = rewindCounter;
    Resume();
  }

  void Main()
  {
    m_Manager->FindTransactionAndAddEvent( m_Id, m_Event, m_RewindCounter );
  }
};

BOOL SIPTransactionManager::FindTransactionAndAddEvent(
  const TransactionId & id,
  SIPEvent * event,
  int rewindCounter
)
{
  OString fsm = id.GetStateMachine();
  PTimedMutex * trnMutex = NULL;
  SIPTransaction::Dictionary * trnPool = NULL;

  if( fsm == "IST" )
  {
    trnMutex = &m_ISTPoolMutex;
    trnPool = &m_ISTPool;
  }else if( fsm == "NIST" )
  {
    trnMutex = &m_NISTPoolMutex;
    trnPool = &m_NISTPool;
  }else if( fsm == "ICT" )
  {
    trnMutex = &m_ICTPoolMutex;
    trnPool = &m_ICTPool;
  }else if( fsm == "NICT" )
  {
    trnMutex = &m_NICTPoolMutex;
    trnPool = &m_NICTPool;
  }else
  {
    PAssert( FALSE, "Unable to identify transaction FSM type" );
  }

  if( !trnMutex->Wait( 100 ) )
  {
    
    if( rewindCounter <= 5 )
      new TransactionEventRetry_3( this, id, event, rewindCounter + 1 );
    else
    {
      LOG( LogError(), "!!! UNABLE TO ACQUIRE TRANSACTION LIST MUTEX - SIPTransactionManager::FindTransactionAndAddEvent!!!" );
      _exit( -1 );
    }
    return TRUE;
  }
  PAutoSignal lock( *trnMutex );


  if( m_IsTerminating )
    return FALSE;

  SIPTransaction * transaction = trnPool->GetAt( id.AsString().c_str() );
  if( transaction == NULL )
  {
    delete event;
    return FALSE;
  }

  LOG_IF_DEBUG( LogDetail(), "Found " << id.AsString() << " for " << *event->GetEvent() );
  transaction->EnqueueEvent( event );

  return TRUE;
}

class TransactionRemoveRetry : public PThread
{
public:
  SIPTransactionManager * m_Manager;
  TransactionId m_Id;

  TransactionRemoveRetry(
    SIPTransactionManager * manager,
    const TransactionId & id
    ) : PThread( 1024 * 2 )
  {
    m_Manager = manager;
    m_Id = id;
    Resume();
  }

  void Main()
  {
    PThread::Sleep( 100 );
    m_Manager->RemoveTransaction( m_Id );
  }
};


BOOL SIPTransactionManager::RemoveTransaction(
  const TransactionId & transactionId
)
{
  OString fsm = transactionId.GetStateMachine();
  PTimedMutex * trnMutex = NULL;
  SIPTransaction::Dictionary * trnPool = NULL;

  if( fsm == "IST" )
  {
    trnMutex = &m_ISTPoolMutex;
    trnPool = &m_ISTPool;
  }else if( fsm == "NIST" )
  {
    trnMutex = &m_NISTPoolMutex;
    trnPool = &m_NISTPool;
  }else if( fsm == "ICT" )
  {
    trnMutex = &m_ICTPoolMutex;
    trnPool = &m_ICTPool;
  }else if( fsm == "NICT" )
  {
    trnMutex = &m_NICTPoolMutex;
    trnPool = &m_NICTPool;
  }else
  {
    PAssert( FALSE, "Unable to identify transaction FSM type" );
  }

  if( !trnMutex->Wait( 100 ) )
  {
    LOG( LogError(), "!!! UNABLE TO ACQUIRE TRANSACTION LIST MUTEX - SIPTransactionManager::RemoveTransaction!!!" );
    new TransactionRemoveRetry( this, transactionId );
    return TRUE;
  }
  PAutoSignal lock( *trnMutex );

  LOG_IF_DEBUG( LogDetail(), "*** REMOVED TRANSACTION *** " << transactionId.AsString() );
  return trnPool->RemoveAt( transactionId.AsString().c_str() ) != NULL;
}

BOOL SIPTransactionManager::FindAckTransactionAndAddEvent(
  const SIPMessage & ack,
  TransactionId & transactionId,
  Logger * logger
)
{
  if( m_IsTerminating )
    return FALSE;

  if( !ack.IsAck() )
    return FALSE;

  OString ackId;
  OString cid;

  OString toTag;
  OString viaBranch;

  toTag = ack.GetToTag();

  viaBranch = ack.GetTopVia().GetBranch();

  cid = ack.GetCallId();

  if( cid.IsEmpty() )
    return FALSE;

  ackId = cid + toTag + "|" + viaBranch + "|ACK";

  transactionId = ackId;

  PWaitAndSignal lock( m_AckTransactionPoolMutex );

  SIPTransaction * transaction = m_AckTransactionPool.RemoveAt( ackId.c_str() );
  if( transaction == NULL )
  {
    LOG_CONTEXT( LogDebug(), cid, "Unable to find ACK Transaction " << ackId );
    return FALSE;
  }

  LOG_CONTEXT( LogDebug(), cid, "Found ACK Transaction " << ackId );

  SIPMessage * msg = new SIPMessage( ack );
  transaction->EnqueueEvent( new SIPEvent( msg ) );

  return TRUE;
}

BOOL SIPTransactionManager::AddAckTransaction(
  const SIPMessage & response,
  SIPTransaction * _transaction
)
{
  if( m_IsTerminating )
    return FALSE;

  SIPFSM::InviteServerTransaction * transaction = dynamic_cast<SIPFSM::InviteServerTransaction*>(_transaction);
  if( transaction == NULL )
    return FALSE;

  OString ackId;
  OString cid;

  OString toTag;
  OString viaBranch;

  toTag = response.GetToTag();

  viaBranch = response.GetTopVia().GetBranch();
  //if( viaBranch.IsEmpty() )
  //  return FALSE;

  cid = response.GetCallId();

  if( cid.IsEmpty() )
    return FALSE;

  ackId = cid + toTag + "|" + viaBranch + "|ACK";

  PWaitAndSignal lock( m_AckTransactionPoolMutex );

  m_AckTransactionPool.SetAt( ackId.c_str(), transaction );

  LOG_CONTEXT( LogDebug(), cid, "Added ACK Transaction " << ackId );

  transaction->SetAckTransactionId( ackId );

  return TRUE;
}

#if 0
BOOL SIPTransactionManager::RemoveAckTransaction(
  const SIPMessage & response,
  SIPTransaction * transaction
)
{
  const SIPMessage & request = transaction->GetOpeningRequest();

  OString ackId;
  CallId callId;
  OString cid;
  OString toTag;

  OString viaBranch;

  if( !request.GetCallId( callId ) )
    return FALSE;

  toTag = request.GetToTag();

  viaBranch = request.GetTopVia().GetBranch();

  cid = callId.AsString();
  if( cid.IsEmpty() )
    return FALSE;

  ackId = cid + toTag + "|" + viaBranch + "|ACK";

  return RemoveAckTransaction( ackId );
}
#endif

BOOL SIPTransactionManager::RemoveAckTransaction(
  const OString & id
)
{
  PWaitAndSignal lock( m_AckTransactionPoolMutex );

  m_AckTransactionPool.RemoveAt( id.c_str() );

  return TRUE;
}

BOOL SIPTransactionManager::FindPrackTransactionAndAddEvent(
  const SIPMessage & ack,
  TransactionId & transactionId,
  Logger * logger
)
{
  if( m_IsTerminating )
    return FALSE;

  if( !ack.IsPrack() )
    return FALSE;

 
  OStringStream ackId;
  ackId << ack.GetCallId() << "-" << ack.GetRAckRSeqNumber();
  OString cid = ack.GetCallId();

  PWaitAndSignal lock( m_PrackTransactionPoolMutex );

  SIPTransaction * transaction = m_PrackTransactionPool.GetAt( ackId.str().c_str() );
  if( transaction == NULL )
  {
    LOG_CONTEXT( LogDebug(), cid, "Unable to find PRACK Transaction " << ackId );
    return FALSE;
  }

  LOG_CONTEXT( LogDebug(), cid, "Found PRACK Transaction " << ackId.str() );

  SIPMessage * msg = new SIPMessage( ack );
  transaction->EnqueueEvent( new SIPEvent( msg ) );
  transactionId = transaction->GetIdentifier();
  return TRUE;
}

BOOL SIPTransactionManager::AddPrackTransaction(
  const SIPMessage & response,
  SIPTransaction * _transaction
)
{
  if( m_IsTerminating )
    return FALSE;

  SIPFSM::InviteServerTransaction * transaction = dynamic_cast<SIPFSM::InviteServerTransaction*>(_transaction);
  if( transaction == NULL )
    return FALSE;

  OStringStream ackId;
  RSeq rseq;
  if( !response.GetRSeq( rseq ) )
    return FALSE;

  ackId <<  response.GetCallId() << "-" << rseq.AsInteger();

  OString cid = response.GetCallId();

  PWaitAndSignal lock( m_PrackTransactionPoolMutex );

  m_PrackTransactionPool.SetAt( ackId.str().c_str(), transaction );

  LOG_CONTEXT( LogDebug(), cid, "Added PRACK Transaction " << ackId.str() );

  transaction->SetPrackTransactionId( ackId.str() );

  return TRUE;
}

BOOL SIPTransactionManager::RemovePrackTransaction(
  const OString & id
)
{
  PWaitAndSignal lock( m_PrackTransactionPoolMutex );
  m_PrackTransactionPool.RemoveAt( id.c_str() );
  return TRUE;
}

void SIPTransactionManager::OnUnknownTransaction(
  const SIPMessage &,
  BOOL
)
{
}

void SIPTransactionManager::EnqueueTransactionManagerEvent(
  PObject * eventObject
)
{
  if( !m_ManagerEventQueue->EnqueueEvent( eventObject ) )
    delete eventObject;
}

void SIPTransactionManager::OnTransactionManagerEvent(
  EventQueue &,
  INT _event
)
{

  PObject * eventObj = (PObject*)_event;

  if( eventObj == NULL )
    return;

  if( PIsDescendant( eventObj, SIPTransactionManager::EventRemoveTransaction ) )
  {
    SIPTransactionManager::EventRemoveTransaction * eventData = dynamic_cast<SIPTransactionManager::EventRemoveTransaction*>(eventObj);
    if( eventData == NULL )
    {
      delete eventObj;
      return;
    }

    RemoveTransaction( eventData->m_TID );
    delete eventData;
    return;
  }
}







