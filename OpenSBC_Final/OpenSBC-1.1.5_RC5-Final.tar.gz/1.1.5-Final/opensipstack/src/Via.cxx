/*
 *
 * Via.cxx
 * 
 * Open SIP Stack ( OSS )
 *
 * Copyright (C) 2006 Joegen E. Baclor. All Rights Reserved.
 *
 * Version: MPL 1.1/GPL 2.0/LGPL 2.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is OpenSIPStack Library.
 *
 * The Initial Developer of the Original Code is Joegen E. Baclor.
 *
 * Contributor(s):
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * $Log: Via.cxx,v $
 * Revision 1.19  2009/03/26 06:29:15  joegenbaclor
 * Added NAT port forwarding support
 *
 * Revision 1.18  2009/03/06 03:10:27  joegenbaclor
 * Move Contruct Via function from the session manager to the user agent
 *
 * Revision 1.17  2009/01/21 09:52:35  joegenbaclor
 * Minor code tweaks
 *
 * Revision 1.16  2009/01/13 14:34:46  joegenbaclor
 * added destructor to sip header and sipheaderb.  fixed rtp bug where an invalid sdes item maybe saved into a pstring
 *
 * Revision 1.15  2009/01/09 12:31:38  joegenbaclor
 *  -We have eliminated ALL calls to MakeUnique for lists and dictionary members in SIP Parser since it is very unreliable specially across multiple threads.
 * -Minor bug fix where m_HasLocalAuthorization is not initialized in two of the constructor overrides of SIPSession resulting to blank Authorization headers being sent in mid-dialog requests.
 * -Fixed DNS SRV lookup.  We only lookup DNS SRV records if a Host Record is not in cache.
 *
 * Revision 1.14  2008/06/23 18:35:18  joegenbaclor
 * Corrections on last commit
 *
 * Revision 1.13  2008/06/23 18:15:52  joegenbaclor
 * Made sure we trim leading spaces when parsing via host address
 *
 * Revision 1.12  2008/06/07 23:58:13  joegenbaclor
 * For some still unknown reason, calling MakeUnique() on params
 *  in Via::GetURI() leaks memory.  This is specially true in Windows but it is
 *  assumed that unix builds are affected by this bug as well.   It is worth noting, though, that it seems that only the release
 *  build is leaking memory and debug does not.   We need to look further
 *  into this because MakeUnique is called allover OpenSIPStack.  For now,
 *  the temporary solution is to call MakeUnique() inside uri.SetParameters()
 *  function after the params have been copied. - Thanks Gustavo Curetti for initially
 *  opening up the topic on leaking parser
 *
 * Revision 1.11  2007/07/14 07:50:34  joegenbaclor
 * Migrated code to use new STL based string class
 *
 * Revision 1.10  2007/07/10 10:12:36  joegenbaclor
 * Added experimental code to use STL tokenizer instead of internal string tokenizer
 *
 * Revision 1.9  2006/11/30 08:19:38  joegenbaclor
 * Relicensed opensipstack to MPL/GPL/LGPL triple license scheme
 *
 * Revision 1.8  2006/06/28 14:15:01  joegenbaclor
 * Bulk commit for Media Proxy functionalities for OpenB2BUA
 * Marks a minor version upgrade from 1.0.2 to 1.0.3
 *
 * Revision 1.7  2006/04/05 00:26:04  joegenbaclor
 * 1.  Completed support for STUN NAT traversal method and OPAL style address translation
 * 2.  More bug fixes to ProxySession
 * 3.  Fixed bug in messages where zero size list headers may be interpreted by the parser as a valid header
 * 4.  Started work on OPAL outbound
 *
 * Revision 1.6  2006/03/30 05:34:16  joegenbaclor
 * 1.  Added configure support for windows build.  Note: Unix configure might be broken at this point.
 * 2.  Changed SIPSessionEvent to include the actual SIPMessage in the event.
 * 3.  Changed SDP to include a blank session name if it is not present.
 * 4.  Worked on OPAL classes in preparation for openphone use
 *
 * Revision 1.5  2006/03/24 15:42:18  joegenbaclor
 * Some bug fixes including possible deadlocks between Session Destruction and ProcessStackEvent
 *
 * Revision 1.4  2006/03/21 14:11:51  joegenbaclor
 * 1.  Added rport support for NAT Traversal
 * 2.  Added NAT Keep alive mechanism in SIPSession
 * 3.  Some Improvements in various classes affecting NAT like Via, SIPTransport etc.
 *
 * Revision 1.3  2006/03/14 03:53:54  joegenbaclor
 * Initial source upload for BETA Release Candidate
 *
 *
 *
 */

#include "Via.h"
#include "SIPTransport.h"

#define new PNEW

using namespace SIPParser;
using namespace SIPTransports;

Via::Via() 
  : SIPHeaderB( "Via" )
{
  m_Port = 0;
  m_Protocol = "UDP";
}

Via::Via( 
  const Via & via 
) : SIPHeaderB( "Via" )
{
  m_Port = 0;
  m_Protocol = "UDP";
  operator=(via);
}

Via::Via(
  const OString & mime
) : SIPHeaderB( "Via" )
{
  m_Port = 0;
  m_Protocol = "UDP";
  operator=( mime );
}

Via::Via(
  const MimeHeader & mime
) : SIPHeaderB( "Via" )
{
  m_Port = 0;
  m_Protocol = "UDP";
  operator=( mime );
}

Via::Via(
  const OString & protocol,
  const OString & address,
  const MimeParam::SortedCollection & params
) : SIPHeaderB( "Via" )
{
  SetAddress( address );
  m_Protocol = protocol;

  for( int i = 0; i < params.GetSize(); i++ )
    m_Parameters.SetAt( params.GetKeyAt(i), new MimeParam( params.GetDataAt(i) ) );
}

Via & Via::operator=( 
  const Via & via
)
{
  m_Protocol = via.m_Protocol;
  m_Address = via.m_Address;
  m_ExternalAddress = via.m_ExternalAddress;
  m_Port = via.m_Port;
  m_Parameters.RemoveAll();
  for( int i = 0; i < via.m_Parameters.GetSize(); i++ )
    m_Parameters.SetAt( via.m_Parameters.GetKeyAt(i), new MimeParam( via.m_Parameters.GetDataAt(i) ) );

  return *this;
}

Via::~Via()
{
}

Via & Via::operator=( 
  const OString & via
)
{
  ///Via: SIP/2.0/UDP pc33.atlanta.com;branch=z9hG4bK776asdhds
  MimeHeader h( via );
  return operator=( h );
}

Via & Via::operator=(
  const MimeHeader & mime
)
{
  /// SIP/2.0/UDP pc33.atlanta.com;branch=z9hG4bK776asdhds

  OString mimeValue = mime.GetMimeValue();

  PINDEX nextSpace = mimeValue.Find( " " );

  if( nextSpace == P_MAX_INDEX )
    return *this;

  /// get the protocol
  OString protoVersion = mimeValue.Left( nextSpace );
  if( protoVersion.IsEmpty() )
    return *this;

  //OStringArray protoVersionTokens = protoVersion.Tokenise( '/' );

  vector<string> protoVersionTokens;
  int size = ParserTools::STLTokenize( protoVersion, protoVersionTokens, "/" );
  if( size != 3 )
    return *this;

  OString v = mimeValue.Mid( nextSpace + 1 );

  PINDEX nextSemiColon = v.Find( ";" );

  OString address = v;
  if( nextSemiColon != P_MAX_INDEX )
  {
    address = v.Left( nextSemiColon );
  }else
  {
    /// via without a branch parameter????
    /// should we return FALSE????
  }

  m_Protocol = protoVersionTokens[2];
  SetAddress( address );
 
  m_Parameters.RemoveAll();
  MimeParam::CreateCollection( mime, m_Parameters );

  return *this;
}

void Via::SetProtocol(
  const OString & transport
)
{
  m_Protocol = transport;
}

void Via::SetAddress(
  const OString & address
)
{
  m_Address = address;
  
  PINDEX hasPort = address.Find( ":" );
  if( hasPort != P_MAX_INDEX )
  {
    OString port = address.Mid( hasPort + 1);
    OString addr = address.Left( hasPort  );
    m_Port = (WORD)port.AsUnsigned();
    m_Address = addr;
  }
  
  m_Address = m_Address.Trim();
}

void Via::SetPort(
  WORD port
)
{
  m_Port = port;
}


const OString & Via::GetProtocol()const
{
  return m_Protocol;
}

const OString & Via::GetAddress()const
{
  return m_Address;
}

const OString & Via::GetTranslatedAddress()const
{
  return m_ExternalAddress.IsEmpty() ? m_Address : m_ExternalAddress;
}

WORD Via::GetPort()const
{
  return m_Port;
}

OString Via::GetBranch()const
{
  OString value;
  GetParameter( "branch", value );
  return value;
}

void Via::SetBranch(
  const OString & _branch 
)
{
  OString branch( _branch );
  if( branch.IsEmpty() )
    branch = ParserTools::GenBranchParameter();

  BOOL replace = TRUE;
  AddParameter( "branch", branch, replace );
}


void Via::PrintOn(
  ostream & strm 
) const
{
  if( m_ExternalAddress.IsEmpty() )
    strm << "Via: SIP/2.0/" <<  m_Protocol.ToUpper() << " " << m_Address;
  else
    strm << "Via: SIP/2.0/" <<  m_Protocol.ToUpper() << " " << m_ExternalAddress;

  if( m_Port != 0 )
    strm << ":" << m_Port;

  for( PINDEX i = 0; i < m_Parameters.GetSize(); i++ )
  {
    strm << ";";
    strm << m_Parameters.GetDataAt( i );
  }
}

void Via::PrepareBody()
{
  OStringStream strm;

  strm << "SIP/2.0/" <<  m_Protocol.ToUpper() << " " << m_Address;

  for( PINDEX i = 0; i < m_Parameters.GetSize(); i++ )
  {
    strm << ";";
    strm << m_Parameters.GetDataAt( i );
  }

  m_HeaderBody = strm.str();
}


PObject * Via::Clone()const
{
  return new Via( *this );
}


SIPURI Via::GetURI()const
{
  SIPURI uri;
  uri.SetHost( GetAddress() );

  if( GetPort() != 0 )
    uri.SetPort( OString( GetPort() ) );

  /// For some still unknown reason, calling MakeUnique() on params
  /// here leaks memory.  This is specially true in Windows but it is
  /// assumed that unix builds are affected by this bug as well.   
  /// It is worth noting, though, that it seems that only the release
  /// build is leaking memory and debug does not.   We need to look further
  /// into this because MakeUnique is called allover OpenSIPStack.  For now,
  /// the temporary solution is to call MakeUnique() inside uri.SetParameters()
  /// function after the params have been copied.

  uri.SetParameters( GetParameters() );

  return uri;
}

WORD Via::GetRPort()const
{
  OString rport;
  if( GetParameter( "rport", rport ) )
    return (WORD)rport.AsUnsigned();;
  return GetPort(); 
}

PIPSocket::Address Via::GetReceiveAddress()const
{
  PIPSocket::Address received;
  OString val;
  if( GetParameter( "received", val ) )
    received = PIPSocket::Address( val );
  
  if( val.IsEmpty() )
    received = PIPSocket::Address( GetAddress() );

  return received;
}

void Via::SetRPort(
  WORD rport
)
{
  AddParameter( "rport", OString( rport ), TRUE );
}

void Via::SetReceiveAddress(
  const PIPSocket::Address & raddr 
)
{
  AddParameter( "received", (const char *)raddr.AsString(), TRUE );
}

BOOL Via::IsBehindNAT()const
{
  SIPURI uri = GetURI();
  
  PIPSocket::Address addr;
  WORD port;

  SIPTransport::Resolve( uri, addr, port );

  BOOL isPrivate = SIPTransport::IsPrivateNetwork( addr );

  if( isPrivate )
  {
    PIPSocket::Address raddr = GetReceiveAddress();
    if( raddr.IsValid() )
      return raddr != addr;
  }

  return FALSE;
}

BOOL Via::IsLoopback()const
{
  SIPURI uri = GetURI();
  
  PIPSocket::Address addr;
  WORD port;

  SIPTransport::Resolve( uri, addr, port );

  return addr.IsLoopback();
}


