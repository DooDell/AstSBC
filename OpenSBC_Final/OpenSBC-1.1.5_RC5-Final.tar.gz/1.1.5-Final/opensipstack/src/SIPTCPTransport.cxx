/*
 *
 * SIPTCPTransport.cxx
 * 
 * Open SIP Stack ( OSS )
 *
 * Copyright (C) 2006 Joegen E. Baclor. All Rights Reserved.
 *
 * Version: MPL 1.1/GPL 2.0/LGPL 2.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is OpenSIPStack Library.
 *
 * The Initial Developer of the Original Code is Joegen E. Baclor.
 *
 * Contributor(s):
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * $Log: SIPTCPTransport.cxx,v $
 * Revision 1.11  2007/10/01 16:17:21  joegenbaclor
 * Added ability to retrieve transport status
 *
 * Revision 1.10  2007/07/15 12:33:21  joegenbaclor
 * Corrected bug in calling OnIncomingSDPOffer where it is called for the second leg instead of the first leg call session.  This is due to the change in placement of the method form receipt of the invite to SetupOutbound
 *
 * Revision 1.9  2007/07/14 09:49:48  joegenbaclor
 * Corrected compile errors in linux
 *
 * Revision 1.8  2007/07/14 07:50:33  joegenbaclor
 * Migrated code to use new STL based string class
 *
 * Revision 1.7  2007/03/04 03:00:34  joegenbaclor
 * Removed Linux compile warnings
 *
 * Revision 1.6  2007/02/27 08:18:33  joegenbaclor
 * Introduces new stages for inbound and outbound processing
 *
 * Revision 1.5  2007/02/27 02:11:30  joegenbaclor
 * *** empty log message ***
 *
 * Revision 1.4  2007/02/22 14:40:38  joegenbaclor
 * Completed multi listener support
 *
 * Revision 1.3  2007/02/04 15:04:10  joegenbaclor
 * Completed transaction layer TCP support
 *
 * Revision 1.2  2007/01/29 08:35:58  joegenbaclor
 * More work on TCP Transport
 *
 * Revision 1.1  2007/01/24 10:19:55  joegenbaclor
 * Work on TCP support has commenced.
 *
 *
 */

#include "SIPTCPTransport.h"

using namespace SIPTransports;

#define new PNEW

SIPTCPTransport::SIPTCPTransport(
  const char * userAgentName,
  SIPTransportManager * manager
) : SIPTransport( userAgentName, manager, SIPTransport::TCP )
{
  m_ListenerSocket = NULL;
}

SIPTCPTransport::~SIPTCPTransport()
{
}

BOOL SIPTCPTransport::ReadPacket(
  SIPPacket & packet
)
{
  return FALSE;
}

BOOL SIPTCPTransport::ReadPacket( 
  SIPMessage *& packet,
  PIPSocket::Address & addr,
  WORD & port,
  PIPSocket::Address & ifaceAddress,
  WORD & ifacePort,
  int & length
)
{
  return ReadPacket( packet, addr, port, length );
}

BOOL SIPTCPTransport::ReadPacket( 
  SIPMessage *& packet,
  PIPSocket::Address & addr,
  WORD & port,
  int & length
)
{
  PTCPSocket * socket = new PTCPSocket;
  if(!socket->Accept(*m_ListenerSocket))
  {
    delete socket;
    return FALSE;
  }

  if( packet->Read( *socket ) )
  {
     packet->SetSocket( socket );
     length = socket->GetLastReadCount();
     return TRUE;
  }

  delete socket;

  return FALSE;

}

BOOL SIPTCPTransport::WritePacket( 
  SIPMessage & packet,
  const PIPSocket::Address & address,
  WORD port,
  const OString & iface
)
{
  return WritePacket( packet, address, port );
}

BOOL SIPTCPTransport::WritePacket( 
  SIPMessage & packet,
  const PIPSocket::Address & address,
  WORD port
)
{
  return FALSE;
}

BOOL SIPTCPTransport::WriteString(
  const OString & packet,
  const PIPSocket::Address & sendAddress,
  WORD sendPort,
  const OString & iface,
  WORD localPort
)
{
  return FALSE;
}

BOOL SIPTCPTransport::WriteBytes(
  PBYTEArray & packet,
  const PIPSocket::Address & sendAddress,
  WORD sendPort,
  const OString & iface,
  WORD localPort
)
{
  return FALSE;
}

BOOL SIPTCPTransport::Listen(
  const OString & iface,
  WORD port
)
{
  PIPSocket::Address addr( iface.c_str() );

  if( addr.IsValid() )
    m_ListenerSocket = new PTCPSocket( addr, port );
  else
    m_ListenerSocket = new PTCPSocket(  port );

  if (!m_ListenerSocket->Listen(5, 0, PSocket::CanReuseAddress )) 
    return FALSE;


  PIPSocket::Address localAddress;
  m_ListenerSocket->GetHostAddress( localAddress );

  OStringStream strm;
  strm << "*** LISTENER STARTED *** " <<  localAddress.AsString() << ":" << port << " [*** TCP ***]";

  PTRACE( 1, strm.str() );

  if( SIPTransport::m_HasReadNotifier )
  {
    strm << "\r\n";
    OString log( strm );
    SIPTransport::m_ReadNotifier( localAddress, reinterpret_cast<INT>(&log) );
  }

  return m_IsListening = TRUE;
}

BOOL SIPTCPTransport::Listen(
  const OString & iface,
  WORD port,
  BOOL append
)
{
  return Listen( iface, port );
}


BOOL SIPTCPTransport::GetListenerAddress(
  const PIPSocket::Address & target,
  PIPSocket::Address & listenerAddress,
  WORD & listenerPort
)
{
  return FALSE;
}

void SIPTCPTransport::CleanUp()
{
  if ( m_ListenerSocket != NULL )
  {
    m_ListenerSocket->Close();
    delete m_ListenerSocket;
    m_ListenerSocket = NULL;
  }
}

BOOL SIPTCPTransport::IsLocalAddressAndPort(
  const PIPSocket::Address & addr,
  WORD port
)const
{
  PAssertAlways( PUnimplementedFunction );
  return FALSE;
}

