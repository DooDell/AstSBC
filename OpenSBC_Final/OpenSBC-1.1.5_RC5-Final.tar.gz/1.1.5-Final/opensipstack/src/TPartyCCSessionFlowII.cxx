/*
 *
 * TPartyCCSessionFlowII.cxx
 *
 * Open SIP Stack ( OSS )
 *
 * Copyright (C) 2006 Joegen E. Baclor. All Rights Reserved.
 *
 * Version: MPL 1.1/GPL 2.0/LGPL 2.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is OpenSIPStack Library.
 *
 * The Initial Developer of the Original Code is Joegen E. Baclor.
 *
 * Contributor(s):
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * $Log: TPartyCCSessionFlowII.cxx,v $
 * Revision 1.4  2009/01/03 12:12:29  joegenbaclor
 * Reimplemented DestroyConenction to enqueue a session event instead to avoid further race conditons and dead locks.
 * We also implemented B2BUAConnection::IsSafeReference() to further guaranty the integrity of connection pointers.
 *
 * Revision 1.3  2007/11/03 08:01:07  joegenbaclor
 * Added domain alias support for upper reg
 *
 * Revision 1.2  2007/10/28 05:59:14  joegenbaclor
 * 1.   We now disconnect b2bua calls on ACK timeout
 *
 * Revision 1.1  2007/10/23 14:12:38  joegenbaclor
 * Initial upload of Flow II 3PCC Session classes
 *
 *
 */


#include "TPartyCCSessionFlowII.h"

using namespace UACORE;

TPartyCCSessionFlowII::TPartyCCSessionFlowII(
  TPartyCCSessionManager & sessionManager,
  const OString & sessionId,
  const From & from_1,
  const From & from_2,
  const To & to_1,
  const To & to_2,
  RouteList * leg1Route,
  RouteList * leg2Route,
  const SDP::SDPMediaFmt & codec
  ) : TPartyCCSession( sessionManager, sessionId, from_1, from_2, to_1, to_2, TPartyCCSession::Flow_II, leg1Route, leg2Route )
{
  m_3PCCAudioCodec = codec;
}

TPartyCCSessionFlowII::~TPartyCCSessionFlowII()
{
}

void TPartyCCSessionFlowII::OnIncomingSIPMessage(
  SIPMessageArrival & messageEvent
)
{
}

void TPartyCCSessionFlowII::OnSessionEvent(
  SIPSessionEvent & sessionEvent
)
{
}

void TPartyCCSessionFlowII::OnTimerExpire(
  SIPTimerExpire & timerEvent
)
{
}


void TPartyCCSessionFlowII::OnHandleStateTrying_1(
  const SIPMessage & eventMsg
)
{
}

void TPartyCCSessionFlowII::OnHandleStateProceeding_1(
  const SIPMessage & eventMsg
)
{
}

void TPartyCCSessionFlowII::OnHandleStateAuth_1(
  const SIPMessage & eventMsg
)
{
}

void TPartyCCSessionFlowII::OnHandleStateConnect_1(
  const SIPMessage & eventMsg
)
{
}

void TPartyCCSessionFlowII::OnHandleStateTrying_2(
  const SIPMessage & eventMsg
)
{
}

void TPartyCCSessionFlowII::OnHandleStateProceeding_2(
  const SIPMessage & eventMsg
)
{
}

void TPartyCCSessionFlowII::OnHandleStateAuth_2(
  const SIPMessage & eventMsg
)
{
}

void TPartyCCSessionFlowII::OnHandleStateConnect_2(
  const SIPMessage & eventMsg
)
{
}

void TPartyCCSessionFlowII::OnHandleStateConfirmed(
  const SIPMessage & eventMsg
)
{
}

void TPartyCCSessionFlowII::OnHandleStateDisconnecting(
  const SIPMessage & eventMsg
)
{
}

void TPartyCCSessionFlowII::OnHandleStateDisconnected(
  const SIPMessage & eventMsg
)
{
}

BOOL TPartyCCSessionFlowII::Send3PCCFlowII_Invite_1()
{
  SIPURI uri = m_3PCCTo_1.GetURI();
  PIPSocket::Address targetAddress = uri.GetAddress();
  SIPMessage invite;

  BOOL willUseProxy = FALSE;

  /// create the request line
  RequestLine requestLine;
  requestLine.SetMethod( "INVITE" );

  OString requestURI = uri.AsString();
  
  requestLine.SetRequestURI( requestURI );
  invite.SetStartLine( requestLine );

  m_TargetURI = requestURI;

  willUseProxy = m_3PCCRoute_1 != NULL ;
  if( willUseProxy && m_3PCCRoute_1->GetSize() > 0 )
  {
    invite.SetRouteList( *m_3PCCRoute_1 );
    Route & route = dynamic_cast<Route&>(m_3PCCRoute_1->GetAt(0));
    RouteURI sendAddress;
    route.GetURI( sendAddress );
    targetAddress = sendAddress.GetURI().GetAddress();
  }

  OString transport;
  if( !uri.GetParameter( "transport", transport ) )
    transport = "udp";

  Via via;
  GetSessionManager().ConstructVia( targetAddress, via, SIPTransport::UDP );
  via.SetBranch( ParserTools::GenBranchParameter() );
  via.AddParameter( "rport", "" );
  invite.AppendVia( via );

  /// Set the inteface address to be used for future requests
  /// based it from the via host
  m_InterfaceAddress = via.GetAddress();
  m_InterfacePort = via.GetPort();


  //set the from
  invite.SetFrom( this->m_3PCCFrom_1 );
  invite.SetFromTag( ParserTools::GenTagParameter() );

  invite.SetTo( this->m_3PCCTo_1 );

  /// Set the call Id
  CallId callId;
  callId.SetHeaderBody( GetSessionId() );
  invite.SetCallId( callId );

  /// Set the CSeq
  CSeq cSeq;
  cSeq.SetMethod( "INVITE" );
  cSeq.SetSequence( 4711 );
  invite.SetCSeq( cSeq );

  /// Set the contact
  SIPURI contactURI = m_3PCCFrom_1;
  contactURI.SetHost( via.GetURI().GetHost() );
  contactURI.SetPort( via.GetURI().GetPort() );

  ContactURI contact( contactURI, this->m_3PCCFrom_1.GetDisplayName() );
  invite.AppendContact( contact );

  BOOL localIPAddress = via.GetURI().GetAddress();
  OString sdp;

  unsigned ownerVersion = PTime().GetTimeInSeconds();

  if( Prepare3PCCSDP_1( localIPAddress, ownerVersion, m_3PCCAudioCodec, sdp ) )
  {
    SetRequest( invite );
    m_3PCCUACInvite_1 = invite;
    return SendRequest( invite );
  }

  return FALSE;
}
    
BOOL TPartyCCSessionFlowII::Send3PCCFlowII_Invite_2(
  const SIPMessage & response 
)
{
  if( !response.HasSDP() )
    return FALSE;

  SIPURI uri = m_3PCCTo_2.GetURI();
  PIPSocket::Address targetAddress = uri.GetAddress();
  SIPMessage invite;

  BOOL willUseProxy = FALSE;

  /// create the request line
  RequestLine requestLine;
  requestLine.SetMethod( "INVITE" );

  OString requestURI = uri.AsString();
  
  requestLine.SetRequestURI( requestURI );
  invite.SetStartLine( requestLine );

  m_TargetURI = requestURI;

  willUseProxy = m_3PCCRoute_2 != NULL ;
  if( willUseProxy && m_3PCCRoute_2->GetSize() > 0 )
  {
    invite.SetRouteList( *m_3PCCRoute_2 );
    Route & route = dynamic_cast<Route&>(m_3PCCRoute_2->GetAt(0));
    RouteURI sendAddress;
    route.GetURI( sendAddress );
    targetAddress = sendAddress.GetURI().GetAddress();
  }

  OString transport;
  if( !uri.GetParameter( "transport", transport ) )
    transport = "udp";

  Via via;
  GetSessionManager().ConstructVia( targetAddress, via, SIPTransport::UDP );
  via.SetBranch( ParserTools::GenBranchParameter() );
  via.AddParameter( "rport", "" );
  invite.AppendVia( via );

  /// Set the inteface address to be used for future requests
  /// based it from the via host
  m_InterfaceAddress = via.GetAddress();
  m_InterfacePort = via.GetPort();


  //set the from
  invite.SetFrom( this->m_3PCCFrom_2 );
  invite.SetFromTag( ParserTools::GenTagParameter() );

  invite.SetTo( this->m_3PCCTo_2 );

  /// Set the call Id
  CallId callId;
  callId.SetHeaderBody( GetSessionId() );
  invite.SetCallId( callId );

  /// Set the CSeq
  CSeq cSeq;
  cSeq.SetMethod( "INVITE" );
  cSeq.SetSequence( 4711 );
  invite.SetCSeq( cSeq );

  /// Set the contact
  SIPURI contactURI = m_3PCCFrom_2;
  contactURI.SetHost( via.GetURI().GetHost() );
  contactURI.SetPort( via.GetURI().GetPort() );

  ContactURI contact( contactURI, this->m_3PCCFrom_2.GetDisplayName() );
  invite.AppendContact( contact );

  OString sdp = response.GetBody();
  invite.SetSDP( sdp );

  m_3PCCUACInvite_2 = invite;

  return SendRequest( invite );

}


BOOL TPartyCCSessionFlowII::Prepare3PCCSDP_1(
      const PIPSocket::Address & localAddress,
      int version,
      const SDP::SDPMediaFmt & codec,
      OString & sdp
)
{
  const char * CRLF = "\r\n";
  
  OStringStream strm;
  strm << "v=0" << CRLF;
  strm << "o=- " << version << " " << version << " IN IP4 " << localAddress.AsSTLString() << CRLF;
  strm << "s=OSS 3PCC Session" << CRLF;
  strm << "c=IN IP4 0.0.0.0"  << CRLF;
  strm << "t=0 0" << CRLF;
  strm << "m=audio 0 RTP/AVP 101 " << codec.GetPayloadType() << CRLF;
  strm << "a=rtpmap:101 telephone-event/8000" << CRLF;
  strm << "a=fmtp:101 0-15" << CRLF;
  strm << "a=rtpmap:" << codec.GetPayloadType() << " " << codec.GetEncodingName() << "/8000" << CRLF;
  sdp = strm.str();

  return TRUE;
}




