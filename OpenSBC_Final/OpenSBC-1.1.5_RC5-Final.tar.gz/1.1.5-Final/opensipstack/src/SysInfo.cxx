/*
 *
 * SysInfo.cxx
 * 
 * Open SIP Stack ( OSS )
 *
 * Copyright (C) 2006 Joegen E. Baclor. All Rights Reserved.
 *
 * Version: MPL 1.1/GPL 2.0/LGPL 2.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is OpenSIPStack Library.
 *
 * The Initial Developer of the Original Code is Joegen E. Baclor.
 *
 * Contributor(s):
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * $Log: SysInfo.cxx,v $
 * Revision 1.5  2007/06/04 16:05:33  joegenbaclor
 * *** empty log message ***
 *
 * Revision 1.4  2007/03/19 02:17:26  joegenbaclor
 * CPU Throttling disabled by default
 *
 * Revision 1.3  2007/03/04 03:26:38  joegenbaclor
 * More compile warnings
 *
 * Revision 1.2  2007/03/04 03:00:34  joegenbaclor
 * Removed Linux compile warnings
 *
 * Revision 1.1  2007/03/03 14:58:12  joegenbaclor
 * Initial upload
 *
 *
 */

#include "SysInfo.h"

////////////////////////////////////////////////
/// Get rid of LNK4221: no public symbols found; 
/// archive member will be inaccessible
const char * sysinfo_file_content = NULL;
////////////////////////////////////////////////

#if ENABLE_CPU_YIELD

#define new PNEW

using namespace Tools;


#if defined( _WIN32 ) || defined (_WIN64) 
/* Windows System Specific */

#include <process.h> 
#include <pdh.h>
#pragma comment(lib,"pdh.lib")

BOOL SysInfo::GetCPUUsage(
  unsigned long & usage
)
{
  static LPCTSTR gszProcessorTime=TEXT("\\Processor(_Total)\\% Processor Time");
  static HQUERY query;
  static HCOUNTER counter;
  static BOOL hasInit = FALSE;
  static LONG lastCycle = 0;

  if( !hasInit )
  {
    if (PdhOpenQuery ( NULL, 1, &query ) == ERROR_SUCCESS)
    {
	    if (PdhAddCounter ( query, gszProcessorTime, 
		    NULL, &counter) == ERROR_SUCCESS)
	    {
		    hasInit = TRUE;
	    }
    }
  }

  PDH_RAW_COUNTER	ppdhRawCounter;
  PDH_FMT_COUNTERVALUE pdhFormattedValue;

  // Collect the current raw data value for all counters in the 
  // specified query and updates the status code of each counter 
  if (PdhCollectQueryData ( query ) != ERROR_SUCCESS)
  {
    // Data collection failed.
    return FALSE;
  }

  // Get the CPU raw counter value	
  if (PdhGetRawCounterValue ( counter, NULL, &ppdhRawCounter ) == ERROR_SUCCESS)
  {
  // Format the CPU counter
    if (PdhGetFormattedCounterValue ( counter, PDH_FMT_LONG, NULL, 
      &pdhFormattedValue) == ERROR_SUCCESS)
    {
      // Got the formatted value.  Show it on the graph
      usage = pdhFormattedValue.longValue;
      return TRUE;
    }
  }

  return FALSE;
}


/////////////////////////////////////////////////////////////////////////////////////////////////////



#elif defined( P_LINUX )
/* Linux System Specific */

BOOL SysInfo::GetCPUUsage(
  unsigned long & usage
)
{
  static unsigned long oldCPUUser   = 0;
  static unsigned long oldCPUSyst   = 0;
  static unsigned long oldCPUWait   = 0;
  static unsigned long oldCPUTotal  = 0;
  unsigned long cpuUser             = 0;
  unsigned long cpuNice             = 0;
  unsigned long cpuSyst             = 0;
  unsigned long cpuIdle             = 0;
  unsigned long cpuWait             = 0;
  unsigned long cpuIrq              = 0;
  unsigned long cpuSoftIrq          = 0;

  PTextFile statFile;
  if( !statFile.Open( "/proc/stat", PFile::ReadOnly ) )
    return FALSE;

  PString line;
  if( !statFile.ReadLine( line ) )
    return FALSE;

  int tokens = sscanf(line.GetPointer(), "cpu %llu %llu %llu %llu %llu %llu %llu",
         &cpuUser,
         &cpuNice,
         &cpuSyst,
         &cpuIdle,
         &cpuWait,
         &cpuIrq,
         &cpuSoftIrq);

  if( tokens < 4 )
  {
    return FALSE;
  }else if( tokens == 4 )
  {
    /* linux 2.4.x doesn't support these values */
    cpuWait = 0;
    cpuIrq = 0;
    cpuSoftIrq = 0;
  }

  unsigned long long cpuTotal    = cpuUser + cpuNice + cpuSyst + cpuIdle + cpuWait + cpuIrq + cpuSoftIrq;
  cpuUser     = cpuUser + cpuNice;
  
  if( oldCPUTotal == 0)
  {
    usage = 0;
  }
  else
  {
    long delta = cpuTotal - oldCPUTotal;
  
    usage = (unsigned long)(100 * ( cpuUser - oldCPUUser ) / delta ) +
            (unsigned long)(100 * ( cpuSyst - oldCPUSyst ) / delta ) +
            (unsigned long)(100 * ( cpuWait - oldCPUWait ) / delta );

  }


  oldCPUUser = cpuUser;
  oldCPUSyst = cpuSyst;
  oldCPUWait = cpuWait;
  oldCPUTotal= cpuTotal;
  return TRUE;

}


/////////////////////////////////////////////////////////////////////////////////////////////////////


#elif defined( P_SOLARIS )
/* Solaris System Specific */

#include <kstat.h>
#include <sys/sysinfo.h>

BOOL SysInfo::GetCPUUsage(
  unsigned long & usage
)
{
  static long   oldCPUUser=0;
  static long   oldCPUSyst=0;
  static long   oldCPUWait=0;
  static long   old_total=0;

  long cpuUser=0, cpu_syst=0, cpu_wait=0;
  long total=0;
  
  int cpuUserPercent=0;
  int cpuSystPercent=0;
  int cpuWaitPercent=0;

  kstat_ctl_t * kctl = kstat_open();
  kstat_t * kstat = kstat_lookup(kctl, "unix", 0, "system_misc");

  if (kstat_read(kctl, kstat, 0) == -1) 
  {
    kstat_close(kctl);
    return FALSE;
  }
  
  kstat_named_t *knamed = reinterpret_cast<kstat_named_t*>(kstat_data_lookup(kstat, "ncpus"));
  if ( knamed == NULL ) 
  {
    kstat_close(kctl);
    return FALSE;
  }
  
  int ncpus = knamed->value.ui32;

  kstat_t **cpu_ks = (kstat_t **) malloc(ncpus * sizeof (kstat_t *));
  cpu_stat_t *cpu_stat = (cpu_stat_t *)malloc (ncpus * sizeof (cpu_stat_t));

  int ncpu = 0;

  for (kstat = kctl->kc_chain; kstat;
       kstat = kstat->ks_next)
  {
    if (strncmp(kstat->ks_name, "cpu_stat", 8) == 0)
    {
      if (-1 == kstat_read(kctl, kstat, NULL)) 
      {
        old_total=0;
        free(cpu_ks);
        free(cpu_stat);
        kstat_close(kctl);
        return FALSE;
        
      }
      
      cpu_ks[ncpu] = kstat;
      ncpu++;
  
      if (ncpu > ncpus) 
      {
        old_total=0;
        free(cpu_ks);
        free(cpu_stat);
        kstat_close(kctl);
        return FALSE;
      }
    }
  }

  
  
  for ( PINDEX i = 0; i < ncpu; i++)
  {
    if ( -1 == kstat_read(kctl, cpu_ks[i], &cpu_stat[i])) 
    {
      old_total=0;
      free(cpu_ks);
      free(cpu_stat);
      kstat_close(kctl);
      return FALSE;
      
    }
    
    cpuUser+=cpu_stat[i].cpu_sysinfo.cpu[cpuUser];
    cpu_syst+=cpu_stat[i].cpu_sysinfo.cpu[CPU_KERNEL];
    cpu_wait+=cpu_stat[i].cpu_sysinfo.cpu[CPU_WAIT];

    total += ( cpu_stat[i].cpu_sysinfo.cpu[0]+
               cpu_stat[i].cpu_sysinfo.cpu[1]+
               cpu_stat[i].cpu_sysinfo.cpu[2]+
               cpu_stat[i].cpu_sysinfo.cpu[3]+
               cpu_stat[i].cpu_sysinfo.cpu[4] );
    
  }

 
  if ( old_total == 0.0 ) 
  {
    cpuUserPercent=0;
    cpuSystPercent=0;
    cpuWaitPercent=0;
  }else 
  {
    cpuUserPercent=(int)((100*(cpuUser-oldCPUUser))/
                                     (total-old_total));
    cpuSystPercent=(int)((100*(cpu_syst-oldCPUSyst))/
                                     (total-old_total));
    cpuWaitPercent=(int)((100*(cpu_wait-oldCPUWait))/
                                     (total-old_total));
  }

  usage = cpuUserPercent + cpuSystPercent + cpuWaitPercent;
  
  oldCPUUser=cpuUser;
  oldCPUSyst=cpu_syst;
  oldCPUWait=cpu_wait;
  old_total=total;
  
  free(cpu_ks);
  free(cpu_stat);
  kstat_close(kctl);
  return TRUE;

}

#else

BOOL SysInfo::GetCPUUsage(
  unsigned long & usage
)
{
  usage = 0;
  return FALSE;
}


#endif
#endif




