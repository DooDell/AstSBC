/*
 *
 * B2BUAConnection.cxx
 * 
 * Open SIP Stack ( OSS )
 *
 * Copyright (C) 2006 Joegen E. Baclor. All Rights Reserved.
 *
 * Version: MPL 1.1/GPL 2.0/LGPL 2.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is OpenSIPStack Library.
 *
 * The Initial Developer of the Original Code is Joegen E. Baclor.
 *
 * Contributor(s):
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * $Log: B2BUAConnection.cxx,v $
 * Revision 1.197  2009/06/09 07:15:00  joegenbaclor
 * added ability to set user data for profiles
 *
 * Revision 1.196  2009/06/04 07:40:59  joegenbaclor
 * corrected wrong spelling
 *
 * Revision 1.195  2009/05/20 08:58:52  joegenbaclor
 * Various bug fixes
 *
 * Revision 1.194  2009/05/13 08:19:13  joegenbaclor
 * Added call back for RTP reads in B2BUA
 *
 * Revision 1.193  2009/05/04 23:52:33  joegenbaclor
 * Minor bug fixes in handling reinvite media where OnIncomingSDPOffer() is not called
 *  when dialog state is connected
 *
 * Revision 1.192  2009/04/02 08:12:40  joegenbaclor
 * removed yiled in eventqueue
 *
 * Revision 1.191  2009/03/17 02:26:27  joegenbaclor
 * Changed FindTransactionAndAddEvent function param to not include the transaction id.  Sof far, we have not used it so its kinda useless
 *
 * Revision 1.190  2009/02/18 12:51:20  joegenbaclor
 * More SDP in ACK support
 *
 * Revision 1.189  2009/02/15 02:55:08  joegenbaclor
 * In this patch, we finally found the deadlock that was haunting the stack for quite a while.
 * The culprit functions are FincGCRefBCallId and CreateServerSession of the Session Manager.
 * The remedy was to give the call-id list its own separate mutex so that it doesn't share
 * the same mutex as the session-id based list.  We also guarded create CreateServerSession
 * with it's own function wide mutex so that only one thread at a time can call this function.
 * Finally, we introduced Yields in this method so that sudden influx of INVITE won't deprive
 * existing sessins with CPU time.
 *
 * Revision 1.188  2009/02/13 06:17:09  joegenbaclor
 * Send cancel for alerting timeout
 *
 * Revision 1.187  2009/02/09 08:11:19  joegenbaclor
 * Destroy leg 2 connection on alerting timeout
 *
 * Revision 1.186  2009/02/09 06:57:07  joegenbaclor
 * Fixed bug in CANCEL and INVITE timeout combo.
 *
 * Revision 1.185  2009/02/09 03:03:36  joegenbaclor
 * notify external call control on invite timeout
 *
 * Revision 1.184  2009/02/01 11:55:51  joegenbaclor
 * Failover on everything aside from 401,407 and 487
 *
 * Revision 1.183  2009/01/27 09:06:05  joegenbaclor
 * removed transport inbound processor queue
 *
 * Revision 1.182  2009/01/26 01:13:46  joegenbaclor
 * Added temporary TRACE lines
 *
 * Revision 1.181  2009/01/25 15:09:37  joegenbaclor
 * Logging enhancements
 *
 * Revision 1.180  2009/01/25 14:18:17  joegenbaclor
 * Rever last change
 *
 * Revision 1.179  2009/01/25 10:27:30  joegenbaclor
 * mutexed incoming call using state mutex to make sure cancel is never processed before this function has finished
 *
 * Revision 1.178  2009/01/21 13:06:40  joegenbaclor
 * More tweaks for SDP in ACK
 *
 * Revision 1.177  2009/01/21 09:52:34  joegenbaclor
 * Minor code tweaks
 *
 * Revision 1.176  2009/01/20 09:18:39  joegenbaclor
 * modified addroute to create anew SIPURI instead of copying to a temp object
 *
 * Revision 1.175  2009/01/18 17:04:28  joegenbaclor
 * Deprecated HAS_OPAL macro
 * Added support for SDP in ACK.
 *
 * Revision 1.174  2009/01/15 07:55:35  joegenbaclor
 * reinstated failover routinge for alerting timeout
 *
 * Revision 1.173  2009/01/12 04:39:09  joegenbaclor
 * Added m_LocallyAuthenticated flag.
 *
 * Revision 1.172  2009/01/04 03:33:56  joegenbaclor
 * Introduced B2BUAConnection::ErrorScrewedUpState to trigger disconnects when receiving out of order BYE request regardless of call-state since nothing good is expected to happen with the call
 *
 * Revision 1.171  2009/01/03 12:12:29  joegenbaclor
 * Reimplemented DestroyConenction to enqueue a session event instead to avoid further race conditons and dead locks.
 * We also implemented B2BUAConnection::IsSafeReference() to further guaranty the integrity of connection pointers.
 *
 * Revision 1.170  2009/01/01 05:27:06  joegenbaclor
 * Introduced ACK Timeout as Session Event so that call destruction is only called by the event queue to avoid the possibility of deadlocks.
 *
 * Revision 1.169  2008/12/31 05:03:10  joegenbaclor
 * Added G729-Raw Codec support for media server
 *
 * Revision 1.168  2008/12/28 03:19:41  joegenbaclor
 * Updated Visual Studio 2005 specific compile settings
 *
 * Revision 1.167  2008/12/23 11:35:27  joegenbaclor
 * Do not call OnCallStop() on ACK timeout.
 *
 * Revision 1.166  2008/12/22 06:56:49  joegenbaclor
 * Application Timers for Alerting and Connect is causing a deadlock on connection destruction.
 * To address this issue, we modified opensipstack to take care of the timers in the ICT Layer.
 *
 * Revision 1.165  2008/12/18 04:22:51  joegenbaclor
 * Changed my mind on Revision 1.164.  Just call OnCallStop() then call DestroyConnection()
 *  right after
 *
 * Revision 1.164  2008/12/18 03:51:15  joegenbaclor
 * call Stop() instead OnCallStop() for ACK timeout.  calling OnCallStop() does not destroy
 *  the connection
 *
 * Revision 1.163  2008/12/17 09:42:16  joegenbaclor
 * Fixed bug in B2BUAConnection::OnAckFor200OkExpire() where m_CallController->OnCallStop()
 *  is called with a null pointer
 *
 * Revision 1.162  2008/12/17 02:55:23  joegenbaclor
 * Disabled UAC Cancel Transaction Handler
 *
 * Revision 1.161  2008/12/16 12:51:15  joegenbaclor
 * Introduced double mutex lock in DestroyConnection()
 *
 * Revision 1.160  2008/12/12 10:37:01  joegenbaclor
 * Fixing bug in rate limit
 *
 * Revision 1.159  2008/12/12 08:58:58  joegenbaclor
 * Fixed bug in reading CScript modules
 * Fixed bug in XOR hash where 200 Ok retransmission are not encrypted
 *
 * Revision 1.158  2008/12/06 05:11:03  joegenbaclor
 * Added Event_IVRContextDetach event to signal the handler the the context has been
 *  detached
 *
 * Revision 1.157  2008/11/25 16:56:33  joegenbaclor
 * Removed more remnants of rewrite request uri
 *
 * Revision 1.156  2008/11/13 05:27:29  joegenbaclor
 * Enhancement:  Call DestroyConnection directly for BYE; Removed unneeded LOG for ACK
 *
 * Revision 1.155  2008/11/11 02:52:50  joegenbaclor
 * Feature:
 *  Allowed application to set the number of transaction thread via the constructor of
 *  the managers
 * Bug: Fixed lifespan timer event to not fire on bypass handlers
 *
 * Revision 1.154  2008/10/29 06:22:25  joegenbaclor
 * Added sanity check in OnReceivedRequest() to make sure we only process requests and
 *  not responses
 *
 * Revision 1.153  2008/10/27 12:39:30  joegenbaclor
 * Implementing the need to update local-authorization dialog state for b2bua calls to
 *  be compatible with ua supporting QOP
 *
 * Revision 1.152  2008/10/27 10:18:11  joegenbaclor
 * Preserve authorization header as dilaog state and send it during creation of in-dialog
 *  requests.
 *
 * Revision 1.151  2008/10/17 04:58:37  joegenbaclor
 * Introduced separate cancel transaction to fix Cancel race condition resulting to ghost
 *  call sessions
 *
 * Revision 1.150  2008/10/15 08:16:44  joegenbaclor
 * Fixed bug in StateCancelPending whereat connections are not destroyed on receipt of a final response to a cencelled invite
 *
 * Revision 1.149  2008/09/25 05:45:45  joegenbaclor
 * Added tailDelay param in IVRPlayFile
 *
 * Revision 1.148  2008/09/23 02:58:35  joegenbaclor
 * Fixied crashed scenario when StartVXML() fails
 *
 * Revision 1.147  2008/09/14 01:18:17  joegenbaclor
 * Stop timers on disconnect
 *
 * Revision 1.146  2008/08/29 06:21:09  joegenbaclor
 * Commiting code for ICT forking support
 *
 * Revision 1.145  2008/08/20 12:56:10  joegenbaclor
 * Removed sending of individual events for IVR User Input
 * Some enhancements related to call audit trail
 *
 * Revision 1.144  2008/08/13 11:44:54  joegenbaclor
 * Normalized TransferCallLocal
 *
 * Revision 1.143  2008/08/02 15:34:30  joegenbaclor
 * Introduced mutex to all calls to B2BUAConnection pointer.
 *
 * Revision 1.142  2008/07/31 05:04:30  joegenbaclor
 * Introduced FirstDigitTimer for DTMF context
 *
 * Revision 1.141  2008/07/29 06:11:56  joegenbaclor
 * Added DumpCallAuditTrail() call back method
 *
 * Revision 1.140  2008/07/26 14:04:23  joegenbaclor
 * Allowed auto-deletion of external call control in b2bua connection destructor
 *
 * Revision 1.139  2008/07/25 08:50:53  joegenbaclor
 * Made sure we call DetachCall() when failing-over
 *
 * Revision 1.138  2008/07/24 02:22:19  joegenbaclor
 * - Fixed bug where m_CanDecrementCounter is not intialized to TRUE in CallSession constructor
 * - Reformatted extra long Sink PTRACE
 *
 * Revision 1.137  2008/07/21 14:40:55  joegenbaclor
 * Renamed AuthenticationPending state to RemoteAuthenticationPending to clarify the
 *  difference between LocalAuthenticationPending
 *
 * Revision 1.136  2008/07/21 05:11:42  joegenbaclor
 * more implementation of inbound authentication for external call control
 *
 * Revision 1.135  2008/07/17 11:56:49  joegenbaclor
 * Fixed bug in TimerEvent not getting propagate properly to B2BUAConnection
 * Changed logging options to inlcude DateTime instead of TimeStamp
 *
 * Revision 1.134  2008/07/16 13:56:39  joegenbaclor
 * moved onconnected so that it gets called only after media has been processed
 *
 * Revision 1.133  2008/07/14 05:16:51  joegenbaclor
 * code aesthetics
 *
 * Revision 1.132  2008/07/10 05:34:33  joegenbaclor
 * Re-ordered session destruction so that Ondisconnect is called in DestroyConnection isntead of OnDestroyConnection
 *
 * Revision 1.131  2008/07/08 12:24:18  joegenbaclor
 * Code aesthetics
 *
 * Revision 1.130  2008/07/04 06:29:35  joegenbaclor
 * More external Call Controller work
 *
 * Revision 1.129  2008/07/01 12:28:12  joegenbaclor
 * added custom call control handler
 *
 * Revision 1.128  2008/06/27 16:37:50  joegenbaclor
 * Transfered deletion of RTP Proxy threads to CloseMediaStreams to free resources early.
 * Modified connection and call resource counters so that they get decremented upon receipt
 *  of the session destruction event.
 * Added RemoveAllSessions method to RTP_SessionManager
 *
 * Revision 1.127  2008/06/15 03:38:50  joegenbaclor
 * Some improvements in announcement handling
 *
 * Revision 1.126  2008/06/13 13:06:37  joegenbaclor
 * implemented announcement service
 *
 * Revision 1.125  2008/06/11 04:45:31  joegenbaclor
 * Added Catch-All-Route functionality.  See http://www.assembla.com/spaces/opensbc/tickets/23
 *
 * Revision 1.124  2008/06/04 02:55:34  joegenbaclor
 * Reverting previous accidental merge
 *
 * Revision 1.122  2008/06/03 15:14:53  joegenbaclor
 * merging rtbe specific callbacks
 *
 * Revision 1.121  2008/06/02 07:27:46  joegenbaclor
 * Merging-in Solegy required patches
 *
 * Revision 1.120  2008/05/27 14:14:10  joegenbaclor
 * Implemented maximum concurrent connection counter
 *
 * Revision 1.119  2008/04/25 06:17:51  rcolobong
 * Handle early media during state transferring
 *
 * Revision 1.118  2008/04/16 00:42:17  joegenbaclor
 * Added OnPostCreateB2BUA callback to allow applications to set parameters of B2BUA
 *  Connections after they are created.
 *
 * Revision 1.117  2008/04/09 02:45:58  joegenbaclor
 * Removed sending of NOTIFYs for locally transfered call since a REFER is not used to initate the transfer.
 *   One specific example is when the media server initated the call transfer via IVRTransferCall()
 *  method.
 *
 * Revision 1.116  2008/03/06 09:24:47  rcolobong
 * Added new info in ResourceCounter class
 *
 * Revision 1.115  2008/03/03 10:02:17  rcolobong
 * Fix one way audio bug during local reINVITEs
 *
 * Revision 1.114  2008/02/14 08:20:07  ijpinzon
 * Fix for video stream thread not being started during reINVITE.
 *
 * Revision 1.113  2008/02/12 07:46:40  rcolobong
 * 1. Alerting and Seize timeout is now handled properly during call transfer
 * 2. Fixed bug wherein the interface address of MediaServer is incorrect
 * 3. Fixed crashes and garbled prompts in IVR
 * 4. Invoke OnDisconnected call handler if state is still connected in OnDestroySession
 *
 * Revision 1.112  2008/01/08 11:25:29  ijpinzon
 * Added Contact when responding with 202 Accepted for Refer
 *
 * Revision 1.111  2008/01/08 07:24:53  rcolobong
 * Fix crashes related to garbage transaction in SIPMessages
 *
 * Revision 1.110  2007/12/21 07:19:35  joegenbaclor
 * Added ability to preserve the transaction via the incoming SIP message.  This pointer may be provided to SendRequest so that responses can avoid another search of the transaction from the transaction db.
 *
 * Revision 1.109  2007/12/04 16:04:12  joegenbaclor
 * Added Access List verification and a way to set Warning header for Reject SIP Messages
 *
 * Revision 1.108  2007/12/04 05:22:38  joegenbaclor
 * Added PRACK in allow list.
 * Bug fixes for IST crashing during destruction due to 100rel changes
 *
 * Revision 1.107  2007/11/21 02:50:20  joegenbaclor
 * Flagged Cancel Pending so that calls are not abandoned right way after receiving a CANCEL from the caller.   This would allow the call to linger and wait untill all the forked calls were canceled by the forking server
 *
 * Revision 1.106  2007/11/20 14:09:41  joegenbaclor
 * SIPTransport:  Added check for interface address.  If not specified by the upper layer, it will be based on the via address
 * Forking:  Various enahncements to handling parallel fork with empahsis on call abandonment
 *
 * Revision 1.105  2007/11/20 07:07:50  joegenbaclor
 * Added ability to proxy CANCEL for forked request
 *
 * Revision 1.104  2007/11/18 16:57:05  joegenbaclor
 * Added support for merged requests ending up in the same connection
 *
 * Revision 1.103  2007/11/08 03:23:55  joegenbaclor
 * Minor  SIPIT 21 interop patches.
 *
 * Revision 1.102  2007/11/07 10:20:20  joegenbaclor
 * various patches for interop issues revealed in SIPIT 21
 *
 * Revision 1.101  2007/10/28 17:24:08  joegenbaclor
 * Added PThread to resource counter
 * We now recycle connections for locally authenticated calls to avoid race conditions
 *
 * Revision 1.100  2007/10/28 05:59:14  joegenbaclor
 * 1.   We now disconnect b2bua calls on ACK timeout
 *
 * Revision 1.99  2007/10/24 08:50:46  joegenbaclor
 * Implemented initial FMC support
 *
 * Revision 1.98  2007/10/17 13:57:03  joegenbaclor
 * Local Refer ReInvite bug fixes
 *
 * Revision 1.97  2007/10/17 03:17:17  joegenbaclor
 * Updated SDP parser and media interface to support local re-Invite feature
 *
 * Revision 1.96  2007/10/15 19:15:34  joegenbaclor
 * Made sure reINVITEs are handled locally when Local REFER is enabled
 *
 * Revision 1.95  2007/10/10 17:00:00  joegenbaclor
 * Logging improvement
 *
 * Revision 1.94  2007/09/21 11:19:24  joegenbaclor
 * Corrected bug where reINVITE might not be handled if SDP is not present
 *
 * Revision 1.93  2007/09/17 02:15:02  joegenbaclor
 * Corrected bug in escaping + signs in SIPURI's
 *
 * Revision 1.92  2007/09/04 22:46:25  joegenbaclor
 * Changed PString to Ostring in IVRSetDTMFGrammar function parameter
 *
 * Revision 1.91  2007/09/04 10:34:02  rcolobong
 * 1. Bug fix on DTMF Input timeout where the timer start running during playing of IVR Prompt
 * 2. Bug fix on DTMF timer which does not reset during dtmf input
 * 3. Add new property "prompts identifier" in SetDTMFGrammar to bind the DTMF grammar to a specific prompt
 * 4. IVRContext now invoke DetachIVRContext() in B2BUAConnection when closing IVRContext
 *
 * Revision 1.90  2007/08/28 01:25:46  joegenbaclor
 * Completed recording SIP signals for CALEA in pcap format
 *
 * Revision 1.89  2007/08/24 01:14:20  joegenbaclor
 * scrapped previous code for upstream proxy handling
 *
 * Revision 1.88  2007/08/21 16:06:00  joegenbaclor
 * Added additional methods to be called for call redirect to allow the application layer
 *  to provide a final route.  Eg: via registration db lookups.  Thanks Julian Tasis
 *  for reporting the problem
 *
 * Revision 1.87  2007/07/26 11:52:56  joegenbaclor
 * Finalized RemoteAuthenticationPending
 *
 * Revision 1.86  2007/07/26 08:15:53  joegenbaclor
 * Uploading support for RemoteAuthenticationPending state in B2BUAConnection.  This fix will eliminatethe need  to generate a diffrent call-id for resending credentials for 401/407
 *
 * Revision 1.85  2007/07/15 13:33:12  joegenbaclor
 * deprecated old connection count variable
 *
 * Revision 1.84  2007/07/14 07:50:29  joegenbaclor
 * Migrated code to use new STL based string class
 *
 * Revision 1.83  2007/07/10 03:23:05  joegenbaclor
 * Added experimental code to use STL tokenizer instead of internal string tokenizer
 *
 * Revision 1.82  2007/07/06 13:38:39  rcolobong
 * Add Upstream Proxy Route feature
 *
 * Revision 1.81  2007/06/16 12:30:40  joegenbaclor
 * Changed CacheManager to return a smart pointer instead of a direct pointer to cache object to avoid segmentation faults when an object expires in cache and another thread has pending ownership of the pointer
 *
 * Renamed CacheManager::GetAt() to CacheManager::CreatePointer() to give a hint to users that the pointer needs to be deleted after being used
 *
 * Revision 1.80  2007/06/15 09:12:14  joegenbaclor
 * Added IVR Transfer reject event
 *
 * Revision 1.79  2007/06/13 09:22:05  joegenbaclor
 * Implemented basic IVR handler in OpenSBC
 *
 * Revision 1.78  2007/06/13 04:16:49  joegenbaclor
 * Fixed bug in IVR call transfer
 *
 * Revision 1.77  2007/06/12 09:22:41  joegenbaclor
 * Added IVR Call Transfer
 *
 * Revision 1.76  2007/06/08 15:10:32  joegenbaclor
 * Added IVR DTMF Grammar
 *
 * Revision 1.75  2007/06/08 09:26:30  joegenbaclor
 * Added B2BIVRInterface handlers
 *
 * Revision 1.74  2007/06/08 02:33:46  joegenbaclor
 * Commiting more Media Server Related Changes
 *
 * Revision 1.73  2007/06/06 09:54:15  joegenbaclor
 * More B2BUAConnection IVR methods
 *
 * Revision 1.72  2007/06/05 16:27:56  joegenbaclor
 * Added IVR audio playback functions to B2BUAConnection
 *
 * Revision 1.71  2007/05/27 06:15:50  joegenbaclor
 * Implemented OnReceivedSDPAnswer()
 *
 * Revision 1.70  2007/05/25 08:38:09  joegenbaclor
 * Introduced GCVERIFYREF and GCCREATEREF Macro
 * Transfered B2BUAConnection::OnIncomingCall to be called in B2BUAEndPoint::OnIncomingSIPMessage
 *
 * Revision 1.69  2007/05/24 14:58:36  joegenbaclor
 * Fixed bug in hold/unhold as reported by EarthLink
 *
 * Revision 1.68  2007/05/16 08:11:15  rcolobong
 * 1. Bug fix on Alerting and Seize Timeout
 * 2. Bug fix on AttachCall method where existing B2BUACall is overriden without releasing its reference
 *
 * Revision 1.67  2007/05/08 05:03:25  joegenbaclor
 * Added 491 Request Pending Support
 *
 * Revision 1.66  2007/05/07 16:15:01  joegenbaclor
 * Fixed memory leaks in Garbage Collection
 *
 * Revision 1.65  2007/05/06 15:52:14  joegenbaclor
 * More bug fixes in Delayed Deletion
 *
 * Revision 1.64  2007/05/04 09:40:52  joegenbaclor
 * more on delayed deletion mechanism
 *
 * Revision 1.63  2007/05/04 08:44:42  joegenbaclor
 * Introduced delayed deletion mechanism
 *
 * Revision 1.62  2007/05/01 04:19:37  rcolobong
 * 1. Add support for enabling and disabling Local Refer
 * 2. Invoke OnCallRejected during failover
 * 3. Add method GenerateCallIdExtensions
 *
 * Revision 1.61  2007/04/20 06:36:50  joegenbaclor
 * Completed initial work on local REFER
 *
 * Revision 1.60  2007/04/19 04:21:09  joegenbaclor
 * Big fixes OnHandleStateTransferring
 *
 * Revision 1.59  2007/04/18 11:10:21  joegenbaclor
 * Corrected type in last commit
 *
 * Revision 1.58  2007/04/18 10:56:29  joegenbaclor
 * Ignored sip messages received froma referred leg when call is already connected.
 *
 * Revision 1.57  2007/04/18 05:35:41  joegenbaclor
 * Added method to force exit of media threads for REFERred calls
 *
 * Revision 1.56  2007/04/17 15:38:44  joegenbaclor
 * More work on local REFER.
 *
 * Revision 1.55  2007/04/17 08:02:15  joegenbaclor
 * more work on local refer
 *
 * Revision 1.54  2007/04/16 14:24:41  joegenbaclor
 * More work on B2B local REFER support
 *
 * Revision 1.53  2007/04/09 08:06:20  joegenbaclor
 * Fixed bug in ACK transaction matching
 *
 * Revision 1.52  2007/03/02 06:22:46  joegenbaclor
 * Corrected some bug in GC.
 * Added CPU Throttle mechanism during heavy load to avoid denial of service
 * Made sure lists are Made unique in SIPHeade clone function
 *
 * Revision 1.51  2007/02/16 11:09:25  joegenbaclor
 * More work on privacy
 *
 * Revision 1.50  2007/02/13 11:21:10  joegenbaclor
 * Made sure a call is destroyed and a 404 sent if the route can't be resolved
 *
 * Revision 1.49  2007/02/09 03:47:35  joegenbaclor
 * 1. Added MaxForwards handling for B2B calls
 * 2. #defined SIP_DEFAULT_MAX_FORWARDS constant
 *
 * Revision 1.48  2007/02/08 18:05:13  joegenbaclor
 * Corrected another bug in Record routing
 *
 * Revision 1.47  2007/01/22 10:01:58  joegenbaclor
 * Fixed bug in handling Notifies
 *
 * Revision 1.46  2007/01/19 08:21:12  joegenbaclor
 * Modified Redirect behavior.  Second leg would now process redirect instead of the
 *  session relaying 3xx to UAC
 *
 * Revision 1.45  2007/01/10 08:07:16  rcolobong
 * 1. Add new method for OnSendB2BConnect Call Interface.
 * 2. OnSendB2BConnect is supported in B2BUserAgent, B2BUACall and B2BUAConnection
 *
 * Revision 1.44  2006/12/19 10:14:26  rcolobong
 * 1. Add method to insert Warning header in 200 Ok response to inbound
 * 2. Alerting timeout will now do failover
 *
 * Revision 1.43  2006/12/17 13:30:58  joegenbaclor
 * Added call attempt index in call-id string to avoid call-id collision during failovers
 *
 * Revision 1.42  2006/11/30 08:19:37  joegenbaclor
 * Relicensed opensipstack to MPL/GPL/LGPL triple license scheme
 *
 * Revision 1.41  2006/11/22 00:05:52  joegenbaclor
 * Bug fixes for multi-listener support
 *
 * Revision 1.40  2006/11/16 01:29:33  rcolobong
 * Notify CallHandler during Authentication Required
 *
 * Revision 1.39  2006/11/10 07:55:35  rcolobong
 * 1. Support Fork Invites using B2BUAForkCalls
 * 2. Handle Cancel events during Forking
 *
 * Revision 1.38  2006/10/30 08:35:55  joegenbaclor
 * Removed more references to presence namespace
 *
 * Revision 1.37  2006/10/25 09:07:46  rcolobong
 * Fix bug where leg1 and leg2 should be set to NULL after OnDestroySession
 *
 * Revision 1.36  2006/10/23 15:44:58  joegenbaclor
 * 1.  Numerous bug fixes for REFER
 * 2.  Added new SIP Headers for SIP timers and Attended call transfer
 * 3.  Added loop sanity check to SIP UDP Transport
 * 4.  Corrected parser bug for ProxyRequire header
 *
 * Revision 1.35  2006/10/11 04:49:47  rcolobong
 * 1. Add support for Notify During Refer
 * 2. Fixed bug where 3xx invoke CallHandler OnRejected
 *
 * Revision 1.34  2006/10/05 13:03:54  rcolobong
 * 1. Fix bug regarding OnRequireCallTransferId calling B2BUA OnRequireRedirectionId Method
 * 2. Add flag in OnSetupOutbound to check if Connection State is already disconnected
 *
 * Revision 1.33  2006/09/25 04:43:30  rcolobong
 * 1. Fix bug in 415 Unsupported Media where CallSession::m_ICTState is not properly initialized during construction.
 * 2. Remove the temporary fix for the 415 Unsupported Media where we use Semaphore to wait for second leg SDP in OnRequireSDPAnswer
 *
 * Revision 1.32  2006/09/22 08:52:45  joegenbaclor
 * Temporary fix for OnRequireSDPAnswer to use a semaphore to wait for second leg SDP
 *
 * Revision 1.31  2006/09/20 11:05:26  joegenbaclor
 * Flagged sending of Session Keep Alive.  Defaults to FALSE
 *
 * Revision 1.30  2006/09/19 10:47:12  rcolobong
 * Disable temporarily session keep alive
 *
 * Revision 1.29  2006/09/18 09:35:16  joegenbaclor
 * Completed initial implementation of RTP media aggregation
 *
 * Revision 1.28  2006/09/18 03:28:55  joegenbaclor
 * 1. More work on media aggregation
 * 2. Check sock->GetPort() for NULL in SIPTransportManager::GetListenerAddress() (thanks to
 *  Vamsi Pottangi for reporting the bug)
 * 3.  Added reference size check to GCObject::ReleaseRef()
 *
 * Revision 1.27  2006/09/15 15:31:39  joegenbaclor
 * Changed Log levels to decrease log size.
 * Changed default session keep alaive interval from 10 seconds to two minutes
 *
 * Revision 1.26  2006/09/15 14:45:22  joegenbaclor
 * Flagged SetSessionState of B2BConnection so it wont propagate events when connection
 *  is already destroyed
 *
 * Revision 1.25  2006/09/15 12:29:45  joegenbaclor
 * Flagged OnDestroySession of B2BConnection so it wont be called twice from different
 *  threads.
 *
 * Revision 1.24  2006/09/08 04:39:17  joegenbaclor
 * Implemented INFO Session Keep-alive
 *
 * Revision 1.23  2006/09/02 17:58:20  joegenbaclor
 * Corrected compile errors in GCC regarding euqation of NULL to GCRef.
 *
 * Revision 1.22  2006/09/01 13:15:58  rcolobong
 * Add Logging during Construction and Destruction of B2BUAConnection
 *
 * Revision 1.21  2006/08/30 08:45:41  rcolobong
 * 1. Update handling for connection and alerting timeout
 * 2. Fix bug where leg1 is destroyed before calling DestroyConnection
 *
 * Revision 1.20  2006/08/30 03:42:05  joegenbaclor
 * Corrected bug in garbage collector loop.
 *
 * Revision 1.19  2006/08/29 10:47:23  rcolobong
 * *** empty log message ***
 *
 * Revision 1.18  2006/08/28 07:18:35  joegenbaclor
 * Bulk Commit: Logging overhaul and Call Session callback changes to reflect SIPMessage eg:  OnAlerting(), OnProgress(), etc
 *
 * Revision 1.17  2006/08/26 14:31:44  joegenbaclor
 * Bulk Commit:  All SIP Sessions are now using new Garbage Collector and smart Pointers
 *
 * Revision 1.16  2006/08/16 04:14:33  rcolobong
 * Invoke StopConnectionTimeout after receiving 2xx response
 *
 * Revision 1.15  2006/08/04 05:31:29  rcolobong
 * 1.  Add Alerting and Connecting Timer
 * 2.  Support failover
 * 3.  Add Alerting, CallAbandoned, Rejected, Disconnected, Connected
 *
 * Revision 1.14  2006/07/19 02:19:21  joegenbaclor
 * 1.  Bug fixes concerning B2BUA destruction during during 3xx, 4xx, 5xx, 6xx local response
 * 2.  Fixed bug where Route header is never removed from outbound Invite resulting that may result to a loop when
 *      Inbound Invite has a Route header present
 * 3.  Added RemoveAllRoutes() in SIPMessage
 *
 * Revision 1.13  2006/07/13 06:53:05  joegenbaclor
 * 1.  Introduced Sanity checks for incoming SIP Message
 * 2.  Corrected bug in SIPURI where enum scheme is not getting recognized.
 * 3.  Added ENUM support to routing
 * 4.  Introduced global routing flag to indicate when and not to rewrite outbound To URI's
 *
 * Revision 1.12  2006/07/06 05:38:11  joegenbaclor
 * Final last minute changes to CBCOM hash support
 *
 * Revision 1.11  2006/06/29 05:09:13  joegenbaclor
 * Changed OnOutgoingCall invite parameter from const to none const to give a
 * chance for applications to modify the outbound invite before being sent to the transport
 *
 * Revision 1.10  2006/06/28 14:14:59  joegenbaclor
 * Bulk commit for Media Proxy functionalities for OpenB2BUA
 * Marks a minor version upgrade from 1.0.2 to 1.0.3
 *
 * Revision 1.9  2006/06/23 04:44:04  joegenbaclor
 * SendB2BRefer() added to B2BUACall
 *
 * Revision 1.8  2006/06/22 08:27:57  joegenbaclor
 * *** empty log message ***
 *
 * Revision 1.7  2006/06/21 14:29:11  joegenbaclor
 * This upload marks the first successful call by OpenB2BUA
 *
 * Revision 1.6  2006/06/20 09:52:55  joegenbaclor
 * Added Routing and SDP Handlers to B2BUA
 *
 * Revision 1.5  2006/06/15 09:47:28  joegenbaclor
 * More preliminary design work on B2BUA
 *
 * Revision 1.4  2006/06/14 08:43:38  joegenbaclor
 * Initial upload of OpenB2BUA applcation and related classes
 *
 * Revision 1.3  2006/04/11 00:18:54  joegenbaclor
 * More work on B2BUA class structures
 *
 * Revision 1.2  2006/04/10 01:09:03  joegenbaclor
 * Implemented Create methods fo B2BUA sessions
 *
 * Revision 1.1  2006/04/08 06:27:13  joegenbaclor
 * Initial upload of B2BUA classes
 *
 *
 */

#include "B2BUAConnection.h"
#include "B2BUAForkCalls.h"
#include "ResourceCounter.h"
#include "SDPLazyParser.h"

#define new PNEW

using namespace B2BUA;
using namespace SDP;

//DWORD B2BUAConnection::m_SeizeTimeout = 0;
//DWORD B2BUAConnection::m_AlertingTimeout = 0;

B2BUAConnection::B2BUAConnection(
  B2BUAEndPoint & ep,
  const OString & sessionId
) : SIPSession( ep, sessionId )
{
  m_CanDecrementConnectionCount = TRUE;
  ++ep.ConnectionCount;
  m_LogTag = "CONNECTION";
  m_RewriteToURI = FALSE;
  m_InsertRouteHeader = TRUE;

  m_Leg1Call = NULL;
  m_Leg2Call = NULL;
  m_SessionState = Idle;
  m_CallSessions.DisallowDeleteObjects();

  m_MediaProxyIfPrivate = FALSE;  /// Always Proxy Media by default
  m_AllowMediaProxy = TRUE;
  m_EnableForkCalls = FALSE;

  m_CallInterval = 0;
  m_CallDuration = 0;

  LOG_CONTEXT( LogDebug(), sessionId, "B2BUAConnection Created 0x" << std::hex << this );
  ResourceCounter::IncrementConnection();
  OStringStream rc;
  ResourceCounter::Print( rc );
  LOG_CONTEXT( LogDebug(), sessionId, "*** COUNTERS *** " << "(Constructor)" << rc.str() );

  m_HasStartedAudioStream = FALSE;
  m_HasStartedVideoStream = FALSE;
  m_ConnectionDestroyed = FALSE;
  m_IsConnectionBeingDestroyed = FALSE;
  m_IsAboutToBeDestroyed = FALSE;
  m_ConnectionDestructCause = 0;
  m_SendSessionKeepAlive = FALSE;
  m_HasReceivedSDP = FALSE;
  m_EnableLocalRefer = FALSE;
  m_CallTransferIndex = 0;
  m_ICTRequestPending = FALSE;
  m_IsLocalTransferedCall = FALSE;
  m_IVRDestroyConnectionOnReject = TRUE;
  m_IVRContext = NULL;
  m_IsReinvitingLocally = FALSE;
  m_IsMergedConnection = FALSE;
  m_KeepAliveInterval = 120;
  m_ApplicationData = NULL;
  m_UseCatchAllRoute = FALSE;
  m_IsIVRChannelOpen = FALSE;
  m_IsAnnouncing = FALSE;
  m_WillSendAnnouncement = FALSE;
  m_CanDecrementCounter = TRUE;
  m_CallController = NULL;
  m_CanDeleteCallControl = FALSE;
  m_HasProcessedQueuedCallArrival = FALSE;
  m_IsDisconnected = FALSE;
  m_CallDuration = 0;
  m_RingDuration = 0;
  m_LocallyAuthenticated = FALSE;
  m_IsExpectingSDPInACK = FALSE;
}

B2BUAConnection::~B2BUAConnection()
{
  if( m_CanDeleteCallControl && m_CallController != NULL )
    delete m_CallController;

  m_CallSessions.AllowDeleteObjects();
  LOG_CONTEXT( LogInfo(), GetSessionId(), "*** DESTROYED B2BUA CONNECTION ***" );
  if( m_CanDecrementCounter )
    ResourceCounter::DecrementConnection();
  if( m_CallDuration != 0 )
    ResourceCounter::RegisterCallDurations( m_CallDuration );

  if( m_CanDecrementConnectionCount )
    --(dynamic_cast<B2BUAEndPoint &>(m_SessionManager).ConnectionCount);

  OStringStream rc;
  ResourceCounter::Print( rc );
  
  LOG_CONTEXT( LogInfo(), GetSessionId(), "*** COUNTERS *** " << rc.str() );
}

BOOL B2BUAConnection::AttachCall(
  const OString & id,
  B2BUACall * call,
  int index
)
{
  PWaitAndSignal lock( m_CallSessionsMutex );
  
  SIPSession::GCRef callRef = GCCREATEREF( call, "B2BUAConnection::AttachCall", "B2BUACall" );
  if( callRef == NULL )
    return FALSE;

  SIPSession::GCRef * cloneRef = new SIPSession::GCRef( callRef );

  if( m_CallSessions.Contains( id.c_str() ) )
  {
    SIPSession::GCRef * ref = m_CallSessions.RemoveAt( id.c_str() );
    delete ref;
  }

  m_CallSessions.SetAt( id.c_str(), cloneRef );

  if( index == -1 )
  {
    if( m_Leg1Call == NULL )
    {
      SetInterfacePort( call->GetInterfacePort() );
      m_Leg1Call = call;
    }else
    {
      m_Leg2Call = call;
    }
  }else if( index == 0 )
  {
    m_Leg1Call = call;
  }else if( index == 1 )
  {
    m_Leg2Call = call;
  }

  call->SetB2BUAConnection( this );

  return TRUE;
}

SIPSession::GCRef * B2BUAConnection::DetachCall(
  const OString & id,
  BOOL autoDelete
)
{
  PWaitAndSignal lock( m_CallSessionsMutex );
  SIPSession::GCRef * ref =  m_CallSessions.RemoveAt( id.c_str() );
  B2BUACall * call = dynamic_cast<B2BUACall*>(ref->GetObject());
  if( call != NULL )
    call->SetB2BUAConnection( NULL );

  if( autoDelete )
  {
    delete ref;
    return NULL;
  }

  return ref;
}

SIPSession::GCRef * B2BUAConnection::FindCall(
  const OString & id
)
{
  PWaitAndSignal lock( m_CallSessionsMutex );
  return m_CallSessions.GetAt( id.c_str() );
}


BOOL B2BUAConnection::OnIncomingCall(
  B2BUACall & call,
  SIPMessage & invite
)
{
  /// Mutex here so that CANCEL will not be processed until we have exited this method
  PWaitAndSignal lock( m_SessionStateMutex );
  B2BUserAgent & b2bua = 
    (B2BUserAgent &)GetSessionManager().GetUserAgent();

  SetExpectingSDPInACK( !invite.HasSDP() );
  return b2bua.OnIncomingCall( *this, call, invite );
}

void B2BUAConnection::OnRequireRedirectionId(
  B2BUACall & call,
  OString & redirectionId
)
{
  B2BUserAgent & b2bua = 
    (B2BUserAgent &)GetSessionManager().GetUserAgent();

  b2bua.OnRequireRedirectionId( *this, call, redirectionId );
}

void B2BUAConnection::OnRequireCallTransferId(
  B2BUACall & call,
  const ReferTo & referTo, 
  OString & redirectionId
)
{
  B2BUserAgent & b2bua = 
    (B2BUserAgent &)GetSessionManager().GetUserAgent();

  b2bua.OnRequireCallTransferId( *this, call, referTo, redirectionId );
}

BOOL B2BUAConnection::OnIncomingSDPOffer(
  B2BUACall & call,
  const SIPMessage & sdp
)
{
  B2BUserAgent & b2bua = 
    (B2BUserAgent &)GetSessionManager().GetUserAgent();
  return b2bua.OnIncomingSDPOffer( *this, call, sdp );
}

BOOL B2BUAConnection::OnIncomingSDPAnswer(
  B2BUACall & call,
  const SIPMessage & sdp
)
{
  if( !m_HasReceivedSDP )
    m_HasReceivedSDP = sdp.HasSDP();

  if( !m_HasReceivedSDP )
    return FALSE;
          
  B2BUserAgent & b2bua = 
    (B2BUserAgent &)GetSessionManager().GetUserAgent();

  return b2bua.OnIncomingSDPAnswer( *this, call, sdp );
}

/// your last chance to produce an answer to the offer.  
/// This will be called either before sending 183, 200 or ACK 
BOOL B2BUAConnection::OnRequireSDPAnswer(
  B2BUACall & call,
  const SIPMessage & offer,
  SIPMessage & answer
)
{
  B2BUserAgent & b2bua = 
    (B2BUserAgent &)GetSessionManager().GetUserAgent();
  return b2bua.OnRequireSDPAnswer( *this, call, offer, answer );
}

BOOL B2BUAConnection::OnSendB2BConnect(
  B2BUACall &,
  const SIPMessage & message
)
{
  B2BUserAgent & b2bua = 
    (B2BUserAgent &)GetSessionManager().GetUserAgent();

  BOOL result = b2bua.OnSendB2BConnect( *this, *m_Leg2Call, message );
  
  if( result )
  {
    // Start the call time interval here
    // for the computation of total
    // call duration
    StartCallTimer();

    // seizure should only be considered
    // when media is bi-directionally sent.  
    // This only occurs after a 200 OK is
    // sent.
    ResourceCounter::IncrementTotalSeizure();
  }

  return result;
}

/// this will be called if an offer is not received in INVITE or when we are initiating the call
BOOL B2BUAConnection::OnRequireSDPOffer(
  B2BUACall & call,
  SIPMessage & offer
)
{
  B2BUserAgent & b2bua = 
    (B2BUserAgent &)GetSessionManager().GetUserAgent();
  return b2bua.OnRequireSDPOffer( *this, call, offer );
}

void B2BUAConnection::OnSetupOutbound( 
  const SIPMessage & inboundInvite 
)
{
  if( m_SessionState == Disconnected )
    return;

  B2BUserAgent & b2bua = 
    (B2BUserAgent &)GetSessionManager().GetUserAgent();

  SIPMessage outboundInvite = inboundInvite;
  outboundInvite.ClearInternalHeaders();
  outboundInvite.SetEncryption( FALSE );
  b2bua.OnSetupOutbound( outboundInvite, *this );
}

void B2BUAConnection::OnSessionKeepAliveTimeout(
  B2BUACall & call 
)
{
  SIPMessage msg; /// dummy event
  DestroyConnection( msg );
}

/** NIST Callbacks */
void B2BUAConnection::NIST_OnReceivedRegister(
  B2BUACall & call,
  const SIPMessage & msg
)
{
  SetSessionState( call, msg );
}

void B2BUAConnection::NIST_OnReceivedRefer(
  B2BUACall & call,
  const SIPMessage & msg
)
{
  SetSessionState( call, msg );
}

void B2BUAConnection::NIST_OnReceivedBye(
  B2BUACall & call,
  const SIPMessage & msg
)
{
  SetSessionState( call, msg );
}

void B2BUAConnection::NIST_OnReceivedOptions(
  B2BUACall & call,
  const SIPMessage & msg
)
{
  SetSessionState( call, msg );
}

void B2BUAConnection::NIST_OnReceivedInfo(
  B2BUACall & call,
  const SIPMessage & msg
)
{
  SetSessionState( call, msg );
}

void B2BUAConnection::NIST_OnReceivedMessage(
  B2BUACall & call,
  const SIPMessage & msg
)
{
  SetSessionState( call, msg );
}

void B2BUAConnection::NIST_OnReceivedCancel(
  B2BUACall & call,
  const SIPMessage & msg
)
{
  SetSessionState( call, msg );
}

void B2BUAConnection::NIST_OnReceivedNotify(
  B2BUACall & call,
  const SIPMessage & msg
)
{
  SetSessionState( call, msg );
}

void B2BUAConnection::NIST_OnReceivedSubscribe(
  B2BUACall & call,
  const SIPMessage & msg
)
{
  SetSessionState( call, msg );
}

void B2BUAConnection::NIST_OnReceivedUnknown(
  B2BUACall & call,
  const SIPMessage & msg
)
{
  SetSessionState( call, msg );
}
void B2BUAConnection::IST_OnReceivedMoreInvite(
  B2BUACall & call,
  const SIPMessage & msg
)
{
  SetSessionState( call, msg );
}

void B2BUAConnection::IST_OnReceivedAck(
  B2BUACall & call,
  const SIPMessage & msg
)
{
  SetSessionState( call, msg );
}

/** NICT CALLBACKS */


void B2BUAConnection::NICT_OnReceived1xx(
  B2BUACall & call,
  const SIPMessage & msg
)
{
  SetSessionState( call, msg );
}

void B2BUAConnection::NICT_OnReceived2xx(
  B2BUACall & call,
  const SIPMessage & msg
)
{
  SetSessionState( call, msg );
}

void B2BUAConnection::NICT_OnReceived3xx(
  B2BUACall & call,
  const SIPMessage & msg
)
{
  SetSessionState( call, msg );
}

void B2BUAConnection::NICT_OnReceived4xx(
  B2BUACall & call,
  const SIPMessage & msg
)
{
  SetSessionState( call, msg );
}

void B2BUAConnection::NICT_OnReceived5xx(
  B2BUACall & call,
  const SIPMessage & msg
)
{
  SetSessionState( call, msg );
}

void B2BUAConnection::NICT_OnReceived6xx(
  B2BUACall & call,
  const SIPMessage & msg
)
{
  SetSessionState( call, msg );
}

void B2BUAConnection::NICT_OnReceivedUnknown(
  B2BUACall & call,
  const SIPMessage & msg
)
{
  SetSessionState( call, msg );
}

/** ICT CALLBACKS */

void B2BUAConnection::ICT_OnReceived1xx(
  B2BUACall & call,
  const SIPMessage & msg
)
{
  SetSessionState( call, msg );
}

void B2BUAConnection::ICT_OnReceived2xx(
  B2BUACall & call,
  const SIPMessage & msg
)
{
  SetSessionState( call, msg );
}

void B2BUAConnection::ICT_OnReceived3xx(
  B2BUACall & call,
  const SIPMessage & msg
)
{
  SetSessionState( call, msg );
}

void B2BUAConnection::ICT_OnReceived4xx(
  B2BUACall & call,
  const SIPMessage & msg
)
{
  SetSessionState( call, msg );
}

void B2BUAConnection::ICT_OnReceived5xx(
  B2BUACall & call,
  const SIPMessage & msg
)
{
  SetSessionState( call, msg );
}

void B2BUAConnection::ICT_OnReceived6xx(
  B2BUACall & call,
  const SIPMessage & msg
)
{
  SetSessionState( call, msg );
}

void B2BUAConnection::ICT_OnReceivedUnknown(
  B2BUACall & call,
  const SIPMessage & msg
)
{
  SetSessionState( call, msg );
}

void B2BUAConnection::SetSessionState(
  B2BUACall & call,
  const SIPMessage & msg
)
{
  PWaitAndSignal lock( m_SessionStateMutex );
  if( !IsSafeReference() )
    return;
  
  if( m_SessionState < Connected 
    && m_SessionState != Transferring 
    && m_SessionState != RemoteAuthenticationPending
    && m_SessionState != CancelPending)
  {
    OnHandlePreConnectState( call, msg );
  }else if( m_SessionState == Transferring )
  {
    OnHandleStateTransferring( call, msg );
  }else if( m_SessionState == RemoteAuthenticationPending )
  {
    OnHandleStateAuthenticationPending( call, msg );
  }else if( m_SessionState == CancelPending )
  {
    OnHandleStateCancelPending( call, msg );
  }else if( m_SessionState == Connected || m_SessionState == Disconnecting )
  {
    OnHandleStateConnected( call, msg );
  }else if( m_SessionState == Disconnected )
  {
    OnHandleStateDisconnected( call, msg );
  }else if( m_SessionState == Terminated )
  {
    OnHandleStateTerminated( call, msg );
  }else
  {
    PAssertAlways( PLogicError );
  }
}

/*
void B2BUAConnection::SetSessionState(
  B2BUACall & call,
  int event
)
{
  PWaitAndSignal lock( m_SessionStateMutex );
  
  if( m_SessionState == Idle )
  {
  }else if( m_SessionState == Trying )
  {
  }else if( m_SessionState == Proceeding )
  {
  }else if( m_SessionState == Connected )
  {
  }else if( m_SessionState == Disconnected )
  {
  }else if( m_SessionState == Terminated )
  {
  }else
  {
    PAssertAlways( PLogicError );
  }
}
*/

void B2BUAConnection::OnOutgoingCall(
  B2BUACall & call,
  SIPMessage & outboundInvite 
)
{
  B2BUserAgent& b2bUA = (B2BUserAgent&)GetSessionManager().GetUserAgent();
  b2bUA.OnOutgoingCall( *this, call, outboundInvite );
}

BOOL B2BUAConnection::OnRouteCallRedirect(
  B2BUACall & call,
  SIPMessage & invite
)
{
  B2BUserAgent& b2bUA = (B2BUserAgent&)GetSessionManager().GetUserAgent();
  return b2bUA.OnRouteCallRedirect( *this, call, invite );
}

void B2BUAConnection::OnAckFor200OkExpire(
  B2BUACall & call
)
{
  EnqueueSessionEvent( new SIPSessionEvent( *this, B2BUAConnection::ErrorAckTimeout ) );
}

void B2BUAConnection::OnHandleLocalRefer( 
  B2BUACall & call,
  SIPMessage & refer 
)
{
  m_IsLocalTransferedCall = FALSE;
  B2BUserAgent& b2bUA = (B2BUserAgent&)GetSessionManager().GetUserAgent();
  b2bUA.OnLocalRefer( *this, call, refer );
  SIPMessage response;
  refer.CreateResponse( response, SIPMessage::Code202_Accepted );
  call.SendRequest( response, refer.GetTransaction() );

  /// reset media flags
  m_HasReceivedSDP = FALSE;
  m_HasStartedAudioStream = FALSE;
  m_HasStartedVideoStream = FALSE;

  B2BMediaInterface::OpalMediaThread * audioThread = 
    (B2BMediaInterface::OpalMediaThread*)call.GetAudioRTPSessionThread();

  if( audioThread != NULL )
    audioThread->ForceExit();

  B2BMediaInterface::OpalMediaThread * videoThread = 
    (B2BMediaInterface::OpalMediaThread*)call.GetVideoRTPSessionThread();

  if( videoThread != NULL )
    videoThread->ForceExit();
  
  B2BUACall * otherEnd = NULL;
  SDPLazyParser sdp;
  if( call.GetLegIndex() == 0 )
  {
    otherEnd = m_Leg2Call;
    sdp = GetLeg2TranslatedSDP();
    sdp.IncrementVersion();
    SetLeg2TranslatedSDP( sdp );
    m_CallTransferIndex = 0;
  }else
  {
    otherEnd = m_Leg1Call;
    sdp = GetLeg1TranslatedSDP();
    sdp.IncrementVersion();
    SetLeg1TranslatedSDP( sdp );
    m_CallTransferIndex = 1;
  }

  /// set the session so that we get a special handler for REFER
  m_SessionState = Transferring;

  SIPMessage invite;

  /// Get the refer-to URI
  ReferTo referTo; 
  refer.GetReferTo( referTo );
  SIPURI requestURI = referTo.GetURI();

  /// create the request line
  RequestLine requestLine;
  requestLine.SetMethod( "INVITE" );
  requestLine.SetRequestURI( requestURI );
  invite.SetStartLine( requestLine );

  PIPSocket::Address targetAddress = requestURI.GetAddress();

  Via via;
  GetSessionManager().ConstructVia( targetAddress, via, SIPTransport::UDP );
  via.SetBranch( ParserTools::GenBranchParameter() );
  via.AddParameter( "rport", "" );
  invite.AppendVia( via );

  /// Set From header
  From from;
  from.SetURI( otherEnd->GetRemoteURI() );
  from.AddParameter( "tag", ParserTools::GenTagParameter() );
  invite.SetFrom( from );

  /// Set To header
  To to;
  to.SetURI( requestURI );
  invite.SetTo( to );

  /// Set the call Id
  CallId callId;
  OString cid = GetLeg1Call()->GetCallId();
  callId.SetHeaderBody( cid );
  invite.SetCallId( callId );

  /// Set the CSeq
  CSeq cSeq;
  cSeq.SetMethod( "INVITE" );
  cSeq.SetSequence( 4711 );
  invite.SetCSeq( cSeq );

  /// Set the contact
  SIPURI contactURI = from.GetURI();
  contactURI.SetHost( via.GetURI().GetHost() );
  contactURI.SetPort( via.GetURI().GetPort() );
  ContactURI contact( contactURI, m_SessionProfile.GetDisplayName() );
  invite.AppendContact( contact );
  
  /// Set the allow header for Requests we support
  OStringArray allowed;
  allowed.AppendString( "INVITE" );
  allowed.AppendString( "BYE" );
  allowed.AppendString( "ACK" );
  allowed.AppendString( "REFER" );
  allowed.AppendString( "MESSAGE" );
  allowed.AppendString( "INFO" );
  allowed.AppendString( "NOTIFY" );
  allowed.AppendString( "OPTIONS" );
  allowed.AppendString( "PRACK" );
  Allow allow( allowed );
  invite.AppendAllow( allow );

  invite.SetSDP( sdp );

  RemoveRoutes();
  
  if( m_CallController == NULL )
    b2bUA.OnHandleLocalRefer( *this, call, invite );
  else
    m_CallController->SetupOutbound( invite );

  EnqueueSessionEvent( new SIPSessionEvent( *this, B2BUAConnection::SetupOutbound, invite ) );
}

void B2BUAConnection::SendLocalReinvite( 
  B2BUACall & callToReInvite
)
{
  ///OnRequireSDPOffer(
  /*
  SDPLazyParser sdp;
  if( callToReInvite.GetLegIndex() == 0 )
  {
    sdp = GetLeg2TranslatedSDP();
    sdp.IncrementVersion();
    SetLeg2TranslatedSDP( sdp );
  }else
  {
    sdp = GetLeg1TranslatedSDP();
    sdp.IncrementVersion();
    SetLeg1TranslatedSDP( sdp );
  }*/

  SIPMessage invite;
  if( callToReInvite.CreateRequestWithinDialog( SIPMessage::Method_INVITE, invite ) )
  {
    //invite.SetBody( sdp );
    //invite.SetContentType( "application/sdp" );
    OnRequireSDPOffer( callToReInvite, invite );
    m_IsReinvitingLocally = TRUE;
    LOG( LogInfo(), "*** LOCAL RE-INVITE *** " << GetSessionManager().GetUserAgent().GetUserAgentName() << " " << invite.GetToURI() );
    callToReInvite.SendRequest( invite );

  }
}

void B2BUAConnection::OnHandlePreConnectState( 
  B2BUACall & call,
  const SIPMessage & message
)
{
  B2BUserAgent& b2bUA = (B2BUserAgent&)GetSessionManager().GetUserAgent();

  if( m_IsMergedConnection && message.IsResponse() && OnReceivedResponseToMergedInvite( call, message ) )
    return;
  else if( message.IsCancel() && call.IsMergedCall() && OnReceivedMergedCancel( call, message ) )
    return;

  SIPMessage msg = message;

  if( call.GetLegIndex() == 1 )
  {
    if( msg.GetCSeqMethod() *= "INVITE" )
    {
      if( msg.Is1xx() )
      {
        if( msg.GetStatusCode() == 100 )
        {
          m_SessionState = Trying;
          return;
        }else
        {
          m_SessionState = Proceeding;
          ///LOG( LogInfo(), "Connection: Alerting / SDP = " << ( msg.HasSDP() ? "TRUE" : "FALSE" ) );
          b2bUA.OnAlerting( *this, call, msg );
          
          if( m_IsExpectingSDPInACK )
            OnIncomingSDPOffer( call, msg );
          else
            OnIncomingSDPAnswer( call, msg );

          if( msg.HasSDP() )
          {
             if( m_IVRContext != NULL )
              IVROnOpenChannel( m_IVRContext );
          }
        }
      }else if( msg.Is2xx() )
      {
        LOG( LogInfo(), "*** CALL ESTABLISHED *** " << GetSessionId() );
        m_SessionState = Connected;
        OnConnected( call, msg );
        if( m_IsExpectingSDPInACK )
          OnIncomingSDPOffer( call, msg );
        else
          OnIncomingSDPAnswer( call, msg );

        if( m_IVRContext )
          IVROnOpenChannel( m_IVRContext );

        // check if we would post a warning message
        if( !m_200OkWarning.GetHeaderBody().IsEmpty() )
        {
          // for now we would overrider warning messages
          // with our warning message
          msg.SetWarning( m_200OkWarning );
        }

        ///LOG( LogInfo(), "Connection: Connected / SDP = " << ( msg.HasSDP() ? "TRUE" : "FALSE" ) );
        /// Start the session keep alive timer

        if( m_SendSessionKeepAlive )
        {
          GetLeg1Call()->StartSessionKeepAlive( GetKeepAliveInterval() * 1000 );
          GetLeg2Call()->StartSessionKeepAlive( GetKeepAliveInterval() * 1000 );
        }

      }else if( !msg.IsRequest() ) // 3xx - 6xx
      {
        int statusCode = msg.GetStatusCode();
        // check if we should fail over
        if( !msg.Is3xx() && 
             statusCode != 401 &&
             statusCode != 407 &&
             statusCode != 487 &&
            !m_HasReceivedSDP )
        {
          SIPMessage newInvite = m_Leg1Call->GetRequest();
          PWaitAndSignal routelock( m_RoutesMutex );
          if( m_Routes.GetSize() >= 1 )
          {
            /// append the Catch all route if defined
            if( m_Routes.GetSize() == 1 && m_UseCatchAllRoute )
            {
              LOG( LogDetail(), "*** TRYING CATCH ALL ROUTE *** " << GetCatchAllRoute() );
              m_Routes.Append( new SIPURI( GetCatchAllRoute() ) );
              m_UseCatchAllRoute = FALSE; /// make sure we dont use it twice
            }else if( m_Routes.GetSize() == 1 && m_WillSendAnnouncement )
            {
              LOG( LogDetail(), "*** SENDING ANNOUNEMENT *** " << GetAnnouncementServerURI() );
              m_Routes.Append( new SIPURI( GetAnnouncementServerURI() ) );
              m_WillSendAnnouncement = FALSE; /// make sure we dont use it twice
            }
              
            // destroy first leg 2 connection
            if( m_Leg2Call != NULL )
            {
              DetachCall( m_Leg2Call->GetCallId(), TRUE );
              m_Leg2Call->Destroy();
              m_Leg2Call = NULL;
            }

            /// Pop the last route that was used prior to fail-over
            if( m_Routes.GetSize() > 0 )
              m_Routes.RemoveAt( 0 );

            LOG( LogInfo(), "Connection: Rejected / Code = " << msg.GetStatusCode() );
            

            // OnRejected method might modify/update/remove the b2bua routes

            if( m_CallController != NULL )
            {
              m_CallController->OnTransferReject( msg );
              return;
            }else if( !m_Routes.IsEmpty() )
            {
              b2bUA.OnRejected( *this, call, msg );
              LOG( LogInfo(), "Connection: Failing over to other routes: Error " << msg.GetStatusCode() );
              Reason reason;
              OStringStream reasonText;
              reasonText << "SIP ;" << "cause=" << msg.GetStatusCode() << " ;" << "text=\"Call Fail-Over\"";   
              reason.SetHeaderBody( reasonText.str() );
              newInvite.SetReason( reason );
              OnSetupOutbound( newInvite );
              return;
            }
          } 
        } 

        // if message status is not 3xx then 
        // we should notify ua for rejection
        if( !msg.Is3xx() )
        {
          if(  statusCode != 401 && statusCode != 407 )
          {
            LOG( LogInfo(), "Connection: Rejected / Code = " << msg.GetStatusCode() );
            m_SessionState = Disconnected;
            b2bUA.OnRejected( *this, call, msg );
          }else
          {
            m_SessionState = RemoteAuthenticationPending;
            /// start the auto destructor timer at the value of Timer B
            StartAutoDestructTimer( 32000 );
            SIPMessage challenge;
            if( statusCode == 401 )
            {
              GetLeg1Call()->GetCurrentUASInvite().CreateResponse( challenge, SIPMessage::Code401_Unauthorized, "", TRUE );
              WWWAuthenticate auth;
              if( msg.GetWWWAuthenticate( auth ) )
                challenge.SetWWWAuthenticate( auth );
            }else if( statusCode == 407 )
            {
              GetLeg1Call()->GetCurrentUASInvite().CreateResponse( challenge, SIPMessage::Code407_ProxyAuthenticationRequired,"", TRUE );
              ProxyAuthenticate auth;
              if( msg.GetProxyAuthenticate( auth ) )
                challenge.SetProxyAuthenticate( auth );
            }

            GetLeg1Call()->SendRequest( challenge, GetLeg1Call()->GetCurrentUASInvite().GetTransaction() );

            return;
          }
        }else
        {
          /// just return as if nothing happend, call is now about to be redirected
          
          return;
        }
      }

      GetLeg1Call()->AnswerB2BCall( call, msg );
    }
  }else if( call.GetLegIndex() == 0 )
  {
    if( msg.IsCancel() )
    {
      SIPMessage ok;
      msg.CreateResponse( ok, SIPMessage::Code200_Ok );
      call.SendRequest( ok, msg.GetTransaction() );
      SIPMessage reqCancelled;
      call.GetRequest().CreateResponse( reqCancelled, SIPMessage::Code487_RequestCancelled );
      call.SendRequest( reqCancelled, call.GetRequest().GetTransaction() );
      
      if( m_SessionState < Connected )
      {
          B2BUACall * leg2Call = GetLeg2Call();
          if( leg2Call )
            leg2Call->SendCancel();
      }
      
      //if( m_IsMergedConnection )
      //{
        /// The two lines below is how we should do CANCEL PENDING STATE 
        /// To allow the call to linger and WAIT for new INVITEs or CANCELs that might be a
        /// byproduct of serial forking
        //m_SessionState = CancelPending;
        //StartAutoDestructTimer( 32000 );
      //}else
      //{
        m_SessionState = Disconnected;
      //}

      LOG( LogInfo(), "*** CALL ABANDONED *** " << GetSessionId() );    
      b2bUA.OnCallAbandoned( *this, call, msg );
    }else if( msg.IsInvite() )
    {
      /// we got a new invite while the call is still in preconnect
      /// This is probably because this INVITE is a forked of
      /// the previous invite but with a different r-uri
      
      SIPURI oldRURI, newRURI;
      const SIPMessage & oldInvite = call.GetCurrentUASInvite();
      oldInvite.GetRequestURI( oldRURI );
      msg.GetRequestURI( newRURI );

      if( oldRURI.GetUser() != newRURI.GetUser() )
      {
        /// ok different users.  lets check if this is actually a fork
        if( msg.GetFromTag() *= oldInvite.GetFromTag() )
        {
          /// ok this is a fork...
          OnReceivedMergedInvite( call, msg );
        }else
        {
          SIPMessage requestPending;
          msg.CreateResponse( requestPending, SIPMessage::Code491_RequestPending );
          call.SendRequest( requestPending, msg.GetTransaction() );
        }
      }else
      {
        if( m_SessionState != LocalAuthenticationPending )
        {
          SIPMessage requestPending;
          msg.CreateResponse( requestPending, SIPMessage::Code491_RequestPending );
          call.SendRequest( requestPending, msg.GetTransaction() );
        }
      }
    }
  }

  if( m_SessionState == Disconnected )
  {
    ResourceCounter::IncrementFailedConnection();
    // if we receive disconnect then
    // stop all timer
    StopCallTimer();
    DestroyConnection( msg );    
  } 
}

void B2BUAConnection::OnHandleStateTransferring( 
  B2BUACall & call,
  const SIPMessage & message
)
{
  /// ignore events from the referrer call
  if( call.IsReferrerCall() )
  {
    LOG( LogWarning(), "OnHandleStateTransferring - Ignoring " << message.GetMethod() );
    return;
  }

  LOG_IF_DEBUG( LogDebugVeryHigh(), message );

  B2BUserAgent& b2bUA = (B2BUserAgent&)GetSessionManager().GetUserAgent();
  SIPMessage msg = message;
  if( !call.IsReferredCall() )
  {
    if( msg.IsBye() )
    {
      if( GetLeg1Call()->IsReferredCall() )
      {
        GetLeg1Call()->SendCancel();
        DetachCall( GetLeg1Call()->GetTransferedCall()->GetCallId(), TRUE );
        GetLeg1Call()->ReleaseTransferedCall();
        
      }else if( GetLeg2Call()->IsReferredCall() )
      {
        GetLeg2Call()->SendCancel();
        DetachCall( GetLeg2Call()->GetTransferedCall()->GetCallId(), TRUE );
        GetLeg2Call()->ReleaseTransferedCall();
      }

      m_SessionState = Disconnected;
      LOG( LogInfo(), "*** CALL ABANDONED *** " << GetSessionId() );
      b2bUA.OnCallAbandoned( *this, call, msg );
      DestroyConnection( msg );  
    }

    return;
  }

  

  if( msg.GetCSeqMethod() *= "INVITE" )
  {
    if( msg.Is1xx() )
    {
      if( msg.GetStatusCode() == 100 )
      {
        return;
      }else
      {
        ///LOG( LogInfo(), "Connection: Alerting / SDP = " << ( msg.HasSDP() ? "TRUE" : "FALSE" ) );
        b2bUA.OnAlerting( *this, call, msg );

        if( m_IsExpectingSDPInACK )
          OnIncomingSDPOffer( call, msg );
        else
          OnIncomingSDPAnswer( call, msg );

        if( m_HasReceivedSDP )
        {
          SIPMessage answer;
          OnRequireSDPAnswer( call, msg, answer );

          if( m_Leg1Call != NULL && m_Leg1Call->IsReferredCall() )
          {
            DetachCall( m_Leg1Call->GetTransferedCall()->GetCallId(), TRUE );
            m_Leg1Call->ReleaseTransferedCall();
            m_Leg1Call->SetReferredCall( FALSE );

            if( m_Leg2Call != NULL )
            {
              SendLocalReinvite( *m_Leg2Call );
            }
          }else if( m_Leg2Call != NULL && GetLeg2Call()->IsReferredCall() )
          {
            /** Do not detach the call here!!! or the 200 ok will not be processed */
            //DetachCall( m_Leg2Call->GetTransferedCall()->GetCallId(), TRUE );
            //m_Leg2Call->ReleaseTransferedCall();
            //m_Leg2Call->SetReferredCall( FALSE );

            if( m_Leg1Call != NULL )
            {
              SendLocalReinvite( *m_Leg1Call );
            }
          }
        }
      }
    }else if( msg.Is2xx() )
    {
      m_SessionState = Connected;
      
      // check if we would post a warning message
      if( !m_200OkWarning.GetHeaderBody().IsEmpty() )
      {
        // for now we would overrider warning messages
        // with our warning message
        msg.SetWarning( m_200OkWarning );
      }

      ///LOG( LogInfo(), "Connection: Connected / SDP = " << ( msg.HasSDP() ? "TRUE" : "FALSE" ) );
      /// Start the session keep alive timer

      if( m_SendSessionKeepAlive )
      {
        GetLeg1Call()->StartSessionKeepAlive( GetKeepAliveInterval() * 1000 );
        GetLeg2Call()->StartSessionKeepAlive( GetKeepAliveInterval() * 1000 );
      }

      if( m_IsExpectingSDPInACK )
        OnIncomingSDPOffer( call, msg );
      else
        OnIncomingSDPAnswer( call, msg );

      if( m_HasReceivedSDP )
      {
        SIPMessage answer;
        OnRequireSDPAnswer( call, msg, answer );
      }

      if( m_IVRContext )
        IVROnOpenChannel( m_IVRContext );

      if( m_Leg1Call != NULL && m_Leg1Call->IsReferredCall() )
      {
        DetachCall( m_Leg1Call->GetTransferedCall()->GetCallId(), TRUE );
        m_Leg1Call->ReleaseTransferedCall();
        m_Leg1Call->SetReferredCall( FALSE );

        if( m_Leg2Call != NULL )
          SendLocalReinvite( *m_Leg2Call );
      }else if( m_Leg2Call != NULL && GetLeg2Call()->IsReferredCall() )
      {
        DetachCall( m_Leg2Call->GetTransferedCall()->GetCallId(), TRUE );
        m_Leg2Call->ReleaseTransferedCall();
        m_Leg2Call->SetReferredCall( FALSE );

        if( m_Leg1Call != NULL )
          SendLocalReinvite( *m_Leg1Call );
      }

      OnConnected( call, msg );
      
    }else
    {
      DetachCall( call.GetTransferedCall()->GetCallId(), TRUE );
      call.ReleaseTransferedCall();
      call.SetReferredCall( FALSE );

	    if( m_IsLocalTransferedCall && m_IVRDestroyConnectionOnReject )
		    DestroyConnection( msg );
      else if( m_IsLocalTransferedCall && !m_IVRDestroyConnectionOnReject )
      {
        if( m_CallController != NULL )
          m_CallController->OnTransferReject( msg );
        else
          IVROnTransferReject( msg );
      }else
        DestroyConnection( msg );
    }
  }
}

void B2BUAConnection::OnHandleStateCancelPending( 
  B2BUACall & call,
  const SIPMessage & msg
)
{
  if( m_IsMergedConnection && msg.IsResponse() && OnReceivedResponseToMergedInvite( call, msg ) )
  {
    return;
  }else if( m_IsMergedConnection && msg.IsCancel() && call.IsMergedCall() && OnReceivedMergedCancel( call, msg ) )
  {
    return;
  }else if( msg.IsInvite() && call.GetType() == SIPSession::Server )
  {
    /// The main dialog has already been cancelled.   
    /// This may nly happen if the caller abandoned the call and not the forking proxy
    SIPMessage requestPending;
    msg.CreateResponse( requestPending, SIPMessage::Code491_RequestPending, "Call Abandonment Ongoing" ); 
    call.SendRequest( requestPending, msg.GetTransaction() );   
  }else if( msg.IsResponse() && call.GetType() == SIPSession::Client )
  {
    if( msg.Is2xx()  )
    {
      if( msg.GetCSeqMethod() *= "INVITE" )
      call.SendBye();
    }
    StartAutoDestructTimer( 5000 );
  }
}


void B2BUAConnection::OnHandleStateAuthenticationPending( 
  B2BUACall & call,
  const SIPMessage & msg
)
{
  if( msg.IsInvite() )
  {
    LOG( LogInfo(), "Got INVITE resend for RemoteAuthenticationPending" );
    StopAutoDestructTimer();
    /// Get a reference to the leg 2 call
    SIPSession::GCRef gcref = GCCREATEREF( GetLeg2Call(), "B2BUAConnection::OnHandleStateAuthenticationPending", "CallSession" );
    if( gcref == NULL )
    {
      SIPMessage response;
      msg.CreateResponse( response, SIPMessage::Code481_TransactionDoesNotExist );
      DestroyConnection(response);
      return;
    }
    
    SIPMessage oldUACInvite = GetLeg2Call()->GetCurrentUACInvite();
    if( !oldUACInvite.IsValid() )
    {
      SIPMessage response;
      msg.CreateResponse( response, SIPMessage::Code481_TransactionDoesNotExist );
      DestroyConnection(response);
      return;
    }
    
    if( msg.HasProxyAuthorization() )
    {
      ProxyAuthorization auth;
      if( msg.GetProxyAuthorization( auth ) )
        oldUACInvite.SetProxyAuthorization( auth );
      else
      {
        SIPMessage response;
        msg.CreateResponse( response, SIPMessage::Code481_TransactionDoesNotExist );
        DestroyConnection(response);
        return;
      }
    }else if( msg.HasAuthorization() )
    {
      Authorization auth;
      if( msg.GetAuthorization( auth ) )
        oldUACInvite.SetAuthorization( auth );
      else
      {
        SIPMessage response;
        msg.CreateResponse( response, SIPMessage::Code481_TransactionDoesNotExist );
        DestroyConnection(response);
        return;
      }
    }else
    {
      SIPMessage response;
      msg.CreateResponse( response, SIPMessage::Code481_TransactionDoesNotExist );
      DestroyConnection(response);
      return;
    }
    
    /// revert the state to trying
    m_SessionState = Trying;
    
   
    /// we got through the if bomabardments
    /// lets increment the CSeq before sending the invite outbound
    oldUACInvite.IncrementCSeq();

    // Just to make sure remove transaction in the SIPMessage
    // this transaction might be already destroyed
    oldUACInvite.SetTransaction( NULL );

    /// Lets change the via branch to ensure we don't collide with the old transaction
    Via via = oldUACInvite.PopTopVia();
    via.AddParameter( "branch", ParserTools::GenBranchParameter(), TRUE );
    oldUACInvite.AppendVia( via );

    LOG( LogDebugVeryHigh(), oldUACInvite );
    GetLeg2Call()->SetCurrentUACInvite( oldUACInvite );
    GetLeg2Call()->SendRequest( oldUACInvite );
    return;
  }
   
}

void B2BUAConnection::OnHandleStateConnected( 
  B2BUACall & call,
  const SIPMessage & msg
)
{
  if( m_IsMergedConnection )
  {
    //check if this msg is for the main branch
    if( msg.IsRequest() )
    {
      if( msg.GetFromTag() != call.GetRemoteTag() )
        if( OnReceivedMergedMidDialogMessage( call, msg ) )
          return;
    }else
    {
      if( msg.GetToTag() != call.GetRemoteTag() )
        if( OnReceivedMergedMidDialogMessage( call, msg ) )
          return;
    }
  }

  /// ignore messages from the referrer leg
  if( call.IsReferrerCall() )
    return;

  if( m_SessionState == Disconnecting )
    if( msg.GetCSeqMethod().ToUpper() != "BYE" )
      return;

  B2BUACall * otherEnd = NULL;
  if( call.GetLegIndex() == 0 )
    otherEnd = GetLeg2Call();
  else
    otherEnd = GetLeg1Call();


  if( msg.IsCancel() )
  { // cancel is not okayed automatically
    // by the CallSession so we need to ok it here
    // since we are already in connected state,
    // Cancel is already late so just do nothing but respond
    SIPMessage ok;
    msg.CreateResponse( ok, SIPMessage::Code481_TransactionDoesNotExist );
    call.SendRequest( ok, msg.GetTransaction() );
  }else if( msg.IsBye() )
  {
    otherEnd->SendBye();
    m_SessionState = Disconnecting;
#if 0
    StartAutoDestructTimer( 5000 );
#else
    DestroyConnection( msg );
#endif
  }else if( msg.IsInvite() )
  {
    
    if( m_ICTRequestPending )
    {
      SIPMessage requestPending;
      msg.CreateResponse( requestPending, SIPMessage::Code491_RequestPending );
      call.SendRequest( requestPending, msg.GetTransaction() );
    }else
    {
      if( msg.HasSDP() )
      {
        if( !m_EnableLocalRefer )
        {
          m_ICTRequestPending = TRUE;
          otherEnd->SendReinvite( msg );
        }else
        {
          ///we must handle hold locally
          SIPMessage ok;
          msg.CreateResponse( ok, SIPMessage::Code200_Ok );
          if( call.GetLegIndex() == 0 )
            ok.SetBody(GetLeg1TranslatedSDP());
          else
            ok.SetBody(GetLeg2TranslatedSDP() );
          ok.SetContentType( "application/sdp" );
          call.SendRequest( ok, msg.GetTransaction() );
        }
      }else
      {
        if( m_IsExpectingSDPInACK )
        { 
          m_ICTRequestPending = TRUE;
          SIPMessage clone;
          if( otherEnd->CloneRequestWithinDialog( msg, clone ) )
          {
            otherEnd->SendRequest( clone );
          }
        }
      }
    }
  }else if( msg.IsRefer() )
  {
    if( m_EnableLocalRefer )
    {
      SIPMessage refer = msg;
      OnHandleLocalRefer( call, refer ); 
    } else 
    {
      SIPMessage xferResponse;
      if( !otherEnd->SendB2BRefer( call, msg ) )
      {
        msg.CreateResponse( xferResponse, SIPMessage::Code406_NotAcceptable );
        call.SendRequest( xferResponse, msg.GetTransaction() );
      } else
      {
        msg.CreateResponse( xferResponse, SIPMessage::Code202_Accepted );

        SIPURI curi;
        curi.SetUser( otherEnd->GetRemoteURI().GetUser() );
        curi.SetHost( otherEnd->GetInterfaceAddress() );
        curi.SetPort( OString( otherEnd->GetInterfacePort() ) );
        ContactURI contactURI;
        contactURI.SetURI( curi );
        xferResponse.RemoveAllContact();
        xferResponse.AppendContact( contactURI );

        SendRequest( xferResponse, msg.GetTransaction() );
        StartAutoDestructTimer( 90000 );
      }
    } 
  }else if( msg.IsNotify() )
  {
    SIPMessage notifyResponse;
    if( !otherEnd->SendB2BNotify( call, msg ) )
    {
      msg.CreateResponse( notifyResponse, SIPMessage::Code406_NotAcceptable );
      call.SendRequest( notifyResponse, msg.GetTransaction() );
    }
  }else if( msg.IsAck() )
  {
    if( m_IsExpectingSDPInACK && msg.HasSDP() )
    {
        B2BUACall * otherEnd = NULL;
        if( call.GetLegIndex() == 0 )     
          otherEnd = GetLeg2Call();
        else
          otherEnd = GetLeg1Call();
        OnIncomingSDPAnswer( call, msg );
        if( m_HasReceivedSDP )
        {
          SIPMessage answer = msg;
          OnRequireSDPAnswer( call, msg, answer );
          otherEnd->SetSDPInACKAnswer( answer );
        }
    }
  }else if (msg.IsRequest() )  /// any request we skipped in all con ditions above
  {
    SIPMessage ok;
    msg.CreateResponse( ok, SIPMessage::Code200_Ok );
    call.SendRequest( ok, msg.GetTransaction() );
    
    SIPMessage clone;
    if( otherEnd->CloneRequestWithinDialog( msg, clone ) )
    {
      ContentType ctype;
      if( msg.GetContentType( ctype ) )
        clone.SetContentType( ctype );

      if( msg.HasBody() )
        clone.SetBody( msg.GetBody() );

      otherEnd->SendRequest( clone );
    }
  }else
  {
    if( msg.GetCSeqMethod() *= "INVITE" )
    {
      m_ICTRequestPending = FALSE;
      /*
      RTP_SessionManager & rtpManager = call.GetRTPSessionManager();
      RTP_UDP * rtp = (RTP_UDP *)rtpManager.GetSession( 
      OpalMediaFormat::DefaultAudioSessionID );
      if( rtp == NULL )*/
      if( !m_IsReinvitingLocally )
      {
        if( msg.Is2xx() )
        {
          if( msg.HasSDP() )
            OnIncomingSDPAnswer( call, msg );  /// process the new SDP
          otherEnd->SendB2BConnect( msg );
        }else if( msg.Is3xx() )
        {
          otherEnd->SendB2BRedirect( msg );
        }else if( msg.Is4xx() || msg.Is5xx() || msg.Is6xx() )
          otherEnd->SendB2BReject( msg );
      }else
      {
        if( !msg.Is1xx() )
          m_IsReinvitingLocally = FALSE;
      }
    }else if( msg.GetCSeqMethod() *= "BYE" )
    {
      if( m_SessionState == Disconnecting )
        m_SessionState = Disconnected;
    }
  }

  if( m_SessionState == Disconnected )
  {
    OnDisconnected( call, msg );
    DestroyConnection( msg );
  }  
}

void B2BUAConnection::OnHandleStateDisconnected( 
  B2BUACall & call,
  const SIPMessage & msg
)
{
  /// ignore messages from the referrer leg
  if( call.IsReferrerCall() )
    return;

  if( msg.IsRequest() )
  {
    SIPMessage response;
    msg.CreateResponse( response, SIPMessage::Code481_TransactionDoesNotExist );
    call.SendRequest( response, msg.GetTransaction() );
  }
}

void B2BUAConnection::OnHandleStateTerminated( 
  B2BUACall & call,
  const SIPMessage & msg
)
{
  /// ignore messages from the referrer leg
  if( call.IsReferrerCall() )
    return;

  if( msg.IsRequest() )
  {
    SIPMessage response;
    msg.CreateResponse( response, SIPMessage::Code481_TransactionDoesNotExist );
    call.SendRequest( response, msg.GetTransaction() );
  }
}

void B2BUAConnection::OnSessionEvent(
  SIPSessionEvent & sessionEvent
)
{
  int event = sessionEvent.GetEvent();
  const SIPMessage & eventMsg = sessionEvent.GetMessage();
  
  switch( event )
  {
    case SetupOutbound:
      OnSetupOutbound( eventMsg );
      break;
    case DestroySession:
      SetGCLifeSpan( 5 ); /// Lifespan set to 64 * T1
      Destroy();
      break;
    case ErrorAlertingTimeout:
    {
      if( GetSessionState() < B2BUAConnection::Connected )
      {
        LOG( LogWarning(), "!!! Alerting Timeout !!!" );
        SIPMessage newInvite = m_Leg1Call->GetRequest();
        PWaitAndSignal routelock( m_RoutesMutex );


        // destroy leg 2 connection
        if( m_Leg2Call != NULL )
        {
          DetachCall( m_Leg2Call->GetCallId(), TRUE );
          m_Leg2Call->SendCancel();
          m_Leg2Call->Destroy();
          m_Leg2Call = NULL;
        }

        if( !m_Routes.IsEmpty()  )
        {
          m_Routes.RemoveAt( 0 );
          if( m_SessionState < B2BUAConnection::Connected )
          {
            if( m_CallController != NULL )
            {
              SIPMessage response;
              newInvite.CreateResponse( response, SIPMessage::Code408_RequestTimeout );
              m_CallController->OnTransferReject( response );
              return;
            }else
            {
              if( m_Routes.GetSize() > 0 )
              {
                B2BUserAgent& b2bUA = (B2BUserAgent&)GetSessionManager().GetUserAgent();
                b2bUA.OnRejected( *this, *m_Leg2Call, eventMsg );
                LOG( LogInfo(), "Connection: Failing over to other routes: Error ALERTING TIMEOUT"  );
                Reason reason;
                OStringStream reasonText;
                reasonText << "SIP ;" << "cause=408 ;" << "text=\"Call Fail-Over\"";   
                reason.SetHeaderBody( reasonText.str() );
                newInvite.SetReason( reason );
                OnSetupOutbound( newInvite );
              }else
              {
                DestroyConnection( sessionEvent );
              }
            }
          }else
          {
            DestroyConnection( sessionEvent );
          }
        }
      }else
      {
        DestroyConnection( sessionEvent );
      }
      break;
    }
    case ErrorSeizeTimeout:
      LOG( LogWarning(), "!!! Seize Timeout !!!" );
      DestroyConnection( sessionEvent );
      break;
    case ErrorNoRoute:
      LOG( LogWarning(), "!!! No Route Available !!!" );
      DestroyConnection( sessionEvent );
      break;
    case ErrorRouteResolution:
      LOG( LogWarning(), "!!! Error Resolving Route !!!" );
      DestroyConnection( sessionEvent );
      break;
    case ErrorAckTimeout:
      LOG( LogWarning(), "!!! ACK Timeout !!!" );
      DestroyConnection( sessionEvent );
      break;
	  case ErrorScrewedUpState:
      LOG( LogWarning(), "!!! Invalid State !!!" );
      DestroyConnection( sessionEvent );
      break;
    case ErrorApplicationDisconnect:
      DestroyConnection( sessionEvent );
      break;
    case ErrorUnsupportedCodec:
      DestroyConnection( sessionEvent );
      break;
  }
}

void B2BUAConnection::DestroyConnection( 
  SIPSessionEvent & event 
)
{
  PWaitAndSignal lock( m_SessionStateMutex );
  if( m_IsConnectionBeingDestroyed )
    return;

  LOG( LogInfo(), "*** B2BUACONNECTION DESTRUCTION SEQUENCE STARTED" );
  SIPMessage msg = event.GetMessage();


  m_SelfDestructTimer.Stop();
  StopCallTimer();
  m_IsConnectionBeingDestroyed = TRUE;

  if( m_ConnectionDestructCause != 200 && msg.IsValid() && msg.IsResponse() )
    m_ConnectionDestructCause = msg.GetStatusCode();

  if( m_Leg1Call != NULL )
  {
    if( !m_IsDisconnected )
      OnDisconnected( *m_Leg1Call, msg ); 

    B2BMediaInterface::OpalMediaThread * audioThread = 
      (B2BMediaInterface::OpalMediaThread*)m_Leg1Call->GetAudioRTPSessionThread();

    if( audioThread != NULL )
      audioThread->ForceExit();

    B2BMediaInterface::OpalMediaThread * videoThread = 
      (B2BMediaInterface::OpalMediaThread*)m_Leg1Call->GetVideoRTPSessionThread();

    if( videoThread != NULL )
      videoThread->ForceExit();
  }

  if( m_Leg2Call != NULL )
  {
    B2BMediaInterface::OpalMediaThread * audioThread = 
      (B2BMediaInterface::OpalMediaThread*)m_Leg2Call->GetAudioRTPSessionThread();

    if( audioThread != NULL )
      audioThread->ForceExit();

    B2BMediaInterface::OpalMediaThread * videoThread = 
      (B2BMediaInterface::OpalMediaThread*)m_Leg2Call->GetVideoRTPSessionThread();

    if( videoThread != NULL )
      videoThread->ForceExit();
  }

  if( m_SessionState < Connected )
    ResourceCounter::IncrementFailedConnection();

  OnFinalizeCallDestruction( event );

  if( m_CallController == NULL )
    EnqueueSessionEvent( new SIPSessionEvent( *this, DestroySession, msg ) );
  else
  {
    m_CallController->Stop( msg );  /// let the call-controller enqueue the event
  }
}

void B2BUAConnection::OnFinalizeCallDestruction( SIPSessionEvent & event )
{
  
  if( m_SessionState == Connected )
  {
    m_Leg1Call->SendBye();
    if( m_Leg2Call != NULL )
      m_Leg2Call->SendBye();
  }else if( m_SessionState < Connected )
  {
    if( event.GetEvent() == ErrorNoRoute || event.GetEvent() == ErrorRouteResolution )
    {
      m_Leg1Call->SetCallAnswerResponse( CallSession::DisconnectWithNotFound );
    }else if( event.GetEvent() == ErrorAlertingTimeout || event.GetEvent() == ErrorSeizeTimeout )
    {
      m_Leg1Call->SetCallAnswerResponse( CallSession::DisconnectWithRequestTimeout );
    }else if( event.GetEvent() == ErrorUnsupportedCodec )
    {
      m_Leg1Call->SetCallAnswerResponse( CallSession::DisconnectWithNotAcceptableHere );
    }else if( event.GetEvent() == ErrorInternalServerError )
    {
      m_Leg1Call->SetCallAnswerResponse( CallSession::DisconnectWithServerInternalError );
    }

    SIPMessage previousInvite = m_Leg1Call->GetCurrentUASInvite();

    if( m_Leg1Call->GetCallAnswerResponse() 
      != CallSession::DisconnectWithUnauthorized && 
      m_Leg1Call->GetCallAnswerResponse() != CallSession::DontDeny
    )
    {
      SIPMessage reject;
      previousInvite.CreateResponse( reject, (SIPMessage::StatusCodes)m_Leg1Call->GetCallAnswerResponse() );
      
      if( !m_Leg1Call->GetCallAnswerResponseWarning().IsEmpty() )
      {
        Warning warning( m_Leg1Call->GetCallAnswerResponseWarning() );
        reject.SetWarning( warning );
      }
      
      SendRequest( reject, previousInvite.GetTransaction() );

      if( m_Leg2Call != NULL )
      {
        m_Leg2Call->SendCancel();
      }
    }
  }
}

void B2BUAConnection::DestroyConnection()
{
  SIPMessage dummy;
  m_ConnectionDestructCause = 200;
  DestroyConnection( dummy );
}

void B2BUAConnection::DestroyConnection(
  const SIPMessage & msg
)
{
  PWaitAndSignal lock( m_SessionStateMutex );
  if( m_IsConnectionBeingDestroyed )
    return;
  m_IsAboutToBeDestroyed = TRUE;
  LOG_CONTEXT( LogInfo(), GetSessionId(), "*** B2BUA CONNECTION QUEUED FOR DELETION ***" );
  EnqueueSessionEvent( new SIPSessionEvent( *this, ErrorApplicationDisconnect, msg ) );
}


void B2BUAConnection::OnDestroySession()
{
  //PWaitAndSignal lock( m_SessionStateMutex );
  if( m_ConnectionDestroyed )
    return;

 
  LOG_CONTEXT( LogInfo(), GetSessionId(), "*** B2BUA CONNECTION CLEANUP ***" );

  m_ConnectionDestroyed = TRUE;  

  --(dynamic_cast<B2BUAEndPoint &>(m_SessionManager).ConnectionCount);
  m_CanDecrementConnectionCount = FALSE;

  m_CanDecrementCounter = FALSE;
  ResourceCounter::DecrementConnection();

  m_Leg1Call->CloseMediaStreams();
  m_Leg1Call->DecrementResourceCounter();
  DetachCall( m_Leg1Call->GetCallId(), TRUE );
  m_Leg1Call->QueueForDestruction();
  
  if( m_Leg2Call != NULL )
  {
    m_Leg2Call->CloseMediaStreams();
    m_Leg2Call->DecrementResourceCounter();
    DetachCall( m_Leg2Call->GetCallId(), TRUE );
    m_Leg2Call->QueueForDestruction();
  }
}

void B2BUAConnection::OnSelfDestruct()
{
  DestroyConnection();
}

void B2BUAConnection::OnGCCollect()
{
  m_Leg1Call->PurgeDestructionQueue();
  if( m_Leg2Call != NULL )
    m_Leg2Call->PurgeDestructionQueue();

  m_CallSessions.AllowDeleteObjects();
  m_CallSessions.RemoveAll();

  m_Leg1Call = NULL;
  m_Leg2Call = NULL;
  
  if( m_ApplicationData )
  {
    delete m_ApplicationData;
    m_ApplicationData = NULL;
  }
}


OString B2BUAConnection::GenerateCallIdExtension()
{
  static PInt16 counter = 0;

  OStringStream stream;
  stream << "0x" << std::setw(4) << std::setfill('0') << std::hex << ++counter;
  return stream.str();
}

/// IVR related members
BOOL B2BUAConnection::AttachIVRContext(
  IVRContext * context
)
{
  PWaitAndSignal lock( m_IVRContextMutex );
  m_IVRContext = context;
  m_IVRContext->AttachB2BUAConnection( this );
  OnAttachIVRContext( context );
  return TRUE;
}

void B2BUAConnection::OnAttachIVRContext( 
  IVRContext * context 
)
{
  B2BUserAgent & b2bua = (B2BUserAgent &)GetSessionManager().GetUserAgent();
  b2bua.IVROnAttachContext( context );
}

BOOL B2BUAConnection::DetachIVRContext()
{
  PWaitAndSignal lock( m_IVRContextMutex );
  B2BUserAgent & b2bua = (B2BUserAgent &)GetSessionManager().GetUserAgent();
  b2bua.IVROnContextDetach( *this );
  OnDetachIVRContext();
  m_IVRContext = NULL;
  m_IsIVRChannelOpen = FALSE;
  return TRUE;
}

void B2BUAConnection::OnDetachIVRContext()
{
}

BOOL B2BUAConnection::IVRPlayText(
  const OString & text 
)
{
  PWaitAndSignal lock( m_IVRContextMutex );
  if( m_IVRContext == NULL )
    return FALSE;
  return m_IVRContext->PlayText( text, PTextToSpeech::Default, 0, 0 );
}

BOOL B2BUAConnection::IVRPlayFile(
  const OString & id,
  const OString & _fn,
  int delay
)
{
  PWaitAndSignal lock( m_IVRContextMutex );
  OString fn;
  if( _fn.ToLower().Right( 4 ) != ".wav" )
    fn = _fn + ".wav";
  else
    fn = _fn;

  LOG( LogInfo(), "*** IVR PLAY FILE *** ID: " << id << " FILE: " <<  fn );

  if( m_IVRContext == NULL )
  {
    IVROnEndPlaying( id );
    LOG( LogError(), "No IVR Context available to play file " << fn );
    return FALSE;
  }

  BOOL ok =  m_IVRContext->PlayFile( id, fn, 0, delay, FALSE );
  
  if( !ok )
  {
    LOG( LogError(), "*** IVR PLAY ERROR *** ID: " << id << " FILE: " <<  fn );
    IVROnEndPlaying( id );
  }

  return ok;
}

BOOL B2BUAConnection::IVRPlayData(
  const OString & id,
  const PBYTEArray & data
)
{
  PWaitAndSignal lock( m_IVRContextMutex );
  
  if( m_IVRContext == NULL )
    return FALSE;

  return m_IVRContext->PlayData( id, data, 0, 0 );
}

BOOL B2BUAConnection::IVRPlayResource(
  const OString & id,
  const PURL & url
)
{
  PWaitAndSignal lock( m_IVRContextMutex );
  
  if( m_IVRContext == NULL )
    return FALSE;

  return m_IVRContext->PlayResource( id, url, 0, 0 );
}

BOOL B2BUAConnection::IVRPlaySilence(
  PINDEX msecs
)
{
  PWaitAndSignal lock( m_IVRContextMutex );
  
  if( m_IVRContext == NULL )
    return FALSE;

  return m_IVRContext->PlaySilence( msecs );
}

BOOL B2BUAConnection::IVRPlaySilence(
  const PTimeInterval & timeout
)
{
  PWaitAndSignal lock( m_IVRContextMutex );
  
  if( m_IVRContext == NULL )
    return FALSE;

  return m_IVRContext->PlaySilence( timeout );
}

BOOL B2BUAConnection::IVRStartRecording(
  const PFilePath & fn, 
  BOOL recordDTMFTerm, 
  const PTimeInterval & recordMaxTime, 
  const PTimeInterval & recordFinalSilence
)
{
  PWaitAndSignal lock( m_IVRContextMutex );
  
  if( m_IVRContext == NULL )
    return FALSE;

  return m_IVRContext->StartRecording( fn, recordDTMFTerm, recordMaxTime, recordFinalSilence  );
}

BOOL B2BUAConnection::IVREndRecording()
{
  PWaitAndSignal lock( m_IVRContextMutex );
  
  if( m_IVRContext == NULL )
    return FALSE;

  return m_IVRContext->EndRecording();
}

BOOL B2BUAConnection::IVRIsPlaying() const
{
  PWaitAndSignal lock( m_IVRContextMutex );
  
  if( m_IVRContext == NULL )
    return FALSE;

  return m_IVRContext->IsPlaying();
}

BOOL B2BUAConnection::IVRIsRecording() const
{
  PWaitAndSignal lock( m_IVRContextMutex );
  
  if( m_IVRContext == NULL )
    return FALSE;

  return m_IVRContext->IsPlaying();
}

PTextToSpeech * B2BUAConnection::IVRSetTextToSpeech(
  PTextToSpeech * _tts, 
  BOOL autoDelete
)
{
  PWaitAndSignal lock( m_IVRContextMutex );
  
  if( m_IVRContext == NULL )
    return FALSE;

  return m_IVRContext->SetTextToSpeech( _tts, autoDelete );
}

PTextToSpeech * B2BUAConnection::IVRSetTextToSpeech(
  const OString & ttsName
)
{
  PWaitAndSignal lock( m_IVRContextMutex );
  
  if( m_IVRContext == NULL )
    return FALSE;

  return m_IVRContext->SetTextToSpeech( ttsName );
}

PTextToSpeech * B2BUAConnection::IVRGetTextToSpeech()
{
  PWaitAndSignal lock( m_IVRContextMutex );
  
  if( m_IVRContext == NULL )
    return FALSE;

  return m_IVRContext->GetTextToSpeech();
}

PString B2BUAConnection::IVRGetDTMFGrammarIdentifier()const
{
  PWaitAndSignal lock( m_IVRContextMutex );
  
  if( m_IVRContext == NULL )
    return PString::Empty();

  return m_IVRContext->GetDTMFGrammarIdentifier();
}

BOOL B2BUAConnection::IVRSetDTMFGrammar(
    const OString & identifier,
    int maxDigits, /// maximum digitd collected
    char termChar, /// terminating char to end collection
    BOOL canStopPlayBack,
    const PTimeInterval & collectTimeout,
    const PTimeInterval & perDigitTimeout,
    const OString & promptIdentifier
)
{
  PWaitAndSignal lock( m_IVRContextMutex );
  
  if( m_IVRContext == NULL )
    return FALSE;

  return m_IVRContext->SetDTMFGrammar( identifier, maxDigits, termChar, canStopPlayBack, collectTimeout, perDigitTimeout, promptIdentifier );
}

void B2BUAConnection::IVROnEndPlaying( 
  const OString & identifier 
)
{
  GCVERIFYREF_VOID( "B2BUAConnection::IVROnEndPlaying" );
  PTRACE( 1, "Stopped playing " << identifier );
  B2BUserAgent & b2bua = 
    (B2BUserAgent &)GetSessionManager().GetUserAgent();
  b2bua.IVROnEndPlaying( *this, identifier );
}

//BOOL B2BUAConnection::IVROnUserInput(
//  const OString & str
//)
//{
//  GCVERIFYREF( "B2BUAConnection::IVROnUserInput", FALSE ) ;
//  PTRACE( 1, "User Input: " << str );
//  B2BUserAgent & b2bua = 
//    (B2BUserAgent &)GetSessionManager().GetUserAgent();
//  return b2bua.IVROnUserInput( *this, str );
//}

BOOL B2BUAConnection::IVROnOpenChannel(
  IVRContext * context 
)
{
  GCVERIFYREF( "B2BUAConnection::IVROnOpenChannel", FALSE ) ;
  PWaitAndSignal lock( m_IVRContextMutex );
  if( m_IsIVRChannelOpen )
    return TRUE;

  B2BUserAgent & b2bua = (B2BUserAgent &)GetSessionManager().GetUserAgent();
  m_IsIVRChannelOpen = b2bua.IVROnOpenChannel( *this );
  return m_IsIVRChannelOpen;
}

void B2BUAConnection::IVROnEndCollection( 
  const OString &grammarId, 
  const OString &grammarBuffer 
)
{
  GCVERIFYREF_VOID( "B2BUAConnection::IVROnOpenChannel" ) ;
  B2BUserAgent & b2bua = 
    (B2BUserAgent &)GetSessionManager().GetUserAgent();
  b2bua.IVROnEndCollection( *this, grammarId, grammarBuffer );
}

void B2BUAConnection::IVROnTransferReject(
  const SIPMessage & reject
)
{
  GCVERIFYREF_VOID( "B2BUAConnection::IVROnTransferReject" ) ;
  B2BUserAgent & b2bua = 
    (B2BUserAgent &)GetSessionManager().GetUserAgent();
  b2bua.IVROnTransferReject( *this, reject );
}

BOOL B2BUAConnection::IVRTransferCall(
  const OString & destNumber,
  BOOL destroyConnectionOnReject
)
{
  GCVERIFYREF( "B2BUAConnection::IVRTransferCall", FALSE ) ;

  SIPURI destURI;
  if( destNumber.Find( "@" ) == P_MAX_INDEX )
  {
    destURI = GetLeg1Call()->GetCurrentUASInvite().GetToURI();
    destURI.SetUser( destNumber );
  }else
  {
    destURI = destNumber;
  }

  m_IVRDestroyConnectionOnReject = destroyConnectionOnReject;
  
  return TransferCallLocal( destURI, m_Leg2Call );

}

BOOL B2BUAConnection::TransferCallLocal(
  SIPURI requestURI,
  B2BUACall * call
)
{
  GCVERIFYREF( "B2BUAConnection::TransferCallLocal", FALSE ) ;

  OString sdp;

  B2BUACall * otherEnd = NULL;;
  if( call->GetLegIndex() == 1 )
  {
    otherEnd = m_Leg1Call;
    sdp = GetLeg1TranslatedSDP();
    m_CallTransferIndex = 1;
  }else
  {
    otherEnd = m_Leg2Call;
    sdp = GetLeg2TranslatedSDP();
    m_CallTransferIndex = 0;
  }

  SIPMessage invite;

  /// create the request line
  RequestLine requestLine;
  requestLine.SetMethod( "INVITE" );
  requestLine.SetRequestURI( requestURI );
  invite.SetStartLine( requestLine );

  PIPSocket::Address targetAddress = requestURI.GetAddress();

  Via via;
  GetSessionManager().ConstructVia( targetAddress, via, SIPTransport::UDP );
  via.SetBranch( ParserTools::GenBranchParameter() );
  via.AddParameter( "rport", "" );
  invite.AppendVia( via );

  /// Set From header
  From from;
  from.SetURI( otherEnd->GetLocalURI() );
  from.AddParameter( "tag", ParserTools::GenTagParameter() );
  invite.SetFrom( from );

  /// Set To header
  To to;
  to.SetURI( requestURI );
  invite.SetTo( to );

  /// Set the call Id
  CallId callId;
  OString cid = GetLeg1Call()->GetCallId();
  callId.SetHeaderBody( cid );
  invite.SetCallId( callId );

  /// Set the CSeq
  CSeq cSeq;
  cSeq.SetMethod( "INVITE" );
  cSeq.SetSequence( 4711 );
  invite.SetCSeq( cSeq );

  /// Set the contact
  SIPURI contactURI = from.GetURI();
  contactURI.SetHost( via.GetURI().GetHost() );
  contactURI.SetPort( via.GetURI().GetPort() );
  ContactURI contact( contactURI, m_SessionProfile.GetDisplayName() );
  invite.AppendContact( contact );
  
  /// Set the allow header for Requests we support
  OStringArray allowed;
  allowed.AppendString( "INVITE" );
  allowed.AppendString( "BYE" );
  allowed.AppendString( "ACK" );
  allowed.AppendString( "REFER" );
  allowed.AppendString( "MESSAGE" );
  allowed.AppendString( "INFO" );
  allowed.AppendString( "NOTIFY" );
  allowed.AppendString( "OPTIONS" );
  allowed.AppendString( "PRACK" );
  Allow allow( allowed );
  invite.AppendAllow( allow );

  invite.SetSDP( sdp );


  return TransferCallLocal( invite, call );
}

BOOL B2BUAConnection::TransferCallLocal(
  SIPMessage & invite,
  B2BUACall * call
)
{
  GCVERIFYREF( "B2BUAConnection::TransferCallLocal", FALSE ) ;
  
  if( call == NULL )
    return FALSE;

  B2BUserAgent& b2bUA = (B2BUserAgent&)GetSessionManager().GetUserAgent();
  /// reset media flags
  m_HasReceivedSDP = FALSE;
  m_HasStartedAudioStream = FALSE;
  m_HasStartedVideoStream = FALSE;
  m_IsLocalTransferedCall = TRUE;

  B2BMediaInterface::OpalMediaThread * audioThread = 
    (B2BMediaInterface::OpalMediaThread*)call->GetAudioRTPSessionThread();

  if( audioThread != NULL )
    audioThread->ForceExit();

  B2BMediaInterface::OpalMediaThread * videoThread = 
    (B2BMediaInterface::OpalMediaThread*)call->GetVideoRTPSessionThread();

  if( videoThread != NULL )
    videoThread->ForceExit();

  // we don't want to NOTIFY for transfer local, because a REFER is not used to initiate it.
  call->DisableCallTransferNotification();  
  call->SendBye();

  
  B2BUACall * otherEnd = NULL;;

  if( call->GetLegIndex() == 1 )
  {
    otherEnd = m_Leg1Call;
    m_CallTransferIndex = 1;
  }else
  {
    otherEnd = m_Leg2Call;
    m_CallTransferIndex = 0;
  }

  /// set the session so that we get a special handler for REFER
  m_SessionState = Transferring;

  RemoveRoutes();
  
  if( this->m_CallController == NULL )
    b2bUA.OnHandleLocalRefer( *this, *call, invite );
  else
    m_CallController->SetupOutbound( invite );

  EnqueueSessionEvent( new SIPSessionEvent( *this, B2BUAConnection::SetupOutbound, invite ) );

  return TRUE;
}


void B2BUAConnection::OnSendRequest(
  B2BUACall & call,
  SIPMessage & msg
)
{
}

void B2BUAConnection::OnReceivedRequest(
  B2BUACall & call,
  const SIPMessage & msg
)
{
  /// update the authorization dialog info
  if( msg.IsRequest() )
  {
    if( m_SessionState == Connected && call.GetLegIndex() == 0 )
    {
      if( GetLeg2Call() != NULL && ( GetLeg2Call()->HasLocalAuthorization() || GetLeg2Call()->HasLocalProxyAuthorization() ) )
      {
        
        if( msg.HasAuthorization()  && GetLeg2Call()->HasLocalAuthorization())
        {
          LOG( LogDebug(), "Updating dialog authorization dialog state" );
          Authorization auth;
          if( msg.GetAuthorization( auth ) )
            GetLeg2Call()->SetLocalAuthorization( auth );
        }else if( msg.HasProxyAuthorization() && GetLeg2Call()->HasLocalProxyAuthorization() )
        {
          LOG( LogDebug(), "Updating dialog proxy-authorization dialog state" );
          ProxyAuthorization auth;
          if( msg.GetProxyAuthorization( auth ) )
            GetLeg2Call()->SetLocalProxyAuthorization( auth );
        }
      }
    }
  }
}

BOOL B2BUAConnection::OnReceivedMergedInvite(
  B2BUACall & call,
  const SIPMessage & invite
)
{
  GCVERIFYREF( "B2BUAConnection::OnReceivedMergedInvite", FALSE );
  m_IsMergedConnection = TRUE;
  return dynamic_cast<B2BUserAgent &>(GetSessionManager().GetUserAgent()).OnReceivedMergedInvite( *this, call, invite );
}

BOOL B2BUAConnection::OnReceivedMergedCancel(
  B2BUACall & call,
  const SIPMessage & cancel
)
{
  GCVERIFYREF( "B2BUAConnection::OnReceivedMergedCancel", FALSE );
  m_IsMergedConnection = TRUE;
  return dynamic_cast<B2BUserAgent &>(GetSessionManager().GetUserAgent()).OnReceivedMergedCancel( *this, call, cancel );
}


BOOL B2BUAConnection::OnReceivedACKToMergedResponse(
  B2BUACall & call,
  const SIPMessage & ack
)
{
  GCVERIFYREF( "B2BUAConnection::OnReceivedACKToMergedResponse", FALSE );
  if( !m_IsMergedConnection )
    return FALSE;
  return dynamic_cast<B2BUserAgent &>(GetSessionManager().GetUserAgent()).OnReceivedACKToMergedResponse( *this, call, ack );
}

BOOL B2BUAConnection::OnReceivedResponseToMergedInvite(
  B2BUACall & call,
  const SIPMessage & response
)
{
  GCVERIFYREF( "B2BUAConnection::OnReceivedResponseToMergedInvite", FALSE );
  if( !m_IsMergedConnection )
    return FALSE;
  return dynamic_cast<B2BUserAgent &>(GetSessionManager().GetUserAgent()).OnReceivedResponseToMergedInvite( *this, call, response );
}

BOOL B2BUAConnection::OnReceivedMergedMidDialogMessage(
  B2BUACall & call,
  const SIPMessage & msg
)
{
  GCVERIFYREF( "B2BUAConnection::OnReceivedMergedMidDialogMessage", FALSE );
  if( !m_IsMergedConnection )
    return FALSE;
  return dynamic_cast<B2BUserAgent &>(GetSessionManager().GetUserAgent()).OnReceivedMergedMidDialogMessage( *this, call, msg );
} 

void B2BUAConnection::StartCallTimer()
{
  GCVERIFYREF_VOID( "B2BUAConnection::StartCallTimer" );
  if( m_CallInterval == 0 )
    m_CallInterval = PTimer::Tick();
}

void B2BUAConnection::StopCallTimer()
{
  GCVERIFYREF_VOID( "B2BUAConnection::StopCallTimer" );
  if( m_CallInterval == 0 )
      return;

  m_CallDuration = (PTimer::Tick() - m_CallInterval).GetMilliSeconds();
  m_CallInterval = 0;
}

void B2BUAConnection::AttachApplicationData( 
  PObject * appData 
)
{
  PWaitAndSignal scopedLock( m_AppDataMutex );
  if( m_ApplicationData )
  {
    delete m_ApplicationData;
    m_ApplicationData = NULL;
  }

  m_ApplicationData = appData;
}

PObject * B2BUAConnection::GetApplicationData()
{
  PWaitAndSignal scopedLock( m_AppDataMutex );
  return m_ApplicationData;
}


void B2BUAConnection::AddRoute( const SIPURI & _route, const SIPMessage * invite )
{
  PWaitAndSignal lock( m_RoutesMutex );
  SIPURI route = _route;
  if( route.GetScheme() != "sip" && route.GetScheme() != "sips" && m_CallController == NULL )
  {
    /// request a call controller for the unknown scheme
    B2BUserAgent & b2bua = dynamic_cast<B2BUserAgent &>(GetSessionManager().GetUserAgent());
    if( !b2bua.OnCreateExternalCallController( *this, route, invite ) )
      return;
  }
    
  m_Routes.Append( new SIPURI( route ) ); 
}

void B2BUAConnection::RemoveRoutes()
{
  PWaitAndSignal lock( m_RoutesMutex );
  m_Routes.RemoveAll();
}

void B2BUAConnection::ProcessCallArrivalQueue()
{
  PWaitAndSignal lock( m_QueuedCallArrivalMutex );
  if( m_HasProcessedQueuedCallArrival )
    return;
  m_HasProcessedQueuedCallArrival = TRUE;
  if( m_Leg1Call != NULL && m_QueuedCallArrival.GetType() == SIP::SIPStackEvent::Message )
  {
    m_Leg1Call->OnIncomingSIPMessage( m_QueuedCallArrival );
  }
}

void B2BUAConnection::OnConnected(
  B2BUACall & call,
  SIPMessage & msg 
)
{
  B2BUserAgent& b2bUA = (B2BUserAgent&)GetSessionManager().GetUserAgent();
  b2bUA.OnConnected( *this, call, msg );
  if( m_CallController != NULL )
    m_CallController->OnCallStart();
}

void B2BUAConnection::OnDisconnected(
      B2BUACall & call,
      const SIPMessage & msg )
{
  PWaitAndSignal lock( m_DisconnectMutex );
  if( m_IsDisconnected )
    return;

  StopCallTimer();

  if( m_CallController != NULL )
    m_CallController->OnCallStop();
  else
  {
    B2BUserAgent& b2bUA = (B2BUserAgent&)GetSessionManager().GetUserAgent();
    b2bUA.OnDisconnected( *this, call, msg );
  }

  m_IsDisconnected = TRUE;
  LOG( LogInfo(), "*** CALL TEAR DOWN *** " << GetSessionId() );
}

void B2BUAConnection::OnTimerExpire(
  B2BUACall & call,
  SIPTimerExpire & timerEvent
)
{
	if( timerEvent.GetTimer() == SIPTimerEvent::B || timerEvent.GetTimer() == SIPTimerEvent::TICTALERTING )
	  EnqueueSessionEvent( new SIPSessionEvent( *this, B2BUAConnection::ErrorAlertingTimeout ) );
	else if( timerEvent.GetTimer() == SIPTimerEvent::TICTCONNECT )
	  EnqueueSessionEvent( new SIPSessionEvent( *this, B2BUAConnection::ErrorSeizeTimeout ) );
}

void B2BUAConnection::OnReadRTPFrame( 
  B2BUACall * /*call*/, 
  const RTP_DataFrame & /*frame*/ 
)
{
}

