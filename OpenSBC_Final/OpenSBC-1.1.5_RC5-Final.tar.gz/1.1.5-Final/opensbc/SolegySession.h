/*
 *
 * SolegySession.h
 *
 * Open SIP Stack ( OSS )
 *
 * Copyright (c) opensipstack.org.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either expressed or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is OpenSIPStack.
 *
 * The Initial Developer of the Original Code is opensipstack.org.
 *
 * The author of this code is Joegen E. Baclor
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * The OpenSIPStack Library includes some GPL/LGPL code libraries that MAY be 
 * enabled at compile time using the --enable-gpllibs configure switch.  If
 * enabled, the content of this file is published under the terms of GNU 
 * General Public License Version 2.  For a detailed list of the available
 * GPL code, see $(opensipstack)/gnu/README file.
 *
 * $Log: SolegySession.h,v $
 * Revision 1.64  2009/06/19 09:59:22  joegenbaclor
 * Implemented temporary ban on no funds
 *
 * Revision 1.63  2009/06/09 10:33:30  joegenbaclor
 * adjusted setting of callstart
 *
 * Revision 1.62  2009/06/09 00:46:57  joegenbaclor
 * Invalidate route-cache if all attempts failed
 *
 * Revision 1.61  2009/06/08 06:30:45  joegenbaclor
 * Added route caching capability to solegy rtts client
 *
 * Revision 1.60  2009/05/26 04:58:07  joegenbaclor
 * added m_MEDIAPROXY support in AUTH
 *
 * Revision 1.59  2009/05/12 11:50:05  joegenbaclor
 * Adding ROUTE-ERROR list ehader support
 *
 * Revision 1.58  2009/05/12 09:34:43  joegenbaclor
 * Fixed bug in solegy route index
 *
 * Revision 1.57  2009/04/16 04:57:27  joegenbaclor
 * Updated authenticator support
 *
 * Revision 1.56  2009/04/14 02:00:10  joegenbaclor
 * Reverting Thread-based transport
 *
 * Revision 1.45  2009/03/14 11:19:02  joegenbaclor
 * added authenticator support in solegy auth
 *
 * Revision 1.44  2009/02/14 06:49:38  joegenbaclor
 * Maximized use of time mutex for rtts session list mutual access
 *
 * Revision 1.43  2009/02/12 13:44:26  joegenbaclor
 * removed timeout timer for errors
 *
 * Revision 1.42  2009/02/11 07:45:43  joegenbaclor
 * Putting a limit to failover
 *
 * Revision 1.41  2009/02/09 06:57:47  joegenbaclor
 * Fixed bug in CANCEL and INVITE timeout combo.
 *
 * Revision 1.40  2009/02/04 06:24:26  joegenbaclor
 * Minor bug fixes.  Added auto destruct timer to SoelgySession.  Added ability to disable local-reg and treat all regs as upper reg.
 *
 * Revision 1.39  2009/01/29 13:15:14  joegenbaclor
 * Implemented new queue for commands comming from b2bua connection towrds the solegy client
 *
 * Revision 1.38  2009/01/27 09:01:02  joegenbaclor
 * Encountered deadlock in STOP
 *
 * Revision 1.37  2009/01/25 03:02:21  joegenbaclor
 * Used events for retransmission timers to avoid locking up pwlib timer thread during
 *  heavy load
 *
 * Revision 1.36  2009/01/21 10:01:56  joegenbaclor
 * Marking bug fix for solegy START race condition
 *
 * Revision 1.35  2009/01/20 03:38:35  joegenbaclor
 * We modified SolegySessionManager::EnqueueEvent to check if the current packet is read from the same  active socket for the session.  If it came from a different socket other thatn the current socket, it will be silently dropped.  This will prevent the race condition brought about by START failover wherein a response  from the previous START attempt maybe interpreted as a response for the new failover ATTEMPT.  This would have been ok if Solegy RTTS allows START packet to have incrementing SEQ parameter since it can be dropped as stale.
 *
 * Revision 1.34  2009/01/08 12:14:32  joegenbaclor
 * Added state cookie support to allow calls to be disconnected upon restart of osbc
 *
 * Revision 1.33  2008/12/18 03:52:03  joegenbaclor
 * Introduced new failover rule.
 *
 * Revision 1.32  2008/11/14 02:57:42  joegenbaclor
 * Feature:  Interim call warning beep via INFO DTMF.
 *
 * Revision 1.31  2008/11/11 02:54:47  joegenbaclor
 * Feature:  Introducing RTTS aggregation of groomer and osbc
 * Bug:  Disconnect calls if ParseRouting has an empty result set
 *
 * Revision 1.30  2008/11/04 02:54:46  joegenbaclor
 * Modified timeouts and removed error blocks in sendign RTTS requests
 *
 * Revision 1.29  2008/10/27 09:44:04  joegenbaclor
 * Subclassing B2BUA objects to give OpenSBC a more fine grained control
 *
 * Revision 1.28  2008/10/22 05:06:25  joegenbaclor
 * Added MPL License Header
 *
 *
 */

#ifndef SOLEGYSESSION_H
#define SOLEGYSESSION_H

#include <ptclib/pxml.h>
#include <ptclib/http.h>
#include "SolegyParser.h"
#include "SolegySocket.h"
#include "SBCConnection.h"
#include "EventQueue.h"
#include "SolegyPromptManager.h"

#define AUTH_TIMEOUT      3000
#define SIGNIN_TIMEOUT    3000
#define SETUP_TIMEOUT     5000
#define CALLSTART_TIMEOUT 8000
#define CALLSTOP_TIMEOUT  8000
#define ERROR_RETRY_INTERVAL 100

using namespace B2BUA;
using namespace EQ;

class OpenSBC;

namespace SOLEGY
{
  class SolegySessionManager;

  class SolegySession : public B2BUAConnection::ExternalCallControl
  {
    PCLASSINFO( SolegySession, B2BUAConnection::ExternalCallControl );
  public:
    enum State{ NONE, START, AUTH, AUTHPENDING, SIGNIN, SETUP, RESET, CALLSTART, CALLSTOP, STOP, RTTS_ERROR, TERMINATED, NO_RESOURCE };
    
    SolegySession(
      SolegySessionManager * manager,
      SolegySocket * socket,
      B2BUAConnection * sipConnection,
      const char * localSessionId,
      BOOL accountingOff = FALSE,
      BOOL ignoreRouting = FALSE
    );

    virtual ~SolegySession();

    virtual BOOL SetupInbound( const  SIPMessage & invite );

    virtual void SetupOutbound( SIPMessage & invite );

    virtual void OnAllRouteExhausted(){};

    virtual BOOL AuthenticateInbound( const  SIPMessage & invite );

    BOOL WritePacket( BOOL isError = FALSE );
    
    virtual BOOL Start( const SIPMessage & msg  );
    virtual BOOL InternalStart( const SIPMessage & msg );

    virtual BOOL SendSTART();
    BOOL SendSTARTFailover();

    virtual BOOL InternalStop( const SIPMessage & msg );
    virtual BOOL Stop( const SIPMessage & msg );
    virtual BOOL SendSTOP();

    virtual BOOL SendAUTH();
    virtual BOOL OnPrepareAUTHInfo( 
      OStringStream & strm 
    );

    virtual BOOL SendSIGNIN();
    virtual BOOL OnPrepareSIGNINInfo(
      OStringStream & strm
    );

    virtual BOOL SendSETUP();
    virtual BOOL OnPrepareSETUPInfo(
      OStringStream & strm
    );

    virtual BOOL SendCALLSTART();
    virtual BOOL OnPrepareCALLSTARTInfo(
      OStringStream & strm
    );

    virtual BOOL SendCALLSTOP();
    virtual BOOL OnPrepareCALLSTOPInfo(
      OStringStream & strm
    );

    virtual BOOL SendERROR( int routeIndex );
    
    void DumpLog( const char * str );

    void DumpCallState();
    void RemoveCallState();

    virtual BOOL OnReceived_START( const OString & packet );
    virtual BOOL OnReceived_AUTH( const OString & packet );
    virtual BOOL OnReceived_SIGNIN( const OString & packet );
    virtual BOOL OnReceived_SETUP( const OString & packet );
    virtual BOOL OnReceived_CALLSTART( const OString & packet );
    virtual BOOL OnReceived_CALLSTOP( const OString & packet );
    virtual void OnReceived_START_ERROR( const OString & packet );
    virtual void OnReceived_AUTH_ERROR( const OString & packet );
    virtual void OnReceived_SIGNIN_ERROR( const OString & packet );
    virtual void OnReceived_SETUP_ERROR( const OString & packet );
    virtual void OnReceived_CALLSTART_ERROR( const OString & packet );
    virtual void OnReceived_CALLSTOP_ERROR( const OString & packet );
    virtual BOOL OnReceived_ERROR( const OString & packet );
    void OnReceived_TIMEOUT();
    virtual void OnReceived_START_TIMEOUT();
    virtual void OnReceived_AUTH_TIMEOUT();
    virtual void OnReceived_SIGNIN_TIMEOUT();
    virtual void OnReceived_SETUP_TIMEOUT();
    virtual void OnReceived_CALLSTART_TIMEOUT();
    virtual void OnReceived_CALLSTOP_TIMEOUT();
    virtual void OnReceived_STOP_TIMEOUT();

    virtual BOOL ProcessDigest( const OString & signin );
    virtual void OnCallStart();
    virtual void InternalOnCallStart();
    virtual void OnCallStop();
    virtual void InternalOnCallStop();
    virtual void OnTransferReject( const SIPMessage & reject );
    virtual void InternalOnTransferReject( const SIPMessage & reject );
    virtual void OnDumpCallAuditTrail();
    virtual void InternalOnDumpCallAuditTrail();

    void OnIVREvent(
      B2BUAConnection * conn,
      const B2BIVRInterface::B2BIVREvent * evt
    );

    void StartRetryTimer( const PTimeInterval & timeout );

    void StopRetryTimer();

    void StartErrorRetryTimer( const PTimeInterval & timeout );

    void StopErrorRetryTimer();

    void PrepareHeader( OStringStream & packet );

    void ProcessEvent();

    BOOL CallConnect();

    virtual void CallDisconnect( const OString & reason ) = 0;

    BOOL CheckSequence( const OString & packet );

    virtual void ProcessPacket( const OString & packet );

    void EnqueuePacket( const PString & packet );
    PString * DequeuePacket();

    virtual BOOL OnPrepareCDRReconInfo( PMIMEInfo & sendMIME );
    virtual BOOL OnDumpCDRReconfInfo( const PFilePath & file );

    PDECLARE_NOTIFIER( PTimer, SolegySession, OnRetryTimer );
    void OnRetryTimer();
    PDECLARE_NOTIFIER( PTimer, SolegySession, OnRetryTimeout );
    PDECLARE_NOTIFIER( PTimer, SolegySession, OnErrorRetryTimer );
    void OnErrorRetryTimer();
    PDECLARE_NOTIFIER( PTimer, SolegySession, OnCallTimerExpire );
    PDECLARE_NOTIFIER( PTimer, SolegySession, OnCallWarningTimerExpire );
    PDECLARE_NOTIFIER( PTimer, SolegySession, OnAutoDestructTimer );
    B2BUAConnection * GetB2BUAConnection(){ return m_B2BUAConnection; };
    State GetState()const{ return m_State; };
    const OString & GetLocalSessionId()const{ return m_LocalSessionId; };
    const OString & GetRemoteSessionId()const{ return m_RemoteSessionId; };
    BOOL IsFailoverCandidate( int code );
    PMutex & GetSocketMutex(){ return m_SocketMutex; };
    SolegySocket * GetSocket(){ return m_Socket; };
  public:
    OString m_BSID;
    OString m_AUTHORIZED;
    OString m_ACCOUNTID; /// this is the PIN collected from the user
    OString m_DIALSTRING; /// this is the tel-no collected from the user
    OString m_ORIGMEDIACODEC;
    OString m_ORIGMEDIADSTADDRESS;
    OString m_ORIGMEDIASRCADDRESS;
    OString m_TERMMEDIACODEC;
    OString m_TERMMEDIADSTADDRESS;
    OString m_TERMMEDIASRCADDRESS;
    OString m_BASICCHARGETIMELEFT;
    OString m_BASICBLOCKSLEFT;
    OString m_TIMELEFT;
    OString m_ORIGSDP;
    OString m_USERNAME;
    OString m_REALM;
    OString m_DIGEST;
    OString m_BRANDSERVICEID;
    OString m_MEDIAPROXY;
    OString m_HOST;

    OString m_EnableDurationPrompt;
    OString m_EnableNumberPrompt;
    OString m_EnableBalancePrompt;
    OString m_EnableDirectDial;
    OString m_EnableReconnect;
    OString m_EnableReset;
    OString m_EnableAuth;
    OString m_EnableUserAuth;
    OString m_GreetingDelay;
    OString m_SeizeTimeOut;
    OString m_PromptsLocation;
    OString m_GreetingPrompt;
    OString m_CriticalBalance;
    OString m_InputTimeout;
    BOOL m_EnableDigestProcessing;

    /// Stuffs we get from SETUP
    OString m_ROUTING;
  protected:
    OString m_ErrorString;
    OString m_STOPErrorString;
    OStringArray m_ErrorRouteList;
    SolegySessionManager * m_SessionManager;
    B2BUAConnection::GCRef m_SIPConnectionReference;
    SBCConnection * m_B2BUAConnection;
    PMutex m_B2BUAConnectionMutex;
    PMutex m_SocketMutex;
    SolegySocket * m_Socket;
    PMutex m_TimerMutex;
    PTimer m_RetryTimer;
    BOOL m_AbortRetry;
    int m_RetryTimerInterval;
    PTimer m_TimeoutTimer;
    PTimer m_ErrorRetryTimer;
    PTimer m_AutoDestructTimer;
    int m_ErrorRetryTimerInterval;
    PTimer m_ErrorTimeoutTimer;
    PTimer m_CallTimer;
    PTimer m_CallWarningTimer;
    WORD m_Sequence;
    OString m_RemoteSessionId;
    OString m_LocalSessionId;
    OString m_CurrentPacket;
    OString m_CurrentErrorPacket;
    PQUEUE(PacketQueue, PString );
    PMutex m_PacketQueueMutex;
    PacketQueue m_PacketQueue;
    State m_State;
    State m_LastFailoverState;
    State m_LastErrorState;
    WORD m_MaxStartRetryCount;
    SIPMessage m_STOPMessage;
    SIPMessage m_CurrentOutboundInvite;
    SIPMessage m_CurrentInboundInvite;
    BOOL m_HasReceivedSTART;
    BOOL m_AccountingOff;
    BOOL m_IgnoreRouting;
    
    OString m_AUTHResponse;
    OString m_SIGNINResponse;
    OString m_SETUPResponse;
    OString m_CALLSTOPResponse;
    OString m_BALANCE;

    PTime m_CallTryingTime;
    PTime m_CallStartTime;
    PTime m_CallStopTime;
    int m_CallDuration;
    int m_RingDuration;


    PLIST( RTBERouteList, SIPMessage );
    RTBERouteList m_RTBERouteList;
    PMutex m_RTBERouteListMutex;

    int m_CurrentRouteIndex;
    BOOL m_IsCallStopPending;
    BOOL m_SendStopOnCallStopEvent;
    BOOL m_CanSendCallStop;

    XBillingVector * m_BillingVector;
    XRoutingVector * m_RoutingVector;
    PFilePath m_StateFile;
    int m_FailoverCount;

    friend class SolegyPromptManager;
    friend class SolegySessionManager;
    public:
      virtual void OnIVRPromptTimeout(){};
  };
}

#endif

