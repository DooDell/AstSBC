/*
 *
 * SBCSIPTrunkEndPoint.cxx
 *
 * Open SIP Stack ( OSS )
 *
 * Copyright (c) opensipstack.org.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either expressed or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is OpenSIPStack.
 *
 * The Initial Developer of the Original Code is opensipstack.org.
 *
 * The author of this code is Joegen E. Baclor
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * The OpenSIPStack Library includes some GPL/LGPL code libraries that MAY be 
 * enabled at compile time using the --enable-gpllibs configure switch.  If
 * enabled, the content of this file is published under the terms of GNU 
 * General Public License Version 2.  For a detailed list of the available
 * GPL code, see $(opensipstack)/gnu/README file.
 *
 * $Log: SBCSIPTrunkEndPoint.cxx,v $
 * Revision 1.9  2009/06/01 03:16:55  joegenbaclor
 * Added outbound call class for sip trunks
 *
 * Revision 1.8  2009/05/27 12:40:34  joegenbaclor
 * Initial upload of switch related classes
 *
 * Revision 1.7  2009/05/05 11:37:58  joegenbaclor
 * updated deprecated functions used by xbase
 * updated MSVC 2005 Project files to include XBase classes
 *
 * Revision 1.6  2009/02/11 01:38:15  joegenbaclor
 * reverting configLock
 *
 * Revision 1.5  2008/12/08 06:03:08  joegenbaclor
 * Added OnCreateServerCallSession override to properly set error responses
 *
 * Revision 1.4  2007/10/30 16:39:36  joegenbaclor
 * Modified default thread count for trunks
 *
 * Revision 1.3  2007/10/17 03:17:39  joegenbaclor
 * More work on sip trunks
 *
 * Revision 1.2  2007/10/15 10:37:49  joegenbaclor
 * Minor bug fixes
 *
 * Revision 1.1  2007/10/02 16:42:56  joegenbaclor
 * Marking initial release of SIP Trunking
 *
 *
 */

#include "SBCSIPTrunk.h"
#include "OString.h"
#include "Version.h"
#include "SBCConfigParams.h"
#include "B2BUAConnection.h"
#include "B2BUAEndPoint.h"
#include "Encryption.h"
#include "SIPUDPTransport.h"
#include "SBCSIPTrunkReg.h"
#include "SBCSIPTrunkEndPoint.h"
#include "SBCSIPTrunkConnection.h"
#include "SBCSIPTrunkOutboundCall.h"

using namespace SIPTransports;

#define new PNEW

///////////////////////////////////////////////////////////


///////////////////////////////////////////////////////////
SBCSIPTrunkEndPoint::SBCSIPTrunkEndPoint(
    SBCSIPTrunk & ua
) : B2BUAEndPoint( ua, 1, 1024 * 2 )
{
}

SBCSIPTrunkEndPoint::~SBCSIPTrunkEndPoint()
{
}

B2BUAConnection * SBCSIPTrunkEndPoint::OnCreateB2BUA(
  const SIPMessage & request,
  const OString & _sessionId,
  B2BUACall * /*call*/
)
{
  OString sessionId = _sessionId + "-connection";
  SBCSIPTrunk & b2bua = (SBCSIPTrunk & )this->GetUserAgent();
  SBCSIPTrunkRoutingHandler * routeHandler = (SBCSIPTrunkRoutingHandler*)b2bua.GetRoutingInterface();
  SBCSIPTrunkReg * trunkReg = b2bua.GetTrunkRegManager()->GetSIPTrunkReg( request.GetToURI() );

  if( trunkReg == NULL )
    return NULL;
 
  SBCSIPTrunkConnection * connection = 
    new SBCSIPTrunkConnection( *this, sessionId, routeHandler, trunkReg );

  
  if( routeHandler->IsEgress( request ) )
  {
    OString egressUser, egressAuthUser, egressPassword;
    connection->SetEgress( TRUE );
    if( trunkReg->GetEgressAuthInfo( request, egressUser, egressAuthUser, egressPassword ) )
    {
      connection->SetEgressUser( egressUser.c_str() );
      connection->SetEgressAuthUser( egressAuthUser.c_str() );
      connection->SetEgressPassword( egressPassword.c_str() );
    }else
    {
      connection->SetEgressUser( "anonymous" );
      connection->SetEgressAuthUser( "anonymous" );
      connection->SetEgressPassword( "anonymous" );
    }
  }else
  {
    connection->SetEgress( FALSE );
  }
  
  connection->SetMediaProxyIfPrivate( TRUE );

  return connection;
}

B2BUAConnection * SBCSIPTrunkEndPoint::CreateB2BUA(
  const SIPMessage & request,
  B2BUACall * call
)
{
  if( !m_SessionsMutex.Wait( 50 ) )
    return NULL;

  OString sessionId = call->GetSessionId();

  B2BUAConnection * b2bua = OnCreateB2BUA( 
    request, 
    sessionId, 
    call 
  );

  if( b2bua == NULL )
  {
    m_SessionsMutex.Signal();
    return NULL;
  }

  b2bua->SetLogContextId( sessionId );

  b2bua->AttachCall( sessionId, call );

  b2bua->EnableLocalRefer( TRUE );
   
  m_SessionsBySessionId.SetAt( b2bua->GetSessionId().c_str(), b2bua );
  m_SessionsMutex.Signal();

  PWaitAndSignal lockCallId( m_SessionByCallIdMutex );
  m_SessionsBySessionId.SetAt( b2bua->GetSessionId().c_str(), b2bua );


  return b2bua;
}

CallSession * SBCSIPTrunkEndPoint::OnCreateServerCallSession(
  SIPMessage & request,
  const OString & sessionId
)
{
  if( !request.IsInvite() )
    return NULL;

  OString toTag = request.GetToTag();
  if( !toTag.IsEmpty() )
  {
    SIPMessage response;
    request.CreateResponse( response, SIPMessage::Code481_TransactionDoesNotExist, "None Existent Session" );
    
    
    SendRequest( response, NULL, request.GetTransaction() );
    return NULL;
  }

  /// incoming INVITE... create a session
  B2BUACall * call = new B2BUACall( *this, request, sessionId );
  call->SetLegIndex( 0 );
  B2BUAConnection * b2bua = CreateB2BUA( request, call );

  if( b2bua == NULL )
  { 
    /// this can only happen if the maximum connection  count has been reached
    SIPMessage response;
    OStringStream reason;
    reason << "No Trunk-Account Configured For User " << request.GetFrom().GetURI().GetUser();
    request.CreateResponse( response, SIPMessage::Code500_InternalServerError, reason.str().c_str() );
    SendRequest( response, NULL, request.GetTransaction() );
    delete call;
    return NULL;
  }

  call->SetB2BUAConnection( b2bua );

  return call;
}

CallSession * SBCSIPTrunkEndPoint::OnCreateClientCallSession(
  const ProfileUA & profile,
  const OString & sessionId
)
{
  SBCSIPTrunkOutboundCall * call = new SBCSIPTrunkOutboundCall( *this, sessionId, profile );
  call->SetLegIndex( 1 );
  call->EnableSessionTimer( m_EnableSessionTimer );
  return call;
}



