#import the C++ callback
cpp = __import__("cpp")
import sys

# Import PySNMP modules
from pysnmp import asn1, v1, v2c
from pysnmp import role

snmp_port = 161
snmp_iface = ''
snmp_community = None

def run():
	addr = [(snmp_iface, snmp_port)]
	server = role.agent( addr )

	active_iface = snmp_iface
	if( snmp_iface == '' ):
		active_iface = '*'
	
	cpp.eval( 'snmp.log', 'PySNMP Initialized on ' + active_iface + ':' + str(snmp_port)  )
	
	# Listen for SNMP messages from remote SNMP managers
	while 1:
		# Receive a request message
		(question, src) = server.receive()

		# Decode request of any version
		(req, rest) = v2c.decode(question)

		# Decode BER encoded Object IDs.
		oids = map(lambda x: x[0], map(asn1.OBJECTID().decode, \
									req['encoded_oids']))

		# Decode BER encoded values associated with Object IDs.
		vals = map(lambda x: x[0](), map(asn1.decode, req['encoded_vals']))
	    
		# Print it out
		cpp.eval( 'snmp.log', 'SNMP message from: ' + str(src) )
		cpp.eval( 'snmp.log', 'Version: ' + str(req['version']+1) + ', type: ' + str(req['tag']) )
		
		snmp_request_type = str(req['tag'])
		
		# Verify community name if needed
		if snmp_community is not None and req['community'] != snmp_community:
			cpp.eval( 'snmp.log',  'WARNING: UNMATCHED COMMUNITY NAME: ' + str(snmp_community) )
			continue
			
		encoded_vals = []
		
		for (oid, val) in map(None, oids, vals):
			if( snmp_request_type == 'GETREQUEST' ):
				snmp_val = cpp.eval( 'snmp.get', oid )
				cpp.eval( 'snmp.log',  oid + ' ---> ' + str(int(snmp_val)) )
				# Create a SNMP response objects from request object
				encoded_vals.append(asn1.INTEGER().encode(int(snmp_val)))

		rsp = req.reply()
		# Create a SNMP response objects from request object
		# Reply back to manager
		rsp['encoded_vals'] = encoded_vals
		server.send(rsp.encode(), src)




