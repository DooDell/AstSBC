#include "HTTPSession.h"
#include "HTTPSessionManager.h"
#include "OpenSBC.h"

HTTPSession::HTTPSession( 
  HTTPSessionManager * manager,
  B2BUAConnection * sipConnection
) 
{
  m_B2BUAConnection = sipConnection;
  m_SessionManager = manager;
  m_HTTPClient = new PHTTPClient( "OpenSBC HTTP Interface" );
  m_AuthPending = FALSE;
  m_IsMediaServerCall = FALSE;
  m_HasSetupMediaServer = FALSE;
}

HTTPSession::~HTTPSession()
{
  delete m_HTTPClient;
}

void HTTPSession::OnIVREvent(
  B2BUAConnection * conn,
  const B2BIVRInterface::B2BIVREvent * evt
)
{
  if( evt == NULL || conn == NULL  )
    return;

  //B2BIVRInterface::B2BIVREvent::Type type = evt->GetType();
  //if( type == B2BIVRInterface::B2BIVREvent::Event_IVROnUserInput || type == B2BIVRInterface::B2BIVREvent::Event_IVROnTransferReject )
  //  return;

  OString replyBody;
  PMIMEInfo replyMIME;
  if( SendIVREVENT( evt, replyMIME, replyBody ) )
  {
    ///handle playing of prompts
    for( int index = 0; index < 20; index++ )
    {
      
      OStringStream key;
      key << "X-CC-IVR-Play-Prompt_" << index;
      OString prompt = (const char*)replyMIME.GetString( key.str().c_str(), "" );
      if( prompt.IsEmpty() )
        break;
      
      SIPURI promptLocation = prompt;
      if( promptLocation.GetScheme() == "file" )
      {
        OString promptId = promptLocation.GetParameter("id");
        m_B2BUAConnection->IVRPlayFile( promptId, promptLocation.GetHost() );
      }else if( promptLocation.GetScheme() == "http" )
      {        
        //TODO handle HTTP here
      }
    }
    /// check if a grammar needs to be set
    OString digitGrammar = (const char *)replyMIME.GetString( "X-CC-IVR-Digit-Grammar", "" );
    if( !digitGrammar.IsEmpty() )
    {
      OStringArray funcVars;
      digitGrammar.Tokenise( funcVars, "," );
      if( funcVars.GetSize() == 6 )
      {
        OString identifier = funcVars[0];
		    int maxDigits = funcVars[1].AsInteger();
		    char termChar = funcVars[2][0];
		    BOOL canStopPlayBack = funcVars[3].AsInteger();
		    int collectTimeout = funcVars[4].AsInteger();
		    int perDigitTimeout = funcVars[5].AsInteger();
        m_B2BUAConnection->IVRSetDTMFGrammar( identifier, maxDigits, termChar, canStopPlayBack, collectTimeout, perDigitTimeout );
      }
    }else
    {
      /// check if we are requested to perform call transfer
      m_Routes = (const char*)replyMIME.GetString( "X-CC-IVR-Transfer", "" );
      if( !m_Routes.IsEmpty() )
      {
        m_B2BUAConnection->AddRoute( m_Routes );
        m_B2BUAConnection->IVRTransferCall( m_Routes, FALSE );
      }else
      {
        /// check if there is a disconnect command
        OString disconnectReason = (const char*)replyMIME.GetString( "X-CC-IVR-Call-Disconnect", "" );
        if( !disconnectReason.IsEmpty() )
          CallDisconnect( disconnectReason );
      }
    }
  }
}

BOOL HTTPSession::SendIVREVENT( 
  const B2BIVRInterface::B2BIVREvent * evt,
  PMIMEInfo & replyMIME, 
  OString & reply 
)
{
  PURL url = m_URLIVRResource;
 
  PMIMEInfo sendMIME;
  sendMIME.SetAt( "Server", url.GetHostName() );
  sendMIME.SetAt( PHTTP::ContentTypeTag, "application/x-www-form-urlencoded" );

  if(url.GetUserName() != "") {
      PStringStream authToken;
      authToken << url.GetUserName() << ":" << url.GetPassword();
      sendMIME.SetAt( "Authorization", PBase64::Encode(authToken) );
  }

  if( !OnPrepareSIPInfo( sendMIME ) )
    return FALSE;

  B2BIVRInterface::B2BIVREvent::Type type = evt->GetType();
  switch( type )
  {
    case B2BIVRInterface::B2BIVREvent::Event_IVROnOpenChannel:
      sendMIME.SetAt( "X-CC-Method", "IVROnOpenChannel" );
      break;
    case B2BIVRInterface::B2BIVREvent::Event_IVROnEndPlaying:
    {
      const B2BIVRInterface::OnEndPlaying * eventObject = static_cast<const B2BIVRInterface::OnEndPlaying *>(evt);
      sendMIME.SetAt( "X-CC-Method", "IVROnEndPlaying" );
      sendMIME.SetAt( "X-CC-IVR-Prompt-ID", eventObject->m_Identifier.c_str() );
    }
      break;
    case B2BIVRInterface::B2BIVREvent::Event_IVROnEndCollection:
    {
      const B2BIVRInterface::OnEndCollection * eventObject = static_cast<const B2BIVRInterface::OnEndCollection *>(evt);
      sendMIME.SetAt( "X-CC-Method", "IVROnEndCollection" );
      sendMIME.SetAt( "X-CC-IVR-Grammar-ID", eventObject->m_GrammarId.c_str() );
      if( !eventObject->m_GrammarBuffer.IsEmpty() )
        sendMIME.SetAt( "X-CC-IVR-Input-Buffer", eventObject->m_GrammarBuffer.c_str() );
      else
        sendMIME.SetAt( "X-CC-IVR-Input-Buffer", "null" );
    }
      break;
    default:
      break;
  }


  int cookieCount = m_IVRCookies.GetSize();
  for( int i = 0; i < cookieCount; i++ )
  {
    //X-CC-IVR-Cookie
    PString key = m_IVRCookies.GetKeyAt( i );
    sendMIME.SetAt( key, m_IVRCookies.GetDataAt(i) );
  }

  // Set thetimeout
  m_HTTPClient->SetReadTimeout( 5000 );

  // Send the POST request to the server
  BOOL ok = m_HTTPClient->PostData( url, sendMIME, "", replyMIME );
  

  // Find the length of the response
  PINDEX contentLength;
  if ( replyMIME.Contains( PHTTP::ContentLengthTag ) )
    contentLength = ( PINDEX ) replyMIME[ PHTTP::ContentLengthTag ].AsUnsigned();
  else if ( ok)
    contentLength = P_MAX_INDEX;
  else
    contentLength = 0;

  // Retrieve cookies
  int headerCount = replyMIME.GetSize();
  for( int i = 0; i < headerCount; i++ )
  {
    //X-CC-IVR-Cookie
    PString key = replyMIME.GetKeyAt( i );
    if( key.Left(15) == "X-CC-IVR-Cookie" )
    {
      m_IVRCookies.SetAt( key, replyMIME.GetDataAt(i) );
    }
  }

  PString replyBody = m_HTTPClient->ReadString( contentLength );
  PTRACE( 1, "HTTP MIME Response from:  " << url << endl << replyMIME << endl << endl << replyBody );  

  if( !ok )
  {
    // Retrieve the response
    
    PTRACE( 1, "HTTP Error: " << replyBody );
    CallDisconnect( "HTTP Handler Error" );
    reply = (const char *)replyBody;
    return FALSE;
  }

  
  return TRUE;
  
}

void HTTPSession::CallDisconnect( const OString & error )
{
  PWaitAndSignal lock( m_B2BUAConnectionMutex );
  if( m_B2BUAConnection != NULL && m_B2BUAConnection->IsSafeReference() )
  {
    const SIPMessage & invite = m_B2BUAConnection->GetCallArrivalQueue().GetMessage();
    SIPMessage response;
    invite.CreateResponse( response, SIPMessage::Code480_TemporarilyNotAvailable, error );
    if( m_B2BUAConnection->GetSessionState() < B2BUAConnection::Connected )
    {
      m_B2BUAConnection->GetLeg1Call()->SendRequest( response );
    }else
    {
      OStringStream reasonText;
      reasonText << "SIP ;" << "cause="  << SIPMessage::Code480_TemporarilyNotAvailable << " ;" << "text=\"" << error << "\"";
      m_B2BUAConnection->GetLeg1Call()->SendBye( reasonText.str().c_str() );
    }
    m_B2BUAConnection->DestroyConnection( response );
  }
}

BOOL HTTPSession::OnPrepareSIPInfo( PMIMEInfo & sendMIME  )
{
  if( !m_CurrentInboundInvite.IsValid() )
    return FALSE;

  sendMIME.SetAt( "X-CC-SIP-Call-ID", m_CurrentInboundInvite.GetCallId().c_str() );
  /// prepare request-uri
  SIPURI ruri = m_CurrentInboundInvite.GetRequestURI();
  sendMIME.SetAt( "X-CC-SIP-R-URI-User", ruri.GetUser().c_str() );
  sendMIME.SetAt( "X-CC-SIP-R-URI-Host", ruri.GetHost().c_str() );
  sendMIME.SetAt( "X-CC-SIP-R-URI-Port", ruri.GetPort().c_str() );

  /// prepare the from header
  const SIPURI & furi = m_CurrentInboundInvite.GetFromURI();
  sendMIME.SetAt( "X-CC-SIP-From-User", furi.GetUser().c_str() );
  sendMIME.SetAt( "X-CC-SIP-From-Host", furi.GetHost().c_str() );
  sendMIME.SetAt( "X-CC-SIP-From-Port", furi.GetPort().c_str() );
  sendMIME.SetAt( "X-CC-SIP-From-Display-Name", m_CurrentInboundInvite.GetFromDisplayName().c_str() );

  return true;
}

BOOL HTTPSession::Start( const SIPMessage & request )
{
  m_CurrentInboundInvite = request;
  OString replyBody;
  PMIMEInfo replyMIME;

  if( m_AuthPending && request.HasProxyAuthorization() )
  {
    if( OnHandleAuthPending( request ) )
    {
       if( !SendSETUP( replyMIME, replyBody ) )
         return FALSE;

       m_Routes = replyMIME.GetString( "X-CC-SIP-Route", "" );
       if( !m_Routes.IsEmpty() )
       {
         PWaitAndSignal lock( m_B2BUAConnectionMutex );
         if( m_B2BUAConnection != NULL && m_B2BUAConnection->IsSafeReference() )
         {
           m_B2BUAConnection->ProcessCallArrivalQueue();
         }

         return TRUE;
       }
    }
  }
 
  if( !SendAUTH( replyMIME, replyBody ) )
    return FALSE;
  
  OString authStatus = (const char *)replyMIME.GetString( "X-CC-AUTH-Status", "deny" );
  OString appLogic = (const char *)replyMIME.GetString( "X-CC-App-Logic", "wsdb" ); 
  m_IsMediaServerCall = (appLogic == "msdb");


  if( authStatus *= "accept" )
  {
    if( !m_IsMediaServerCall )
    {
      if( !SendSETUP( replyMIME, replyBody ) )
          return FALSE;

      
      m_Routes = replyMIME.GetString( "X-CC-AUTH-Route", "" );
      if( !m_Routes.IsEmpty() )
      {
        PWaitAndSignal lock( m_B2BUAConnectionMutex );
        if( m_B2BUAConnection != NULL && m_B2BUAConnection->IsSafeReference() )
        {
          m_B2BUAConnection->ProcessCallArrivalQueue();
        }

        return TRUE;
      }
    }else
    {
      PWaitAndSignal lock( m_B2BUAConnectionMutex );
        if( m_B2BUAConnection != NULL && m_B2BUAConnection->IsSafeReference() )
        {
          m_B2BUAConnection->ProcessCallArrivalQueue();
        }
    }
  }else if( authStatus *= "challenge" )
  {
    m_A1Hash = (const char *)replyMIME.GetString( "X-CC-AUTH-Hash", "" );
    OnHandleAuthChallenge( request );
  }else if( authStatus *= "deny" )
  {
    return OnHandleAuthDeny( replyMIME, replyBody );
  }
  
  return TRUE;
}

BOOL HTTPSession::Stop( const SIPMessage & msg )
{
  PWaitAndSignal lock2( m_B2BUAConnectionMutex );
  if( m_B2BUAConnection != NULL )
  {
    m_B2BUAConnection->AttachCallController( NULL );
    m_B2BUAConnection->EnqueueSessionEvent( new SIPSessionEvent( *m_B2BUAConnection, B2BUAConnection::DestroySession, msg ) );
    m_B2BUAConnection = NULL;
  }
  return TRUE;
}

BOOL HTTPSession::SetupInbound( const SIPMessage & /*invite*/ )
{
  return TRUE;
}

void HTTPSession::SetupOutbound( SIPMessage & invite )
{
  if( m_IsMediaServerCall && !m_HasSetupMediaServer )
  {
    PWaitAndSignal lock2( m_B2BUAConnectionMutex );
    if( m_B2BUAConnection != NULL && m_B2BUAConnection->IsSafeReference() )
    {
      OpenSBC * sbc = m_SessionManager->GetSBC();
      SIPURI annc( sbc->GetMediaServer()->GetListenerAddress(), sbc->GetMediaServer()->GetListenerPort() );
      annc.SetUser( "annc" );
      annc.AddParameter( "play", "prompts/basic/cant_complete.wav" );
      m_B2BUAConnection->RemoveRoutes();
      m_B2BUAConnection->AddRoute( annc );
      m_HasSetupMediaServer = TRUE;
    }
  }else
  {
    SIPURI route( m_Routes );
    invite.SetRequestURI( route );

    PWaitAndSignal lock2( m_B2BUAConnectionMutex );
    if( m_B2BUAConnection != NULL && m_B2BUAConnection->IsSafeReference() )
    {
      m_B2BUAConnection->RemoveRoutes();
      m_B2BUAConnection->AddRoute( route );
    }
  }
}

void HTTPSession::OnCallStart()
{
  OString reply;
  SendCALLSTART( reply );
}

void HTTPSession::OnCallStop()
{
  OString replyBody;
  SendCALLSTOP( replyBody );
}

void HTTPSession::OnTransferReject( const SIPMessage & /*reject*/ )
{
  OString reply;
  SendCALLREJECT( reply );
}

BOOL HTTPSession::SendAUTH( PMIMEInfo & replyMIME, OString & reply )
{
  PURL url = m_URLAuthResource;
 
  PMIMEInfo sendMIME;
  sendMIME.SetAt( "Server", url.GetHostName() );
  sendMIME.SetAt( PHTTP::ContentTypeTag, "application/x-www-form-urlencoded" );

  if(url.GetUserName() != "") {
      PStringStream authToken;
      authToken << url.GetUserName() << ":" << url.GetPassword();
      sendMIME.SetAt( "Authorization", PBase64::Encode(authToken) );
  }

  if( !OnPrepareSIPInfo( sendMIME ) )
    return FALSE;

  if( !OnPrepareAUTHInfo( sendMIME ) )
    return FALSE;

  // Set thetimeout
  m_HTTPClient->SetReadTimeout( 5000 );

  // Send the POST request to the server
  BOOL ok = m_HTTPClient->PostData( url, sendMIME, "", replyMIME );
  if( !ok )
  {
    CallDisconnect( "HTTP Handler Error" );
    return FALSE;
  }

  // Find the length of the response
  PINDEX contentLength;
  if ( replyMIME.Contains( PHTTP::ContentLengthTag ) )
    contentLength = ( PINDEX ) replyMIME[ PHTTP::ContentLengthTag ].AsUnsigned();
  else if ( ok)
    contentLength = P_MAX_INDEX;
  else
    contentLength = 0;

  // Retrieve the response
  PString replyBody = m_HTTPClient->ReadString( contentLength );
  PTRACE( 1, "HTTP MIME Response from:  " << url << endl << replyMIME << endl << endl << replyBody );
  if ( !ok ) 
    return FALSE;

  reply = (const char *)replyBody;
  return TRUE;
  
}

BOOL HTTPSession::OnHandleAuthDeny(PMIMEInfo & /*replyMIME*/, OString & /*replyBody*/)
{
  CallDisconnect( "Access Denied" );
  return TRUE;
}

BOOL HTTPSession::OnHandleAuthChallenge( const SIPMessage & request )
{
  MD5::Nonce opaque;
  MD5::Nonce nonce;

  SIPParser::From from;
  OString host = request.GetFrom().GetURI().GetHost();

  ProxyAuthenticate proxyAuthenticate;
  proxyAuthenticate.SetLeadString( "Digest" );
  proxyAuthenticate.AddParameter( "realm", host );
  proxyAuthenticate.AddParameter( "nonce", nonce.AsQuotedString() );
  proxyAuthenticate.AddParameter( "opaque", opaque.AsQuotedString() );
  proxyAuthenticate.AddParameter( "algorithm", "MD5" );

  PWaitAndSignal lock( m_B2BUAConnectionMutex );
  if( m_B2BUAConnection != NULL && m_B2BUAConnection->IsSafeReference() )
  {
    m_AuthPending = TRUE;
    m_B2BUAConnection->SetSessionState( B2BUAConnection::LocalAuthenticationPending );
    /// Stop the application timers to make sure they dont fire when we are in RemoteAuthenticationPending state
    //m_B2BUAConnection->StopSeizeTimer();
    //m_B2BUAConnection->StopAlertingTimer();
    /// start the auto destructor timer at the value of Timer B
    m_B2BUAConnection->StartAutoDestructTimer( 32000 );
    
    SIPMessage authChallenge;
    request.CreateResponse( authChallenge, 
    SIPMessage::Code407_ProxyAuthenticationRequired );
    authChallenge.SetProxyAuthenticate( proxyAuthenticate );
    m_B2BUAConnection->GetLeg1Call()->SendRequest( authChallenge, request.GetTransaction() );
  }

  return TRUE;
}

BOOL HTTPSession::OnHandleAuthPending( const SIPMessage & invite )
{
  ProxyAuthorization auth;
  if( !invite.GetProxyAuthorization( auth ) )
  {
    PTRACE( 1, "No Proxy Authorization Header in request" );
    CallDisconnect( "Invalid Authorization Header" );
    return FALSE;
  }

  OString userName;
  OString realm;
  OString uri;
  OString nonce;
  OString opaque;
  OString response;

  if( !auth.GetParameter( "username", userName ) )
  {
    PTRACE( 1, "No User Name specified in AUTHORIZATION" );
    CallDisconnect( "Invalid User" );
    return FALSE;
  }

  if( !auth.GetParameter( "realm", realm ) )
  {
    PTRACE( 1, "No Realm specified in AUTHORIZATION" );
    CallDisconnect( "Invalid Realm" );
    return FALSE;
  }

  if( !auth.GetParameter( "uri", uri ) )
  {
    PTRACE( 1, "No URI specified in AUTHORIZATION" );
    CallDisconnect( "Invalid Auhtorization URI" );
    return FALSE;
  }

  if( !auth.GetParameter( "nonce", nonce ) )
  {
    PTRACE( 1, "No NONCE specified in AUTHORIZATION" );
    CallDisconnect( "Invalid Nonce" );
    return FALSE;
  }

  if( !auth.GetParameter( "response", response ) )
  {
    PTRACE( 1, "No Authorization response in AUTHORIZATION" );
    CallDisconnect( "Invalid Authorization Response" );
    return FALSE;
  }

  OString a1 = m_A1Hash;
  OStringStream userURI;
  userURI << "sip:" << ParserTools::UnQuote( userName ) << "@" << ParserTools::UnQuote( realm );

  MD5::A2Hash a2( invite.GetMethod(), uri );
  MD5::MD5Authorization localAuth = MD5::MD5Authorization( a1, ParserTools::UnQuote(nonce), a2 );

  OString md5Local =  localAuth.AsString();///MD5::MD5Authorization::Construct( a1.AsString(), ParserTools::UnQuote( nonce ), a2.AsString() );

  OString md5Remote = ParserTools::UnQuote( response ); 


  if( md5Local != md5Remote )
  {
    PTRACE( 1,  "Authorization token did not match: " 
      << " Local [" << md5Local << "]" << " Remote [" << md5Remote );

    LOG_IF_DEBUG( m_B2BUAConnection->LogWarning(), "Authorization token did not match: " 
      << " Local [" << md5Local << "]" << " Remote [" << md5Remote );
    
    CallDisconnect( "Not Authorized" );
    return FALSE;
  }else
  {
    return TRUE;
  }
}

BOOL HTTPSession::OnPrepareAUTHInfo( PMIMEInfo & sendMIME )
{
  sendMIME.SetAt( "X-CC-Method", "AUTH" );
  return TRUE;
}

BOOL HTTPSession::SendSETUP( PMIMEInfo & replyMIME, OString & reply )
{
  PURL url = m_URLSetupResource;
  
  PMIMEInfo sendMIME;
  sendMIME.SetAt( "Server", url.GetHostName() );
  sendMIME.SetAt( PHTTP::ContentTypeTag, "application/x-www-form-urlencoded" );

  if(url.GetUserName() != "") {
      PStringStream authToken;
      authToken << url.GetUserName() << ":" << url.GetPassword();
      sendMIME.SetAt( "Authorization", PBase64::Encode(authToken) );
  }

  if( !OnPrepareSIPInfo( sendMIME ) )
    return FALSE;

  if( !OnPrepareSETUPInfo( sendMIME ) )
    return FALSE;

  // Set thetimeout
  m_HTTPClient->SetReadTimeout( 5000 );

  // Send the POST request to the server
  BOOL ok = m_HTTPClient->PostData( url, sendMIME, "", replyMIME );
  if( !ok )
  {
    CallDisconnect( "HTTP Handler Error" );
    return FALSE;
  }

  // Find the length of the response
  PINDEX contentLength;
  if ( replyMIME.Contains( PHTTP::ContentLengthTag ) )
    contentLength = ( PINDEX ) replyMIME[ PHTTP::ContentLengthTag ].AsUnsigned();
  else if ( ok)
    contentLength = P_MAX_INDEX;
  else
    contentLength = 0;

  // Retrieve the response
  PString replyBody = m_HTTPClient->ReadString( contentLength );
  
  if ( !ok  ) 
    return FALSE;

  int maxCallTime = replyMIME.GetInteger( "X-CC-SIP-Max-Time", 0 );
  if( maxCallTime > 0 )
  {
    m_CallTimer = PTimer( maxCallTime * 1000 );
    m_CallTimer.SetNotifier( PCREATE_NOTIFIER( OnCallTimerExpire ) );
    m_CallTimer.Resume();
  }

  reply = (const char *)replyBody;
  return TRUE;
}

void HTTPSession::OnCallTimerExpire( PTimer &, INT )
{
  CallDisconnect( "Maximum Call Time Reached" );
}

BOOL HTTPSession::OnPrepareSETUPInfo( PMIMEInfo & sendMIME )
{
  sendMIME.SetAt( "X-CC-Method", "SETUP" );
  return TRUE;
}

BOOL HTTPSession::SendCALLSTART( OString & reply )
{
  PURL url = m_URLCallStartResource;
  
  PMIMEInfo sendMIME, replyMIME;
  sendMIME.SetAt( "Server", url.GetHostName() );
  sendMIME.SetAt( PHTTP::ContentTypeTag, "application/x-www-form-urlencoded" );

  if(url.GetUserName() != "") {
      PStringStream authToken;
      authToken << url.GetUserName() << ":" << url.GetPassword();
      sendMIME.SetAt( "Authorization", PBase64::Encode(authToken) );
  }

  if( !OnPrepareCALLSTARTInfo( sendMIME ) )
    return FALSE;

  // Set thetimeout
  m_HTTPClient->SetReadTimeout( 5000 );

  // Send the POST request to the server
  BOOL ok = m_HTTPClient->PostData( url, sendMIME, "", replyMIME );
  if( !ok )
  {
    CallDisconnect( "HTTP Handler Error" );
    return FALSE;
  }

  // Find the length of the response
  PINDEX contentLength;
  if ( replyMIME.Contains( PHTTP::ContentLengthTag ) )
    contentLength = ( PINDEX ) replyMIME[ PHTTP::ContentLengthTag ].AsUnsigned();
  else if ( ok)
    contentLength = P_MAX_INDEX;
  else
    contentLength = 0;

  // Retrieve the response
  PString replyBody = m_HTTPClient->ReadString( contentLength );
  
  if ( !ok ) 
    return FALSE;

  reply = (const char *)replyBody;
  return TRUE;
}

BOOL HTTPSession::OnPrepareCALLSTARTInfo( PMIMEInfo & /*sendMIME*/ )
{
  return TRUE;
}

BOOL HTTPSession::SendCALLSTOP( OString & reply )
{
  PURL url = m_URLCallStopResource;
  
  PMIMEInfo sendMIME, replyMIME;
  sendMIME.SetAt( "Server", url.GetHostName() );
  sendMIME.SetAt( PHTTP::ContentTypeTag, "application/x-www-form-urlencoded" );

  if(url.GetUserName() != "") {
      PStringStream authToken;
      authToken << url.GetUserName() << ":" << url.GetPassword();
      sendMIME.SetAt( "Authorization", PBase64::Encode(authToken) );
  }

  if( !OnPrepareCALLSTOPInfo( sendMIME ) )
    return FALSE;

  // Set thetimeout
  m_HTTPClient->SetReadTimeout( 5000 );

  // Send the POST request to the server
  BOOL ok = m_HTTPClient->PostData( url, sendMIME, "", replyMIME );
  if( !ok )
  {
    CallDisconnect( "HTTP Handler Error" );
    return FALSE;
  }

  // Find the length of the response
  PINDEX contentLength;
  if ( replyMIME.Contains( PHTTP::ContentLengthTag ) )
    contentLength = ( PINDEX ) replyMIME[ PHTTP::ContentLengthTag ].AsUnsigned();
  else if ( ok)
    contentLength = P_MAX_INDEX;
  else
    contentLength = 0;

  // Retrieve the response
  PString replyBody = m_HTTPClient->ReadString( contentLength );
  
  if ( !ok ) 
    return FALSE;

  reply = (const char *)replyBody;
  return TRUE;
}

BOOL HTTPSession::OnPrepareCALLSTOPInfo( PMIMEInfo & /*sendMIME*/ )
{
  return TRUE;
}

BOOL HTTPSession::SendCALLREJECT( OString & reply )
{
  PURL url = m_URLTransferRejectResource;
  
  PMIMEInfo sendMIME, replyMIME;
  sendMIME.SetAt( "Server", url.GetHostName() );
  sendMIME.SetAt( PHTTP::ContentTypeTag, "application/x-www-form-urlencoded" );

  if(url.GetUserName() != "") {
      PStringStream authToken;
      authToken << url.GetUserName() << ":" << url.GetPassword();
      sendMIME.SetAt( "Authorization", PBase64::Encode(authToken) );
  }

  if( !OnPrepareCALLREJECTInfo( sendMIME ) )
    return FALSE;

  // Set thetimeout
  m_HTTPClient->SetReadTimeout( 5000 );

  // Send the POST request to the server
  BOOL ok = m_HTTPClient->PostData( url, sendMIME, "", replyMIME );
  if( !ok )
  {
    CallDisconnect( "HTTP Handler Error" );
    return FALSE;
  }

  // Find the length of the response
  PINDEX contentLength;
  if ( replyMIME.Contains( PHTTP::ContentLengthTag ) )
    contentLength = ( PINDEX ) replyMIME[ PHTTP::ContentLengthTag ].AsUnsigned();
  else if ( ok)
    contentLength = P_MAX_INDEX;
  else
    contentLength = 0;

  // Retrieve the response
  PString replyBody = m_HTTPClient->ReadString( contentLength );
  
  if ( !ok ) 
    return FALSE;

  reply = (const char *)replyBody;
  return TRUE;
}

BOOL HTTPSession::OnPrepareCALLREJECTInfo( PMIMEInfo & /*sendMIME*/ )
{
  return TRUE;
}

void HTTPSession::OnDumpCallAuditTrail()
{
}


















































































































