/*
 *
 * SBCTrunk.h
 * 
  * Open SIP Stack ( OSS )
 *
 * Copyright (c) opensipstack.org.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either expressed or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is OpenSIPStack.
 *
 * The Initial Developer of the Original Code is opensipstack.org.
 *
 * The author of this code is Joegen E. Baclor
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * The OpenSIPStack Library includes some GPL/LGPL code libraries that MAY be 
 * enabled at compile time using the --enable-gpllibs configure switch.  If
 * enabled, the content of this file is published under the terms of GNU 
 * General Public License Version 2.  For a detailed list of the available
 * GPL code, see $(opensipstack)/gnu/README file.
 *
 * $Log: SBCTrunk.h,v $
 * Revision 1.7  2009/03/03 08:05:44  joegenbaclor
 * *** empty log message ***
 *
 * Revision 1.6  2007/09/04 21:58:13  joegenbaclor
 * More work on SIP Trunks.
 *
 * Revision 1.5  2007/08/20 06:41:59  joegenbaclor
 * Upgraded version to 1.1.5
 *
 * Revision 1.4  2007/08/20 06:24:45  joegenbaclor
 * commiting alpha code for new backdoor using trunks
 *
 * Revision 1.3  2007/08/16 13:25:50  joegenbaclor
 * More work on trunking
 *
 * Revision 1.2  2007/08/12 01:57:49  joegenbaclor
 * More work on trunking
 *
 * Revision 1.1  2007/08/08 07:36:08  joegenbaclor
 * Added SBCTrunk classes
 * Removed singleton factory for OSSAppConfig
 *
 *
 */

#ifndef SBCTRUNK_H
#define SBCTRUNK_H

#include "OpenSBC.h"
#include "OSSApplication.h"

class SBCTrunk;
class SBCTrunkManager;
class SBCRoutingHandler;


class SBCTrunkProcess : public OSSApplication
{
  PCLASSINFO( SBCTrunkProcess, OSSApplication );
public:
  SBCTrunkProcess(
    SBCTrunkManager * manager,
    WORD sipPort,
    const char * trunkName,
    OSSAppConfig * config
  );

  SBCTrunkProcess(
    SBCTrunkManager * manager,
    WORD httpPort,
    WORD sipPort,
    const char * trunkName,
    const char * configTemplate
   );

  virtual ~SBCTrunkProcess();

  virtual PString GetConfigurationFilePath()const;

  virtual OSSAppConfig * OnCreateAppConfig();

  virtual BOOL OnTrunkStart();

  virtual void OnTrunkStop();

  //Pure virtuals from OSSApplication
  virtual void OnStart( 
    OSSAppConfig & config 
  );

  virtual void OnConfigChanged( 
    OSSAppConfig & config,
    const char * section = NULL 
  );

  virtual void OnExternalConfigChanged( 
    OSSAppConfig & config,
    const char * section = NULL 
  );

  virtual void OnHandleCommandArgs(
      PINDEX i,
      const PString & arg
  );

  PINLINE void SetEndPoint( B2BUAEndPoint * ep ){ m_EndPoint = ep; }; 
  PINLINE SBCTrunk * GetTrunk()const{ return m_Trunk; };
  PINLINE SBCTrunkManager * GetTrunkManager()const{ return m_TrunkManager; };
  PINLINE WORD GetTrunkSIPPort()const{ return m_TrunkSIPPort; };
  PDECLARE_NOTIFIER( PThread, SBCTrunkProcess, OnConfigChanged );
  PDECLARE_NOTIFIER( PThread, SBCTrunkProcess, OnExternalConfigChanged );
  PDICTIONARY(Collection, PCaselessString, SBCTrunkProcess );
protected:
  WORD m_TrunkHTTPPort;
  const char * m_TrunkName;
  const char * m_TrunkConfigTemplate;
  SBCTrunk * m_Trunk;
  SBCTrunkManager * m_TrunkManager;
  WORD m_TrunkSIPPort;
  BOOL m_HasExternalConfig;
  B2BUAEndPoint * m_EndPoint;
};


class SBCTrunkConfig : public OSSAppConfig
{
  PCLASSINFO( SBCTrunkConfig, OSSAppConfig );
public:
  SBCTrunkConfig( 
    OSSApplication * app, 
    WORD httpPort 
  );
  
  virtual BOOL Initialize( 
    const PFilePath & xml 
  );
};

class SBCTrunk : public OpenSBC
{
  PCLASSINFO( SBCTrunk, OpenSBC );
public:
  SBCTrunk(
    SBCTrunkProcess * trunkProcess,
    B2BUserAgent::UAMode mode = B2BUserAgent::B2BOnlyMode
  );
  virtual ~SBCTrunk();

  virtual OSSAppConfig * GetAppConfig()const;

  virtual void OnConfigChanged( 
    OSSAppConfig & config,
    const char * section = NULL 
  );

  virtual B2BCallInterface * OnCreateCallInterface();

  virtual B2BAuthInterface * OnCreateAuthInterface();

  virtual B2BMediaInterface * OnCreateMediaInterface();

  virtual B2BRoutingInterface * OnCreateRoutingInterface();

  virtual B2BIVRInterface * OnCreateIVRInterface();

  PINLINE SBCTrunkProcess * GetTrunkProcess()const{ return m_TrunkProcess; };
  OpenSBC * GetMainTrunk()const;

  void OnTransactionCreated(
    const SIPMessage & request,
    SIPTransaction *& transaction
  );

protected:
  SBCTrunkProcess * m_TrunkProcess;
};

class SBCTrunkManager : public PObject
{
  PCLASSINFO( SBCTrunkManager, PObject );
public:
  SBCTrunkManager( 
    OpenSBCDaemon * mainProcess,
    OpenSBC * mainTrunk
  );
  
  BOOL CreateTrunkProcess(
    WORD sipPort,
    const char * trunkName,
    OSSAppConfig * config
  );

  BOOL CreateTrunkProcess(
    WORD httpPort,
    WORD sipPort,
    const char * trunkName,
    const char * configTemplate
   );

  SBCTrunkProcess * GetTrunkProcess(
    const char * trunkName
  );

  virtual SBCTrunk * OnCreateTrunk( 
    SBCTrunkProcess * trunkProcess 
  );

  virtual void OnCleanup();

  PINLINE OpenSBCDaemon * GetMainProcess()const{ return m_MainProcess; };
  PINLINE OpenSBC * GetMainTrunk()const{ return m_MainTrunk; };

protected:
   OpenSBCDaemon * m_MainProcess;
   OpenSBC * m_MainTrunk;
   PMutex m_TrunkProcessListMutex;
   SBCTrunkProcess::Collection m_TrunkProcessList;
};

#endif //SBCTRUNK_H




