/*
 *
 * SolegyWSPT.cxx
 *
 * Open SIP Stack ( OSS )
 *
 * Copyright (c) opensipstack.org.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either expressed or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is OpenSIPStack.
 *
 * The Initial Developer of the Original Code is opensipstack.org.
 *
 * The author of this code is Joegen E. Baclor
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * The OpenSIPStack Library includes some GPL/LGPL code libraries that MAY be 
 * enabled at compile time using the --enable-gpllibs configure switch.  If
 * enabled, the content of this file is published under the terms of GNU 
 * General Public License Version 2.  For a detailed list of the available
 * GPL code, see $(opensipstack)/gnu/README file.
 *
 * $Log: SolegyWSPT.cxx,v $
 * Revision 1.17  2009/04/14 02:00:10  joegenbaclor
 * Reverting Thread-based transport
 *
 * Revision 1.12  2009/03/14 11:19:02  joegenbaclor
 * added authenticator support in solegy auth
 *
 * Revision 1.11  2009/01/27 09:01:02  joegenbaclor
 * Encountered deadlock in STOP
 *
 * Revision 1.10  2009/01/20 06:33:43  joegenbaclor
 * Delayed connection destruction until solegy session destructor.  Got rid of the connection mutex because we are assured of a valid pointer within the lifetime of
 *  solegy session object
 *
 * Revision 1.9  2009/01/14 15:50:10  joegenbaclor
 * Deleting the content of the solegy session event queue seems to make opensbc crash.  instead we just make sure that no more events are enqueued when state is termianted
 *
 * Revision 1.8  2009/01/03 12:14:24  joegenbaclor
 * Reimplemented DestroyConenction to enqueue a session event instead to avoid further race conditons and dead locks.
 * We also implemented B2BUAConnection::IsSafeReference() to further guaranty the integrity of connection pointers.
 *
 * Revision 1.7  2008/12/12 09:09:10  joegenbaclor
 * Dont charge failed CNAM queries
 *
 * Revision 1.6  2008/12/06 05:10:16  joegenbaclor
 * Fixed bug where premature call cancelation for IVR calls may result to the b2bua connection
 *  not getting destroyed.
 *
 * Revision 1.5  2008/11/20 11:02:35  joegenbaclor
 * Depcrecated old SIPMessage URI accessors
 *
 * Revision 1.4  2008/10/22 05:21:31  joegenbaclor
 * Changing default value of m_AcceptAllCalls to TRUE
 *
 * Revision 1.3  2008/10/22 05:06:25  joegenbaclor
 * Added MPL License Header
 *
 *
 */

#include "SolegyWSPT.h"
#include "OpenSBC.h"
#include "SBCRoutingHandler.h"
#include "SBCConfigParams.h"

using namespace SOLEGY;

#define new PNEW

#define RTTS_LOG( detail ) \
{ \
  if( m_B2BUAConnection != NULL && m_B2BUAConnection->IsSafeReference() ) \
  LOG( m_B2BUAConnection->LogInfo(), "RTTS: " << detail ); \
}

SolegyWSPT::SolegyWSPT(
  SolegySessionManager * manager,
  SolegySocket * socket,
  B2BUAConnection * sipConnection,
  const char * localSessionId,
  BOOL accountingOff,
  BOOL ignoreRouting
) : SolegySession( manager, socket, sipConnection, localSessionId, accountingOff, ignoreRouting )
{
  m_IsWholeSale = TRUE;
  m_CNAMCharge = FALSE;
}


BOOL SolegyWSPT::OnPrepareSETUPInfo( OStringStream & strm )
{
  if( m_B2BUAConnection != NULL && m_B2BUAConnection->IsSafeReference() )
  {
    const SIPMessage & invite = m_B2BUAConnection->GetCallArrivalQueue().GetMessage();
    m_DIALSTRING = invite.GetRequestURI().GetUser();
    strm << "DIALSTRING=" << m_DIALSTRING << endl;
    return TRUE;
  }
  return FALSE;
}

BOOL SolegyWSPT::OnReceived_AUTH( const OString & packet )
{
  if( !SolegySession::OnReceived_AUTH( packet ) )
    return FALSE;

  m_SessionManager->EnqueueEvent( "SendSIGNIN", this );
  return TRUE;
}

BOOL SolegyWSPT::OnPrepareSIGNINInfo( OStringStream & /*strm*/ )
{
  return TRUE;
}

BOOL SolegyWSPT::OnReceived_SIGNIN( const OString & packet )
{
  if( !SolegySession::OnReceived_SIGNIN( packet ) )
    return FALSE;

  m_SessionManager->EnqueueEvent( "SendSETUP", this );
  return TRUE;
}

BOOL SolegyWSPT::OnReceived_SETUP( const OString & packet )
{
  if( !SolegySession::OnReceived_SETUP( packet ) )
    return FALSE;

  PWaitAndSignal lock( m_RTBERouteListMutex );
  
  if( m_RTBERouteList.GetSize()<= 0 )
  {
    if( m_B2BUAConnection != NULL && m_B2BUAConnection->IsSafeReference() )
    {
      const SIPMessage & invite = m_B2BUAConnection->GetCallArrivalQueue().GetMessage();

      if( SolegyParser::ParseRouting( packet, invite, m_RTBERouteList ) )
        CallConnect();
    }
  }

  return TRUE;
}

void SolegyWSPT::OnTransferReject( const SIPMessage & reject )
{
  PWaitAndSignal lock( m_RTBERouteListMutex );
  m_ErrorString = SolegyParser::ConvertRTTSErrorToString( SolegyParser::ConvertSIPToRTTSError( reject ) );

  m_SessionManager->EnqueueEvent( "SendERROR", this );
  SIPMessage response;
  int code = reject.GetStatusCode();
  if( code  >= 500 )
    code = SIPMessage::Code480_TemporarilyNotAvailable; /// 5xx is bad

  m_CurrentInboundInvite.CreateResponse( response, (WORD)code );
  m_B2BUAConnection->GetLeg1Call()->SendRequest( response );
  m_B2BUAConnection->DestroyConnection( response );
    
  m_SessionManager->EnqueueEvent( "SendCALLSTOP", this );
}


BOOL SolegyWSPT::SetupInbound( const SIPMessage & invite )
{
  m_CurrentInboundInvite = invite;
  return TRUE;
}



void SolegyWSPT::SetupOutbound( SIPMessage & invite )
{
  PWaitAndSignal lock( m_RTBERouteListMutex );

  if( m_State != SETUP )
    return;

  int count = m_RTBERouteList.GetSize();
  
  if( count > 0 )
  {
    m_RTBERouteList.DisallowDeleteObjects();
    SIPMessage * route = (SIPMessage *)m_RTBERouteList.RemoveAt(0);
    m_RTBERouteList.AllowDeleteObjects();
    if( route != NULL )
    {
      OString cnamHeader;
      cnamHeader = route->GetInternalHeader( "CNAM" );
      if( !cnamHeader.IsEmpty() )
      {
        m_CNAMCharge = TRUE;
        From from = invite.GetFrom();
        OStringStream cnam;
        RTTS_LOG( "Setting CNAM - " <<  cnamHeader);
        cnam << '"' << cnamHeader << '"';
        from.SetDisplayName( cnam.str() );
        invite.SetFrom( from );
      }

      ++m_CurrentRouteIndex;

      if( m_B2BUAConnection != NULL && m_B2BUAConnection->IsSafeReference() )
      {
        m_B2BUAConnection->RemoveRoutes();
        m_B2BUAConnection->AddRoute( invite.GetRequestURI() );

        OString routeSet;
        routeSet = route->GetInternalHeader( "ROUTE-SET" );
        m_B2BUAConnection->SetOutboundRouteSet( routeSet );
      }
      delete route;
    }
  }

  m_CurrentOutboundInvite = invite;
  m_CallStartTime = m_CallTryingTime = PTime();
  
  m_SessionManager->EnqueueEvent( "SendCALLSTART", this );
}

void SolegyWSPT::OnCallStart()
{
  ///do nothing
  ///we already sent callstart on setup
}

void SolegyWSPT::OnCallStop()
{
  ///do nothing
}


BOOL SolegyWSPT::OnPrepareCALLSTARTInfo(
  OStringStream & strm
)
{
  ////do nothing
  strm << "TERMINATINGHOST=1" << endl;
  return TRUE;
}

BOOL SolegyWSPT::OnPrepareCALLSTOPInfo(
  OStringStream & strm
)
{
  if( m_CNAMCharge )
    strm << "DURATION=1" << endl;
  else
    strm << "DURATION=0" << endl;
  return TRUE;
}

BOOL SolegyWSPT::OnReceived_CALLSTART( const OString & packet )
{
  if( !SolegySession::OnReceived_CALLSTART( packet ) )
    return FALSE;
  
  m_SessionManager->EnqueueEvent( "SendCALLSTOP", this );
  return TRUE;
}

void SolegyWSPT::CallDisconnect( const OString & error )
{
  if( m_B2BUAConnection != NULL && m_B2BUAConnection->IsSafeReference() )
  {
    const SIPMessage & invite = m_B2BUAConnection->GetCallArrivalQueue().GetMessage();
    SIPMessage response;
    invite.CreateResponse( response, SIPMessage::Code480_TemporarilyNotAvailable, error );
    if( m_B2BUAConnection->GetSessionState() < B2BUAConnection::Connected )
    {
      m_B2BUAConnection->GetLeg1Call()->SendRequest( response );
    }else
    {
      OStringStream reasonText;
      reasonText << "SIP ;" << "cause="  << SIPMessage::Code480_TemporarilyNotAvailable << " ;" << "text=\"" << error << "\"";
      m_B2BUAConnection->GetLeg1Call()->SendBye( reasonText.str().c_str() );
    }
    m_B2BUAConnection->DestroyConnection( response );
  }
}











































































































































































