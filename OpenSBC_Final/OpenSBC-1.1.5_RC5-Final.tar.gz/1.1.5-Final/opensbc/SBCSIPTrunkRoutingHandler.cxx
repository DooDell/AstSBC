/*
 *
 * SBCSIPTrunkRoutingHandler.cxx
 *
 * Open SIP Stack ( OSS )
 *
 * Copyright (c) opensipstack.org.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either expressed or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is OpenSIPStack.
 *
 * The Initial Developer of the Original Code is opensipstack.org.
 *
 * The author of this code is Joegen E. Baclor
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * The OpenSIPStack Library includes some GPL/LGPL code libraries that MAY be 
 * enabled at compile time using the --enable-gpllibs configure switch.  If
 * enabled, the content of this file is published under the terms of GNU 
 * General Public License Version 2.  For a detailed list of the available
 * GPL code, see $(opensipstack)/gnu/README file.
 *
 * $Log: SBCSIPTrunkRoutingHandler.cxx,v $
 * Revision 1.4  2009/06/01 03:16:55  joegenbaclor
 * Added outbound call class for sip trunks
 *
 * Revision 1.3  2008/11/20 11:02:35  joegenbaclor
 * Depcrecated old SIPMessage URI accessors
 *
 * Revision 1.2  2007/10/02 16:48:07  joegenbaclor
 * Corrected compile errors and warnings in linux
 *
 * Revision 1.1  2007/10/02 16:42:56  joegenbaclor
 * Marking initial release of SIP Trunking
 *
 *
 */

#include "SBCSIPTrunk.h"
#include "OString.h"
#include "Version.h"
#include "SBCConfigParams.h"
#include "B2BUAConnection.h"
#include "B2BUAEndPoint.h"
#include "Encryption.h"
#include "SIPUDPTransport.h"
#include "SBCSIPTrunkReg.h"
#include "SBCSIPTrunkEndPoint.h"
#include "SBCSIPTrunkRoutingHandler.h"
using namespace SIPTransports;

#define new PNEW

////////////////////////////////////////////////////////////
SBCSIPTrunkRoutingHandler::SBCSIPTrunkRoutingHandler(  
  SBCSIPTrunk & b2bua 
) : B2BRoutingInterface( b2bua ),
    m_SBCSIPTrunk( b2bua )
{
}

SBCSIPTrunkRoutingHandler::~SBCSIPTrunkRoutingHandler()
{
}

/// returns TRUE if the invite came from the main trunk
BOOL SBCSIPTrunkRoutingHandler::IsEgress(
  const SIPMessage & request
)
{
  OpenSBC * mainSBC = m_SBCSIPTrunk.GetTrunkProcess()->GetTrunkManager()->GetMainProcess()->GetSBC();
  return mainSBC->GetB2BUAEndPoint()->GetTransportManager()->IsLocalAddressAndPort( request.GetTopVia().GetURI() );
}


BOOL SBCSIPTrunkRoutingHandler::B2BRouteCall(
  B2BUAConnection & connection,
  SIPMessage & invite,
  BOOL /*ignoreRegistrations*/
)
{
  const Via &via = invite.GetTopVia();

  OString callId = invite.GetCallId();

  OpenSBC * mainSBC = m_SBCSIPTrunk.GetTrunkProcess()->GetTrunkManager()->GetMainProcess()->GetSBC();
  BOOL outbound = mainSBC->GetB2BUAEndPoint()->GetTransportManager()->IsLocalAddressAndPort( via.GetURI() );

  if( outbound )
  {
    connection.SetRewriteToURI( FALSE );
    SIPURI routeURI;
    invite.GetRequestURI( routeURI );
    PIPSocket::Address verifiedAddress;
    WORD verifiedPort = 0;
    
    if( !GetB2BUA().GetStack().GetTransportManager()->IsLocalAddressAndPort( routeURI ) )
    {
      if( SIPTransport::Resolve( routeURI, verifiedAddress, verifiedPort, SIPTransport::UDP, FALSE ) )
      {
        LOG_CONTEXT( LogInfo(), callId, "*** Using Request URI *** " << routeURI << " as route" );
        connection.AddRoute( routeURI );
        return TRUE;
      }
    }else
    {
      routeURI = invite.GetToURI();
      if( !GetB2BUA().GetStack().GetTransportManager()->IsLocalAddressAndPort( routeURI ) )
      {
        if( SIPTransport::Resolve( routeURI, verifiedAddress, verifiedPort, SIPTransport::UDP, FALSE ) )
        {
          LOG_CONTEXT( LogInfo(), callId, "*** Using To URI *** " << routeURI << " as route" );
          connection.AddRoute( routeURI );
          return TRUE;
        }
      }
    }
  }else
  {
    
    PIPSocket::Address addr;
    WORD port;
    if( !dynamic_cast<SIPUDPTransport*>(mainSBC->GetB2BUAEndPoint()->GetTransportManager()->GetUDPTransport())->GetDefaultListenerAddress( addr, port ) )
      return FALSE;

    connection.SetRewriteToURI( FALSE );
    SIPURI route( addr, port );
    connection.AddRoute( route );
    
    
    To to = invite.GetTo();
    SIPURI toURI = to.GetURI();
    toURI.SetPort( OString( port ) );
    to.SetURI( toURI );
    invite.SetTo( to );
  }

  return TRUE;
}

////////////////////////////////////////////////////////////




