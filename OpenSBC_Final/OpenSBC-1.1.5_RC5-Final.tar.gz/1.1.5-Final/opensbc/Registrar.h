/*
 *
 * Registrar.h
 *
 * Open SIP Stack ( OSS )
 *
 * Copyright (c) opensipstack.org.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either expressed or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is OpenSIPStack.
 *
 * The Initial Developer of the Original Code is opensipstack.org.
 *
 * The author of this code is Joegen E. Baclor
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * The OpenSIPStack Library includes some GPL/LGPL code libraries that MAY be 
 * enabled at compile time using the --enable-gpllibs configure switch.  If
 * enabled, the content of this file is published under the terms of GNU 
 * General Public License Version 2.  For a detailed list of the available
 * GPL code, see $(opensipstack)/gnu/README file.
 *
 * $Log: Registrar.h,v $
 * Revision 1.12  2009/03/06 03:17:18  joegenbaclor
 * configurable OPTIONS based NAT keep alive support
 *
 * Revision 1.11  2009/02/04 06:24:26  joegenbaclor
 * Minor bug fixes.  Added auto destruct timer to SoelgySession.  Added ability to disable local-reg and treat all regs as upper reg.
 *
 * Revision 1.10  2008/10/05 14:01:41  joegenbaclor
 * Added logging to upper-reg
 * Fixed unquoted realm parameter in proxy authentication
 *
 * Revision 1.9  2008/09/30 09:48:56  joegenbaclor
 * IVR Prompt Manager releated code
 *
 * Revision 1.8  2008/09/22 05:58:35  joegenbaclor
 * Added stateful upper reg classes
 *
 * Revision 1.7  2008/09/12 09:49:44  joegenbaclor
 * - Upper registration bug fixes.
 * - Bring back support for upper reg routing
 * - Bring back support for upper-reg domain rewrite
 *
 * Revision 1.6  2008/09/10 03:56:29  joegenbaclor
 * Updated VC2005 build
 *
 * Revision 1.5  2008/09/09 03:31:24  joegenbaclor
 * Upper Registration bug fixes
 *
 * Revision 1.4  2008/09/05 03:54:45  joegenbaclor
 * reactivation registration status using new registrar.
 *
 * Revision 1.3  2008/09/02 06:59:19  joegenbaclor
 * *** empty log message ***
 *
 * Revision 1.2  2008/09/02 04:57:39  joegenbaclor
 * Added new upper reg classes
 *
 * Revision 1.1  2008/08/27 03:02:14  joegenbaclor
 * Adding new registrar code
 *
 *
 */

#ifndef REGISTRAR_H
#define REGISTRAR_H

#include "Registration.h"
#include "SIPUserAgent.h"
#include "EventQueue.h"
#include "Logger.h"

using namespace SIPTransactions;
using namespace SIP;
using namespace EQ;
using namespace Tools;

class Router;

namespace REGISTRAR
{

class Registrar : public SIPTransactionBypass, public Logger
{
  PCLASSINFO( Registrar, SIPTransactionBypass );
public:
  Registrar( SIPUserAgent & userAgent, BOOL createUpperReg = TRUE );

  ~Registrar();

  virtual void OnReceivedMessage(
    const SIPMessage & message,
    SIPTransaction * transaction
  );

  virtual void OnTimerExpire(
    SIPTimerEvent & /*timer*/,
    SIPTransaction * /*transaction*/
  ){};

  void OnAuthPending(
    const SIPMessage & message,
    SIPTransaction * transaction
  );

  virtual void OnFlushRegistration( Registration * reg );

  BOOL FindRegistrationBinding(
    const SIPMessage & request,
    Contact & contact
  );

  // this is merely for backward compatibility with old API (use FindRegistrationBinding instead! )
  BOOL FindRegistration(
    const SIPURI & uri,
    SIPMessage & reg
  );

  virtual void OnParseUpperRegRoutes();

  PINLINE void SetAcceptAllRegistrations( BOOL accept ){ m_AcceptAllReg = accept; };
  PINLINE void SetNATKeepAliveInterval( int seconds ){ m_NATKeepAliveInterval = seconds; };
  PINLINE void SetUseOptionsNATKeepAlive( BOOL yes = TRUE ){ m_UseOptionsNATKeepAlive = yes; };

  PDICTIONARY( RegistrationList, PCaselessString, Registration );
  RegistrationList m_RegistrationList;
  PMutex m_RegistrationListMutex;
  PLIST( RegistrationLandFill, Registration );
  RegistrationLandFill m_RegistrationLandFill;
  SIPUserAgent & m_UserAgent;
  BOOL m_AcceptAllReg;
  int m_NATKeepAliveInterval;
  BOOL m_UseOptionsNATKeepAlive;
  BOOL m_EnableUpperReg;
  BOOL m_AllRegAsUpperReg;
  Registrar * m_UpperRegistrar;
  EventQueue * m_EventQueue;
  Router * m_UpperRegistrationRoutes;
  BOOL m_UpperRegRewriteFromDomain;
  BOOL m_UpperRegRewriteToDomain;
  BOOL m_UpperRegEnableStateful;
  PDECLARE_NOTIFIER( EQ::EventQueue, REGISTRAR::Registrar, OnProcessEvent );
  PDECLARE_NOTIFIER( PTimer, REGISTRAR::Registrar, OnClearLandFill );
  PTimer m_LandFillCollector;
};
};
#endif
