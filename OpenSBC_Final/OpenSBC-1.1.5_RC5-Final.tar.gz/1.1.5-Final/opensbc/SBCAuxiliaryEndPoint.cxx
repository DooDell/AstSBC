#include "SBCAuxiliaryEndPoint.h"
#include "OpenSBC.h"

#define new PNEW

SBCAuxiliaryUA::SBCAuxiliaryUA( OpenSBC * sbc ) : SIPUserAgent( "SBCAUX" ), m_SBC( sbc ) 
{
  m_EP = NULL;
}

BOOL SBCAuxiliaryUA::InitEndPoint()
{
  if( m_EP != NULL )
    return FALSE;

  m_EP = new SBCAuxiliaryEP( *this );

  SIPURI bindAddress((const char *)m_SBC->GetAppConfig()->GetString( configKeySIPTransportSection, configKeyAuxiliaryInterfaceAddress, "sip:*:5070" ));


  PIPSocket::Address bindIp( bindAddress.GetHost() );
  if( !bindIp.IsValid() )
    bindIp = m_SBC->GetTransportManager()->GetDefaultInterfaceAddress( FALSE );
  WORD bindPort = (WORD)bindAddress.GetPort().AsUnsigned(); 

  GetDefaultProfile().GetTransportProfile().EnableUDP( bindIp, bindPort );
  if( !Initialize(1) )
    return FALSE;
  
  if( !StartTransportThreads() )
    return FALSE;

  return TRUE;
}

void SBCAuxiliaryUA::ProcessEvent( 
  SIPStackEvent * event 
)
{
  m_EP->ProcessStackEvent( event );
}
  
////////////////////////////

SBCAuxiliaryEP::SBCAuxiliaryEP(
  SBCAuxiliaryUA & ua
) : CallSessionManager( ua, 1, 1024 * 10 ), m_UA( ua )
{
}

CallSession * SBCAuxiliaryEP::OnCreateClientCallSession(
  const ProfileUA & profile,
  const OString & sessionId
)
{
  return new SBCAuxiliaryCall( this, sessionId, profile );
}

BOOL SBCAuxiliaryEP::ManageSession( SBCAuxiliaryCall * session )
{
  if( !m_SessionsMutex.Wait( 1000 ) )
  {
    LOG( LogError(), "!!! UNABLE TO ACQUIRE SIP SESSION LIST MUTEX = SIPSessionManager::CreateClientSession !!!" );
    return FALSE;
  }

  if( m_SessionsBySessionId.Contains( session->GetSessionId().c_str() ) )
  {
    m_SessionsMutex.Signal();
    return FALSE;
  }

  m_SessionsBySessionId.SetAt( session->GetSessionId().c_str(), session );
  m_SessionsMutex.Signal();
  
  {
  PWaitAndSignal lockCallId( m_SessionByCallIdMutex );
  m_SessionsByCallId.SetAt( session->GetCallId().c_str(), session );
  }

  return TRUE;
}

//////////////////////////

SBCAuxiliaryCall::SBCAuxiliaryCall(
  SBCAuxiliaryEP * ep,
  const OString & sessionId,
  const ProfileUA & profile
) : CallSession( *ep, sessionId, profile )
{
}









