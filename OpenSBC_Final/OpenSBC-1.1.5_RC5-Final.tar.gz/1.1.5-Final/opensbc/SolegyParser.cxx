/*
 *
 * SolegyParser.cxx
 *
 * Open SIP Stack ( OSS )
 *
 * Copyright (c) opensipstack.org.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either expressed or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is OpenSIPStack.
 *
 * The Initial Developer of the Original Code is opensipstack.org.
 *
 * The author of this code is Joegen E. Baclor
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * The OpenSIPStack Library includes some GPL/LGPL code libraries that MAY be 
 * enabled at compile time using the --enable-gpllibs configure switch.  If
 * enabled, the content of this file is published under the terms of GNU 
 * General Public License Version 2.  For a detailed list of the available
 * GPL code, see $(opensipstack)/gnu/README file.
 *
 * $Log: SolegyParser.cxx,v $
 * Revision 1.24  2009/03/14 11:19:02  joegenbaclor
 * added authenticator support in solegy auth
 *
 * Revision 1.23  2008/11/20 11:02:35  joegenbaclor
 * Depcrecated old SIPMessage URI accessors
 *
 * Revision 1.22  2008/11/11 02:54:47  joegenbaclor
 * Feature:  Introducing RTTS aggregation of groomer and osbc
 * Bug:  Disconnect calls if ParseRouting has an empty result set
 *
 * Revision 1.21  2008/10/22 05:06:25  joegenbaclor
 * Added MPL License Header
 *
 *
 */

#include "SolegyParser.h"
#include "SDPLazyParser.h"
#include "Encryption.h"
#include "ptclib/cypher.h"

#define new PNEW

using namespace SOLEGY;
using namespace Encryption;

#define HEADER_PAYLOAD_MAX_SIZE 2048

OString SolegyParser::GetString(
  const char * name, 
  const OString & packet,
  const OString & def
)
{
  OString value;
  if( ParseHeader( name, value, packet ) )
    return value;
  return def;
}

BOOL SolegyParser::GetBoolean(
  const char * name, 
  const OString & packet,
  BOOL def
)
{
  OString value;
  if( ParseHeader( name, value, packet ) )
    return value.AsInteger();
  return def;
}

int SolegyParser::GetInteger(
  const char * name, 
  const OString & packet,
  int def
)
{
  OString value;
  if( ParseHeader( name, value, packet ) )
    return value.AsInteger();
  return def;
}

double SolegyParser::GetReal(
  const char * name, 
  const OString & packet,
  double def
)
{
  OString value;
  if( ParseHeader( name, value, packet ) )
    return value.AsReal();
  return def;
}

int SolegyParser::ParseErrorCode( const OString & errorPacket )
{
  OString error;
  if( SolegyParser::ParseHeader( "ERROR", error, errorPacket ) )
  {
    OStringArray tokens = error.Tokenise( " " );
    if( tokens.GetSize() > 1 )
      return tokens[0].AsInteger();
  }
  return 0;
}

OString SolegyParser::ParseErrorDesc( const OString & errorPacket )
{
  OString error;
  if( SolegyParser::ParseHeader( "ERROR", error, errorPacket ) )
  {
    OStringArray tokens = error.Tokenise( " " );
    if( tokens.GetSize() > 1 )
      error = tokens[1];
  }
  return error;
}

BOOL SolegyParser::ParseHeader( 
  const char * name, 
  OString & value, 
  const OString & packet
)
{
  int len = (int)strlen(name);
  PINDEX loc = 0;
 
  PINDEX size = packet.GetLength();
  for( ;; )
  {
    loc = packet.Find( name, loc );
    if( loc == P_MAX_INDEX )
    {
      return FALSE;
    }

    if( loc == 0 || ::isspace(packet[loc-1]) )
    {
      char eq = packet[loc + len]; 
      if( loc + len + 1 < size && eq == '=' )
      {
        loc = loc + len + 1;
        int i = 0;
        char val[HEADER_PAYLOAD_MAX_SIZE];
        memset( val, '\0', HEADER_PAYLOAD_MAX_SIZE );
        while( loc < size &&  packet[loc] != '\r' && packet[loc] != '\n' )
          val[i++] = packet[loc++];
        value = (const char *)&val[0];
        return TRUE;
      }else
      {
        loc++;
      }
    }else
    {
      loc++;
    }
  }
  
  return FALSE;
}

BOOL SolegyParser::ParseRouteVector(
  const SIPMessage & invite,
  SIPMessage::Collection & rtbeRouteList
)
{
  XRoutingVector * routeVector = invite.GetXRoutingVector();
  if( routeVector == NULL )
    return FALSE;

  OString routingHeader = routeVector->GetHeaderBody();

  SIPURI rURI;
  invite.GetRequestURI(rURI);
  const SIPURI & fURI = invite.GetFromURI();
  size_t len = routingHeader.GetLength();
  size_t i = 0;

  
  for( ;; )
  {
    SIPURI fromURI = fURI;
    SIPURI reqURI = rURI;
    size_t elementIndex = 0;
    char scheme[50];
    memset( scheme, '\0', 50 );

    for( ;; )
    {
      char c = routingHeader[i];
      if( c != ':' && !::isspace(c) )
        scheme[elementIndex++] = routingHeader[i];
      else if( c == ':' )
      {
        i++;
        break;
      }

      if(i++ >= len )
        return rtbeRouteList.GetSize() != 0;
    }

  
    elementIndex = 0;
    char fromUser[256];
    memset( fromUser, '\0', 256 );

    for( ;; )
    {
      char c = routingHeader[i];
      if( c != '*' && !::isspace(c) )
        fromUser[elementIndex++] = routingHeader[i];
      else if( c == '*' )
      {
        i++;
        break;
      }

      if(i++ >= len )
        return rtbeRouteList.GetSize() != 0;
    }

    elementIndex = 0;
    char dnis[256];
    memset( dnis, '\0', 256 );

    for( ;; )
    {
      char c = routingHeader[i];
      if( c != '@' && !::isspace(c) )
        dnis[elementIndex++] = routingHeader[i];
      else if( c == '@' )
      {
        i++;
        break;
      }

      if(i++ >= len )
        return rtbeRouteList.GetSize() != 0;
    }

    elementIndex = 0;
    char fromHost[256];
    memset( fromHost, '\0', 256 );

    for( ;; )
    {
      char c = routingHeader[i];
      if( c != ':' && !::isspace(c) )
        fromHost[elementIndex++] = routingHeader[i];
      else if( c == ':' )
      {
        i++;
        break;
      }

      if(i++ >= len )
        return rtbeRouteList.GetSize() != 0;
    }

    elementIndex = 0;
    char targetPort[5];
    memset( targetPort, '\0', 5 );

    for( ;; )
    {
      char c = routingHeader[i];
      if( c != ':' && !::isspace(c) )
        targetPort[elementIndex++] = routingHeader[i];
      else if( c == ':' )
      {
        i++;
        break;
      }

      if(i++ >= len )
        return rtbeRouteList.GetSize() != 0;
    }

    elementIndex = 0;
    char target[256];
    memset( target, '\0', 256 );

    for( ;; )
    {
      char c = routingHeader[i];
      if( c != ';' && !::isspace(c) )
        target[elementIndex++] = routingHeader[i];
      else if( c == ';' )
      {
        i++;
        break;
      }
      if(i++ >= len )
        return rtbeRouteList.GetSize() != 0;
    }

    if( strcmp( scheme, "sip" ) == 0 )
    {
      /// populate the routelist
      if( dnis[0] != '\0' )
        reqURI.SetUser( (const char *)&dnis[0] );
      
      if( target[0] != '\0' )
        reqURI.SetHost( (const char *)&target[0] );

      if( targetPort[0] != '\0' )
        reqURI.SetPort( (const char *)&targetPort[0] );
      else 
        reqURI.SetPort( "" );

      if( fromUser[0] != '\0' )
      {
        if( strcmp( fromUser, "NULL" ) == 0 )
          fromURI.SetUser("");
        else if( strcmp( fromUser, "null" ) != 0 )
          fromURI.SetUser( (const char *)&fromUser[0] );
      }

      if( fromHost[0] != '\0' )
        fromURI.SetHost( (const char *)&fromHost[0] );

      SIPMessage * newRoute = new SIPMessage();
      RequestLine rLine;
      rLine.SetMethod( "INVITE" );
      rLine.SetRequestURI( reqURI );
      From from;
      from.SetURI( fromURI );
      newRoute->SetStartLine(rLine);
      newRoute->SetFrom( from );
      rtbeRouteList.Append( newRoute );
    }
  }

}


BOOL SolegyParser::ParseRouting( 
  const OString & setupPacket,
  const SIPMessage & invite,
  SIPMessage::Collection & rtbeRouteList,
  BOOL ignoreRoutes
)
{
  if( rtbeRouteList.GetSize() > 0 )
    return TRUE;

  OString routingHeader;
  if( !SolegyParser::ParseHeader( "ROUTING", routingHeader, setupPacket ) )
    return FALSE;

  if( routingHeader.IsEmpty() )
    return FALSE;

  SIPURI rURI;
  invite.GetRequestURI(rURI);
  const SIPURI & fURI = invite.GetFromURI();
  size_t len = routingHeader.GetLength();
  size_t i = 0;

  if( ignoreRoutes )
  {
    SIPMessage * relayroute = new SIPMessage();
    
    const RequestLine & rLine = invite.GetRequestLine();
    From from = invite.GetFrom();

    relayroute->SetStartLine(rLine);
    relayroute->SetFrom( from );
    rtbeRouteList.Append( relayroute );
    goto CNAM;
  }

  
  for( ;; )
  {
    SIPURI fromURI = fURI;
    SIPURI reqURI = rURI;
    size_t elementIndex = 0;
    char scheme[50];
    memset( scheme, '\0', 50 );

    for( ;; )
    {
      char c = routingHeader[i];
      if( c != ':' && !::isspace(c) )
        scheme[elementIndex++] = routingHeader[i];
      else if( c == ':' )
      {
        i++;
        break;
      }

      if(i++ >= len )
        goto CNAM;
        //return rtbeRouteList.GetSize() != 0;
    }

  
    elementIndex = 0;
    char fromUser[256];
    memset( fromUser, '\0', 256 );

    for( ;; )
    {
      char c = routingHeader[i];
      if( c != '*' && !::isspace(c) )
        fromUser[elementIndex++] = routingHeader[i];
      else if( c == '*' )
      {
        i++;
        break;
      }

      if(i++ >= len )
        goto CNAM;
        //return rtbeRouteList.GetSize() != 0;
    }

    elementIndex = 0;
    char dnis[256];
    memset( dnis, '\0', 256 );

    for( ;; )
    {
      char c = routingHeader[i];
      if( c != '@' && !::isspace(c) )
        dnis[elementIndex++] = routingHeader[i];
      else if( c == '@' )
      {
        i++;
        break;
      }

      if(i++ >= len )
        return rtbeRouteList.GetSize() != 0;
    }

    elementIndex = 0;
    char fromHost[256];
    memset( fromHost, '\0', 256 );

    for( ;; )
    {
      char c = routingHeader[i];
      if( c != ':' && !::isspace(c) )
        fromHost[elementIndex++] = routingHeader[i];
      else if( c == ':' )
      {
        i++;
        break;
      }

      if(i++ >= len )
        return rtbeRouteList.GetSize() != 0;
    }

    elementIndex = 0;
    char targetPort[5];
    memset( targetPort, '\0', 5 );

    for( ;; )
    {
      char c = routingHeader[i];
      if( c != ':' && !::isspace(c) )
        targetPort[elementIndex++] = routingHeader[i];
      else if( c == ':' )
      {
        i++;
        break;
      }

      if(i++ >= len )
        goto CNAM;
        //return rtbeRouteList.GetSize() != 0;
    }

    elementIndex = 0;
    char target[256];
    memset( target, '\0', 256 );

    for( ;; )
    {
      char c = routingHeader[i];
      if( c != ';' && !::isspace(c) )
        target[elementIndex++] = routingHeader[i];
      else if( c == ';' )
      {
        i++;
        break;
      }
      if(i++ >= len )
        goto CNAM;
        //return rtbeRouteList.GetSize() != 0;
    }

    if( strcmp( scheme, "sip" ) == 0 )
    {
      /// populate the routelist
      if( dnis[0] != '\0' )
        reqURI.SetUser( (const char *)&dnis[0] );
      
      if( target[0] != '\0' )
        reqURI.SetHost( (const char *)&target[0] );

      if( targetPort[0] != '\0' )
        reqURI.SetPort( (const char *)&targetPort[0] );
      else 
        reqURI.SetPort( "" );

      if( fromUser[0] != '\0' )
      {
        if( strcmp( fromUser, "NULL" ) == 0 )
          fromURI.SetUser("");
        else if( strcmp( fromUser, "null" ) != 0 )
          fromURI.SetUser( (const char *)&fromUser[0] );
      }

      if( fromHost[0] != '\0' )
        fromURI.SetHost( (const char *)&fromHost[0] );


      #if 0  /// test timeout
      SIPMessage * timeoutRoute = new SIPMessage();
      RequestLine rLine = "INVITE sip:12345@10.0.0.1:5060 SIP/2.0";
      From from;
      from.SetURI( fromURI );
      timeoutRoute->SetStartLine(rLine);
      timeoutRoute->SetFrom( from );
      rtbeRouteList.Append( timeoutRoute );
      #endif

      #if 0  /// test 404
      SIPURI dummyreqURI = "sip:1@fwd.pulver.com";
      SIPMessage * dummyRoute = new SIPMessage();
      RequestLine dummyrLine;
      dummyrLine.SetMethod( "INVITE" );
      dummyrLine.SetRequestURI( dummyreqURI );
      From dummyfrom;
      dummyfrom.SetURI( fromURI );
      dummyRoute->SetStartLine(dummyrLine);
      dummyRoute->SetFrom( dummyfrom );
      rtbeRouteList.Append( dummyRoute );
      #endif

      #if 1
      SIPMessage * newRoute = new SIPMessage();
      RequestLine rLine;
      rLine.SetMethod( "INVITE" );
      rLine.SetRequestURI( reqURI );
      From from;
      from.SetURI( fromURI );
      newRoute->SetStartLine(rLine);
      newRoute->SetFrom( from );
      rtbeRouteList.Append( newRoute );
      
      #endif
    }
  }

CNAM:
  ///parse CNAM 
  OString cnamInfo;
  int routeCount = rtbeRouteList.GetSize();

  if( SolegyParser::ParseHeader( "CNAMINFO", cnamInfo, setupPacket ) )
  {
    OStringArray cnamTokens;
    cnamInfo.Tokenise(cnamTokens, ";" );  
    int cnamCount = cnamTokens.GetSize();
    int count = routeCount <= cnamCount ? routeCount : cnamCount;

    for( PINDEX i = 0; i < count; i++ )
    {
      if( !cnamTokens[i].IsEmpty() )
      {
        if( cnamTokens[i][0] != ';' )
        {
          SIPMessage &route = rtbeRouteList[i];
          route.AddInternalHeader( "CNAM", cnamTokens[i] );
        }
      }
    }
  }

  OString finalRoute;
  if( !ignoreRoutes && SolegyParser::ParseHeader( "FINALROUTEURL", finalRoute, setupPacket ) )
  {
    ///FINALROUTEURL=sip:finalroute::70.42.73.172

    SIPURI finalRouteRURI;
    if( rtbeRouteList.GetSize() > 0 )
      finalRouteRURI = rtbeRouteList[0].GetRequestURI();
    else
      finalRouteRURI = invite.GetRequestURI();
    
    OStringArray tokens = finalRoute.Tokenise(":");
    if( tokens.GetSize() == 4 )
    {
      finalRouteRURI.SetHost( tokens[3] );
      finalRouteRURI.SetPort( tokens[2] );

      SIPMessage * newRoute = new SIPMessage();
      RequestLine rLine;
      rLine.SetMethod( "INVITE" );
      rLine.SetRequestURI( finalRouteRURI );
      From from;
      from.SetURI( fURI );
      newRoute->SetStartLine(rLine);
      newRoute->SetFrom( from );
      newRoute->AddInternalHeader( "rtts-call-accounting", "off" );
      rtbeRouteList.Append( newRoute );
    }
  }

  OString routeSetCount;
  if( SolegyParser::ParseHeader( "ROUTE-SET-COUNT", routeSetCount, setupPacket ) )
  {
    static const char route_indices[20][14] = { 
      "ROUTE-SET[0]",
      "ROUTE-SET[1]",
      "ROUTE-SET[2]",
      "ROUTE-SET[3]",
      "ROUTE-SET[4]",
      "ROUTE-SET[5]",
      "ROUTE-SET[6]",
      "ROUTE-SET[7]",
      "ROUTE-SET[8]",
      "ROUTE-SET[9]",
      "ROUTE-SET[10]",
      "ROUTE-SET[11]",
      "ROUTE-SET[12]",
      "ROUTE-SET[13]",
      "ROUTE-SET[14]",
      "ROUTE-SET[15]",
      "ROUTE-SET[16]",
      "ROUTE-SET[17]",
      "ROUTE-SET[18]",
      "ROUTE-SET[19]"
    };

    int count = routeSetCount.AsInteger();
    for( int i = 0; i < count && i < 20 && i < routeCount; i++ )
    {
      OString currentRouteEntry;
      if( SolegyParser::ParseHeader( route_indices[i], currentRouteEntry, setupPacket ) )
      {
         SIPMessage &route = rtbeRouteList[i];
         route.AddInternalHeader( "ROUTE-SET", currentRouteEntry );
      }
    }
  }

  return rtbeRouteList.GetSize() != 0;
}

BOOL SolegyParser::ParseWholeNumber(
  const OString & _whole, 
  OString &wHundredThousands,
  OString &wTenThousands,
  OString &wThousands,
  OString &wHundreds,
  OString &wTens,
  OString &wOnes
)
{
  OString whole = _whole;
  OStringArray tokens = whole.Tokenise( "." );
  if( tokens.GetSize() == 2 )
    whole = tokens[0];

  int wLen = (int)whole.GetLength();
  char c = whole[0];
    
  if( wLen == 6 )
  {
    switch( c )
    {
    case '1':
      wHundredThousands = "one";
      break;
    case '2':
      wHundredThousands = "two";
      break;
    case '3':
      wHundredThousands = "three";
      break;
    case '4':
      wHundredThousands = "four";
      break;
    case '5':
      wHundredThousands = "five";
      break;
    case '6':
      wHundredThousands = "six";
      break;
    case '7':
      wHundredThousands = "seven";
      break;
    case '8':
      wHundredThousands = "eight";
      break;
    case '9':
      wHundredThousands = "nine";
      break;
    }

    whole[0] = whole[1];
    whole[1] = whole[2];
    whole[2] = whole[3];
    whole[3] = whole[4];
    whole[4] = whole[5];
    whole[5] = '\0';
    c = whole[0];
    wLen = 5;
  }

  if( wLen == 5 )
  {
    switch( c )
    {
    case '1':
      wTenThousands = "ten";
      break;
    case '2':
      wTenThousands = "twenty";
      break;
    case '3':
      wTenThousands = "thirty";
      break;
    case '4':
      wTenThousands = "forty";
      break;
    case '5':
      wTenThousands = "fifty";
      break;
    case '6':
      wTenThousands = "sixty";
      break;
    case '7':
      wTenThousands = "seventy";
      break;
    case '8':
      wTenThousands = "eighty";
      break;
    case '9':
      wTenThousands = "ninety";
      break;
    }

    whole[0] = whole[1];
    whole[1] = whole[2];
    whole[2] = whole[3];
    whole[3] = whole[4];
    whole[4] = '\0';
    c = whole[0];
    wLen = 4;
  }

  if( wLen == 4 )
  {
    switch( c )
    {
    case '1':
      wThousands = "one";
      break;
    case '2':
      wThousands = "two";
      break;
    case '3':
      wThousands = "three";
      break;
    case '4':
      wThousands = "four";
      break;
    case '5':
      wThousands = "five";
      break;
    case '6':
      wThousands = "six";
      break;
    case '7':
      wThousands = "seven";
      break;
    case '8':
      wThousands = "eight";
      break;
    case '9':
      wThousands = "nine";
      break;
    }

    whole[0] = whole[1];
    whole[1] = whole[2];
    whole[2] = whole[3];
    whole[3] = '\0';
    c = whole[0];
    wLen = 3;
  }

  if( wLen == 3 )
  {
    switch( c )
    {
    case '1':
      wHundreds = "one";
      break;
    case '2':
      wHundreds = "two";
      break;
    case '3':
      wHundreds = "three";
      break;
    case '4':
      wHundreds = "four";
      break;
    case '5':
      wHundreds = "five";
      break;
    case '6':
      wHundreds = "six";
      break;
    case '7':
      wHundreds = "seven";
      break;
    case '8':
      wHundreds = "eight";
      break;
    case '9':
      wHundreds = "nine";
      break;
    }

    whole[0] = whole[1];
    whole[1] = whole[2];
    whole[2] = '\0';
    c = whole[0];
    wLen = 2;
  }

  if( wLen == 2 )
  {
    switch( c )
    {
    case '1':
      wTens = "ten";
      break;
    case '2':
      wTens = "twenty";
      break;
    case '3':
      wTens = "thirty";
      break;
    case '4':
      wTens = "forty";
      break;
    case '5':
      wTens = "fifty";
      break;
    case '6':
      wTens = "sixty";
      break;
    case '7':
      wTens = "seventy";
      break;
    case '8':
      wTens = "eighty";
      break;
    case '9':
      wTens = "ninety";
      break;
    }

    whole[0] = whole[1];
    whole[1] = '\0';
    c = whole[0];
    wLen = 1;
  }

  if( wLen == 1 )
  {
    switch( c )
    {
    case '1':
      wOnes = "one";
      break;
    case '2':
      wOnes = "two";
      break;
    case '3':
      wOnes = "three";
      break;
    case '4':
      wOnes = "four";
      break;
    case '5':
      wOnes = "five";
      break;
    case '6':
      wOnes = "six";
      break;
    case '7':
      wOnes = "seven";
      break;
    case '8':
      wOnes = "eight";
      break;
    case '9':
      wOnes = "nine";
      break;
    }
  }

  return TRUE;
}
  
BOOL SolegyParser::ParseWholeNumber( const OString & whole, OStringArray &words)
{
  OString wHundredThousands;
  OString wTenThousands;
  OString wThousands;
  OString wHundreds;
  OString wTens;
  OString wOnes;

  if( !SolegyParser::ParseWholeNumber(
    whole, 
    wHundredThousands,
    wTenThousands,
    wThousands,
    wHundreds,
    wTens,
    wOnes
  )) return FALSE;

  bool hasThousands = false;
  bool hasHundreds = false;

  if( !wHundredThousands.IsEmpty() )
  {
    words.AppendString( wHundredThousands );
    words.AppendString( "hundred" );
    hasThousands = true;
  }

  if( !wTenThousands.IsEmpty() )
  {
    if( wThousands.IsEmpty() )
      words.AppendString(wTenThousands);
    else
    {
      if( wTenThousands == "ten" )
      {
        if( wThousands == "one" )
          wTenThousands = "eleven";
        else if( wThousands == "two" )
          wTenThousands = "twelve";
        else if( wThousands == "three" )
          wTenThousands = "thirteen";
        else if( wThousands == "four" )
          wTenThousands = "fourteen";
        else if( wThousands == "five" )
          wTenThousands = "fifteen";
        else if( wThousands == "six" )
          wTenThousands = "sixteen";
        else if( wThousands == "seven" )
          wTenThousands = "seventeen";
        else if( wThousands == "eight" )
          wTenThousands = "eighteen";
        else if( wThousands == "nine" )
          wTenThousands = "nineteen";
        wThousands = ""; // blank it out
      }
      words.AppendString(wTenThousands);
    }

    hasThousands = true;
  }

  if( !wThousands.IsEmpty() )
  {
    hasThousands = true;
    words.AppendString( wThousands );
  }

  if( hasThousands )
    words.AppendString( "thousand" );

  if( !wHundreds.IsEmpty() )
  {
    words.AppendString( wHundreds );
    words.AppendString( "hundred" );
    hasHundreds = true;
  }

  if( !wTens.IsEmpty() )
  {
    if( wOnes.IsEmpty() )
      words.AppendString(wTens);
    else
    {
      if( wTens == "ten" )
      {
        if( wOnes == "one" )
          wTens = "eleven";
        else if( wOnes == "two" )
          wTens = "twelve";
        else if( wOnes == "three" )
          wTens = "thirteen";
        else if( wOnes == "four" )
          wTens = "fourteen";
        else if( wOnes == "five" )
          wTens = "fifteen";
        else if( wOnes == "six" )
          wTens = "sixteen";
        else if( wOnes == "seven" )
          wTens = "seventeen";
        else if( wOnes == "eight" )
          wTens = "eighteen";
        else if( wOnes == "nine" )
          wTens = "nineteen";
        wOnes = ""; // blank it out
      }
      words.AppendString(wTens);
    }
  }

  if( !wOnes.IsEmpty() )
    words.AppendString( wOnes );
  
  return TRUE;
}

BOOL SolegyParser::ParseBalanceAsEnglish( 
  const OString & value, 
  OString &wHundredThousands,
  OString &wTenThousands,
  OString &wThousands,
  OString &wHundreds,
  OString &wTens,
  OString &wOnes,
  OString &cTens,
  OString &cOnes,
  OString &currencyCode
)
{
  int len = (int)value.GetLength();
  if( len < 5 ) //we need at least 5 chars
    return FALSE;
  
  char currency[4];
  char whole[10];
  memset( whole, '\0', 10 );
  char decimal[3];
  memset( decimal, '\0', 3 );

  currency[0] = value[0];
  currency[1] = value[1];
  currency[2] = value[2];
  currency[3] = '\0';

  currencyCode = (const char *)&currency[0];
  
  if( !isspace(value[3]) )
    return FALSE;

  int i = 4;
  int j = 0;
  bool hasDecimal = true;
  for( ;; )
  {
    char c = value[i];
    if( c != '.' && c != '\0' && i < len )
      whole[j++] = c;
    else
    {
      hasDecimal = c == '.';
      break;
    }
    i++;
  }

  if( hasDecimal )
  {
    i++;
    j = 0;
    for( ;; )
    {
      char c = value[i];
      if( j < 3 && c != '\0' && i < len )
        decimal[j++] = c;
      else
        break;
      i++;
    }
  }

  if( whole[0] != '\0' )
  {
    if( !SolegyParser::ParseWholeNumber( 
      (const char *)&whole[0],
      wHundredThousands,
      wTenThousands,
      wThousands,
      wHundreds,
      wTens,
      wOnes) )return FALSE;
  }

  if( decimal[0] != '\0' )
  {
      
    char c = decimal[0];
    if( c != '0' )
    {
      switch( c )
      {
      case '1':
        cTens = "ten";
        break;
      case '2':
        cTens = "twenty";
        break;
      case '3':
        cTens = "thirty";
        break;
      case '4':
        cTens = "forty";
        break;
      case '5':
        cTens = "fifty";
        break;
      case '6':
        cTens = "sixty";
        break;
      case '7':
        cTens = "seventy";
        break;
      case '8':
        cTens = "eighty";
        break;
      case '9':
        cTens = "ninety";
        break;
      }
    }

    c = decimal[1];
    if( c != '\0' )
    {
      switch( c )
      {
      case '1':
        cOnes = "one";
        break;
      case '2':
        cOnes = "two";
        break;
      case '3':
        cOnes = "three";
        break;
      case '4':
        cOnes = "four";
        break;
      case '5':
        cOnes = "five";
        break;
      case '6':
        cOnes = "six";
        break;
      case '7':
        cOnes = "seven";
        break;
      case '8':
        cOnes = "eight";
        break;
      case '9':
        cOnes = "nine";
        break;
      }
    }
  }

  return TRUE;
}

BOOL SolegyParser::ParseBalanceAsEnglish(
    const OString & value,
    OStringArray & words 
)
{
  OString wHundredThousands;
  OString wTenThousands;
  OString wThousands;
  OString wHundreds;
  OString wTens;
  OString wOnes;
  OString cTens;
  OString cOnes;
  OString currencyCode; 

  bool hasThousands = false;
  bool hasHundreds = false;
  
  if( !SolegyParser::ParseBalanceAsEnglish(
        value, 
        wHundredThousands,
        wTenThousands,
        wThousands,
        wHundreds,
        wTens,
        wOnes,
        cTens,
        cOnes,
        currencyCode ) ) return FALSE;
 
  bool hasCents = !cTens.IsEmpty() || !cOnes.IsEmpty();

  if( !wHundredThousands.IsEmpty() )
  {
    words.AppendString( wHundredThousands );
    words.AppendString( "hundred" );
    hasThousands = true;
  }

  if( !wTenThousands.IsEmpty() )
  {
    if( wThousands.IsEmpty() )
      words.AppendString(wTenThousands);
    else
    {
      if( wTenThousands == "ten" )
      {
        if( wThousands == "one" )
          wTenThousands = "eleven";
        else if( wThousands == "two" )
          wTenThousands = "twelve";
        else if( wThousands == "three" )
          wTenThousands = "thirteen";
        else if( wThousands == "four" )
          wTenThousands = "fourteen";
        else if( wThousands == "five" )
          wTenThousands = "fifteen";
        else if( wThousands == "six" )
          wTenThousands = "sixteen";
        else if( wThousands == "seven" )
          wTenThousands = "seventeen";
        else if( wThousands == "eight" )
          wTenThousands = "eighteen";
        else if( wThousands == "nine" )
          wTenThousands = "nineteen";

        words.AppendString(wTenThousands);
        wThousands = ""; // blank it out
      }
    }

    hasThousands = true;
  }

  if( !wThousands.IsEmpty() )
  {
    hasThousands = true;
    words.AppendString( wThousands );
  }

  if( hasThousands )
    words.AppendString( "thousand" );

  if( !wHundreds.IsEmpty() )
  {
    words.AppendString( wHundreds );
    words.AppendString( "hundred" );
    hasHundreds = true;
  }

  if( !wTens.IsEmpty() )
  {
    if( wOnes.IsEmpty() )
      words.AppendString(wTens);
    else
    {
      if( wTens == "ten" )
      {
        if( wOnes == "one" )
          wTens = "eleven";
        else if( wOnes == "two" )
          wTens = "twelve";
        else if( wOnes == "three" )
          wTens = "thirteen";
        else if( wOnes == "four" )
          wTens = "fourteen";
        else if( wOnes == "five" )
          wTens = "fifteen";
        else if( wOnes == "six" )
          wTens = "sixteen";
        else if( wOnes == "seven" )
          wTens = "seventeen";
        else if( wOnes == "eight" )
          wTens = "eighteen";
        else if( wOnes == "nine" )
          wTens = "nineteen";
        wOnes = ""; // blank it out
      }
      words.AppendString(wTens);
    }

  }

  if( !wOnes.IsEmpty() )
    words.AppendString( wOnes );

  if( currencyCode == "USD" )
  {
    if( words.GetSize() == 1 && words[0] == "one" )
      words.AppendString( "dollar" );
    else
      words.AppendString( "dollars" );
  }

  if( hasCents )
    words.AppendString( "and" );

  

  if( !cTens.IsEmpty() )
  {
    if( cOnes.IsEmpty() )
      words.AppendString(cTens);
    else
    {
      if( cTens == "ten" )
      {
        if( cOnes == "one" )
          cTens = "eleven";
        else if( cOnes == "two" )
          cTens = "twelve";
        else if( cOnes == "three" )
          cTens = "thirteen";
        else if( cOnes == "four" )
          cTens = "fourteen";
        else if( cOnes == "five" )
          cTens = "fifteen";
        else if( cOnes == "six" )
          cTens = "sixteen";
        else if( cOnes == "seven" )
          cTens = "seventeen";
        else if( cOnes == "eight" )
          cTens = "eighteen";
        else if( cOnes == "nine" )
          cTens = "nineteen";

        
        cOnes = ""; // blank it out
      }
      words.AppendString(cTens);
    }
  }

  if( !cOnes.IsEmpty() )
    words.AppendString( cOnes );

  if( hasCents && currencyCode == "USD" )
    words.AppendString( "cents" );


  return TRUE;
}

BOOL SolegyParser::ParseMinuteAsEnglish(
  const OString & value,
  OStringArray & words 
)
{
  //long seconds = value.AsInteger();
  OString minutes = value; //( seconds / 60 );
  if( !SolegyParser::ParseWholeNumber( minutes, words ) )
    return FALSE;

  if( words.GetSize() == 1 && words[0] == "one" )
    words.AppendString( "minute" );
  else
    words.AppendString( "minutes" );
  return TRUE;
}



BOOL SolegyParser::ParseMediaAttributes(
  const OString & leg1SDP,
  const OString & leg1TranslatedSDP,
  const OString & leg2SDP,
  const OString & leg2TranslatedSDP,
  OString & ORIGMEDIACODEC,
  OString & ORIGMEDIADSTADDRESS,
  OString & ORIGMEDIASRCADDRESS,
  OString & TERMMEDIACODEC,
  OString & TERMMEDIADSTADDRESS,
  OString & TERMMEDIASRCADDRESS
)
{
  using SDP::SDPLazyParser;
  SDPLazyParser sdp1 = leg1SDP;
  SDPLazyParser sdp2 = leg2SDP;
  SDPLazyParser translated_sdp1 = leg1TranslatedSDP;
  SDPLazyParser translated_sdp2 = leg2TranslatedSDP;

  SIPURI sdp1_address;
  OString sdp1_codec;
  int sdp1_pt = 0;
  sdp1.GetMediaFormat( SDPLazyParser::Audio, 0, 0, sdp1_pt, sdp1_codec, sdp1_address );

  SIPURI sdp2_address;
  OString sdp2_codec;
  int sdp2_pt = 0;
  sdp2.GetMediaFormat( SDPLazyParser::Audio, 0, 0, sdp2_pt, sdp2_codec, sdp2_address );

  SIPURI translated_sdp1_address;
  OString translated_sdp1_codec;
  int translated_sdp1_pt = 0;
  translated_sdp1.GetMediaFormat( SDPLazyParser::Audio, 0, 0, translated_sdp1_pt, translated_sdp1_codec, translated_sdp1_address );

  SIPURI translated_sdp2_address;
  OString translated_sdp2_codec;
  int translated_sdp2_pt = 0;
  translated_sdp2.GetMediaFormat( SDPLazyParser::Audio, 0, 0, translated_sdp2_pt, translated_sdp2_codec, translated_sdp2_address );  
  
  ORIGMEDIACODEC = sdp1_codec;
  ORIGMEDIADSTADDRESS = translated_sdp2_address.AsString();
  ORIGMEDIASRCADDRESS = sdp1_address.AsString();
  
  TERMMEDIACODEC = sdp2_codec;
  TERMMEDIADSTADDRESS = sdp2_address.AsString();
  TERMMEDIASRCADDRESS = translated_sdp1_address.AsString();

  return TRUE;
}

SolegyParser::RTTSError SolegyParser::ConvertSIPToRTTSError(
  const SIPMessage & msg
)
{
  WORD response = 0;
  if( msg.IsCancel() )
    return SolegyParser::ErrorCancelled;
  else if( msg.Is1xx() || msg.Is2xx() || msg.IsRefer() || msg.Is3xx() )
    return SolegyParser::ErrorNone;
  else if( !msg.IsRequest() )
    response = msg.GetStatusCode();
  
  switch( response )
  {
  case 0:   return SolegyParser::ErrorNone;
  case 400: return SolegyParser::ErrorInvalid;      
  case 401: return SolegyParser::ErrorAuthFailed;     
  case 402: return SolegyParser::ErrorTimeExceeded;   
  case 403: return SolegyParser::ErrorAuthRejected;   
  case 404: return SolegyParser::ErrorNotFound;      
  case 405: return SolegyParser::ErrorInvalid;      
  case 406: return SolegyParser::ErrorInvalid;      
  case 407: return SolegyParser::ErrorAuthRequired;   
  case 408: return SolegyParser::ErrorConnectTimeout;  
  case 409: return SolegyParser::ErrorInvalid;      
  case 410: return SolegyParser::ErrorNotAvailable;   
  case 411: return SolegyParser::ErrorInvalid;      
  case 413: return SolegyParser::ErrorInvalid;      
  case 414: return SolegyParser::ErrorInvalid;      
  case 415: return SolegyParser::ErrorUnsupportedMedia;
  case 420: return SolegyParser::ErrorInvalid;      
  case 480: return SolegyParser::ErrorNoAnswer;      
  case 481: return SolegyParser::ErrorInvalid;      
  case 482: return SolegyParser::ErrorInvalid;      
  case 483: return SolegyParser::ErrorInvalid;      
  case 484: return SolegyParser::ErrorInvalid;      
  case 485: return SolegyParser::ErrorInvalid;      
  case 486: return SolegyParser::ErrorRemoteBusy;     
  case 487: return SolegyParser::ErrorCancelled;     
  case 488: return SolegyParser::ErrorUnsupportedMedia;
  case 500: return SolegyParser::ErrorUnknown;      
  case 501: return SolegyParser::ErrorInvalid;      
  case 502: return SolegyParser::ErrorInvalid;      
  case 503: return SolegyParser::ErrorNoService;     
  case 504: return SolegyParser::ErrorConnectTimeout;  
  case 505: return SolegyParser::ErrorInvalid;      
  case 600: return SolegyParser::ErrorNotFound;      
  case 603: return SolegyParser::ErrorDeclined;      
  case 604: return SolegyParser::ErrorNotFound;      
  case 606: return SolegyParser::ErrorInvalid;
  default:  return SolegyParser::ErrorUnknown;
  }
}

OString SolegyParser::ConvertRTTSErrorToString( 
  SolegyParser::RTTSError error 
)
{
  OStringStream errorMessage;
  errorMessage << error << "-Proxy[";
  switch( error )
	{
	case SolegyParser::ErrorNone:   		      errorMessage << "ErrorNone"; break;
	case SolegyParser::ErrorConnectTimeout:   errorMessage <<  "ErrorConnectTimeout"; break; 
	case SolegyParser::ErrorTrunkBusy:    		errorMessage <<  "ErrorTrunkBusy"; break;
	case SolegyParser::ErrorChannelBusy:    	errorMessage <<  "ErrorChannelBusy"; break;
	case SolegyParser::ErrorUnsupportedMedia:	errorMessage <<  "ErrorUnsupportedMedia"; break;
	case SolegyParser::ErrorNotFound:		      errorMessage <<  "ErrorNotFound"; break;
	case SolegyParser::ErrorNoMedia:      		errorMessage <<  "ErrorNoMedia"; break;
	case SolegyParser::ErrorMediaTimeout: 		errorMessage <<  "ErrorMediaTimeout"; break;
	case SolegyParser::ErrorNotAvailable: 		errorMessage <<  "ErrorNotAvailable"; break;
	case SolegyParser::ErrorRemoteBusy:   		errorMessage <<  "ErrorRemoteBusy"; break;
	case SolegyParser::ErrorRemoteBadNumber:	errorMessage <<  "ErrorRemoteBadNumber"; break;
	case SolegyParser::ErrorNoAnswer:       	errorMessage <<  "ErrorNoAnswer"; break;
	case SolegyParser::ErrorTimeExceeded:   	errorMessage <<  "ErrorTimeExceeded"; break;
	case SolegyParser::ErrorDeclined:     		errorMessage <<  "ErrorDeclined"; break;
	case SolegyParser::ErrorInvalid:      		errorMessage <<  "ErrorInvalid"; break;
	case SolegyParser::ErrorNotInService: 		errorMessage <<  "ErrorNotInService"; break;
	case SolegyParser::ErrorSit:          		errorMessage <<  "ErrorSit"; break;
	case SolegyParser::ErrorNoDialTone:   		errorMessage <<  "ErrorNoDialTone"; break;
	case SolegyParser::ErrorAuthFailed:   		errorMessage <<  "ErrorAuthFailed"; break;
	case SolegyParser::ErrorAuthRejected: 		errorMessage <<  "ErrorAuthRejected"; break;
	case SolegyParser::ErrorAuthInvalid:  		errorMessage <<  "ErrorAuthInvalid"; break;
	case SolegyParser::ErrorUnknown:      		errorMessage <<  "ErrorUnknown"; break;
	case SolegyParser::ErrorFailed:       		errorMessage <<  "ErrorFailed"; break;
	case SolegyParser::ErrorCancelled:    		errorMessage <<  "ErrorCancelled"; break;
	case SolegyParser::ErrorAuthRequired: 		errorMessage <<  "ErrorAuthRequired"; break;
	case SolegyParser::ErrorAbandoned:    		errorMessage <<  "ErrorAbandoned"; break;
	case SolegyParser::ErrorNoRoute:      		errorMessage <<  "ErrorNoRoute"; break;
	case SolegyParser::ErrorRedirect:     		errorMessage <<  "ErrorRedirect"; break;
	case SolegyParser::ErrorNoService:    		errorMessage <<  "ErrorNoService"; break;
  case SolegyParser::ErrorInvalidDigest:    errorMessage <<  "Digest did not Match"; break;
	default: errorMessage <<  "(unknown)"; break;
	}

  errorMessage << "]";
  return errorMessage.str();
}


BOOL SolegyParser::XORDecodeValue(
  const char * _key,
  const char * _in,
  OString & out
)
{
  int keyLen = (int)::strlen( _key );
  if( keyLen < 2 )
    return FALSE;
  PBYTEArray key(2);
  key[0] = _key[0];  
  key[1] = _key[keyLen-1];

  PBYTEArray in;
  if( !PBase64::Decode( _in, in ) )
    return FALSE;

  return Encryption::Engine::XOR::Encrypt( in, out, key ); 
}

BOOL SolegyParser::XOREncodeValue(
  const char * _key,
  const char * _in,
  OString & out
)
{
  int keyLen = (int)::strlen( _key );
  if( keyLen < 2 )
    return FALSE;
  PBYTEArray key(2);
  key[0] = _key[0];  
  key[1] = _key[keyLen-1];

  int inLen = (int)::strlen( _in );
  PBYTEArray in;
  in.SetSize( inLen );
  ::memcpy( in.GetPointer( inLen ), _in, inLen );

  PBYTEArray _out;
  if( !Encryption::Engine::XOR::Encrypt( in, _out, key ) )
    return FALSE;

  out = (const char *)PBase64::Encode( _out );
  return TRUE;
}


