
#ifndef SBCAUXEP_H
#define SBCAUXEP_H

#include "SIPUserAgent.h"
#include "CallSessionManager.h"
#include "CallSession.h"

using namespace UACORE;
using namespace SIP;

class OpenSBC;
class SBCAuxiliaryEP;
class SBCAuxiliaryCall;

class SBCAuxiliaryUA : public SIPUserAgent
{
  PCLASSINFO( SBCAuxiliaryUA, SIPUserAgent );
public:
  SBCAuxiliaryEP * m_EP;
  OpenSBC * m_SBC;

  SBCAuxiliaryUA( OpenSBC * sbc );

  BOOL InitEndPoint();

  void ProcessEvent( 
    SIPStackEvent * event 
  );
  
  
};

class SBCAuxiliaryEP : public CallSessionManager
{
  PCLASSINFO( SBCAuxiliaryEP, CallSessionManager );
public:
  SBCAuxiliaryUA & m_UA;

  SBCAuxiliaryEP(
    SBCAuxiliaryUA & ua
  );

  virtual CallSession * OnCreateClientCallSession(
    const ProfileUA & profile,
    const OString & sessionId
  );

  BOOL ManageSession( SBCAuxiliaryCall * session );
};

class SBCAuxiliaryCall : public CallSession
{
  PCLASSINFO( SBCAuxiliaryCall, CallSession );
public:
  SBCAuxiliaryEP * m_EP;
  SBCAuxiliaryCall(
    SBCAuxiliaryEP * ep,
    const OString & sessionId,
    const ProfileUA & profile
  );
};

#endif //SBCAUXEP_H




