/*
 *
 * SBCSwitchRTPBridge.cxx
 *
 * Open SIP Stack ( OSS )
 *
 * Copyright (c) opensipstack.org.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either expressed or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is OpenSIPStack.
 *
 * The Initial Developer of the Original Code is opensipstack.org.
 *
 * The author of this code is Joegen E. Baclor
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * The OpenSIPStack Library includes some GPL/LGPL code libraries that MAY be 
 * enabled at compile time using the --enable-gpllibs configure switch.  If
 * enabled, the content of this file is published under the terms of GNU 
 * General Public License Version 2.  For a detailed list of the available
 * GPL code, see $(opensipstack)/gnu/README file.
 *
 * $Log: SBCSwitchRTPBridge.cxx,v $
 * Revision 1.6  2009/06/27 02:41:19  joegenbaclor
 * fixing gcc compile warnings
 *
 * Revision 1.5  2009/06/27 02:38:24  joegenbaclor
 * fixing gcc compile errors
 *
 * Revision 1.4  2009/06/02 08:53:38  joegenbaclor
 * Marking first sucessful IVR stream
 *
 * Revision 1.3  2009/06/01 09:47:28  joegenbaclor
 * more IVR related work
 *
 * Revision 1.2  2009/05/29 09:31:32  joegenbaclor
 * Added Switch IVR Classes
 *
 * Revision 1.1  2009/05/27 12:40:34  joegenbaclor
 * Initial upload of switch related classes
 *
 *
 */

#include "SBCSwitchRTPBridge.h"
#include "SBCSwitchIVRInterface.h"
#define new PNEW
using namespace SWITCH;

////////////////////////////////////////////////////////////

SBCSwitchRTPBridge::SBCSwitchRTPBridge( 
  RTP_UDP * leg1,
  RTP_UDP * leg2
  ) : PThread( 10240, PThread::NoAutoDeleteThread, PThread::NormalPriority, "SBCSwitchRTPBridge" )
{
  m_Leg1 = leg1;
  m_Leg2 = leg2;
  
  m_Leg1DataSocket = &(m_Leg1->GetDataSocket());
  m_Leg1DataSocket->SetReadTimeout( 5 );
  
  m_Leg1ControlSocket = &(m_Leg1->GetControlSocket());
  m_Leg1ControlSocket->SetReadTimeout( 5 );

  m_Leg2DataSocket = &(m_Leg2->GetDataSocket());
  m_Leg2DataSocket->SetReadTimeout( 5 );

  m_Leg2ControlSocket = &(m_Leg2->GetControlSocket());
  m_Leg2ControlSocket->SetReadTimeout( 5 );

  m_IsTerminated = FALSE;
  m_IsPaused = FALSE;
  m_IsIVRAttached = FALSE;
  m_IVRChannel = NULL;
}

void SBCSwitchRTPBridge::AttachIVRChannel( SBCSwitchIVRInterface * channel )
{
  m_IVRChannelMutex.Wait();
  m_IVRChannel = channel;
  m_IsIVRAttached = TRUE;
  m_IVRChannelMutex.Signal();
}

void SBCSwitchRTPBridge::DetachIVRChannel()
{
  m_IVRChannelMutex.Wait();
  m_IsIVRAttached = FALSE;
  m_IVRChannel = NULL;
  m_IVRChannelMutex.Signal();
}

void SBCSwitchRTPBridge::ProcessStream()
{
  m_IVRChannelMutex.Wait();
  if( m_IsIVRAttached && m_IVRChannel != NULL )
  {
    m_IVRChannel->ProcessStream();
    m_IVRChannelMutex.Signal();
    return;
  }
  m_IVRChannelMutex.Signal();

  if( m_IsPaused )
  {
    PThread::Sleep(5);
    return;
  }

  PSocket::SelectList selectList;
  selectList.Append( m_Leg1DataSocket );
  selectList.Append( m_Leg1ControlSocket );
  selectList.Append( m_Leg2DataSocket );
  selectList.Append( m_Leg2ControlSocket );

  PChannel::Errors error = PSocket::Select( selectList, 5 );
  
  if (error != PChannel::NoError || m_IsTerminated )
    return;

  if( selectList.GetSize() == 0)
    return;
  
  PUDPSocket * sock = (PUDPSocket *)selectList.GetAt(0);

  if( (sock == m_Leg1DataSocket || sock == m_Leg1ControlSocket) && !m_IsTerminated )
  {
    RTP_DataFrame frame;
    if( m_Leg1->ReadData( frame ) )
      if( sock == m_Leg1DataSocket )
        m_Leg2->WriteData( frame );
  }else if( (sock == m_Leg2DataSocket || sock == m_Leg2ControlSocket) && !m_IsTerminated )
  {
    RTP_DataFrame frame;
    if( m_Leg2->ReadData( frame ) )
      if( sock == m_Leg2DataSocket )
        m_Leg1->WriteData( frame );
  }
}

void SBCSwitchRTPBridge::Main()
{
  PTRACE( 1, "RTP: SBCSwitchRTPBridge STARTED" );
  while( !m_IsTerminated )
    ProcessStream();
  PTRACE( 1, "RTP: SBCSwitchRTPBridge TERMINATED" );
}

BOOL SBCSwitchRTPBridge::SetTerminated()
{
  m_IsTerminated = TRUE;
  BOOL ok = WaitForTermination( 10000 );
  if( !ok )
  {
    PTRACE( 1, "RTP: Unable to terminate SBCSwitchRTPBridge thread" );
  }
  return ok;
}

////////////////////////////////////////////////////////////////


