#include "SBCSwitchMedia.h"
#include "SBCSwitchConnection.h"
#include "SBCSwitchEndPoint.h"
#include "SBCSwitchIVRChannel.h"
#include "OpenSBC.h"
#include "SBCMediaHandler.h"
#include "SDPLazyParser.h"
#include "SBCSwitchLeg1.h"
#include "SBCSwitchLeg2.h"
#include "SBCSwitchConnection.h"

#define new PNEW

using namespace SWITCH;

///////////////////////////////////////////////////////////////////////////////

SBCSwitchMediaStream::SBCSwitchMediaStream(
  const OpalMediaFormat & mediaFormat, ///  Media format for stream
  unsigned sessionID,                  ///  Session number for stream
  BOOL isSource,                       ///  Is a source stream
  SBCSwitchIVRSession * ivr,
  SBCB2BUACall * call                  ///  The call owning the stream
  ) : OpalRawMediaStream( mediaFormat, sessionID, isSource, ivr, FALSE )
{
  m_B2BUACall = call;
  m_IVRSession = ivr;
}

BOOL SBCSwitchMediaStream::Open()
{
  
  if (isOpen)
    return TRUE;

  if (m_IVRSession->IsOpen()) 
  {
    SBCSwitchIVRChannel * ivrChannel = m_IVRSession->GetIVRChannel();
    OString ivrChannelMediaFormat;
    
    if (ivrChannel == NULL) 
    {
      PTRACE(1, "IVR: IVR engine not really open");
      return FALSE;
    }

    ivrChannelMediaFormat = ivrChannel->GetMediaFormat();
    
    if (mediaFormat != ivrChannelMediaFormat.c_str()) 
    {
      PTRACE(1, "IVR: Cannot use VXML engine: asymmetrical media format");
      return FALSE;
    }

    return OpalMediaStream::Open();
  }

  if (m_IVRSession->Open((const char *)mediaFormat))
    return OpalMediaStream::Open();

  PTRACE(1, "IVR: Cannot open IVR engine: incompatible media format");
  return FALSE;

}

BOOL SBCSwitchMediaStream::IsSynchronous() const{return FALSE;}

///////////////////////////////////////////////////////////////////////////////

SBCSwitchMedia::SBCSwitchMedia( 
  SBCSwitchEndPoint * switchEp,
  SBCAuxiliaryEP * auxEp,
  SBCSwitchConnection * conn,
  const OString & sessionId,
  const ProfileUA & profile
) : SBCAuxiliaryCall( auxEp, sessionId, profile )
{
  m_B2BSDPState = SBCSwitchMedia::SDP_StateNone;
  m_SwitchConnection = conn;
  m_AuxEndPoint = auxEp;
  m_SwitchEndPoint = switchEp;
  m_MediaStream = NULL;
  m_PeerMediaStream = NULL;
  m_ActiveAudioBridge = NULL;
  m_ActiveVideoBridge = NULL;
  m_PayloadType = SDPMediaFmt::IllegalPayloadType;
}

SBCSwitchMedia::~SBCSwitchMedia()
{
}

BOOL SBCSwitchMedia::SetupMediaServer(
  const SIPURI & serverURL,
  SIPMessage & request
)
{
  return TRUE;
}

BOOL SBCSwitchMedia::OnSwitchIncomingSDPOffer(
  SBCSwitchConnection * conn,
  SBCB2BUACall * call,
  const SIPMessage & message
)
{
  PWaitAndSignal lock( m_SDPMutex );
  if( !message.HasSDP() )
    return TRUE;

  SBCSwitchRTPInterface * rtpIface = dynamic_cast<SBCSwitchRTPInterface *>(call);

  if( m_B2BSDPState != SDP_StateNone && m_B2BSDPState != SDP_StateNegotiated )
  {
#ifdef _MSC_VER
    switch( m_B2BSDPState )
    {
      case SDP_StateReceivedOffer:
        MSVCTRACE( "Error: Got IncomingSDPOffer in state SDP_StateReceivedOffer" );
        break;
      case SDP_StateWaitingAnswer:
        MSVCTRACE( "Error: Got IncomingSDPOffer in state SDP_StateWaitingAnswer" );
        break;
      case SDP_StateReceivedAnswerPreview:
        MSVCTRACE( "RTP: Got IncomingSDPOffer in state SDP_StateReceivedAnswerPreview" );
        break;
      case SDP_StateReceivedAnswerFinal:
        MSVCTRACE( "Error: Got IncomingSDPOffer in state SDP_StateReceivedAnswerFinal" );
      break;
    }
#endif //_MSC_VER
    return FALSE;
  }


  BOOL isInitialOffer = m_B2BSDPState == SDP_StateNone;
  SDPLazyParser sdp = message.GetBody();
  SIPURI audioMediaAddress, videoMediaAddress;
  OString sid, vid;
  sdp.GetSessionId( vid, sid );
  OString newID = sid + vid;

  m_B2BSDPState = SDP_StateReceivedOffer;
  
  if( !isInitialOffer )
  {
    /// This is a re-offer !!!
    /// check if the session Id has changed  
    if( newID == rtpIface->GetRemoteSDPID() )
    {
      LOG( LogInfo(), "RTP: SDP Offer is the same as previous. Keep-Alive?" );
      return TRUE; /// its the same.  This is probably a session-timer
    }
    
    // ok session id different.  Preserve it
    rtpIface->SetRemoteSDPID( newID );  
  }

  rtpIface->SetRemoteSDP( sdp );

  BOOL hasAudio = sdp.GetMediaCount( SDPLazyParser::Audio ) > 0;
  BOOL hasVideo = sdp.GetMediaCount( SDPLazyParser::Video ) > 0;
  LOG( LogInfo(), "RTP: New SDP " << sid << " " << vid << " Audio=" << hasAudio << " Video=" << hasVideo << " for LEG " << call->GetLegIndex() );
  
  PAssert( !call->GetInterfaceAddress().IsEmpty() &&  !call->GetTranslatedInterfaceAddress().IsEmpty(), PLogicError );
  PIPSocket::Address iface( call->GetInterfaceAddress().c_str() );
  iface.SetExternalIP( call->GetTranslatedInterfaceAddress().c_str() );

  rtpIface->SetLocalSDPAddress( iface );
  LOG( LogInfo(), call->GetInterfaceAddress().c_str() );
  LOG( LogInfo(), "RTP: Setting Local RTP Address to " <<  iface << "/" << iface.GetExternalIP() << " for LEG " << call->GetLegIndex()  );

  /// Create RTP Session for Audio
  if( hasAudio )
  {
    if( !sdp.GetMediaAddress( SDPLazyParser::Audio, audioMediaAddress ) )
    {
      LOG( LogError(), "RTP: Unable to Audio parse media address from SDP for LEG " << call->GetLegIndex() );
      return FALSE;
    }
    // check if its a hold
    if( audioMediaAddress.GetHost() == "0.0.0.0" )
    {
      LOG( LogInfo(), "RTP: SDP Offer (AUDIO) address is 0.0.0.0. Call-Hold for LEG "<< call->GetLegIndex() );
    }
   
    int rfc2833Payload = SDPMediaFmt::IllegalPayloadType;
    sdp.GetPayloadTypeFromName( SDPLazyParser::Audio, 0, "telephone-event", rfc2833Payload );

    if( !m_SwitchEndPoint->CreateRTPSession(
      *call,
      OpalMediaFormat::DefaultAudioSessionID, 
      iface, 
      audioMediaAddress.GetAddress(), /// media address we got in SDP
      message.GetSourceAddress(), /// temporary send address in case call is natted
      (WORD)audioMediaAddress.GetPort().AsUnsigned(), /// media port we got from SDP
      call->IsEncryptionEnabled(),
      rfc2833Payload)) 
    {
      LOG( LogError(), "!!! Unable to create RTP Session (AUDIO) for " << sid << " " << vid << " LEG " << call->GetLegIndex()<< " !!!" );
      return FALSE;
    }
  }

  if( hasVideo )
  {
    if( !sdp.GetMediaAddress( SDPLazyParser::Video, videoMediaAddress ) )
    {
      LOG( LogError(), "RTP: Unable to parse Video media address from SDP for LEG " << call->GetLegIndex() );
      return FALSE;
    }
    // check if its a hold
    if( videoMediaAddress.GetHost() == "0.0.0.0" )
    {
      LOG( LogInfo(), "RTP: SDP Offer (Video) address is 0.0.0.0. Call-Hold for LEG "<< call->GetLegIndex() );
    }

    if( !m_SwitchEndPoint->CreateRTPSession(
      *call, 
      OpalMediaFormat::DefaultVideoSessionID, 
      iface, 
      videoMediaAddress.GetAddress(), /// media address we got in SDP
      message.GetSourceAddress(), /// temporary send address in case call is natted
      (WORD)videoMediaAddress.GetPort().AsUnsigned(), /// media port we got from SDP
      call->IsEncryptionEnabled() )) 
    {
      LOG( LogError(), "!!! Unable to create RTP Session (VIDEO) for " << sid << " " << vid << " LEG " << call->GetLegIndex()<< " !!!" );
      return FALSE;
    }
  }

  return TRUE;
}


BOOL SBCSwitchMedia::OnSwitchRequireSDPOffer(
  SBCSwitchConnection * conn,
  SBCB2BUACall * call,
  SIPMessage & message
)
{
  PWaitAndSignal lock( m_SDPMutex );
  if( !message.HasSDP() )
    return TRUE;

  SBCSwitchRTPInterface * rtpIface = dynamic_cast<SBCSwitchRTPInterface *>(call);

  if( m_B2BSDPState != SDP_StateReceivedOffer )
  {
#ifdef _MSC_VER
    switch( m_B2BSDPState )
    {
      case SDP_StateNone:
      {
        MSVCTRACE( "Got RequireSDPOffer in state SDP_StateNone" );
      }
      break;
      case SDP_StateWaitingAnswer:
      {
        MSVCTRACE( "Got RequireSDPOffer in state SDP_StateWaitingAnswer" );
      }
      break;
      case SDP_StateReceivedAnswerPreview:
        MSVCTRACE( "RTP: Got RequireSDPOffer in state SDP_StateReceivedAnswerPreview" );
        break;
      case SDP_StateReceivedAnswerFinal:
      {
        MSVCTRACE( "Got RequireSDPOffer in state SDP_StateReceivedAnswerFinal" );
      }
      break;
      case SDP_StateNegotiated:
      {
        MSVCTRACE( "Got RequireSDPOffer in state SDP_StateNegotiated" );
      }
      break;
    }
#endif //_MSC_VER
    return FALSE;
  }


  SDPLazyParser sdp = message.GetBody();
#if 0
  if( GetPayloadType() != SDPMediaFmt::IllegalPayloadType )
  {
    /// we have a media server present
      PBYTEArray mask(1);
      mask[0] = GetPayloadType();
      sdp.ApplyMediaFormatMask( SDPLazyParser::Audio, 0, mask );
      message.SetBody( sdp );
  }
#endif
  m_B2BSDPState = SDP_StateWaitingAnswer;

  OString sid, vid;
  sdp.GetSessionId( vid, sid );
  OString newID = sid + vid;

  BOOL hasAudio = sdp.GetMediaCount( SDPLazyParser::Audio ) > 0;
  BOOL hasVideo = sdp.GetMediaCount( SDPLazyParser::Video ) > 0;
  LOG( LogInfo(), "RTP: New SDP " << sid << " " << vid << " Audio=" << hasAudio << " Video=" << hasVideo << " for LEG " << call->GetLegIndex() );
  
  PAssert( !call->GetInterfaceAddress().IsEmpty() &&  !call->GetTranslatedInterfaceAddress().IsEmpty(), PLogicError );
  PIPSocket::Address iface( call->GetInterfaceAddress().c_str() );
  iface.SetExternalIP( call->GetTranslatedInterfaceAddress().c_str() );

  rtpIface->SetLocalSDPAddress( iface );
  LOG( LogInfo(), call->GetInterfaceAddress().c_str() );
  LOG( LogInfo(), "RTP: Setting Local RTP Address to " <<  iface << "/" << iface.GetExternalIP() << " for LEG " << call->GetLegIndex()  );
  PIPSocket::Address initialTarget = call->GetInitialTargetAddress();
  PAssert( initialTarget.IsValid(), PLogicError );
  
  /// Create RTP Session for Audio
  SIPURI audioMediaAddress, videoMediaAddress;
  if( hasAudio )
  {
    if( !sdp.GetMediaAddress( SDPLazyParser::Audio, audioMediaAddress ) )
    {
      LOG( LogError(), "RTP: Unable to Audio parse media address from SDP for LEG " << call->GetLegIndex() );
      return FALSE;
    }

    BOOL isHold = audioMediaAddress.GetHost() == "0.0.0.0";
    if( isHold )
    {
      LOG( LogInfo(), "RTP: SDP Offer (AUDIO) address is 0.0.0.0. Call-Hold for LEG "<< call->GetLegIndex() );
    }

    int rfc2833Payload = SDPMediaFmt::IllegalPayloadType;
    sdp.GetPayloadTypeFromName( SDPLazyParser::Audio, 0, "telephone-event", rfc2833Payload );

    if( m_SwitchEndPoint->CreateRTPSession(
      *call, 
      OpalMediaFormat::DefaultAudioSessionID, 
      iface, 
      initialTarget, /// Wisest guess where SDP will come from (Based on signaling target)
      initialTarget, /// Wisest guess where SDP will come from (Based on signaling target)
      0, /// this is yet to be known
      call->IsEncryptionEnabled(),
      rfc2833Payload )) 
    {
      sdp.SetOriginAddress( call->GetTranslatedInterfaceAddress().c_str() );
      sdp.SetGlobalAddress( call->GetTranslatedInterfaceAddress().c_str() );
      if( !isHold )
      {
        //translate the SDP;
        RTP_UDP * rtp = (RTP_UDP*)call->GetRTPSessionManager().GetSession( OpalMediaFormat::DefaultAudioSessionID );
        sdp.SetMediaAddress( SDPLazyParser::Audio, 0, call->GetTranslatedInterfaceAddress().c_str(), rtp->GetLocalDataPort() );
      }
    }else
    {
      LOG( LogError(), "RTP: !!! Unable to create RTP Session (AUDIO) for " << sid << " " << vid << " LEG " << call->GetLegIndex()<< " !!!" );
      return FALSE;
    }
  }

  if( hasVideo )
  {
    if( !sdp.GetMediaAddress( SDPLazyParser::Video, videoMediaAddress ) )
    {
      LOG( LogError(), "RTP: Unable to parse Video media address from SDP for LEG " << call->GetLegIndex() );
      return FALSE;
    }
    // check if its a hold
    BOOL isHold = videoMediaAddress.GetHost() == "0.0.0.0";
    if( isHold )
    {
      LOG( LogInfo(), "RTP: SDP Offer (Video) address is 0.0.0.0. Call-Hold for LEG "<< call->GetLegIndex() );
    }

    if( m_SwitchEndPoint->CreateRTPSession(
      *call, 
      OpalMediaFormat::DefaultVideoSessionID, 
      iface, 
      initialTarget, /// Wisest guess where SDP will come from (Based on signaling target)
      initialTarget, /// Wisest guess where SDP will come from (Based on signaling target)
      0, /// this is yet to be known
      call->IsEncryptionEnabled() )) 
    {
      if( !isHold )
      {
        //translate the SDP;
        RTP_UDP * rtp = (RTP_UDP*)call->GetRTPSessionManager().GetSession( OpalMediaFormat::DefaultVideoSessionID );
        sdp.SetMediaAddress( SDPLazyParser::Video, 0, call->GetTranslatedInterfaceAddress().c_str(), rtp->GetLocalDataPort() );
      }
    }else
    {
      LOG( LogError(), "RTP: !!! Unable to create RTP Session (VIDEO) for " << sid << " " << vid << " LEG " << call->GetLegIndex()<< " !!!" );
      return FALSE;
    }
  }

  message.SetSDP( sdp );

  return TRUE;
}

BOOL SBCSwitchMedia::OnSwitchIncomingSDPAnswer(
  SBCSwitchConnection * conn,
  SBCB2BUACall * call,
  const SIPMessage & message
)
{
  PWaitAndSignal lock( m_SDPMutex );
  if( !message.HasSDP() )
    return TRUE;

  SBCSwitchRTPInterface * rtpIface = dynamic_cast<SBCSwitchRTPInterface *>(call);

  if( m_B2BSDPState != SDP_StateWaitingAnswer &&
      m_B2BSDPState != SDP_StateReceivedAnswerPreview &&
      m_B2BSDPState != SDP_StateReceivedAnswerPreviewMultiple )
  {
#ifdef _MSC_VER
    switch( m_B2BSDPState )
    {
      case SDP_StateNone:
        MSVCTRACE( "RTP: Got IncomingSDPAnswer in state SDP_StateNone" );
        break;
      case SDP_StateReceivedOffer:
        MSVCTRACE( "RTP: Got IncomingSDPAnswer in state SDP_StateReceivedOffer" );
        break;
      case SDP_StateReceivedAnswerPreview:
        MSVCTRACE( "RTP: Got IncomingSDPAnswer in state SDP_StateReceivedAnswerPreview" );
        break;
      case SDP_StateReceivedAnswerFinal:
        MSVCTRACE( "RTP: Got IncomingSDPAnswer in state SDP_StateReceivedAnswerFinal" );
        break;
      case SDP_StateNegotiated:
        MSVCTRACE( "RTP: Got IncomingSDPAnswer in state SDP_StateNegotiated" );
        break;
    }
#endif //_MSC_VER
    return FALSE;
  }

  if( message.Is1xx() )
  {
    if( m_B2BSDPState == SDP_StateReceivedAnswerPreview )
      m_B2BSDPState = SDP_StateReceivedAnswerPreviewMultiple;
    else
      m_B2BSDPState = SDP_StateReceivedAnswerPreview;
  }else if( message.Is2xx() )
  {
    if( m_B2BSDPState == SDP_StateReceivedAnswerPreview )
      m_B2BSDPState = SDP_StateReceivedAnswerFinalWithPreview;
    else if( m_B2BSDPState == SDP_StateWaitingAnswer )
      m_B2BSDPState = SDP_StateReceivedAnswerFinal;
  }else
  {
    return FALSE;
  }

  SDPLazyParser sdp = message.GetBody();
  rtpIface->SetRemoteSDP( sdp );
  RTP_UDP * audioRTP = (RTP_UDP*)call->GetRTPSessionManager().GetSession( OpalMediaFormat::DefaultAudioSessionID );
  if( audioRTP != NULL )
  {
    SIPURI mediaAddress;
    sdp.GetMediaAddress( SDPLazyParser::Audio, mediaAddress );
    PIPSocket::Address addr = mediaAddress.GetAddress();
    WORD port = (WORD)mediaAddress.GetPort().AsUnsigned();
    audioRTP->SetTemporaryRemoteSocketInfo( addr, port, TRUE ); 
  }

  RTP_UDP * videoRTP = (RTP_UDP*)call->GetRTPSessionManager().GetSession( OpalMediaFormat::DefaultVideoSessionID );
  if( videoRTP != NULL )
  {
    SIPURI mediaAddress;
    sdp.GetMediaAddress( SDPLazyParser::Video, mediaAddress );
    PIPSocket::Address addr = mediaAddress.GetAddress();
    WORD port = (WORD)mediaAddress.GetPort().AsUnsigned();
    videoRTP->SetTemporaryRemoteSocketInfo( addr, port, TRUE ); 
  }

  return TRUE;
}

BOOL SBCSwitchMedia::OnSwitchRequireSDPAnswer(
  SBCSwitchConnection * conn,
  SBCB2BUACall * call,
  SIPMessage & message
)
{
  PWaitAndSignal lock( m_SDPMutex );
  if( !message.HasSDP() )
    return TRUE;

  if( m_B2BSDPState != SDP_StateReceivedAnswerPreview && 
      m_B2BSDPState != SDP_StateReceivedAnswerFinal && 
      m_B2BSDPState != SDP_StateReceivedAnswerFinalWithPreview &&
      m_B2BSDPState != SDP_StateReceivedAnswerPreviewMultiple )
  {
#ifdef _MSC_VER
    switch( m_B2BSDPState )
    {
      case SDP_StateNone:
        MSVCTRACE( "Got RequireSDPAnswer in state SDP_StateNone" );
        break;
      case SDP_StateReceivedOffer:
        MSVCTRACE( "Got RequireSDPAnswer in state SDP_StateReceivedOffer" );
        break;
      case SDP_StateWaitingAnswer:
        MSVCTRACE( "Got RequireSDPAnswer in state SDP_StateWaitingAnswer" );
        break;
      case SDP_StateReceivedAnswerFinal:
        MSVCTRACE( "Got RequireSDPAnswer in state SDP_StateReceivedAnswerFinal" );
        break;
      case SDP_StateNegotiated:
        MSVCTRACE( "Got RequireSDPAnswer in state SDP_StateNegotiated" );
        break;
    }
#endif //_MSC_VER
    return FALSE;
  }

  SDPLazyParser sdp = message.GetBody();
  sdp.SetOriginAddress( call->GetTranslatedInterfaceAddress().c_str() );
  sdp.SetGlobalAddress( call->GetTranslatedInterfaceAddress().c_str() );

  RTP_UDP * audioRTP = (RTP_UDP*)call->GetRTPSessionManager().GetSession( OpalMediaFormat::DefaultAudioSessionID );
  if( audioRTP != NULL )
    sdp.SetMediaAddress( SDPLazyParser::Audio, 0, call->GetTranslatedInterfaceAddress().c_str(), audioRTP->GetLocalDataPort() );

  RTP_UDP * videoRTP = (RTP_UDP*)call->GetRTPSessionManager().GetSession( OpalMediaFormat::DefaultVideoSessionID );
  if( videoRTP != NULL )
    sdp.SetMediaAddress( SDPLazyParser::Video, 0, call->GetTranslatedInterfaceAddress().c_str(), videoRTP->GetLocalDataPort() );

  BOOL ok = TRUE;

  if( m_B2BSDPState == SDP_StateReceivedAnswerFinal || m_B2BSDPState == SDP_StateReceivedAnswerFinalWithPreview )
  {
    if( m_B2BSDPState == SDP_StateReceivedAnswerFinal )
      ok = BridgeEndToEnd();
    m_B2BSDPState = SDP_StateNegotiated;
  }else
  {
    if( m_B2BSDPState != SDP_StateReceivedAnswerPreview )
      ok = BridgeEndToEnd();
  }

  message.SetSDP( sdp );

  return ok;
}

BOOL SBCSwitchMedia::BridgeMS( SBCB2BUACall * calltoBridge )
{
  PWaitAndSignal lock( m_RTPBridgeMutex );
  if( m_SwitchConnection == NULL || !m_SwitchConnection->IsSafeReference() )
    return FALSE;

  /// Pause the active audio bridge;
  if( m_ActiveAudioBridge != NULL )
    m_ActiveAudioBridge->SetPause( TRUE );

  return TRUE;
}

BOOL SBCSwitchMedia::BridgeEndToEnd()
{
  PWaitAndSignal lock( m_RTPBridgeMutex );
  if( m_SwitchConnection == NULL || !m_SwitchConnection->IsSafeReference() )
    return FALSE;

  if( m_ActiveAudioBridge != NULL )
  {
    m_ActiveAudioBridge->SetPause( FALSE );
    return TRUE;
  }

  SBCSwitchLeg1 * leg1 = dynamic_cast<SBCSwitchLeg1*>(m_SwitchConnection->GetLeg1Call());
  if( leg1 == NULL )
    return FALSE;

  SBCSwitchLeg2 * leg2 = dynamic_cast<SBCSwitchLeg2*>(m_SwitchConnection->GetLeg2Call());
  if( leg2 == NULL )
    return FALSE;

  

  RTP_UDP * audio1 = (RTP_UDP *)(leg1->GetRTPSessionManager().GetSession( OpalMediaFormat::DefaultAudioSessionID ));
  RTP_UDP * audio2 = (RTP_UDP *)(leg2->GetRTPSessionManager().GetSession( OpalMediaFormat::DefaultAudioSessionID ));
  if( audio1 != NULL && audio2 != NULL )
  {
    LOG( LogInfo(), "RTP: Bridge Info " <<
      audio1->GetTemporaryRemoteDataAddress() << ":" << audio1->GetTemporaryRemoteDataPort() << "<-" <<
      audio1->GetLocalAddress() << ":" << audio1->GetLocalDataPort() << " | " << 
      audio2->GetLocalAddress() << ":" << audio2->GetLocalDataPort() << "->" <<
      audio2->GetTemporaryRemoteDataAddress() << ":" << audio2->GetTemporaryRemoteDataPort() );
       
    m_ActiveAudioBridge = new SBCSwitchRTPBridge( audio1, audio2 );
    m_ActiveAudioBridge->Resume();
  }

  if( m_ActiveVideoBridge != NULL )
  {
    if( !m_ActiveVideoBridge->SetTerminated() )
      return FALSE;

    delete m_ActiveVideoBridge;
    m_ActiveVideoBridge = NULL;
  }

  RTP_UDP * video1 = (RTP_UDP *)(leg1->GetRTPSessionManager().GetSession( OpalMediaFormat::DefaultVideoSessionID ));
  RTP_UDP * video2 = (RTP_UDP *)(leg2->GetRTPSessionManager().GetSession( OpalMediaFormat::DefaultVideoSessionID ));
  if( video1 != NULL && video2 != NULL )
  {
    LOG( LogInfo(), "RTP: Bridge Info " <<
      video1->GetTemporaryRemoteDataAddress() << ":" << video1->GetTemporaryRemoteDataPort() << "<-" <<
      video1->GetLocalAddress() << ":" << video1->GetLocalDataPort() << " | " << 
      video2->GetLocalAddress() << ":" << video2->GetLocalDataPort() << "->" <<
      video2->GetTemporaryRemoteDataAddress() << ":" << video2->GetTemporaryRemoteDataPort() );

    m_ActiveVideoBridge = new SBCSwitchRTPBridge( video1, video2 );
    m_ActiveVideoBridge->Resume();
  }

  return TRUE;
}

BOOL SBCSwitchMedia::BridgeDestroy()
{
  if( m_ActiveAudioBridge != NULL )
  {
    if( !m_ActiveAudioBridge->SetTerminated() )
      return FALSE;

    delete m_ActiveAudioBridge;
    m_ActiveAudioBridge = NULL;
  }

  if( m_ActiveVideoBridge != NULL )
  {
    if( !m_ActiveVideoBridge->SetTerminated() )
      return FALSE;

    delete m_ActiveVideoBridge;
    m_ActiveVideoBridge = NULL;
  }

  return TRUE;
}

