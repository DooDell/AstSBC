/*
 *
 * SBCSwitchConnection.h
 *
 * Open SIP Stack ( OSS )
 *
 * Copyright (c) opensipstack.org.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either expressed or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is OpenSIPStack.
 *
 * The Initial Developer of the Original Code is opensipstack.org.
 *
 * The author of this code is Joegen E. Baclor
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * The OpenSIPStack Library includes some GPL/LGPL code libraries that MAY be 
 * enabled at compile time using the --enable-gpllibs configure switch.  If
 * enabled, the content of this file is published under the terms of GNU 
 * General Public License Version 2.  For a detailed list of the available
 * GPL code, see $(opensipstack)/gnu/README file.
 *
 * $Log: SBCSwitchConnection.h,v $
 * Revision 1.4  2009/06/09 07:11:49  joegenbaclor
 * added ivr leg class
 *
 * Revision 1.3  2009/06/03 11:57:16  joegenbaclor
 * Checking in MOH feature
 *
 * Revision 1.2  2009/05/29 09:31:32  joegenbaclor
 * Added Switch IVR Classes
 *
 * Revision 1.1  2009/05/27 12:40:34  joegenbaclor
 * Initial upload of switch related classes
 *
 *
 */

#ifndef SBCSWITCHEDCONNECTION_H
#define SBCSWITCHEDCONNECTION_H


#include "SBCConnection.h"
#include "SBCSwitchMedia.h"
#include "SBCSwitchCallFeature.h"
#include "SBCB2BUACall.h"

namespace SWITCH
{
  using namespace B2BUA;

  class SBCSwitchConnection : public SBCConnection, public SBCSwitchCallFeatureInterface
  {
    PCLASSINFO( SBCSwitchConnection, SBCConnection );
  public:

    enum SwitchConnectionEvent
    {
      Event_IVRAnswer = SBCConnection::NumCallControlEvent
    };

    SBCSwitchConnection(
      B2BUAEndPoint & ep,
      const OString & sessionId
    );

    virtual ~SBCSwitchConnection();

    virtual void OnSessionEvent(
      SIPSessionEvent & sessionEvent
    );

    virtual void AddRoute( 
      const SIPURI & route, 
      const SIPMessage * invite = NULL 
    );

    virtual void OnSetupOutbound(
      const SIPMessage & inboundInvite
    );
  
    virtual void OnDestroySession();
    
    virtual BOOL OnIncomingSDPOffer(
      B2BUACall & call,
      const SIPMessage & sdp
    );

    virtual BOOL OnIncomingSDPAnswer(
      B2BUACall & call,
      const SIPMessage & sdp
    );

    /// your last chance to produce an answer to the offer.  
    /// This will be called either before sending 183, 200 or ACK 
    virtual BOOL OnRequireSDPAnswer(
      B2BUACall & call,
      const SIPMessage & offer,
      SIPMessage & answer
    );

    /// this will be called if an offer is not received in INVITE or when we are initiating the call
    virtual BOOL OnRequireSDPOffer(
      B2BUACall & call,
      SIPMessage & offer
    );

    virtual void OnConnected(
      B2BUACall & call,
      SIPMessage & msg 
    );
    virtual void OnDisconnected(
      B2BUACall & call,
      const SIPMessage & msg 
    );

    virtual void OnReceivedFCodeEvent(
      SBCB2BUACall & call,
      const OString & fCode
    );

    PIPSocket::Address GetSDPAddress( const PIPSocket::Address & iface )const;


    PINLINE void AttachSwitchMedia( SBCSwitchMedia * media ){ m_SwitchMedia = media; };
    SBCSwitchMedia * GetSwitchMedia()const{ return m_SwitchMedia; };
  protected:
    SBCSwitchMedia * m_SwitchMedia;
    
  };
}


#endif //SBCSWITCHEDCONNECTION_H
