/*
 *
 * PythonScript.cxx
 * 
 * Open SIP Stack ( OSS )
 *
 * Copyright (c) opensipstack.org.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either expressed or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is OpenSIPStack.
 *
 * The Initial Developer of the Original Code is opensipstack.org.
 *
 * The author of this code is Joegen E. Baclor
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * The OpenSIPStack Library includes some GPL/LGPL code libraries that MAY be 
 * enabled at compile time using the --enable-gpllibs configure switch.  If
 * enabled, the content of this file is published under the terms of GNU 
 * General Public License Version 2.  For a detailed list of the available
 * GPL code, see $(opensipstack)/gnu/README file.
 *
 * $Log: PythonScript.cxx,v $
 * Revision 1.7  2008/03/13 06:02:27  joegenbaclor
 * Completed new GCC build environment with PHP and Python support
 *
 * Revision 1.6  2008/03/12 03:36:55  joegenbaclor
 * More GCC compile fixes for python and variant class
 *
 * Revision 1.5  2008/03/11 15:00:40  joegenbaclor
 * PHP Build fixes
 *
 * Revision 1.4  2008/03/11 02:10:03  joegenbaclor
 * Revised PHP Sapi implementation and removed python from configure script check
 *
 * Revision 1.3  2008/03/05 05:56:49  joegenbaclor
 * Updated Visual Studio 2005 project to include Python script support files
 *
 * Revision 1.2  2008/03/04 17:50:48  joegenbaclor
 * Added PySNMP support
 *
 * Revision 1.1  2008/03/04 06:44:31  joegenbaclor
 * Adding Python classes
 *
 *
 */

#include <python/PythonScript.h>

#if HAS_PYTHON_SAPI

#ifdef WIN32
#pragma message("*** Python SAPI Enabled ***")
#endif

#include <iostream>

extern "C"
{
#ifdef WIN32
#pragma warning(disable: 4996)
#ifdef _DEBUG
#undef _DEBUG
#include <Python.h>
#define _DEBUG
#else
#include <Python.h>
#endif
#else
#include <Python.h>
#endif
}

//#ifdef _MSC_VER
//#ifndef _WIN32_WCE
//#pragma comment(lib, PYTHON_LIBRARY)
//#endif // !_WIN32_WCE
//#endif

using namespace PYTHON;

static PyObject * py_module = NULL;
static PythonScript * script_engine = NULL;

struct PythonSingleton
{
  PythonSingleton()
  {
    Py_Initialize();  
  }

  //~PythonSingleton()
  //{
  //  Py_Finalize();
  //}
};

static PythonSingleton python_singleton;

class python_exception: public std::exception
{
public:
  python_exception( const std::string & w )
  {
    m_What = w;
  }
  
  ~python_exception()throw(){}

  const char* what() const throw()
  {
    return m_What.c_str();
  }

  std::string m_What;
};

static PyObject* cpp_evaluate(PyObject *self, PyObject *tuple)
{
  if( !PyTuple_Check( tuple ) )
  {
    Py_INCREF(Py_None);
    return Py_None;
  }

  Py_ssize_t t_size = PyTuple_Size( tuple );
  if( t_size == 0 )
  {
    Py_INCREF(Py_None);
    return Py_None;
  }

  PyObject* func = PyTuple_GetItem( tuple, 0);
  if( !PyString_Check(func) )
  {
    Py_INCREF(Py_None);
    return Py_None;
  }

  std::string funcName = std::string( PyString_AsString(func) );
  
  PythonVariantMap in, out;
  for( Py_ssize_t i = 1; i < t_size; i++ )
  {
    PyObject* py_ret = PyTuple_GetItem( tuple, i);
    if( py_ret != NULL )
    {
      char buf[20];
      sprintf( buf, "%d", (int)i );
      if( PyString_Check(py_ret) )
      {
        in[buf] = std::string( PyString_AsString(py_ret) );
      }else if( PyInt_Check(py_ret) )
      {
        in[buf] = PyInt_AsLong( py_ret );
      }else if( PyLong_Check(py_ret) )
      {
        in[buf] = PyLong_AsLong( py_ret );
      }else if( PyFloat_Check(py_ret) )
      {
        in[buf] = PyFloat_AsDouble( py_ret );
      }else if( py_ret == Py_False || py_ret == Py_True)
      {
        in[buf] = py_ret == Py_True ? true : false;
      }else if( PyTuple_Check( py_ret ) )
      {
        Py_ssize_t t_size = PyTuple_Size( py_ret );

        for( Py_ssize_t i = 0; i < t_size; i++ )
        {
          PyObject* item = PyTuple_GetItem( py_ret, i);
          if( item != NULL )
          {
            char buf[20];
            sprintf( buf, "%d", (int)i );
            if( PyString_Check(item) )
            {
              in[buf] = std::string( PyString_AsString(item) );
            }else if( PyInt_Check(item) )
            {
              in[buf] = PyInt_AsLong( item );
            }else if( PyLong_Check(item) )
            {
              in[buf] = PyLong_AsLong( item );
            }else if( PyFloat_Check(item) )
            {
              in[buf] = PyFloat_AsDouble( item );
            }else if( item == Py_False || item == Py_True)
            {
              in[buf] = item == Py_True ? true : false;
            }
          }
        }
      }else if( PyList_Check( py_ret ) )
      {
        Py_ssize_t t_size = PyList_Size( py_ret );

        for( Py_ssize_t i = 0; i < t_size; i++ )
        {
          PyObject* item = PyList_GetItem( py_ret, i);
          if( item != NULL )
          {
            char buf[20];
            sprintf( buf, "%d", (int)i );
            if( PyString_Check(item) )
            {
              in[buf] = std::string( PyString_AsString(item) );
            }else if( PyInt_Check(item) )
            {
              in[buf] = PyInt_AsLong( item );
            }else if( PyLong_Check(item) )
            {
              in[buf] = PyLong_AsLong( item );
            }else if( PyFloat_Check(item) )
            {
              in[buf] = PyFloat_AsDouble( item );
            }else if( item == Py_False || item == Py_True)
            {
              in[buf] = item == Py_True ? true : false;
            }
          }
        }
      }else if( PyDict_Check( py_ret ) )
      {
        PyObject *key, *item;
        Py_ssize_t pos = 0;
        while (PyDict_Next(py_ret, &pos, &key, &item)) 
        {
          char buf[20];
          sprintf( buf, "%d", (int)pos );
          std::string first;
          if( PyString_Check(key) )
            first = std::string( PyString_AsString(key) );
          else
            first = buf;

          if( PyString_Check(item) )
          {
            in[first] = std::string( PyString_AsString(item) );
          }else if( PyInt_Check(item) )
          {
            in[first] = PyInt_AsLong( item );
          }else if( PyLong_Check(item) )
          {
            in[first] = PyLong_AsLong( item );
          }else if( PyFloat_Check(item) )
          {
            in[first] = PyFloat_AsDouble( item );
          }else if( item == Py_False || item == Py_True)
          {
            in[first] = item == Py_True ? true : false;
          }
        }
      }
    }
  }

  script_engine->OnCPPEvaluate( funcName, in, out );

  if( out.size() == 1 )
  {
    PythonVariantMap::iterator iter = out.begin();

    PyObject* py_val = NULL;
    if ( iter->second.is_type<int>() )
    {
      py_val = PyInt_FromLong((long)(int)iter->second);
      Py_INCREF(py_val);
    }else if ( iter->second.is_type<double>() )
    {
      py_val = PyFloat_FromDouble((double)iter->second);
      Py_INCREF(py_val);
    }else if ( iter->second.is_type<long>() )
    {
      py_val = PyLong_FromLong((long)iter->second);
      Py_INCREF(py_val);
    }else if ( iter->second.is_type<std::string>() )
    {
      std::string str_value = iter->second.str();
      py_val = PyString_FromString(str_value.c_str());
      Py_INCREF(py_val);
    }else if( iter->second.is_type<bool>() )
    {
      py_val = PyBool_FromLong((long)iter->second);
    }else
    {
      throw python_exception( "Python Function Parameter Unknown Type" );
    }

    Py_INCREF(py_val);
    return py_val;
  }

  Py_INCREF(Py_None);
  return Py_None;
}

static PyMethodDef cpp_functions[ ] = 
{
  {"eval",   (PyCFunction)cpp_evaluate,   METH_VARARGS},
  {NULL, NULL}
};


PythonScript::PythonScript( int argc, char **argv )
{
  if( script_engine == NULL )
    script_engine = this;

  PySys_SetArgv(argc, argv);
  py_module = NULL;
  PyImport_AddModule("cpp");
  Py_InitModule("cpp", cpp_functions);
}

PythonScript::~PythonScript()
{
}

int PythonScript::LoadScript( const std::string & file )
{
  if( py_module != NULL )
    Py_DECREF( py_module );
  
  py_module = NULL;
  PyObject* name = PyString_FromString(file.c_str());
  py_module = PyImport_Import(name);   

  Py_DECREF(name);
  if (!py_module)
    return false;

  return true;
}


bool PythonScript::PythonEvaluate( 
  const std::string & funcName,
  PythonVariantMap & in,
  PythonVariantMap & out
)
{
  if (!py_module )
    return false;

  PyObject* func = PyObject_GetAttrString(py_module, const_cast<char*>(funcName.c_str()));
  
  if (!func ) 
  {
    return false;  
  }else if( !PyCallable_Check(func))
  {
    Py_DECREF(func); 
    return false;
  }

  PyObject* tuple = NULL;

  if( in.size() > 0 )
  {
    tuple = PyTuple_New(in.size());
    Py_XINCREF(tuple);
    int  tupleIndex = 0;
    for( PythonVariantMap::iterator iter = in.begin(); iter != in.end(); iter++ )
    {
      PyObject* py_val = NULL;
      if ( iter->second.is_type<int>() )
      {
        py_val = PyInt_FromLong((long)(int)iter->second);
        PyTuple_SetItem(tuple, ++tupleIndex, py_val);
        Py_DECREF(py_val);
      }else if ( iter->second.is_type<double>() )
      {
        py_val = PyFloat_FromDouble((double)iter->second);
        PyTuple_SetItem(tuple, ++tupleIndex, py_val );
        Py_DECREF(py_val);
      }else if ( iter->second.is_type<long>() )
      {
        py_val = PyLong_FromLong((long)iter->second);
        PyTuple_SetItem(tuple, ++tupleIndex, py_val );
        Py_DECREF(py_val);
      }else if ( iter->second.is_type<std::string>() )
      {
        std::string str_value;
        str_value = iter->second.str();
        py_val = PyString_FromString(str_value.c_str());
        PyTuple_SetItem(tuple, ++tupleIndex, py_val );
        Py_DECREF(py_val);
      }else if( iter->second.is_type<bool>() )
      {
        py_val = PyBool_FromLong((long)iter->second);
        PyTuple_SetItem(tuple, ++tupleIndex, py_val );
        Py_DECREF(py_val);
      }else
      {
        throw python_exception( "Python Function Parameter Unknown Type" );
      }
    }
  }

  PyObject* py_ret = PyObject_CallObject(func, tuple);
  
  if( py_ret != NULL )
  {
    if( PyString_Check(py_ret) )
    {
      out["0"] = std::string( PyString_AsString(py_ret) );
    }else if( PyInt_Check(py_ret) )
    {
      out["0"] = PyInt_AsLong( py_ret );
    }else if( PyLong_Check(py_ret) )
    {
      out["0"] = PyLong_AsLong( py_ret );
    }else if( PyFloat_Check(py_ret) )
    {
      out["0"] = PyFloat_AsDouble( py_ret );
    }else if( py_ret == Py_False || py_ret == Py_True)
    {
      out["0"] = py_ret == Py_True ? true : false;
    }else if( PyTuple_Check( py_ret ) )
    {
      Py_ssize_t t_size = PyTuple_Size( py_ret );

      for( Py_ssize_t i = 0; i < t_size; i++ )
      {
        PyObject* item = PyTuple_GetItem( py_ret, i);
        if( item != NULL )
        {
          char buf[20];
          sprintf( buf, "%d", (int)i );
          if( PyString_Check(item) )
          {
            out[buf] = std::string( PyString_AsString(item) );
          }else if( PyInt_Check(item) )
          {
            out[buf] = PyInt_AsLong( item );
          }else if( PyLong_Check(item) )
          {
            out[buf] = PyLong_AsLong( item );
          }else if( PyFloat_Check(item) )
          {
            out[buf] = PyFloat_AsDouble( item );
          }else if( item == Py_False || item == Py_True)
          {
            out[buf] = item == Py_True ? true : false;
          }
        }
      }
    }else if( PyList_Check( py_ret ) )
    {
      Py_ssize_t t_size = PyList_Size( py_ret );

      for( Py_ssize_t i = 0; i < t_size; i++ )
      {
        PyObject* item = PyList_GetItem( py_ret, i);
        if( item != NULL )
        {
          char buf[20];
          sprintf( buf, "%d", (int)i );
          if( PyString_Check(item) )
          {
            out[buf] = std::string( PyString_AsString(item) );
          }else if( PyInt_Check(item) )
          {
            out[buf] = PyInt_AsLong( item );
          }else if( PyLong_Check(item) )
          {
            out[buf] = PyLong_AsLong( item );
          }else if( PyFloat_Check(item) )
          {
            out[buf] = PyFloat_AsDouble( item );
          }else if( item == Py_False || item == Py_True)
          {
            out[buf] = item == Py_True ? true : false;
          }
        }
      }
    }else if( PyDict_Check( py_ret ) )
    {
      PyObject *key, *item;
      Py_ssize_t pos = 0;
      while (PyDict_Next(py_ret, &pos, &key, &item)) 
      {
        char buf[20];
        sprintf( buf, "%d", (int)pos );
        std::string first;
        if( PyString_Check(key) )
          first = std::string( PyString_AsString(key) );
        else
          first = buf;

        if( PyString_Check(item) )
        {
          out[first] = std::string( PyString_AsString(item) );
        }else if( PyInt_Check(item) )
        {
          out[first] = PyInt_AsLong( item );
        }else if( PyLong_Check(item) )
        {
          out[first] = PyLong_AsLong( item );
        }else if( PyFloat_Check(item) )
        {
          out[first] = PyFloat_AsDouble( item );
        }else if( item == Py_False || item == Py_True)
        {
          out[first] = item == Py_True ? true : false;
        }
      }
    }
  }

  if( tuple != NULL )
    Py_XDECREF(tuple);

  Py_DECREF(func);  
  
  return true;
}

#else
#pragma message("*** Python SAPI Disabled ***")
#endif  //HAS_PYTHON_SAPI
