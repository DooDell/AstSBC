/*
 *
 * SolegyPromptManager.h
 *
 * Open SIP Stack ( OSS )
 *
 * Copyright (c) opensipstack.org.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either expressed or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is OpenSIPStack.
 *
 * The Initial Developer of the Original Code is opensipstack.org.
 *
 * The author of this code is Joegen E. Baclor
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * The OpenSIPStack Library includes some GPL/LGPL code libraries that MAY be 
 * enabled at compile time using the --enable-gpllibs configure switch.  If
 * enabled, the content of this file is published under the terms of GNU 
 * General Public License Version 2.  For a detailed list of the available
 * GPL code, see $(opensipstack)/gnu/README file.
 *
 * $Log: SolegyPromptManager.h,v $
 * Revision 1.8  2008/12/06 05:10:16  joegenbaclor
 * Fixed bug where premature call cancelation for IVR calls may result to the b2bua connection
 *  not getting destroyed.
 *
 * Revision 1.7  2008/10/22 05:06:25  joegenbaclor
 * Added MPL License Header
 *
 *
 */

#ifndef SOLEGYPROMPTMANAGER_H
#define SOLEGYPROMPTMANAGER_H

#include <ptlib.h>
#include "OString.h"
#include "B2BUAConnection.h"

using namespace Tools;

namespace SOLEGY
{
  class SolegySession;

  class SolegyPrompt : public PObject
  {
    PCLASSINFO( SolegyPrompt, PObject );
  public:
    enum PromptNumType
    {
      PR_NUM_ZERO,
      PR_NUM_ONE,
      PR_NUM_TWO,
      PR_NUM_THREE,
      PR_NUM_FOUR,
      PR_NUM_FIVE,
      PR_NUM_SIX,
      PR_NUM_SEVEN,
      PR_NUM_EIGHT,
      PR_NUM_NINE,
      PR_NUM_TEN,
      PR_NUM_ELEVEN,
      PR_NUM_TWELVE,
      PR_NUM_THIRTEEN,
      PR_NUM_FOURTEEN,
      PR_NUM_FIFTEEN,
      PR_NUM_SIXTEEN,
      PR_NUM_SEVENTEEN,
      PR_NUM_EIGHTEEN,
      PR_NUM_NINETEEN,
      PR_NUM_TWENTY,
      PR_NUM_THIRTY,
      PR_NUM_FORTY,
      PR_NUM_FIFTY,
      PR_NUM_SIXTY,
      PR_NUM_SEVENTY,
      PR_NUM_EIGHTY,
      PR_NUM_NINETY,
      PR_NUM_HUNDRED,
      PR_NUM_THOUSAND,
      PR_NUM_THOUSANDS,
      PR_NUM_MILLION,
      PR_NUM_MILLIONS,
      PR_NUM_CUSTOM_1,
      PR_NUM_CUSTOM_2,
      PR_NUM_CUSTOM_3,
      PR_NUM_CUSTOM_4,
      PR_NUM_CUSTOM_5,
      PR_NUM_CUSTOM_6,
      PR_NUM_CUSTOM_7,
      PR_NUM_CUSTOM_8,
      PR_NUM_CUSTOM_9,
      PR_NUM_CUSTOM_10,
      NUM_PR_NUM
    };

    enum PromptPhraseType
    {
      PR_PRH_WELCOME,
      PR_PRH_GOOD_BYE,
      PR_PRH_ENTER_PIN,
      PR_PRH_INVALID_PIN,
      PR_PRH_ENTER_NUMBER,
      PR_PRH_INVALID_NUMBER,
      PR_PRH_TRY_AGAIN,
      PR_PRH_INFORM_CALL_TRANSFER,
      PR_PRH_INFORM_BALANCE,
      PR_PRH_INFORM_TALK_TIME,
      PR_PRH_AND,
      PR_PRH_CUSTOM_1,
      PR_PRH_CUSTOM_2,
      PR_PRH_CUSTOM_3,
      PR_PRH_CUSTOM_4,
      PR_PRH_CUSTOM_5,
      PR_PRH_CUSTOM_6,
      PR_PRH_CUSTOM_7,
      PR_PRH_CUSTOM_8,
      PR_PRH_CUSTOM_9,
      PR_PRH_CUSTOM_10,
      NUM_PR_PRH
    };

    enum PromptCurrencyType
    {
      PR_CUR_DOLLAR,
      PR_CUR_DOLLARS,
      PR_CUR_POUND,
      PR_CUR_POUNDS,
      PR_CUR_EURO,
      PR_CUR_EUROS,
      PR_CUR_CENT,
      PR_CUR_CENTS,
      PR_CUR_CUSTOM_1,
      PR_CUR_CUSTOM_2,
      PR_CUR_CUSTOM_3,
      PR_CUR_CUSTOM_4,
      PR_CUR_CUSTOM_5,
      PR_CUR_CUSTOM_6,
      PR_CUR_CUSTOM_7,
      PR_CUR_CUSTOM_8,
      PR_CUR_CUSTOM_9,
      PR_CUR_CUSTOM_10,
      NUM_PR_CUR
    };

    enum PromptDateTimeType
    {
      PR_DTIME_SECOND,
      PR_DTIME_SECONDS,
      PR_DTIME_MINUTE,
      PR_DTIME_MINUTES,
      PR_DTIME_HOUR,
      PR_DTIME_HOURS,
      PR_DTIME_DAY,
      PR_DTIME_DAYS,
      PR_DTIME_WEEK,
      PR_DTIME_WEEKS,
      PR_DTIME_MONTH,
      PR_DTIME_MONTHS,
      PR_DTIME_YEAR,
      PR_DTIME_YEARS,
      PR_DTIME_MONDAY,
      PR_DTIME_TUESDAY,
      PR_DTIME_WEDNESDAY,
      PR_DTIME_THURSDAY,
      PR_DTIME_FRIDAY,
      PR_DTIME_SATURDAY,
      PR_DTIME_SUNDAY,
      PR_DTIME_JANUARY,
      PR_DTIME_FEBRUARY,
      PR_DTIME_MARCH,
      PR_DTIME_APRIL,
      PR_DTIME_MAY,
      PR_DTIME_JUNE,
      PR_DTIME_JULY,
      PR_DTIME_AUGUST,
      PR_DTIME_SEPTEMBER,
      PR_DTIME_OCTOBER,
      PR_DTIME_NOVEMBER,
      PR_DTIME_DECEMBER,
      NUM_PR_DTIME
    };

    enum PromptErrorType
    {
      PR_ERROR_ACCOUNT_DEPLETED,
      PR_ERROR_CALL_FAILED,
      PR_ERROR_MAX_CALL_DURATION_REACHED,
      PR_ERROR_MAX_SIMULTANEOUS_ACCESS_REACHED,
      PR_ERROR_MEDIA_INACTIVE,
      PR_ERROR_NO_FUNDS,
      PR_ERROR_SERVICE_NOT_AVAILABLE,
      PR_ERROR_BAD_NUMBER,
      PR_ERROR_BUSY,
      PR_ERROR_FAST_BUSY,
      PR_ERROR_CUSTOM_1,
      PR_ERROR_CUSTOM_2,
      PR_ERROR_CUSTOM_3,
      PR_ERROR_CUSTOM_4,
      PR_ERROR_CUSTOM_5,
      PR_ERROR_CUSTOM_6,
      PR_ERROR_CUSTOM_7,
      PR_ERROR_CUSTOM_8,
      PR_ERROR_CUSTOM_9,
      PR_ERROR_CUSTOM_10,
      NUM_PR_ERROR
    };

    enum PromptType
    {
      TypeNum,
      TypePhrase,
      TypeCurrency,
      TypeDateTime,
      TypeError,
      NumType
    };

    SolegyPrompt(
      PromptType type,
      int id,
      const char * name,
      int timeout
    )
    {
      m_PromptType = type;
      m_PromptId = id;
      m_PromptName = name;
      m_PromptTimeout = timeout;
    }

    PLIST( Array, SolegyPrompt );
    PromptType m_PromptType;
    int m_PromptId;
    OString m_PromptName;
    int m_PromptTimeout;
    OString m_PromptFile;
  };

  class SolegyPromptManager : public PObject
  {
    PCLASSINFO( SolegyPromptManager, PObject );
  public:


    SolegyPromptManager( 
      SolegySession * session
    );

    virtual ~SolegyPromptManager();

    BOOL InitFromAUTH( 
      const OString & auth 
    );

    BOOL GetWholeNumber(
      const OString & _whole, 
      OString &wHundredThousands,
      OString &wTenThousands,
      OString &wThousands,
      OString &wHundreds,
      OString &wTens,
      OString &wOnes
    );

    BOOL GetWholeNumber( 
      const OString & whole, 
      OStringArray &words );

    BOOL GetNumber( SolegyPrompt::PromptNumType type, OString & file );
    BOOL GetPhrase( SolegyPrompt::PromptPhraseType type, OString & file );
    BOOL GetError( SolegyPrompt::PromptErrorType type, OString & file );
    BOOL GetDateTime( SolegyPrompt::PromptDateTimeType type, OString & file );
    BOOL GetCurrency( SolegyPrompt::PromptCurrencyType type, OString & file );

    BOOL GetCurrency( 
      const OString & whole, 
      OStringArray &words );

  protected:
    BOOL m_IsInitialized;
    PDirectory m_PromptPhraseDir;
    PDirectory m_PromptNumberDir;
    PDirectory m_PromptErrorDir;
    PDirectory m_PromptDateTimeDir;
    PDirectory m_PromptCurrencyDir;
    PConfig * m_Config;
    SolegySession * m_Session;

  protected:
    int m_InputTimeout;
    
    OString m_PromptsLocation;
    OString m_LanguageOptions;
    OString m_GreetingPrompt;

    PTimer m_PromptTimer;
    PDECLARE_NOTIFIER( PTimer, SolegyPromptManager, OnPromptTimeout );

  public:
    void IVRCollect( const char * grammarId, int bufferSize, char termChar );
    void IVRPlaySilence( int silence );
    BOOL IVRAnnounce( SolegyPrompt::Array & prompts, int silence = 0 );
    BOOL IVRAnnounce( SolegyPrompt & prompt, int silence = 0, int tailSilence = 0 );
    BOOL IVRAnnounce( const OString & id, const OString & path, int silence = 0, int tailSilence = 0  );
    BOOL IVRAnnounceCurrency( const OString & id, const OString & currency, int silence = 0, int tailSilence = 0 );
    BOOL IVRAnnounceInterval( const OString & id, const PTimeInterval & interval, BOOL inMinutes = TRUE, int silence = 0, int tailSilence = 0 );
  };

}

#endif

