#include "SolegyFraudDetect.h"
#include "Solegy.h"
#include "OpenSBC.h"

using namespace SOLEGY;

SolegyFraudDetect::SolegyFraudDetect( 
  SolegySessionManager * manager,
  int alertIntervalInHours
)
{
  m_SolegySessionManager = manager;
  /// Send every 12 hours
  m_MailAlertTimer.SetNotifier( PCREATE_NOTIFIER( OnMailAlertTimer ) );
  m_MailAlertTimer.RunContinuous( PTimeInterval( 0,0,0, alertIntervalInHours ) );
}

SolegyFraudDetect::~SolegyFraudDetect()
{
}

void SolegyFraudDetect::ProcessHostSpoofing( 
  const SIPMessage & invite 
)
{
  OString domain = invite.GetFromURI().GetHost();
  OString via = invite.GetBottomVia().GetAddress();
  OString src = invite.GetBottomVia().GetReceiveAddress().AsSTLString();

  PIPSocket::Address viaIP( via.c_str() );
  PIPSocket::Address hostIP( domain.c_str() );
  
  if( hostIP.IsValid() && viaIP != hostIP )
  {
    PWaitAndSignal lock( m_HostSpoofingInfoMutex );

    OStringStream error;
    error << "Host spoofing detected! " << " Real=" << viaIP << " Spoofed=" << hostIP << " Destination= " << invite.GetRequestURI().GetUser();
    LOG_CONTEXT( LogWarning(), invite.GetCallId(), "!!! RTTS: " << error.str().c_str() );

    HostSpoofingInfo * hostInfo = m_HostSpoofingInfo.GetAt( domain );
    if( hostInfo == NULL )
    {
      hostInfo = new HostSpoofingInfo();
      m_HostSpoofingInfo.SetAt( domain, hostInfo );
    }

    hostInfo->m_FromHost = domain;
    OString sendTuple = via + "/" + src;
    if( hostInfo->m_ViaSendAddress.GetStringsIndex( sendTuple.c_str() ) == P_MAX_INDEX )
      hostInfo->m_ViaSendAddress.AppendString( sendTuple.c_str() );

    hostInfo->m_TotalAttempt++;
  }else if( hostIP.IsValid() && viaIP == hostIP ) /// host and via are equal.  check if somebody spoofed it
  {
    
    PWaitAndSignal lock( m_HostSpoofingInfoMutex );
    HostSpoofingInfo * hostInfo = m_HostSpoofingInfo.GetAt( domain );
    if( hostInfo != NULL )
    {
      OString sendTuple = via + "/" + src;
      if( hostInfo->m_ViaSendAddress.GetStringsIndex( sendTuple.c_str() ) == P_MAX_INDEX )
        hostInfo->m_ViaSendAddress.AppendString( sendTuple.c_str() );
    }
  } else if( !hostIP.IsValid() )// host is a domain
  {
    PWaitAndSignal lock( m_HostSpoofingInfoMutex );
    HostSpoofingInfo * hostInfo = m_HostSpoofingInfo.GetAt( hostIP.AsString() );
    if( hostInfo == NULL )
    {
      hostInfo = new HostSpoofingInfo();
      m_HostSpoofingInfo.SetAt( hostIP.AsString(), hostInfo );

      OString sendTuple = hostIP.AsSTLString() + "/" + domain;
      if( hostInfo->m_ViaSendAddress.GetStringsIndex( sendTuple.c_str() ) == P_MAX_INDEX )
        hostInfo->m_ViaSendAddress.AppendString( sendTuple.c_str() );

      if( hostInfo->m_ViaSendAddress.GetSize() > 1 )
      {
        OStringStream error;
        error << "Domain spoofing detected! " << " Real=" << hostIP << " Spoofed=" << domain << " Destination= " << invite.GetRequestURI().GetUser();
        LOG_CONTEXT( LogWarning(), invite.GetCallId(), "!!! RTTS: " << error.str().c_str() );
      }
    }
  }
}

void  SolegyFraudDetect::HostSpoofingInfo::PrintOn( ostream & strm )const
{
  strm << m_TotalAttempt << " calls were masquerading as " << m_FromHost << " from source addresses/domains [ ";
  for( int i = 0; i < m_ViaSendAddress.GetSize(); i++ )
    strm << m_ViaSendAddress[i] << ", ";
  strm << "]" << endl;
}

void SolegyFraudDetect::OnMailAlertTimer( PTimer &, INT )
{
  PThread::Create( PCREATE_NOTIFIER( OnSendMailAlert ) );
}

void SolegyFraudDetect::OnSendMailAlert( PThread &, INT )
{
  PStringStream email;
  BOOL hasPossibleSpoofingHits = FALSE;
  {
    PWaitAndSignal lock( m_HostSpoofingInfoMutex );
    if( m_HostSpoofingInfo.GetSize() == 0 )
      return;

    for( int i = 0; i < m_HostSpoofingInfo.GetSize(); i++ )
    {
      HostSpoofingInfo & hostInfo = m_HostSpoofingInfo.GetDataAt(i);
      if( hostInfo.m_ViaSendAddress.GetSize() > 1 )
      {
        hasPossibleSpoofingHits = TRUE;
        email << hostInfo << endl;
      }
    }

    PStringToString viaToHost;
    for( int i = 0; i < m_HostSpoofingInfo.GetSize(); i++ )
    {
      HostSpoofingInfo & hostInfo = m_HostSpoofingInfo.GetDataAt(i);
      for( int j = 0; j < hostInfo.m_ViaSendAddress.GetSize(); j++ )
      {
        const PString & sendAddr = hostInfo.m_ViaSendAddress[j];
        const OString & domain = hostInfo.m_FromHost;
        PString * previousDomain = NULL;
        if( viaToHost.GetSize() > 0 ) 
          previousDomain = viaToHost.GetAt( sendAddr );

        if( previousDomain == NULL )
        {
          viaToHost.SetAt( sendAddr, domain.c_str() );
        }else
        {
          hasPossibleSpoofingHits = TRUE;
          email << "Host " << sendAddr << " previously masqueraded as " << *previousDomain << " and now as "  << domain << endl;
          email << hostInfo << endl;
        }
      }
    }   

    m_HostSpoofingInfo.RemoveAll();
  }
  if( hasPossibleSpoofingHits )
  {
    /// send alert to admin
    m_SolegySessionManager->GetSBC()->SendMailAlert( "Host Spoofing Summary Report", email );
    m_SolegySessionManager->SendMailAlert( "Host Spoofing Summary Report", email, "SMTP-Fraud-Alert-Mailing-List" );
  }
}




