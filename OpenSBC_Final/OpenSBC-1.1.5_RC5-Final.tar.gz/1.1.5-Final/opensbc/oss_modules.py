#import the C++ callback
cpp = __import__("cpp")

#basic init callback
def init_modules():
	cpp.eval( "init_modules" )
	
#import the SNMP Module
import snmp

def run_snmp():
	snmp.run()