/*
 *
 * SBCBackDoorTrunk.cxx
 *
 * Open SIP Stack ( OSS )
 *
 * Copyright (c) opensipstack.org.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either expressed or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is OpenSIPStack.
 *
 * The Initial Developer of the Original Code is opensipstack.org.
 *
 * The author of this code is Joegen E. Baclor
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * The OpenSIPStack Library includes some GPL/LGPL code libraries that MAY be 
 * enabled at compile time using the --enable-gpllibs configure switch.  If
 * enabled, the content of this file is published under the terms of GNU 
 * General Public License Version 2.  For a detailed list of the available
 * GPL code, see $(opensipstack)/gnu/README file.
 *
 * $Log: SBCBackDoorTrunk.cxx,v $
 * Revision 1.23  2009/05/12 07:50:27  joegenbaclor
 * Made sure CANCEL does not use transaction bypass
 *
 * Revision 1.22  2009/05/07 13:26:30  joegenbaclor
 * rewrite To URI for pass through backdoor requests
 *
 * Revision 1.21  2009/03/26 06:32:26  joegenbaclor
 * Added NAT port forwarding support
 *
 * Revision 1.20  2009/03/20 05:29:42  joegenbaclor
 * make sure we dont set bypass handlers for INVITE's
 *
 * Revision 1.19  2009/03/20 03:02:10  joegenbaclor
 * process send-addr in backdoor trunk
 *
 * Revision 1.18  2009/03/17 02:24:41  joegenbaclor
 * introduced bypassing of ICT responses for fater response time
 *
 * Revision 1.17  2009/03/13 03:36:25  joegenbaclor
 * minor bug fixes in unsolicited request support
 *
 * Revision 1.16  2009/03/13 02:50:06  joegenbaclor
 * fixing compile errors
 *
 * Revision 1.15  2009/03/13 02:26:18  joegenbaclor
 * In this revision, we moved listener configuration to its own
 * page allowing all listeners to be configured seperately.
 * Previous behavior only allowed the main listener to be configured.
 * We have also added a out of dialog handler in the backdoor trunk
 * to allow unsolcited messages like OPTIONS and NOTIFY to passthrough.
 * Both of these functionalities are still under testing.
 *
 * Revision 1.14  2008/12/22 06:51:46  joegenbaclor
 * Application Timers for Alerting and Connect is causing a deadlock on connection destruction.
 * To address this issue, we modified opensipstack to take care of the timers in the ICT Layer.
 *
 * Revision 1.13  2008/11/25 15:11:52  joegenbaclor
 * Deprecated SetRewriteRequestURI().  We should always rewrite it!
 *
 * Revision 1.12  2008/11/20 11:02:34  joegenbaclor
 * Depcrecated old SIPMessage URI accessors
 *
 * Revision 1.11  2008/09/29 06:31:15  joegenbaclor
 * fixed more upper reg bugs
 *
 * Revision 1.10  2008/09/09 03:31:25  joegenbaclor
 * Upper Registration bug fixes
 *
 * Revision 1.9  2007/11/20 07:06:50  joegenbaclor
 * Added support for Request-URI routing
 *
 * Revision 1.8  2007/11/18 16:53:51  joegenbaclor
 * Added support for merged requests ending up in the same connection
 *
 * Revision 1.7  2007/10/30 16:39:36  joegenbaclor
 * Modified default thread count for trunks
 *
 * Revision 1.6  2007/10/01 16:17:27  joegenbaclor
 * Added transport status page in http admin
 *
 * Revision 1.5  2007/09/04 21:58:13  joegenbaclor
 * More work on SIP Trunks.
 *
 * Revision 1.4  2007/08/29 08:13:15  rcolobong
 * Fix bug on using proxy causing access violation in EndPoint trunk
 *
 * Revision 1.3  2007/08/20 06:41:59  joegenbaclor
 * Upgraded version to 1.1.5
 *
 * Revision 1.2  2007/08/20 06:24:45  joegenbaclor
 * commiting alpha code for new backdoor using trunks
 *
 * Revision 1.1  2007/08/16 13:33:37  joegenbaclor
 * More work on trunking
 *
 *
 */

#include "SBCBackDoorTrunk.h"
#include "OString.h"
#include "Version.h"
#include "SBCConfigParams.h"
#include "B2BUAConnection.h"
#include "B2BUAEndPoint.h"
#include "Encryption.h"
#include "SIPUDPTransport.h"
#include "SBCCallHandler.h"

using namespace SIPTransports;

#define new PNEW

///////////////////////////////////////////////////////////

class SBCBackDoorEndPoint : public B2BUAEndPoint
{
  PCLASSINFO( SBCBackDoorEndPoint, B2BUAEndPoint );
public:
  SBCBackDoorEndPoint(
      SBCBackDoorTrunk & ua
  );

  virtual ~SBCBackDoorEndPoint();
};
///////////////////////////////////////////////////////////
SBCBackDoorEndPoint::SBCBackDoorEndPoint(
    SBCBackDoorTrunk & ua
) : B2BUAEndPoint( ua, 1, 1024 * 2 )
{
}

SBCBackDoorEndPoint::~SBCBackDoorEndPoint()
{
}
///////////////////////////////////////////////////////////
class SBCBackDoorCallHandler : public B2BCallInterface
{
  PCLASSINFO( SBCBackDoorCallHandler, B2BCallInterface );
public:
  SBCBackDoorCallHandler(  
    SBCBackDoorTrunk & b2bua 
  );

  BOOL OnReceivedMergedInvite(
    B2BUserAgent & userAgent,
    B2BUAConnection & connection,
    B2BUACall & call,
    const SIPMessage & invite
  );
};
///////////////////////////////////////////////////////////

class SBCBackDoorRoutingHandler : public B2BRoutingInterface
{
  PCLASSINFO( SBCBackDoorRoutingHandler, B2BRoutingInterface );
public:
  SBCBackDoorRoutingHandler(  
    SBCBackDoorTrunk & b2bua 
  );

  virtual ~SBCBackDoorRoutingHandler();

  virtual BOOL B2BRouteCall(
    B2BUAConnection & connection,
    SIPMessage & invite,
    BOOL ignoreRegistrations = FALSE
  );

protected:
  SBCBackDoorTrunk & m_SBCBackDoorTrunk;
};

////////////////////////////////////////////////////////////
SBCBackDoorRoutingHandler::SBCBackDoorRoutingHandler(  
  SBCBackDoorTrunk & b2bua 
) : B2BRoutingInterface( b2bua ),
    m_SBCBackDoorTrunk( b2bua )
{
}

SBCBackDoorRoutingHandler::~SBCBackDoorRoutingHandler()
{
}

BOOL SBCBackDoorRoutingHandler::B2BRouteCall(
  B2BUAConnection & connection,
  SIPMessage & invite,
  BOOL /*ignoreRegistrations*/
)
{
  const Via &via = invite.GetTopVia();

  OString callId = invite.GetCallId();

  OpenSBC * mainSBC = m_SBCBackDoorTrunk.GetTrunkProcess()->GetTrunkManager()->GetMainProcess()->GetSBC();
  BOOL outbound = mainSBC->GetB2BUAEndPoint()->GetTransportManager()->IsLocalAddressAndPort( via.GetURI() );

  if( outbound )
  {
    connection.SetRewriteToURI( FALSE );
    SIPURI routeURI;
    invite.GetRequestURI( routeURI );
    PIPSocket::Address verifiedAddress;
    WORD verifiedPort = 0;
    
    if( !GetB2BUA().GetStack().GetTransportManager()->IsLocalAddressAndPort( routeURI ) )
    {
      if( SIPTransport::Resolve( routeURI, verifiedAddress, verifiedPort, SIPTransport::UDP, FALSE ) )
      {
        LOG_CONTEXT( LogInfo(), callId, "*** Using Request URI *** " << routeURI << " as route" );
        connection.AddRoute( routeURI );
        return TRUE;
      }
    }else
    {
      routeURI = invite.GetToURI();
      if( !GetB2BUA().GetStack().GetTransportManager()->IsLocalAddressAndPort( routeURI ) )
      {
        if( SIPTransport::Resolve( routeURI, verifiedAddress, verifiedPort, SIPTransport::UDP, FALSE ) )
        {
          LOG_CONTEXT( LogInfo(), callId, "*** Using To URI *** " << routeURI << " as route" );
          connection.AddRoute( routeURI );
          return TRUE;
        }
      }
    }
  }else
  {
    
    PIPSocket::Address addr;
    WORD port;
    if( !dynamic_cast<SIPUDPTransport*>(mainSBC->GetB2BUAEndPoint()->GetTransportManager()->GetUDPTransport())->GetDefaultListenerAddress( addr, port ) )
      return FALSE;

    
    SIPURI route( addr, port );
    SIPURI ruri;
    invite.GetRequestURI(ruri);
    route.SetParameters( ruri.GetParameters() );
    route.SetUser( ruri.GetUser() );
    connection.AddRoute( route );
    /// deprecated: connection.SetRewriteRequestURI( TRUE );
    connection.SetRewriteToURI( FALSE );
  }

  return TRUE;
}

////////////////////////////////////////////////////////////
SBCBackDoorCallHandler::SBCBackDoorCallHandler(  
  SBCBackDoorTrunk & b2bua 
) : B2BCallInterface( b2bua )
{
}

BOOL SBCBackDoorCallHandler::OnReceivedMergedInvite(
  B2BUserAgent & userAgent,
  B2BUAConnection & connection,
  B2BUACall & call,
  const SIPMessage & invite
)
{
  SBCBackDoorTrunk & trunk = dynamic_cast<SBCBackDoorTrunk&>(userAgent);
  return trunk.GetMainTrunk()->GetSBCCallHandler()->OnReceivedBackDoorMergedInvite( userAgent, connection, call, invite );
}
////////////////////////////////////////////////////////////

SBCBackDoorTrunk::SBCBackDoorTrunk(
  SBCTrunkProcess * trunkProcess
  ) : SBCTrunk( trunkProcess )
{
  m_UserAgentName = "Backdoor Trunk";
  m_HasInitConfig = FALSE;
  m_BackDoorPort = 0;
  m_MainSBCPort = 0;
  SBCBackDoorEndPoint * ep = new SBCBackDoorEndPoint( *this);
  trunkProcess->SetEndPoint( ep );
  SetEndPoint( ep );

  B2BUserAgent::Proxy * proxy = 
    new B2BUserAgent::Proxy( *this, 1, 1024 * 2 );

  SetProxy( proxy );
}

SBCBackDoorTrunk::~SBCBackDoorTrunk()
{
}

B2BRoutingInterface * SBCBackDoorTrunk::OnCreateRoutingInterface()
{
  return new SBCBackDoorRoutingHandler( *this );
}

B2BCallInterface * SBCBackDoorTrunk::OnCreateCallInterface()
{
  return new SBCBackDoorCallHandler( *this );
}

void SBCBackDoorTrunk::OnConfigChanged( 
  OSSAppConfig & config,
  const char * /*section*/  
)
{
  if( m_HasInitConfig )
    return;

  m_HasInitConfig = TRUE;

  int workerThreadCount = 1;
  
  // Enable Feature SIP Session Timers
  GetB2BUAEndPoint()->EnableSessionTimer( FALSE );

  Encryption::Engine::m_Key = (const char *)config.GetString( configKeySection, configKeyEncryptionKey, Encryption::Engine::m_DefKey );
  OString encMode = config.GetString( configKeySection, configKeyEncryption, "XOR" );
  if( encMode *= "XOR" )
    Encryption::Engine::m_Type = Encryption::Engine::Type_XOR;
  else if( encMode *= "DiffShift" )
    Encryption::Engine::m_Type = Encryption::Engine::Type_DiffShift;

 
  m_AcceptAllCalls = TRUE;
  GetB2BUAEndPoint()->EnableLocalRefer( FALSE );

  PStringArray privacyDomains;
  for( PINDEX i = 0; i <  config.GetListSize( configKeyPrivacyTrustedDomainSection, configKeyPrivacyDomain ); i++ )
    privacyDomains.AppendString( config.GetListItem( configKeyPrivacyTrustedDomainSection, configKeyPrivacyDomain, i ) );
  AddPrivacyTrustedDomains( privacyDomains, TRUE );
  SetPrivacyDefaultRealm( config.GetString( configKeyPrivacyTrustedDomainSection, configKeyPrivacyDefaultRealm, "" ) );

  SIPURI bindAddress((const char *)config.GetString( configKeySIPTransportSection, configKeyBackdoorInterfaceAddress, "sip:*:5062" ));
  /// set the backdoor port of the main trunk
  OpenSBC * mainSBC = GetTrunkProcess()->GetTrunkManager()->GetMainProcess()->GetSBC();
  mainSBC->SetBackDoorPort( (WORD)bindAddress.GetPort().AsUnsigned() );

  m_BackDoorIface = PIPSocket::Address( bindAddress.GetHost() );
  if( !m_BackDoorIface.IsValid() )
    m_BackDoorIface = mainSBC->GetTransportManager()->GetDefaultInterfaceAddress( FALSE );

  m_BackDoorPort = (WORD)bindAddress.GetPort().AsUnsigned(); 
  GetDefaultProfile().GetTransportProfile().EnableUDP( m_BackDoorIface, m_BackDoorPort  );
#if ENABLE_TCP_TRANSPORT
  GetDefaultProfile().GetTransportProfile().EnableTCP( m_BackDoorIface, m_BackDoorPort  );
#endif

  Initialize( workerThreadCount );

  m_RoutingHandler->RefreshStaticRoutes();

}

void SBCBackDoorTrunk::ProcessEvent(
    SIPStackEvent * event
)
{
  m_EndPoint->ProcessStackEvent( m_Proxy, event );
}

void SBCBackDoorTrunk::OnTransactionCreated(
  const SIPMessage & msg,
  SIPTransaction *& transaction
)
{
  if( msg.IsResponse() || 
      msg.IsCancel()   || 
      !msg.GetToTag().IsEmpty() ||
      transaction->GetType() == SIPTransaction::IST || 
      transaction->GetType() == SIPTransaction::ICT )
  {
    return;
  }


  OpenSBC * mainSBC = GetTrunkProcess()->GetTrunkManager()->GetMainProcess()->GetSBC();
  const Via &via = msg.GetTopVia();
  BOOL outbound = mainSBC->GetB2BUAEndPoint()->GetTransportManager()->IsLocalAddressAndPort( via.GetURI() );

  if( !outbound )
  {
    /// everything received here would be proxied towards the main trunk
    dynamic_cast<SIPTransactionBypass*>(this)->m_AutoDeleteBypass = FALSE;
    transaction->SetBypassHandler( dynamic_cast<SIPTransactionBypass*>(this), FALSE ); 
  }
}

void SBCBackDoorTrunk::OnReceivedBypassedMessage(
  const SIPMessage & message,
  SIPTransaction * transaction 
)
{
  if(  transaction->GetType() == SIPTransaction::NIST )
  {
    if( message.IsRequest() )
    {
      SIPMessage outbound = message;
      
      
      OpenSBC * mainSBC = GetTrunkProcess()->GetTrunkManager()->GetMainProcess()->GetSBC();
      if( m_MainSBCPort == 0 || !m_MainSBCAddress.IsValid() )
      {
        mainSBC->GetTransportManager()->GetListenerAddress( SIPTransport::UDP, m_BackDoorIface, m_MainSBCAddress, m_MainSBCPort );
      }

      SIPURI ruri = message.GetRequestURI();
      OString userString = ruri.GetUser();
      if( userString.Left( 9 ) == "x-reg-id-" )
      {
        OString xAliasRegId = userString.Mid( 9 );
        OString xAliasCURI = ParserTools::UnescapeAsRFC2396( xAliasRegId );
        SIPURI targetURI( xAliasCURI );
        LOG_CONTEXT( LogInfo(), message.GetCallId(), "*** UPPER REG UNSOLICITED REQUEST *** -->> Callee: " << message.GetFromURI() 
          << " AOR: " << message.GetRequestURI() << " BINDING: " << targetURI );
        

        OString sendAddr = targetURI.RemoveParameter( "send-addr" );
        if( !sendAddr.IsEmpty() )
        {
          sendAddr = "sip:" + sendAddr;
          SIPURI newTarget( sendAddr );
          outbound.SetSendAddress( newTarget );
        }
        outbound.SetToURI( targetURI );
        outbound.SetRequestURI( targetURI );

      }else
      {

        Contact contact;
        if( !mainSBC->GetLocalRegistrar()->FindRegistrationBinding( outbound, contact ) )
        {
          SIPMessage * response = new SIPMessage();
          message.CreateResponse( *response, SIPMessage::Code404_NotFound, "Not Regitered" );
          SIPParser::Server h( mainSBC->GetUserAgentBuildName() );
          response->SetServer( h );
          transaction->EnqueueEvent(new SIPEvent( response ));
          return;
        }
        SIPURI targetURI = contact.GetTopURI();
        OString sendAddr = targetURI.RemoveParameter( "send-addr" );
        if( !sendAddr.IsEmpty() )
        {
          sendAddr = "sip:" + sendAddr;
          SIPURI newTarget( sendAddr );
          outbound.SetSendAddress( newTarget );
        }
        outbound.SetRequestURI( targetURI );
      }

      

      /// set our via
      Via via;
      via.SetAddress( m_MainSBCAddress.AsSTLString() );
      via.SetPort( m_MainSBCPort );
      via.SetBranch( ParserTools::GenBranchParameter() );
      via.AddParameter( "rport", "" );
      outbound.AppendVia( via );
      outbound.RemoveAllRoutes();
      mainSBC->GetStack().FindTransactionAndAddEvent( outbound, FALSE, 0, this );
    }
  }else if( transaction->GetType() == SIPTransaction::NICT )
  {
    if( message.IsResponse() )
    {
      SIPMessage outbound = message;
      outbound.PopTopVia();
      GetStack().FindTransactionAndAddEvent( outbound, FALSE, 0 );  
    }
  }
}


