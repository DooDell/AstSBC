/*
 *
 * SBCCallHandler.cxx
 *
 * Open SIP Stack ( OSS )
 *
 * Copyright (c) opensipstack.org.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either expressed or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is OpenSIPStack.
 *
 * The Initial Developer of the Original Code is opensipstack.org.
 *
 * The author of this code is Joegen E. Baclor
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * The OpenSIPStack Library includes some GPL/LGPL code libraries that MAY be 
 * enabled at compile time using the --enable-gpllibs configure switch.  If
 * enabled, the content of this file is published under the terms of GNU 
 * General Public License Version 2.  For a detailed list of the available
 * GPL code, see $(opensipstack)/gnu/README file.
 *
 * $Log: SBCCallHandler.cxx,v $
 * Revision 1.41  2009/06/01 09:47:28  joegenbaclor
 * more IVR related work
 *
 * Revision 1.40  2009/03/17 02:24:41  joegenbaclor
 * introduced bypassing of ICT responses for fater response time
 *
 * Revision 1.39  2009/01/21 10:01:56  joegenbaclor
 * Marking bug fix for solegy START race condition
 *
 * Revision 1.38  2009/01/12 04:50:01  joegenbaclor
 * We modified two things in this commit.  The first is to handle CANCEL requests arriving before an in INVITE is sent out to the upstream termination. Previous implementation did not handle this case properly which results to the call still being attempted even after it was aborted by the caller.  The second bug fix is we introduced m_LocallyAuthenticated in the B2BUAConnection layer so that the SBC can determine cases where both the SBC and the upstream termination both challenged the INVITE resulting to a double authentication.  Although RFC 3261 allows this, we yet have to see UAs that can handle authentication from two realms.  In most cases this call would end up in bad state so its better to just destroy the connection when this happens.
 *
 * Revision 1.37  2009/01/09 12:32:16  joegenbaclor
 * In this build we introduced state cookies for Solegy Calls.  The state cookie would allow OpenSBC to disconnect  calls (both BYE and CALLSTOP) after a restart or a crash happen by reconstructing dialog and RTTS state using the cookie data.  The cookie is created on CALLSTART and will be deleted on CALLSTOP.  When a crash happens, calls may stay  connected making it impossible to bill reliably.  Disconnecting calls on restart would minimize the possibility of runaway calls.
 *
 * Revision 1.36  2008/11/20 11:02:35  joegenbaclor
 * Depcrecated old SIPMessage URI accessors
 *
 * Revision 1.35  2008/11/03 02:35:09  joegenbaclor
 * Introducing new a la B2BUA-Routes Outbound-Proxy routing and deprecated old global
 *  Outbound-Proxy parameter
 *
 * Revision 1.34  2008/09/12 09:49:44  joegenbaclor
 * - Upper registration bug fixes.
 * - Bring back support for upper reg routing
 * - Bring back support for upper-reg domain rewrite
 *
 * Revision 1.33  2008/09/10 03:56:29  joegenbaclor
 * Updated VC2005 build
 *
 * Revision 1.32  2008/09/04 01:13:16  joegenbaclor
 * Finalized routing via registrar for SLA support
 * Used SetInternalHeader connection method instead of the unsafe AddInternalHeader
 *
 * Revision 1.31  2008/09/01 14:44:29  joegenbaclor
 * Commiting interim code for new registrar with SLA support
 *
 * Revision 1.30  2008/08/29 06:21:21  joegenbaclor
 * Added paralllel forking support
 *
 * Revision 1.29  2008/08/20 12:56:39  joegenbaclor
 * Removed sending of individual events for IVR User Input
 * Some enhancements related to call audit trail
 *
 * Revision 1.28  2008/02/28 13:36:15  rcolobong
 * Added feature to rewrite the FROM domain to a specific domain in the B2BUA routes
 *
 * Revision 1.27  2008/01/28 02:03:11  rcolobong
 * Fix minor bugs in enum domain-squat
 *
 * Revision 1.26  2008/01/24 01:43:52  joegenbaclor
 * Added flag for enum routes to allow rewriting of from domain to squat in the domain resolved through enum
 *
 * Revision 1.25  2008/01/18 05:28:49  joegenbaclor
 * Added Oubound Proxy assignement for B2BUA calls
 *
 * Revision 1.24  2008/01/10 12:59:15  rcolobong
 * Add support for info digit
 *
 * Revision 1.23  2008/01/08 08:42:14  rcolobong
 * 1. Add configuration to enable/disable backdoor, calea, and sip trunk port
 * 2. More work on handling spiral or merged invite
 *
 * Revision 1.22  2007/12/21 09:48:07  joegenbaclor
 * Added ability to preserve the transaction via the incoming SIP message.  This pointer may be provided to SendRequest so that responses can avoid another search of the transaction from the transaction db.
 *
 * Revision 1.21  2007/11/20 14:07:04  joegenbaclor
 * Some Merge Cancel bug fixes
 *
 * Revision 1.20  2007/11/20 07:06:50  joegenbaclor
 * Added support for Request-URI routing
 *
 * Revision 1.19  2007/11/18 17:20:34  joegenbaclor
 * Corrected compile errors in gcc
 *
 * Revision 1.18  2007/11/18 16:53:51  joegenbaclor
 * Added support for merged requests ending up in the same connection
 *
 * Revision 1.17  2007/10/15 10:43:27  joegenbaclor
 * Corrected unix compile error
 *
 * Revision 1.16  2007/10/15 10:37:49  joegenbaclor
 * Minor bug fixes
 *
 * Revision 1.15  2007/10/10 01:00:18  joegenbaclor
 * Added check for Allow header when local refer is enabled
 *
 * Revision 1.14  2007/08/28 01:25:19  joegenbaclor
 * Completed recording SIP signals for CALEA in pcap format
 *
 * Revision 1.13  2007/08/25 12:17:32  joegenbaclor
 * commiting initial CALEA working alpha code
 *
 * Revision 1.12  2007/08/25 09:08:42  joegenbaclor
 * More work on CALEA trunk
 *
 * Revision 1.11  2007/08/24 01:14:42  joegenbaclor
 * scrapped previous code for upstream proxy handling
 *
 * Revision 1.10  2007/08/08 07:36:08  joegenbaclor
 * Added SBCTrunk classes
 * Removed singleton factory for OSSAppConfig
 *
 * Revision 1.9  2007/07/14 09:48:59  joegenbaclor
 * Corrected compile errors in linux
 *
 * Revision 1.8  2007/07/14 07:53:56  joegenbaclor
 * Migrated code to use new STL based string class
 *
 * Revision 1.7  2007/07/07 15:21:17  joegenbaclor
 * Added iproute2 support for linux
 *
 * Revision 1.6  2007/07/06 14:18:25  rcolobong
 * Add Upstream Proxy Route feature
 *
 * Revision 1.5  2007/02/16 11:09:20  joegenbaclor
 * More work on privacy
 *
 * Revision 1.4  2007/02/09 03:50:30  joegenbaclor
 * 1. Added MaxForwards handling for B2B calls
 * 2. #defined SIP_DEFAULT_MAX_FORWARDS constant
 *
 * Revision 1.3  2007/02/08 13:38:12  joegenbaclor
 * Changed signature of B2BCallInterface::OnIncomingCall to allow for intial rejection
 *  of call before routing is performed.
 *
 * Revision 1.2  2006/08/29 07:45:42  rcolobong
 * Remove warning messages in Windows
 *
 * Revision 1.1  2006/08/14 10:04:59  rcolobong
 * Convert B2BUA to SBC
 * Support MP logging
 *
 * Revision 1.2  2006/06/29 05:09:12  joegenbaclor
 * Changed OnOutgoingCall invite parameter from const to none const to give a
 * chance for applications to modify the outbound invite before being sent to the transport
 *
 * Revision 1.1  2006/06/20 09:58:11  joegenbaclor
 * *** empty log message ***
 *
 *
 */


#include "SBCCallHandler.h"
#include "SBCRoutingHandler.h"
#include "B2BUAConnection.h"
#include "SBCConfigParams.h"

#define DEFAULT_UPSTREAM_BACKDOOR_PORT 13900

SBCCallHandler::SBCCallHandler( 
  OpenSBC & ua 
  ) : B2BCallInterface( ua )
{
  m_CATLog = NULL;
  OpenCATLog();
}

SBCCallHandler::~SBCCallHandler()
{
}

CallSession::AnswerCallDeniedResponse SBCCallHandler::OnIncomingCall(
  B2BUAConnection & connection,
  B2BUACall & call,
  SIPMessage & invite
)
{
  SIPHeader allowRTP( "SBC-RTP-Proxy" );
  if( invite.PopCustomHeader( "SBC-RTP-Proxy", allowRTP ) )
  {
    if( allowRTP.GetHeaderBody() *= "off" )
      connection.SetAllowMediaProxy( FALSE );
  }

  return B2BCallInterface::OnIncomingCall( connection, call, invite );
}

void SBCCallHandler::OnOutgoingCall(
  B2BUAConnection & connection,
  B2BUACall & /*call*/,
  SIPMessage & invite
)
{
  OpenSBC & sbc = dynamic_cast<OpenSBC&>(GetB2BUA());

  /// check privacy
  if( invite.HasPrivacy() )
  {
    Privacy privacy;
    invite.GetPrivacy( privacy );

    if( privacy.GetHeaderBody().Trim() *= "id" )
    {
      SIPURI uri;
      if( invite.GetRequestURI( uri )  )
      {
        SIPURI domainEntry;
        if( !sbc.IsPrivacyTrustedDomain( uri, domainEntry ) )
        {
          invite.RemoveAllPAssertedIdentities();
          invite.RemoveAllPPreferredIdentities();
        }
      }
    }
  }

  /// check if this call is filtered for CALEA monitoring
  if( GetSBC().GetSBCRoutingHandler()->IsCALEAMonitoredCall( invite ) )
  { 
    RouteURI routeURI;
    routeURI = RouteURI( GetSBC().GetCALEATrunkURI() );
    routeURI.SetLooseRouter( TRUE );
    invite.AppendRoute( routeURI );
  }


  /// check if we are suppose to use the sip trunk
  B2BRoutingInterface::B2BRouteList routeList = connection.GetRoutes();
  if( routeList.GetSize() > 0 )
  {
    SIPURI firstRoute = routeList[0];

    if( firstRoute.FindParameter( "domain-squat" ) != P_MAX_INDEX )
    {
      SIPURI fromURI = invite.GetFromURI();
      fromURI.SetHost( firstRoute.GetHost() );
      fromURI.SetPort( firstRoute.GetPort() );

      From from = invite.GetFrom();
      from.SetURI( fromURI );
      invite.SetFrom( from );
    }
  }

  /// check if we will handle locally and append a REFER in the ALLOW header
  if( GetSBC().GetB2BUAEndPoint()->IsLocalReferEnabled() )
  {
    if( invite.HasAllow() && !invite.IsAllowed( SIPMessage::Method_REFER ) )
      invite.AppendAllow( "REFER" );
  }

  OString infoDigit;
  SIPURI fromURI = invite.GetFromURI();

  BOOL appendDigitInfo = FALSE;
  {
    if( fromURI.GetParameter( "isup-oli", infoDigit ) )
    {
      PWaitAndSignal configLock( PHTTPConfig::m_HTTPConfigMutex );
      OSSAppConfig * config = dynamic_cast<OpenSBC&>(GetB2BUA()).GetAppConfig();

      appendDigitInfo = config->GetBoolean( configKeyB2BUASection, configKeyB2BUAAppendInfoDigit, 
        FALSE );

      // if Info Digit is empty then set the value to "00"
      // if Info Digit is a single digit value then
      // append 0 to the value
      if( appendDigitInfo )
      {
        if( infoDigit.IsEmpty() )
        {
          infoDigit = "00";
        } else if( infoDigit.GetLength() == 1 )
        {
          infoDigit = "0" + infoDigit;
        }
      }
    }
  }

  if( appendDigitInfo )
  {
    OString newUser = infoDigit + fromURI.GetUser();
    fromURI.SetUser( newUser );
    // Remove isup oli here
    fromURI.RemoveParameter( "isup-oli" );
    From from = invite.GetFrom();
    from.SetURI( fromURI );
    invite.SetFrom( from );
  }

  OString routeFromDomain = connection.GetInternalHeader( "REWRITE-FROM-DOMAIN" );
  if( !routeFromDomain.IsEmpty() )
  {
    SIPURI tempFromURI = invite.GetFromURI();
    tempFromURI.SetHost( routeFromDomain );

    From from = invite.GetFrom();
    from.SetURI( tempFromURI );
    invite.SetFrom( from );
  }

  SIPHeader parallelFork( "PARALLEL-FORK" );
  if( connection.GetInternalHeader( "PARALLEL-FORK", parallelFork ) )
  {
    if( parallelFork.GetHeaderBody() == "T" )
    {
      parallelFork.SetHeaderBody( "F" );
      connection.SetInternalHeader( "PARALLEL-FORK", parallelFork ); // set it to false so the next route will not re-use it again
      B2BRoutingInterface::B2BRouteList routes =  connection.GetRoutes();
      int count = routes.GetSize();
      Route routeList;
      for( PINDEX i = 1; i < count; i++ )
      {
        RouteURI routeURI;
        routeURI.SetURI( routes[i] );
        routeList.AddURI( routeURI, TRUE );
      }

      if( routeList.GetSize() > 0 )
      {
        SIPHeader forkHeader( "PARALLEL-FORK" );
        forkHeader.SetHeaderBody( routeList.GetHeaderBody() );
        invite.AddInternalHeader( forkHeader );
      }

      connection.RemoveRoutes();
    }
  }
}

void SBCCallHandler::OnCallReinvite(
  B2BUAConnection &,
  B2BUACall &,
  const SIPMessage &
)
{
}

void SBCCallHandler::OnProceeding(
  B2BUAConnection &,
  B2BUACall &,
  const SIPMessage &
)
{
}


void SBCCallHandler::OnAlerting(
  B2BUAConnection &,
  B2BUACall &,
  const SIPMessage &
)
{
}

void SBCCallHandler::OnProgress(
  B2BUAConnection &,
  B2BUACall &,
  const SIPMessage &
)
{
}



void SBCCallHandler::OnConnected(
  B2BUAConnection &,
  B2BUACall &,
  const SIPMessage &
)
{
}


void SBCCallHandler::OnRejected(
  B2BUAConnection & conn,
  B2BUACall &,
  const SIPMessage & /*reject*/
)
{
  DumpCATLog( conn, TRUE );
}

void SBCCallHandler::OnDisconnected(
  B2BUAConnection & conn,
  B2BUACall &,
  const SIPMessage &
)
{
  DumpCATLog( conn, FALSE );
}

void SBCCallHandler::OnInSessionMessage(
  B2BUAConnection &,
  B2BUACall &,
  const SIPMessage &
)
{
}

BOOL SBCCallHandler::OnReceivedMergedInvite(
  B2BUserAgent & userAgent,
  B2BUAConnection & connection,
  B2BUACall & call,
  const SIPMessage & _invite
)
{
  OpenSBC & sbc = dynamic_cast<OpenSBC&>(GetB2BUA());
  SIPMessage invite = _invite;
  SIPURI route;
  if( !dynamic_cast<SBCRoutingHandler*>(sbc.GetRoutingInterface())->B2BRouteMergedInvite( invite, route ) )
  {
    return FALSE;
  }

  invite.SetRequestURI( route );
  invite.SetSendAddress( route );

  OString branch = invite.GetViaBranch();
  OString newBranch = ParserTools::GenBranchParameter();
  if( !branch.IsEmpty() )
  {
    OString data = route.AsString() + "|" + newBranch;
    connection.AddMergedBranch( branch, data );
  }

  /// insert a via
  Via via;
  PIPSocket::Address targetAddress = route.GetAddress();
  call.GetSessionManager().ConstructVia( targetAddress, via, SIPTransport::UDP, invite.GetInterfacePort() );
  via.SetBranch( newBranch );
  via.AddParameter( "rport", "" );
  via.AddParameter( "merged", "yes" );
  invite.AppendVia( via );

  if( invite.GetRouteSize() > 0 )
  {
    SIPURI topRoute = invite.GetTopRouteURI();
    if( userAgent.GetTransportManager()->IsLocalAddressAndPort( topRoute ) )
      invite.PopTopRouteURI();
  }

  SIPURI routeURI = via.GetURI().GetBasicURI();
  RouteURI recordRoute;
  recordRoute.SetURI( routeURI );
  recordRoute.SetLooseRouter( TRUE );
  invite.AppendRecordRoute( recordRoute );
  return userAgent.SendRequest( invite );
}

BOOL SBCCallHandler::OnReceivedMergedCancel(
  B2BUserAgent & userAgent,
  B2BUAConnection & connection,
  B2BUACall & call,
  const SIPMessage & _cancel
)
{
  /// response with 200 Ok right away
  SIPMessage ok;
  _cancel.CreateResponse( ok, SIPMessage::Code200_Ok );
  call.SendRequest( ok, _cancel.GetTransaction() );
  
  OString branch = _cancel.GetViaBranch();
 
  OString data;
  if( !branch.IsEmpty() && !connection.IsMergedBranch( branch, data ) )
    return FALSE;

  OStringArray tokens = data.Tokenise( "|" );

  if( tokens.GetSize() != 2 )
    return FALSE;

  SIPURI route( tokens[0] );

  SIPMessage cancel = _cancel;

  cancel.SetRequestURI( route );
  cancel.SetSendAddress( route );
  /// insert a via
  Via via;
  PIPSocket::Address targetAddress = route.GetAddress();
  call.GetSessionManager().ConstructVia( targetAddress, via, SIPTransport::UDP, cancel.GetInterfacePort() );
  via.SetBranch( tokens[1] );
  via.AddParameter( "rport", "" );
  via.AddParameter( "merged", "yes" );
  cancel.RemoveAllVias();
  cancel.AppendVia( via );

  if( cancel.GetRouteSize() > 0 )
  {
    SIPURI topRoute = cancel.GetTopRouteURI();
    if( userAgent.GetTransportManager()->IsLocalAddressAndPort( topRoute ) )
      cancel.PopTopRouteURI();
  }

  SIPURI routeURI = via.GetURI().GetBasicURI();
  RouteURI recordRoute;
  recordRoute.SetURI( routeURI );
  recordRoute.SetLooseRouter( TRUE );
  cancel.AppendRecordRoute( recordRoute );
  return userAgent.SendRequest( cancel );
}

BOOL SBCCallHandler::OnReceivedACKToMergedResponse(
  B2BUserAgent & userAgent,
  B2BUAConnection & /*connection*/,
  B2BUACall & /*call*/,
  const SIPMessage & _ack
)
{
  SIPMessage ack = _ack;
  SIPURI ruri; 
  ack.GetRequestURI(ruri);
  if( !userAgent.GetTransportManager()->IsLocalAddressAndPort( ruri ) )
  {
    if( ack.HasRoute() )
    {
      Route route = ack.GetRouteAt( 0 );
      RouteURI routeURI;
      route.GetURI( routeURI );
      if( userAgent.GetTransportManager()->IsLocalAddressAndPort( routeURI.GetURI()  ) )
        ack.PopTopRouteURI();
    }

    userAgent.GetStack().EnqueueTransportWriteEvent( ack );
    return TRUE;
  }
  return FALSE;
}

BOOL SBCCallHandler::OnReceivedResponseToMergedInvite(
  B2BUserAgent & userAgent,
  B2BUAConnection & connection,
  B2BUACall & /*call*/,
  const SIPMessage & response
)
{
  const Via &via = response.GetTopVia();

  OString merged;
  if( via.GetParameter( "merged", merged ) )
  {
    SIPMessage relay = response;
    relay.PopTopVia();

    if( response.Is2xx() )
    {
      OString tag = response.GetToTag();
      if( !tag.IsEmpty() )
        connection.AddMergedTag( tag );
    }

    return userAgent.SendRequest( relay );
  }

  return FALSE;
}

BOOL SBCCallHandler::OnReceivedMergedMidDialogMessage(
  B2BUserAgent & userAgent,
  B2BUAConnection & connection,
  B2BUACall & call,
  const SIPMessage & _msg
)
{
  if( _msg.IsCancel() )
    return OnReceivedMergedCancel( userAgent, connection, call, _msg );
  
  SIPMessage msg = _msg;
  if( msg.IsRequest() )
  {
    SIPURI ruri; 
    msg.GetRequestURI(ruri);
    if( !userAgent.GetTransportManager()->IsLocalAddressAndPort( ruri ) )
    {
      if( msg.GetRouteSize() > 0 )
      {
        SIPURI route = msg.GetTopRouteURI();
        if( userAgent.GetTransportManager()->IsLocalAddressAndPort( route ) )
          msg.PopTopRouteURI();
      }

      Via via;
      PIPSocket::Address targetAddress = ruri.GetAddress();
      call.GetSessionManager().ConstructVia( targetAddress, via, SIPTransport::UDP, msg.GetInterfacePort() );
      via.SetBranch( ParserTools::GenBranchParameter() );
      via.AddParameter( "rport", "" );
      via.AddParameter( "merged", "yes" );
      msg.AppendVia( via );

      SIPURI routeURI = via.GetURI().GetBasicURI();
      RouteURI recordRoute;
      recordRoute.SetURI( routeURI );
      recordRoute.SetLooseRouter( TRUE );
      msg.AppendRecordRoute( recordRoute );
      
      return userAgent.SendRequest( msg );
    }
  }else
  {
    if( msg.GetViaSize() > 0 )
    {
      const Via &via = msg.GetTopVia();
      SIPURI viaURI = via.GetURI();
      if( !userAgent.GetTransportManager()->IsLocalAddressAndPort( viaURI ) )
      {
        SIPURI route = msg.GetTopRouteURI();
        if( userAgent.GetTransportManager()->IsLocalAddressAndPort( route ) )
          msg.PopTopRouteURI();

        return userAgent.SendRequest( msg );
      }
    }
  }

  return FALSE;
}

BOOL SBCCallHandler::OnReceivedBackDoorMergedInvite(
  B2BUserAgent & /*userAgent*/,
  B2BUAConnection & /*connection*/,
  B2BUACall & call,
  const SIPMessage & invite
)
{
  OpenSBC & sbc = dynamic_cast<OpenSBC&>(GetB2BUA());
  const Via &via = invite.GetTopVia();
  PIPSocket::Address remoteAddr( via.GetAddress().c_str() );
  PIPSocket::Address localAddr;
  WORD localPort = 5060;
  sbc.GetB2BUAEndPoint()->GetTransportManager()->GetListenerAddress( SIPTransport::UDP, remoteAddr, localAddr, localPort );
  
  SIPURI ruri;
  invite.GetRequestURI( ruri);
  ruri.SetHost( localAddr.AsSTLString() );
  OString port( localPort );
  ruri.SetPort( port );
  ContactURI curi;
  curi.SetURI( ruri );

  SIPMessage redirect;
  invite.CreateResponse( redirect, SIPMessage::Code302_MovedTemporarily, "Redirect To Main Trunk" );
  redirect.AppendContact( curi );
  return call.SendRequest( redirect, invite.GetTransaction() );
}

BOOL SBCCallHandler::DumpCATLog( B2BUAConnection & conn, BOOL rejected )
{
  PWaitAndSignal lock( m_CATMutex );
  PTime now;
  if( now.GetDay() != m_CATDate.GetDay() )
    OpenCATLog();

  B2BUACall * call_1 =  conn.GetLeg1Call();
  B2BUACall * call_2 =  conn.GetLeg2Call();

  if( call_1 == NULL || call_2 == NULL )
    return FALSE;

  SIPMessage inboundInvite = call_1->GetCurrentUASInvite();
  SIPMessage outboundInvite = call_2->GetCurrentUACInvite();

  OStringStream strm;
  strm << now.AsString("yyyy/MM/dd hh:mm:ss.uuu");

  if( call_2 != NULL )
    strm << " [" << call_2->GetCallId().c_str() << "]";
  else if( call_1 != NULL ) 
    strm << " [" << call_1->GetCallId().c_str() << "]";

  if( rejected )
  {
    switch( call_2->GetCallEndReason() )
    {
      case CallSession::ICT_Recv3xx:
      case CallSession::ICT_Recv4xx:
      case CallSession::ICT_Recv5xx:
      case CallSession::ICT_Recv6xx:
        strm << " CS:" << call_2->GetCallEndStatusCode();
      default:
        strm << " CS:200";
    }
  }else
  {
    strm << " CS:200";
  }

  strm << " OC:" << inboundInvite.GetFromURI().GetUser().c_str();
  strm << "<" << inboundInvite.GetFromURI().GetHost().c_str() << ">";
  strm << " TC:" << inboundInvite.GetRequestURI().GetUser().c_str();
  if( outboundInvite.IsValid() )
  {
    strm << "(" << outboundInvite.GetRequestURI().GetUser().c_str() << ")";
    strm << "<" << outboundInvite.GetRequestURI().GetHost().c_str() << ">";
  }else
  {
    strm << "()<>";
  }

  strm << " RT:" << conn.GetRingDuration() / 1000;
  strm << " CT:" << conn.GetCallDuration() / 1000;

  return m_CATLog->WriteLine( strm.str().c_str() );
}

BOOL SBCCallHandler::OpenCATLog()
{ 
  PWaitAndSignal lock( m_CATMutex );
  PFilePath catDIR = OSSApplication::GetApplicationDirectory() + "CAT";
  if( !PDirectory::Exists( catDIR ) )
    PDirectory::Create( catDIR );

  catDIR = catDIR + "/static";
  if( !PDirectory::Exists( catDIR ) )
    PDirectory::Create( catDIR );

  OStringStream m;
  m << catDIR + "/CAT" << m_CATDate.GetYear() << m_CATDate.GetMonth() << m_CATDate.GetDay();

  PFilePath fp( m.str() ); 
  
  delete m_CATLog;
  m_CATLog = new PTextFile( fp, PFile::ReadWrite );
  m_CATLog->SetPosition(0, PFile::End);

  return TRUE;
}



