/*
 *
 * SolegyParser.h
 *
 * Open SIP Stack ( OSS )
 *
 * Copyright (c) opensipstack.org.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either expressed or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is OpenSIPStack.
 *
 * The Initial Developer of the Original Code is opensipstack.org.
 *
 * The author of this code is Joegen E. Baclor
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * The OpenSIPStack Library includes some GPL/LGPL code libraries that MAY be 
 * enabled at compile time using the --enable-gpllibs configure switch.  If
 * enabled, the content of this file is published under the terms of GNU 
 * General Public License Version 2.  For a detailed list of the available
 * GPL code, see $(opensipstack)/gnu/README file.
 *
 * $Log: SolegyParser.h,v $
 * Revision 1.12  2009/03/14 11:19:02  joegenbaclor
 * added authenticator support in solegy auth
 *
 * Revision 1.11  2008/11/11 02:54:47  joegenbaclor
 * Feature:  Introducing RTTS aggregation of groomer and osbc
 * Bug:  Disconnect calls if ParseRouting has an empty result set
 *
 * Revision 1.10  2008/10/22 05:06:25  joegenbaclor
 * Added MPL License Header
 *
 *
 */

#ifndef SOLEGYPARSER_H
#define SOLEGYPARSER_H

#include "SIPMessage.h"
using namespace SIPParser;

namespace SOLEGY
{
  class  SolegyParser 
  {
  public:

    enum RTTSError
    {
      ErrorNone				      = 8000,
      ErrorConnectTimeout		= 8001,
      ErrorTrunkBusy			  = 8002,
      ErrorChannelBusy		  = 8003,
      ErrorUnsupportedMedia	= 8004,
      ErrorNotFound			    = 8005,
      ErrorNoMedia			    = 8006,
      ErrorMediaTimeout		  = 8007,
      ErrorNotAvailable		  = 8008,
      ErrorRemoteBusy			  = 8009,
      ErrorRemoteBadNumber	= 8010,
      ErrorNoAnswer			    = 8011,
      ErrorTimeExceeded		  = 8012,
      ErrorDeclined			    = 8013,
      ErrorInvalid			    = 8014,
      ErrorNotInService		  = 8015,
      ErrorSit				      = 8016,
      ErrorNoDialTone			  = 8017,
      ErrorAuthFailed			  = 8018,
      ErrorAuthRejected		  = 8019,
      ErrorUnknown			    = 8020,
      ErrorFailed				    = 8021,
      ErrorCancelled			  = 8022,
      ErrorAuthRequired		  = 8023,
      ErrorAbandoned			  = 8024,
      ErrorNoRoute			    = 8025,
      ErrorAuthInvalid		  = 8026,
      ErrorRedirect			    = 8027,
      ErrorNoService			  = 8028,
      ErrorInvalidDigest    = 8029,
    }; // enum MPError

    static BOOL ParseRouting( 
      const OString & routingHeader,
      const SIPMessage & invite,
      SIPMessage::Collection & routes,
      BOOL ignoreRoutes = FALSE
    ); 

    static BOOL ParseRouteVector(
      const SIPMessage & invite,
      SIPMessage::Collection & routes
    );

    static OString GetString(
      const char * name, 
      const OString & packet,
      const OString & def = ""
    );

    static BOOL GetBoolean(
      const char * name, 
      const OString & packet,
      BOOL def = FALSE
    );

    static int GetInteger(
      const char * name, 
      const OString & packet,
      int def = 0
    );

    static double GetReal(
      const char * name, 
      const OString & packet,
      double def = 0
    );



    static BOOL ParseHeader( 
      const char * name, 
      OString & value, 
      const OString & packet
    );

    static int ParseErrorCode( const OString & errorPacket );
    static OString ParseErrorDesc( const OString & errorPacket );


    static BOOL ParseWholeNumber(
      const OString & whole, 
      OString &wHundredThousands,
      OString &wTenThousands,
      OString &wThousands,
      OString &wHundreds,
      OString &wTens,
      OString &wOnes
    );

    static BOOL ParseWholeNumber( 
      const OString & value, 
      OStringArray &words
    );

    static BOOL ParseBalanceAsEnglish(
      const OString & value,
      OStringArray & words 
    );

    static BOOL ParseMinuteAsEnglish(
      const OString & value,
      OStringArray & words 
    );

    static BOOL ParseBalanceAsEnglish( 
      const OString & balanceHeader, 
      OString &wHundredThousands,
      OString &wTenThousands,
      OString &wThousands,
      OString &wHundreds,
      OString &wTens,
      OString &wOnes,
      OString &cTens,
      OString &cOnes,
      OString &currencyCode
    );

    static BOOL ParseMediaAttributes(
      const OString & leg1SDP,
      const OString & leg1TranslatedSDP,
      const OString & leg2SDP,
      const OString & leg2TranslatedSDP,
      OString & ORIGMEDIACODEC,
      OString & ORIGMEDIADSTADDRESS,
      OString & ORIGMEDIASRCADDRESS,
      OString & TERMMEDIACODEC,
      OString & TERMMEDIADSTADDRESS,
      OString & TERMMEDIASRCADDRESS
    );

    static SolegyParser::RTTSError ConvertSIPToRTTSError(
      const SIPMessage & msg
    );

    static OString ConvertRTTSErrorToString( 
      SolegyParser::RTTSError error 
    );

    static BOOL XORDecodeValue(
      const char * key,
      const char * in,
      OString & out
    );

    static BOOL XOREncodeValue(
      const char * key,
      const char * in,
      OString & out
    );


  };
}

#endif



