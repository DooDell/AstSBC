/*
 *
 * SBCSwitchDTMFHandler.cxx
 *
 * Open SIP Stack ( OSS )
 *
 * Copyright (c) opensipstack.org.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either expressed or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is OpenSIPStack.
 *
 * The Initial Developer of the Original Code is opensipstack.org.
 *
 * The author of this code is Joegen E. Baclor
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * The OpenSIPStack Library includes some GPL/LGPL code libraries that MAY be 
 * enabled at compile time using the --enable-gpllibs configure switch.  If
 * enabled, the content of this file is published under the terms of GNU 
 * General Public License Version 2.  For a detailed list of the available
 * GPL code, see $(opensipstack)/gnu/README file.
 *
 * $Log: SBCSwitchDTMFHandler.cxx,v $
 * Revision 1.4  2009/06/03 11:57:16  joegenbaclor
 * Checking in MOH feature
 *
 * Revision 1.3  2009/06/01 09:47:28  joegenbaclor
 * more IVR related work
 *
 * Revision 1.2  2009/05/29 09:31:32  joegenbaclor
 * Added Switch IVR Classes
 *
 * Revision 1.1  2009/05/27 12:40:34  joegenbaclor
 * Initial upload of switch related classes
 *
 *
 */

#include "SBCSwitchDTMFHandler.h"
#include "SBCSwitchFeatureCode.h"
#include "SBCB2BUACall.h"
#define new PNEW
using namespace SWITCH;
using namespace B2BUA;


/////////////////////////////////////////////

SBCSwitchDTMFQueue::SBCSwitchDTMFQueue( SBCSwitchDTMFInterface * iface )
{
  
  m_DTMFInterface = iface;
  m_Handler = NULL;
}

SBCSwitchDTMFQueue::~SBCSwitchDTMFQueue()
{
  FlushDTMFBuffer();
}

void SBCSwitchDTMFQueue::AttachHandler( SBCSwitchDTMFHandler * handler )
{
  PWaitAndSignal lock( m_DTMFQueueMutex );
  m_Handler = handler;
}


void SBCSwitchDTMFQueue::OnReceiveRFC2833Tone(
  const OpalRFC2833Info & tone 
)
{
  PWaitAndSignal lock( m_DTMFQueueMutex );
  m_DTMFQueue.Enqueue( new OpalRFC2833Info( tone ) );
  if( m_Handler != NULL )
  {
    m_Handler->OnReceiveRFC2833Tone( tone );
  }
}

OpalRFC2833Info * SBCSwitchDTMFQueue::DequeueDTMF()
{
  PWaitAndSignal lock( m_DTMFQueueMutex );
  return m_DTMFQueue.Dequeue();
}

OString SBCSwitchDTMFQueue::DequeueDTMFString()
{
  OString dtmf;
  for(;;)
  {
    OpalRFC2833Info * tone = m_DTMFQueue.Dequeue();
    if( tone == NULL )
      break;
    dtmf += tone->GetTone();
    delete tone;
  }
  return dtmf;
}

int SBCSwitchDTMFQueue::GetQueueSize()const
{
  PWaitAndSignal lock( m_DTMFQueueMutex );
  return m_DTMFQueue.GetSize();
}

void SBCSwitchDTMFQueue::FlushDTMFBuffer()
{
  PWaitAndSignal lock( m_DTMFQueueMutex );
  for(;;)
  {
    OpalRFC2833Info * tone = m_DTMFQueue.Dequeue();
    if( tone == NULL )
      break;
    delete tone;
  }
}


/////////////////////////////////////
SBCSwitchDTMFHandler::SBCSwitchDTMFHandler( 
  SBCSwitchDTMFQueue * queue,
  const PTimeInterval &firstDigitTimerInterval,
  const PTimeInterval &interDigitTimerInterval,
  const PTimeInterval &intraDigitTimerInterval)
{ 
  m_FirstDigitTimerInterval = firstDigitTimerInterval;
  m_InterDigitTimerInterval = interDigitTimerInterval;
  m_IntraDigitTimerInterval = intraDigitTimerInterval;
  m_DTMFQueue = queue;
  m_IsPassive = FALSE;
}

SBCSwitchDTMFHandler::SBCSwitchDTMFHandler( 
  SBCSwitchDTMFQueue * queue)
{ 
  m_DTMFQueue = queue;
  m_IsPassive = TRUE;
}

void SBCSwitchDTMFHandler::Activate( BOOL flushOldDigits )
{
  PWaitAndSignal lock( m_DTMFQueue->GetMutex() );
  m_DTMFQueue->AttachHandler( this );
  
  /// flush the buffer
  if( flushOldDigits )
    m_DTMFQueue->FlushDTMFBuffer();

  if( !m_IsPassive )
  {
    /// Stop the timers just in case they are still running
    m_FirstDigitTimer.Stop();
    m_InterDigitTimer.Stop();
    m_IntraDigitTimer.Stop();

    /// Check if we already have digits
    if( m_DTMFQueue->GetQueueSize() == 0 )
    {
      m_FirstDigitTimer = PTimer( m_FirstDigitTimerInterval );
      m_FirstDigitTimer.SetNotifier( PCREATE_NOTIFIER( _OnFirstDigitTimer ) );
      m_FirstDigitTimer.Resume();
    }

    m_IntraDigitTimer = PTimer( m_IntraDigitTimerInterval );
    m_IntraDigitTimer.SetNotifier( PCREATE_NOTIFIER( _OnIntraDigitTimer ) );
    m_IntraDigitTimer.Resume();
  }
}

void SBCSwitchDTMFHandler::OnReceiveRFC2833Tone( const OpalRFC2833Info & tone )
{
  if( !m_IsPassive )
  {
    m_FirstDigitTimer.Stop();
    m_InterDigitTimer.Stop();
  }
  OnDTMFProcessQueue( tone );
  if( !m_IsPassive )
  {
    m_InterDigitTimer = PTimer( m_InterDigitTimerInterval );
    m_InterDigitTimer.SetNotifier( PCREATE_NOTIFIER( _OnInterDigitTimer ) );
    m_InterDigitTimer.Resume();
  }
}

SBCSwitchDTMFHandler::~SBCSwitchDTMFHandler(){}
void SBCSwitchDTMFHandler::_OnFirstDigitTimer( PTimer &, INT ){ OnFirstDigitTimeout(); }
void SBCSwitchDTMFHandler::_OnInterDigitTimer( PTimer &, INT ){ OnInterDigitTimeout(); }
void SBCSwitchDTMFHandler::_OnIntraDigitTimer( PTimer &, INT ){ OnIntraDigitTimeout(); }

////////////////////////////

SBCSwitchDTMFInterface::SBCSwitchDTMFInterface()
{ 
  m_DTMFQueue = new SBCSwitchDTMFQueue( this );
  m_FCodeHandler = NULL;
}
SBCSwitchDTMFInterface::~SBCSwitchDTMFInterface()
{ 
  delete m_DTMFQueue;
  delete m_FCodeHandler; 
}

