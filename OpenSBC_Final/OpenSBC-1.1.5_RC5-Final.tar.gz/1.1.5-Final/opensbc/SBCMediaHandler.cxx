/*
 *
 * SBCMediaHandler.cxx
 * 
 * Open SIP Stack ( OSS )
 *
 * Copyright (C) 2006 Joegen E. Baclor. All Rights Reserved.
 *
 * Version: MPL 1.1/GPL 2.0/LGPL 2.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is OpenSIPStack Library.
 *
 * The Initial Developer of the Original Code is Joegen E. Baclor.
 *
 * Contributor(s):
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * $Log: SBCMediaHandler.cxx,v $
 * Revision 1.7  2009/06/22 09:31:58  joegenbaclor
 * *** empty log message ***
 *
 * Revision 1.6  2009/06/22 09:09:01  joegenbaclor
 * added port in bind error log
 *
 * Revision 1.5  2009/06/22 08:59:33  joegenbaclor
 * modified setting of RTP port range to not use opal manager
 *
 * Revision 1.4  2009/05/27 12:40:34  joegenbaclor
 * Initial upload of switch related classes
 *
 * Revision 1.3  2009/05/14 11:14:55  joegenbaclor
 * initially set target port to the one in SDP
 *
 * Revision 1.2  2009/04/20 04:16:44  joegenbaclor
 * added null check for rtp poiner returned by getsession
 *
 * Revision 1.1  2009/03/26 06:18:14  joegenbaclor
 * Moved RTP/SDP media handler to the application layer
 *
 *
 */

#include "B2BUA.h"
#include "SBCMediaHandler.h"
#include "B2BUACall.h"
#include "B2BUAConnection.h"
#include "SDPLazyParser.h"

#define new PNEW

using namespace B2BUA;
using namespace SDP;

SBCMediaHandler::SBCMediaHandler(  
    B2BUserAgent & b2bua 
) : B2BMediaInterface( b2bua )
{
  SetRTPPortRange( 30000, 50000 );
  m_RTPSocketList.DisallowDeleteObjects();
  m_RTPSelectList.DisallowDeleteObjects();
  m_ProxyPrivateContact = TRUE;
  m_ProxyViaReceived = TRUE;
  m_ProxyViaSendAddress = TRUE;
  m_ProxyViaRPort = TRUE;
  m_ProxyAllMedia = FALSE;
}

SBCMediaHandler::~SBCMediaHandler()
{
}

/// Called when an invite is received with SDP
/// or a 180, 183, 200 is received with SDP
BOOL SBCMediaHandler::OnIncomingSDPOffer(
  B2BUAConnection & connection,
  B2BUACall & call,
  const SIPMessage & sdp
)
{
  if( call.GetLegIndex() == 0 )
    connection.SetLeg1SDP( sdp.GetBody() );
  else
  {
    connection.SetLeg2SDP( sdp.GetBody() );
  }

  if( !connection.IsAllowMediaProxy() )
    return TRUE;

  return CreateRTPSession( connection, call, sdp, connection.GetMediaProxyIfPrivate() );
}

BOOL SBCMediaHandler::OnIncomingSDPAnswer(
  B2BUAConnection & connection,
  B2BUACall & call,
  const SIPMessage & sdp
)
{
  if( call.GetLegIndex() == 0 )
    connection.SetLeg1SDP( sdp.GetBody() );
  else
  {
    connection.SetLeg2SDP( sdp.GetBody() );
  }

  if( !sdp.HasSDP() )
    return FALSE;

  SDPLazyParser parser = sdp.GetBody();

  RTP_SessionManager & manager = call.GetRTPSessionManager();
  RTP_UDP * audio = (RTP_UDP *)manager.GetSession( 
        OpalMediaFormat::DefaultAudioSessionID );

  RTP_UDP * video = (RTP_UDP *)manager.GetSession( 
  OpalMediaFormat::DefaultVideoSessionID );

 
  if( audio != NULL )
  {
    SIPURI audioAddr;
    parser.GetMediaAddress( SDPLazyParser::Audio, audioAddr );
    PIPSocket::Address targetAddress = audioAddr.GetAddress();
    WORD targetPort = (WORD)audioAddr.GetPort().AsUnsigned();

    if( targetAddress.IsValid() && targetPort != 0 )
    {
      if( !SIPTransport::IsPrivateNetwork( targetAddress ) )
      {
        audio->SetRemoteSocketInfo( targetAddress, targetPort, TRUE );
        audio->SetRemoteSocketInfo( targetAddress, targetPort + 1, FALSE );
      }else
      {
        audio->SetRemoteSocketInfo( 0, 0, TRUE );
        audio->SetRemoteSocketInfo( 0, 0 + 1, FALSE );
        audio->SetTemporaryRemoteSocketInfo( targetAddress, targetPort, TRUE );
        audio->SetTemporaryRemoteSocketInfo( targetAddress, targetPort + 1, FALSE );
      }
    }
  }

  if( video != NULL )
  {
    SIPURI videoAddr;
    parser.GetMediaAddress( SDPLazyParser::Video, videoAddr );
    PIPSocket::Address targetAddress = videoAddr.GetAddress();
    WORD targetPort = (WORD)videoAddr.GetPort().AsUnsigned();

    if( targetAddress.IsValid() && targetPort != 0 )
    {
      if( !SIPTransport::IsPrivateNetwork( targetAddress ) )
      {
        video->SetRemoteSocketInfo( targetAddress, targetPort, TRUE );
        video->SetRemoteSocketInfo( targetAddress, targetPort + 1, FALSE );
      }else
      {
        video->SetRemoteSocketInfo( 0, 0, TRUE );
        video->SetRemoteSocketInfo( 0, 0 + 1, FALSE );
        video->SetTemporaryRemoteSocketInfo( targetAddress, targetPort, TRUE );
        video->SetTemporaryRemoteSocketInfo( targetAddress, targetPort + 1, FALSE );
      }
    }
  }

  return TRUE;
}

/// Called when sending an outbound INVITE or reInvites
BOOL SBCMediaHandler::OnRequireSDPOffer(
  B2BUAConnection & connection,
  B2BUACall & call,
  SIPMessage & offer
)
{
  if( call.GetLegIndex() == 0 )
  { 
    LOG( call.LogDebug(), "RTP: First Leg offer being set from Second Leg SDP" );

    if( connection.GetLeg2SDP().IsEmpty() )
      return FALSE;

    offer.SetSDP( connection.GetLeg2SDP() );

  }else if( call.GetLegIndex() == 1 )
  {
    LOG( call.LogDebug(), "RTP: Second Leg offer being set from First Leg SDP" );

    if( connection.GetLeg1SDP().IsEmpty() )
      return FALSE;

    offer.SetSDP( connection.GetLeg1SDP() );
  }
  
  return TranslateSDPOffer( connection, call, offer );
}

/// called when a previously received offer is to be answered
/// usually called when sending 183 0r 200 OK
BOOL SBCMediaHandler::OnRequireSDPAnswer(
  B2BUAConnection & connection,
  B2BUACall & call,
  const SIPMessage & offer,
  SIPMessage & answer
)
{
  if( call.GetLegIndex() == 0 )
  { 
    if( connection.GetLeg2SDP().IsEmpty() )
    {
      return FALSE;
    }

    answer.SetSDP( connection.GetLeg2SDP() );

  }else if( call.GetLegIndex() == 1 )
  {
    if( connection.GetLeg1SDP().IsEmpty() )
    {
      return FALSE;
    }

    answer.SetSDP( connection.GetLeg1SDP() );
  }

  BOOL ok = FALSE;
  if( TranslateSDPAnswer( connection, call, offer, answer ) )
    ok = OnOpenMediaStreams( connection );

  return ok;
}


BOOL SBCMediaHandler::CreateRTPSession(
  B2BUAConnection & connection,
  B2BUACall & call,
  const SIPMessage & request,
  BOOL createOnlyIfPrivate
)
{

  if( request.IsInvite() )
  {
    if( !createOnlyIfPrivate )
    {
      PTRACE( 5, "RTP: Media Proxy Forced" );
    }

    const Via & via = request.GetTopVia();
    SIPURI viaURI;
    viaURI = via.GetURI();


    if( createOnlyIfPrivate && m_ProxyPrivateContact )
    {
      if( request.GetContactSize() > 0 )
        createOnlyIfPrivate = !request.GetTopContactURI().IsPrivateNetwork();

      if( !createOnlyIfPrivate )
      {
        PTRACE( 5, "RTP: Media Proxy Forced on Private Contact" );
      }
    }
    
    if( createOnlyIfPrivate && m_ProxyViaReceived )
    {
      if( request.GetViaSize() > 0 )
      {
        PIPSocket::Address received = via.GetReceiveAddress();
        PIPSocket::Address host = viaURI.GetAddress();
        if( host.Byte1() != 127 )
        {
          createOnlyIfPrivate = (host == received);
          if( !createOnlyIfPrivate )
          {
            PTRACE( 5, "RTP: Media Proxy Forced on different via host and source address" );
          }
        }
      }
    }

    if( createOnlyIfPrivate && m_ProxyViaSendAddress )
    {
      if( request.GetViaSize() > 0 )
      {
        PIPSocket::Address host = viaURI.GetAddress();
        createOnlyIfPrivate = !host.IsRFC1918();

        if( !createOnlyIfPrivate )
        {
          PTRACE( 5, "RTP: Media Proxy Forced On Private Via" );
        }
      }
    }

    if( createOnlyIfPrivate && m_ProxyViaRPort )
    {
      if( via.GetPort() != 0 )
      {
        createOnlyIfPrivate = (via.GetRPort() == via.GetPort());
        if( !createOnlyIfPrivate )
        {
          PTRACE( 5, "RTP: Media Proxy Forced On Different Rport" );
        }
      }
    }
  }
  

  SDPLazyParser parser = request.GetBody();
  SIPURI mediaAddress, videoAddress, faxAddress;
  RTP_SessionManager & manager = call.GetRTPSessionManager();
  OString callId = request.GetCallId();
  
  if( request.GetViaSize() == 0 )
  {
    LOG_CONTEXT( LogError(), callId, "RTP: Unable to create RTP session because via size is zero" );
    return FALSE;
  }

  PIPSocket::Address targetAddress( request.GetInterfaceAddress().c_str() );
  PIPSocket::Address localAddress = targetAddress;
  WORD targetPort = 0;

  Via targetVia;
  if( targetAddress.IsValid() )
  {
    if( !call.GetSessionManager().ConstructVia( targetAddress, targetVia, SIPTransport::UDP ) )
    {
      LOG_CONTEXT( LogError(), callId, "RTP: *** VIA ERROR *** Unable to create RTP session" );
      return FALSE;
    }
  }
  if( !targetVia.GetExternalAddress().IsEmpty() )
    localAddress.SetExternalIP( targetVia.GetExternalAddress().c_str() );

  if( parser.GetMediaAddress( SDPLazyParser::Audio, mediaAddress ) )
  {
    targetPort = (WORD)mediaAddress.GetPort().AsUnsigned();
    if( ( mediaAddress.IsPrivateNetwork() || !createOnlyIfPrivate || mediaAddress.GetHost() == "127.0.0.1" ) )
    {
      if( !CreateRTPSession(
        callId, 
        OpalMediaFormat::DefaultAudioSessionID,
        localAddress,
        mediaAddress.GetAddress(),
        targetAddress,
        targetPort,
        manager,
        call.IsEncryptionEnabled()
      ) )return FALSE;
      else
      {
        LOG_CONTEXT( LogInfo(), callId, 
          "*** RTP Session CREATED *** " <<  
          "l-addr=" << localAddress <<
          " r-addr=" << mediaAddress.GetAddress() << "/" <<  targetAddress << 
          " r-port=" << targetPort );
      }
    }
  }

  if( parser.GetMediaAddress( SDPLazyParser::Video, videoAddress ) )
  {
    if( ( videoAddress.IsPrivateNetwork() || !createOnlyIfPrivate || videoAddress.GetHost() == "127.0.0.1" ) )
    {
      if( !CreateRTPSession(
        callId, 
        OpalMediaFormat::DefaultVideoSessionID,
        localAddress,
        videoAddress.GetAddress(),
        targetAddress,
        targetPort,
        manager,
        call.IsEncryptionEnabled()
      ) )return FALSE;
      else
      {
        LOG_CONTEXT( LogInfo(), request.GetCallId(), 
          "*** RTP Session CREATED *** " <<  
          "l-addr=" << localAddress <<
          " r-addr=" << videoAddress.GetAddress() << "/" <<  targetAddress << 
          " r-port=" << targetPort );
      }
    }
  }

  return TRUE;
}

BOOL SBCMediaHandler::CreateRTPSession(
  const OString & callId,
  unsigned sessionId,
  const PIPSocket::Address & localAddress,
  const PIPSocket::Address & targetAddress,
  const PIPSocket::Address & receivedAddress,
  WORD targetPort,
  RTP_SessionManager & manager,
  BOOL isEncrypted
)
{
  // create an RTP session
  RTP_UDP * rtpSession = (RTP_UDP*)manager.GetSession(sessionId);
  if(  rtpSession == NULL )
  {
    rtpSession = new RTP_UDP(sessionId);
    rtpSession->SetWillSendReport( FALSE );

    WORD firstPort = GetNextRTPDataPort();
    WORD nextPort = firstPort;
    while (!rtpSession->Open(localAddress,
                            nextPort, nextPort,
                            m_OpalManager.GetRtpIpTypeofService(),
                            NULL,
                            NULL)) 
    {
      LOG_CONTEXT( LogError(), callId, "RTP: Unable to create RTP session.  Bind Error on port " << nextPort);
      nextPort = GetNextRTPDataPort();
      if (nextPort == firstPort) 
      {
        delete rtpSession;
        return FALSE;
      }
    }

    manager.AddSession( rtpSession );
  }

  rtpSession->SetEncryption( isEncrypted );

  rtpSession->SetLocalAddress(localAddress);
  if( targetAddress.IsValid() && targetPort != 0 )
  {
    if( !SIPTransport::IsPrivateNetwork( targetAddress ) )
    {
      rtpSession->SetRemoteSocketInfo( targetAddress, targetPort, TRUE );
      rtpSession->SetRemoteSocketInfo( targetAddress, targetPort + 1, FALSE );
    }else
    {
      rtpSession->SetRemoteSocketInfo( 0, 0, TRUE );
      rtpSession->SetRemoteSocketInfo( 0, 0 + 1, FALSE );
      rtpSession->SetTemporaryRemoteSocketInfo( receivedAddress, targetPort, TRUE );
      rtpSession->SetTemporaryRemoteSocketInfo( receivedAddress, targetPort + 1, FALSE );
    }
  }
  
  return TRUE;
}

BOOL SBCMediaHandler::TranslateSDPOffer(
  B2BUAConnection & connection,
  B2BUACall & call,
  SIPMessage & offer
)
{

  SDPLazyParser parser = offer.GetBody();
  SIPURI mediaAddress, videoAddress, faxAddress;
  RTP_SessionManager & manager = call.GetRTPSessionManager();
  OString callId = offer.GetCallId();

  BOOL mediaProxy = FALSE;
  OString globalAddress;

  parser.GetGlobalAddress( globalAddress );

  if( call.GetLegIndex() == 0 )
  { 
    //this can only be a reinvite initiated by callee
    if( parser.GetMediaCount( SDPLazyParser::Audio ) > 0 )
    {
      /// check if leg1 has an RTP session created by the very first invite
      RTP_UDP * rtp = (RTP_UDP *)manager.GetSession( OpalMediaFormat::DefaultAudioSessionID );

      if( rtp != NULL )
      {
        PIPSocket::Address addr = rtp->GetLocalAddress();
        PIPSocket::Address portForwardingIP( addr.GetExternalIP() );
        if( portForwardingIP.IsValid() )
          addr = portForwardingIP;

        parser.SetOriginAddress( addr.AsSTLString() );
        WORD port = rtp->GetLocalDataPort();

        LOG( call.LogDebug(), "RTP: (Audio) First Leg Offer being translated to " << addr << ":" << port );

        SIPURI mediaAddr;
        parser.GetMediaAddress( SDPLazyParser::Audio, mediaAddr, 0 );
        if( mediaAddr.GetHost() == "0.0.0.0" )
          addr = 0;

        parser.SetMediaAddress(
          SDPLazyParser::Audio,
          0,
          addr.AsSTLString(),
          port );

        mediaProxy = TRUE;
        if( globalAddress != "0.0.0.0" )
          globalAddress = rtp->GetLocalAddress().AsSTLString();
      }else
      {
        LOG( call.LogDebug(), "RTP: (Audio) No RTP Session found for First Leg" );
        /// this could be referred call
        B2BUACall * leg2 = connection.GetLeg2Call();
        if( leg2 == NULL )
        {
          LOG( call.LogDebug(), "RTP: Unable to retrieve a pointer to Leg 2" );
          return FALSE;
        }

        // Create Reference here. There are chances that it might be deleted
        // if the B2BUAConnection is in state of destruction.
        SIPSession::GCRef leg2Ref = GCCREATEREF( leg2, "SBCMediaHandler::TranslateSDPOffer", "B2BUACall Leg 2" ); 
        if( leg2Ref == NULL )
        {
          LOG( call.LogDebug(), "RTP: Unable to retrieve a reference to Leg 2" );
          return FALSE;
        }

        RTP_SessionManager & leg2RTPManager = leg2->GetRTPSessionManager();
        ///check if leg 2 has an RTP session
        /// if it has, then lets create a corresponding stream
        /// for leg 1 if its not there
        RTP_UDP * leg2Audio = (RTP_UDP *)leg2RTPManager.GetSession( 
          OpalMediaFormat::DefaultAudioSessionID );

        /// create leg 2 RTP sessions.  we will base localAddress
        /// from the via we have in the INVITE
        if( leg2Audio != NULL )
        {
          const Via & via = offer.GetTopVia();
          PIPSocket::Address localAddress( via.GetAddress().c_str() );
          PIPSocket::Address targetAddress;
          WORD targetPort;
          SIPTransport::Resolve( offer, targetAddress, targetPort );

          CreateRTPSession(
            callId,
            OpalMediaFormat::DefaultAudioSessionID,
            localAddress,
            targetAddress,
            via.GetReceiveAddress(),
            0,
            manager );

          rtp = (RTP_UDP *)manager.GetSession( OpalMediaFormat::DefaultAudioSessionID );

		      if( rtp == NULL )
		        return FALSE;

          PIPSocket::Address addr = rtp->GetLocalAddress();
          parser.SetOriginAddress( addr.AsSTLString() );
          WORD port = rtp->GetLocalDataPort();

          // We were offered a black hole IP, pass it on to the other leg too.
          SIPURI mediaAddr;
          parser.GetMediaAddress( SDPLazyParser::Audio, mediaAddr, 0 );
          if( mediaAddr.GetHost() == "0.0.0.0" )
            addr = 0;

          LOG( call.LogDebug(), "RTP: (Audio) First Leg Offer being translated to " << addr << ":" << port );

          parser.SetMediaAddress(
            SDPLazyParser::Audio,
            0,
            addr.AsSTLString(),
            port );

          mediaProxy = TRUE;
          if( globalAddress != "0.0.0.0" )
            globalAddress = rtp->GetLocalAddress().AsSTLString();
        }
      }
    }

    if( parser.GetMediaCount( SDPLazyParser::Video ) > 0 )
    {
      /// check if leg1 has an RTP session created by the very first invite
      RTP_UDP * rtp = (RTP_UDP *)manager.GetSession( OpalMediaFormat::DefaultVideoSessionID );

      if( rtp != NULL )
      {
        PIPSocket::Address addr = rtp->GetLocalAddress();
        PIPSocket::Address portForwardingIP( addr.GetExternalIP() );
        if( portForwardingIP.IsValid() )
          addr = portForwardingIP;

        parser.SetOriginAddress( addr.AsSTLString() );
        WORD port = rtp->GetLocalDataPort();

        // We were offered a black hole IP, pass it on to the other leg too.
        SIPURI mediaAddr;
        parser.GetMediaAddress( SDPLazyParser::Video, mediaAddr, 0 );
        if( mediaAddr.GetHost() == "0.0.0.0" )
          addr = 0;

        LOG( call.LogDebug(), "RTP: (Video) First Leg Offer being translated to " << addr << ":" << port );

        parser.SetMediaAddress(
          SDPLazyParser::Video,
          0,
          addr.AsSTLString(),
          port );

        mediaProxy = TRUE;
        if( globalAddress != "0.0.0.0" )
          globalAddress = rtp->GetLocalAddress().AsSTLString();
      }else
      {
        LOG( call.LogDebug(), "RTP: (Video) No RTP Session found for First Leg" );
      }
    }

    // If we're proxying the media, set the SDP's global address if possible.
    if ( mediaProxy )
      parser.SetGlobalAddress( globalAddress );

  }else if( call.GetLegIndex() == 1 )
  {
    /// this could be an outbound invite
    /// or a reInvite invoked by the caller
    B2BUACall * leg1 = connection.GetLeg1Call();
    if( leg1 == NULL )
      return FALSE;

    // Create Reference here. There are chances that it might be deleted
    // if the B2BUAConnection is in state of destruction.
    SIPSession::GCRef leg1Ref = GCCREATEREF( leg1, "SBCMediaHandler::TranslateSDPOffer", "B2BUACall Leg 1" ); 
    if( leg1Ref == NULL )
      return FALSE;

    RTP_SessionManager & leg1RTPManager = leg1->GetRTPSessionManager();
    ///check if leg 1 has an RTP session
    /// if it has, then lets create a corresponding stream
    /// for leg 2 if its not there
    RTP_UDP * leg1Audio = (RTP_UDP *)leg1RTPManager.GetSession( 
      OpalMediaFormat::DefaultAudioSessionID );

    RTP_UDP * leg1Video = (RTP_UDP *)leg1RTPManager.GetSession( 
      OpalMediaFormat::DefaultVideoSessionID );

    if( leg1Audio != NULL || leg1Video != NULL )
    {
      /// leg 1 has RTP Sessions, now check leg2.
      RTP_UDP * leg2Audio = (RTP_UDP *)manager.GetSession( 
        OpalMediaFormat::DefaultAudioSessionID );

      RTP_UDP * leg2Video = (RTP_UDP *)manager.GetSession( 
        OpalMediaFormat::DefaultVideoSessionID );

      if( leg2Audio == NULL || leg2Video == NULL )
      {
        /// create leg 2 RTP sessions.  we will base localAddress
        /// from the via we have in the INVITE
        const Via & via = offer.GetTopVia();
        PIPSocket::Address localAddress( via.GetAddress().c_str() );
        PIPSocket::Address targetAddress = localAddress;

        Via targetVia;
        if( targetAddress.IsValid() )
        {
          if( !call.GetSessionManager().ConstructVia( targetAddress, targetVia, SIPTransport::UDP ) )
          {
            LOG_CONTEXT( LogError(), callId, "RTP: *** VIA ERROR *** Unable to create RTP session" );
            return FALSE;
          }
        }
        if( !targetVia.GetExternalAddress().IsEmpty() )
          localAddress.SetExternalIP( targetVia.GetExternalAddress().c_str() );

        if( leg1Audio != NULL && leg2Audio == NULL  )
          CreateRTPSession(
            callId,
            OpalMediaFormat::DefaultAudioSessionID,
            localAddress,
            targetAddress,
            via.GetReceiveAddress(),
            0,
            manager );

        if( leg1Video != NULL && leg2Video == NULL )
          CreateRTPSession(
            callId,
            OpalMediaFormat::DefaultVideoSessionID,
            localAddress,
            targetAddress,
            via.GetReceiveAddress(),
            0,
            manager );
      }

      /// now translate the offer
      //this can only be a reinvite initiated by callee
      if( parser.GetMediaCount( SDPLazyParser::Audio ) > 0 )
      {
        /// check if leg1 has an RTP session created by the very first invite
        RTP_UDP * rtp = (RTP_UDP *)manager.GetSession( OpalMediaFormat::DefaultAudioSessionID );

        if( rtp != NULL )
        {
          
          PIPSocket::Address addr = rtp->GetLocalAddress();
          PIPSocket::Address portForwardingIP( addr.GetExternalIP() );
          if( portForwardingIP.IsValid() )
            addr = portForwardingIP;
         
          WORD port = rtp->GetLocalDataPort();

          // We were offered a black hole IP, pass it on to the other leg too.
          SIPURI mediaAddr;
          parser.GetMediaAddress( SDPLazyParser::Audio, mediaAddr, 0 );
          if( mediaAddr.GetHost() == "0.0.0.0" )
            addr = 0;

          LOG( call.LogDebug(), "RTP: (Audio) SDP Offer being translated to " << addr << ":" << port );

          parser.SetMediaAddress(
            SDPLazyParser::Audio,
            0,
            addr.AsSTLString(),
            port );

          mediaProxy = TRUE;
          if( globalAddress != "0.0.0.0" )
            globalAddress = addr.AsSTLString();
        }else
        {
          LOG( call.LogDebug(), "RTP: (Audio) No RTP Session found for Second Leg" );
        }
      }

      if( parser.GetMediaCount( SDPLazyParser::Video ) > 0 )
      {
        /// check if leg2 has an RTP session created by the very first invite
        RTP_UDP * rtp = (RTP_UDP *)manager.GetSession( OpalMediaFormat::DefaultVideoSessionID );

        if( rtp != NULL )
        {
          PIPSocket::Address addr = rtp->GetLocalAddress();
          PIPSocket::Address portForwardingIP( addr.GetExternalIP() );
          if( portForwardingIP.IsValid() )
            addr = portForwardingIP;

          WORD port = rtp->GetLocalDataPort();

          // We were offered a black hole IP, pass it on to the other leg too.
          SIPURI mediaAddr;
          parser.GetMediaAddress( SDPLazyParser::Video, mediaAddr, 0 );
          if( mediaAddr.GetHost() == "0.0.0.0" )
            addr = 0;

          LOG( call.LogDebug(), "RTP: (Video) SDP Offer being translated to " << addr << ":" << port );

          parser.SetMediaAddress(
            SDPLazyParser::Video,
            0,
            addr.AsSTLString(),
            port );
          
          mediaProxy = TRUE;
          if( globalAddress != "0.0.0.0" )
            globalAddress = addr.AsSTLString();
        }else
        {
          LOG( call.LogDebug(), "RTP: (Video) No RTP Session found for Second Leg" );
        }
      }
    }

    // If we're proxying the media, set the SDP's global address if possible.
    if ( mediaProxy )
      parser.SetGlobalAddress( globalAddress );
  }

  if( call.GetLegIndex() == 0 )
  {
    SDPLazyParser oldOffer = connection.GetLeg2TranslatedSDP();

    if( !oldOffer.IsEmpty() )
    {
      OString oldVersion, oldId, newVersion, newId;
      oldOffer.GetSessionId( oldVersion, oldId );
      parser.GetSessionId( newVersion, newId );
      if( oldId.AsUnsigned() != newId.AsUnsigned() || oldVersion.AsUnsigned() != newVersion.AsUnsigned() )
      {
        unsigned long newver = oldVersion.AsUnsigned() + 1;
        OString version( newver );
        parser.SetSessionId( version, oldId );
      }
    }
    connection.SetLeg2TranslatedSDP( parser );
  }else
  {
    SDPLazyParser oldOffer = connection.GetLeg1TranslatedSDP();

    if( !oldOffer.IsEmpty() )
    {
      OString oldVersion, oldId, newVersion, newId;
      oldOffer.GetSessionId( oldVersion, oldId );
      parser.GetSessionId( newVersion, newId );
      if( oldId.AsUnsigned() != newId.AsUnsigned() || oldVersion.AsUnsigned() != newVersion.AsUnsigned() )
      {
        unsigned long newver = oldVersion.AsUnsigned() + 1;
        OString version( newver );
        parser.SetSessionId( version, oldId );
      }
    }
    connection.SetLeg1TranslatedSDP( parser );
  }

  offer.SetSDP( parser );

  return TRUE;
}

BOOL SBCMediaHandler::TranslateSDPAnswer(
  B2BUAConnection & connection,
  B2BUACall & call,
  const SIPMessage & offer,
  SIPMessage & answer
)
{
  SDPLazyParser parser = answer.GetBody();
  SIPURI mediaAddress, videoAddress, faxAddress;
  RTP_SessionManager & manager = call.GetRTPSessionManager();

  BOOL mediaProxy = FALSE;
  OString globalAddress;

  parser.GetGlobalAddress( globalAddress );

  if( parser.GetMediaCount( SDPLazyParser::Audio ) > 0 )
  {
    RTP_UDP * rtp = (RTP_UDP *)manager.GetSession( OpalMediaFormat::DefaultAudioSessionID );

    if( rtp != NULL )
    {
      PIPSocket::Address addr = rtp->GetLocalAddress();
      PIPSocket::Address portForwardingIP( addr.GetExternalIP() );
      if( portForwardingIP.IsValid() )
        addr = portForwardingIP;

      parser.SetOriginAddress( addr.AsSTLString() );
      WORD port = rtp->GetLocalDataPort();

      // Received a black hole IP, pass it on to the other leg too.
      SIPURI mediaAddr;
      parser.GetMediaAddress( SDPLazyParser::Audio, mediaAddr, 0 );
      if( mediaAddr.GetHost() == "0.0.0.0" )
        addr = 0;

      parser.SetMediaAddress(
        SDPLazyParser::Audio,
        0,
        addr.AsSTLString(),
        port );

      mediaProxy = TRUE;
      if( globalAddress != "0.0.0.0" )
        globalAddress = addr.AsSTLString();
      
    }
  }

  if( parser.GetMediaCount( SDPLazyParser::Video ) > 0 )
  {
    /// check if leg2 has an RTP session created by the very first invite
    RTP_UDP * rtp = (RTP_UDP *)manager.GetSession( OpalMediaFormat::DefaultVideoSessionID );

    if( rtp != NULL )
    {
      PIPSocket::Address addr = rtp->GetLocalAddress();
      PIPSocket::Address portForwardingIP( addr.GetExternalIP() );
      if( portForwardingIP.IsValid() )
        addr = portForwardingIP;

      parser.SetOriginAddress( addr.AsSTLString() );
      WORD port = rtp->GetLocalDataPort();

      // Received a black hole IP, pass it on to the other leg too.
      SIPURI mediaAddr;
      parser.GetMediaAddress( SDPLazyParser::Video, mediaAddr, 0 );
      if( mediaAddr.GetHost() == "0.0.0.0" )
        addr = 0;

      parser.SetMediaAddress(
        SDPLazyParser::Video,
        0,
        addr.AsSTLString(),
        port );

      mediaProxy = TRUE;
      if( globalAddress != "0.0.0.0" )
        globalAddress = addr.AsSTLString();

    }
  }

  // If we're proxying the media, set the SDP's global address if possible.
  if ( mediaProxy )
    parser.SetGlobalAddress( globalAddress );

  if( call.GetLegIndex() == 0 )
  {
    SDPLazyParser oldAnswer = connection.GetLeg2TranslatedSDP();

    if( !oldAnswer.IsEmpty() )
    {
      OString oldVersion, oldId, newVersion, newId;
      oldAnswer.GetSessionId( oldVersion, oldId );
      parser.GetSessionId( newVersion, newId );
      if( oldId.AsUnsigned() != newId.AsUnsigned() || oldVersion.AsUnsigned() != newVersion.AsUnsigned() )
      {
        unsigned long newver = oldVersion.AsUnsigned() + 1;
        OString version( newver );
        parser.SetSessionId( version, oldId );
      }
    }
    connection.SetLeg2TranslatedSDP( parser );
  }else
  {
    SDPLazyParser oldAnswer = connection.GetLeg1TranslatedSDP();

    if( !oldAnswer.IsEmpty() )
    {
      OString oldVersion, oldId, newVersion, newId;
      oldAnswer.GetSessionId( oldVersion, oldId );
      parser.GetSessionId( newVersion, newId );
      if( oldId.AsUnsigned() != newId.AsUnsigned() || oldVersion.AsUnsigned() != newVersion.AsUnsigned() )
      {
        unsigned long newver = oldVersion.AsUnsigned() + 1;
        OString version( newver );
        parser.SetSessionId( version, oldId );
      }
    }
    connection.SetLeg1TranslatedSDP( parser );
  }

  answer.SetBody( parser );

  return TRUE;
}

BOOL SBCMediaHandler::OnOpenMediaStreams(
  B2BUAConnection & connection
)
{
  PWaitAndSignal lock( m_MediaStreamsMutex );

  B2BUACall * leg1Call = connection.GetLeg1Call();
  B2BUACall * leg2Call = connection.GetLeg2Call();
  RTP_SessionManager & leg1Manager = leg1Call->GetRTPSessionManager();
  RTP_SessionManager & leg2Manager = leg2Call->GetRTPSessionManager();

  if( !connection.HasStartedAudioStream() ) {
      //start audio media streams
    RTP_UDP * leg1Audio = (RTP_UDP*)leg1Manager.GetSession( OpalMediaFormat::DefaultAudioSessionID );
    RTP_UDP * leg2Audio = (RTP_UDP*)leg2Manager.GetSession( OpalMediaFormat::DefaultAudioSessionID );

    if( leg1Audio != NULL && leg2Audio != NULL )
    {
      if( leg2Call->GetAudioRTPSessionThread() == NULL )
      {
        leg2Call->AttachAudioRTPSessionThread(
          new OpalMediaThread( leg2Audio, leg1Audio, leg2Call ) );
      }else
      {
        OpalMediaThread * thrd = (OpalMediaThread *)leg2Call->GetAudioRTPSessionThread();
        //thrd->m_IsPaused = TRUE;
        //thrd->m_Leg1 = leg2Audio;
        //thrd->m_Leg2 = leg1Audio;
        //thrd->m_IsPaused = FALSE;
        thrd->AttachSession( leg2Audio, leg1Audio, leg2Call );
      }

      if( leg1Call->GetAudioRTPSessionThread() == NULL )
      {
        leg1Call->AttachAudioRTPSessionThread(
          new OpalMediaThread( leg1Audio, leg2Audio, leg1Call ) );
      }else
      {
        OpalMediaThread * thrd = (OpalMediaThread *)leg1Call->GetAudioRTPSessionThread();
        //thrd->m_IsPaused = TRUE;
        //thrd->m_Leg1 = leg1Audio;
        //thrd->m_Leg2 = leg2Audio;
        //thrd->m_IsPaused = FALSE;
        thrd->AttachSession( leg1Audio, leg2Audio, leg1Call );
      }

      connection.StartAudioStream();
    }
  }

  if( !connection.HasStartedVideoStream() ) {

    RTP_UDP * leg1Video = (RTP_UDP*)leg1Manager.GetSession( OpalMediaFormat::DefaultVideoSessionID );
    RTP_UDP * leg2Video = (RTP_UDP*)leg2Manager.GetSession( OpalMediaFormat::DefaultVideoSessionID );

    if( leg1Video != NULL && leg2Video != NULL )
    {
      if( leg2Call->GetVideoRTPSessionThread() == NULL )
      {
        leg2Call->AttachVideoRTPSessionThread(
          new OpalMediaThread( leg2Video, leg1Video, leg2Call ) );
      }else
      {
        OpalMediaThread * thrd = (OpalMediaThread *)leg2Call->GetVideoRTPSessionThread();
        //thrd->m_IsPaused = TRUE;
        //thrd->m_Leg1 = leg2Video;
        //thrd->m_Leg2 = leg1Video;
        //thrd->m_IsPaused = FALSE;
        thrd->AttachSession( leg2Video, leg1Video, leg2Call );
      }

      if( leg1Call->GetVideoRTPSessionThread() == NULL )
      {
        leg1Call->AttachVideoRTPSessionThread(
          new OpalMediaThread( leg1Video, leg2Video, leg1Call ) );
      }else
      {
        OpalMediaThread * thrd = (OpalMediaThread *)leg1Call->GetVideoRTPSessionThread();
        //thrd->m_IsPaused = TRUE;
        //thrd->m_Leg1 = leg1Video;
        //thrd->m_Leg2 = leg2Video;
        //thrd->m_IsPaused = FALSE;
        thrd->AttachSession( leg1Video, leg2Video, leg1Call );
      }

      connection.StartVideoStream();
    }
  }

  return TRUE;
}










