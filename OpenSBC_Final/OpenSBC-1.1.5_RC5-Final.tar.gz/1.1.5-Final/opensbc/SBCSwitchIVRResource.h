/*
 *
 * SBCSwitchIVRResource.h
 *
 * Open SIP Stack ( OSS )
 *
 * Copyright (c) opensipstack.org.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either expressed or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is OpenSIPStack.
 *
 * The Initial Developer of the Original Code is opensipstack.org.
 *
 * The author of this code is Joegen E. Baclor
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * The OpenSIPStack Library includes some GPL/LGPL code libraries that MAY be 
 * enabled at compile time using the --enable-gpllibs configure switch.  If
 * enabled, the content of this file is published under the terms of GNU 
 * General Public License Version 2.  For a detailed list of the available
 * GPL code, see $(opensipstack)/gnu/README file.
 *
 * $Log: SBCSwitchIVRResource.h,v $
 * Revision 1.3  2009/06/27 03:18:45  joegenbaclor
 * fixed new line warnings in gcc
 *
 * Revision 1.2  2009/06/03 11:57:16  joegenbaclor
 * Checking in MOH feature
 *
 *
 */
#ifndef SBCSWITCHIVRRESOURCE_H
#define SBCSWITCHIVRRESOURCE_H
//////////////////////////////////////////////////////////////////

#include "ptlib.h"
#include "ptclib/url.h"
#include "OString.h"
using namespace Tools;

namespace SWITCH
{
  class SBCSwitchIVRChannel;
  class SBCSwitchIVRRecordable : public PObject
  {
    PCLASSINFO(SBCSwitchIVRRecordable, PObject);
    public:
      SBCSwitchIVRRecordable()
      { 
        m_ConsecutiveSilence = 0; 
        m_FinalSilence = 3000; 
        m_MaxDuration = 30000; 
      }

      virtual BOOL Open(const OString & _arg) = 0;

      virtual void Record(SBCSwitchIVRChannel & outgoingChannel) = 0;

      virtual void OnStart(){}

      virtual BOOL OnFrame(BOOL /*isSilence*/) { return FALSE; }

      virtual void OnStop(){}

      PINLINE void SetFinalSilence(unsigned v){ m_FinalSilence = v; }
      PINLINE unsigned GetFinalSilence(){ return m_FinalSilence; }
      PINLINE void SetMaxDuration(unsigned v){ m_MaxDuration = v; }
      PINLINE unsigned GetMaxDuration(){ return m_MaxDuration; }

    protected:
      PTime m_SilenceStart;
      PTime m_RecordStart;
      unsigned m_FinalSilence;
      unsigned m_MaxDuration;
      unsigned m_ConsecutiveSilence;
  };

  //////////////////////////////////////////////////////////////////

  class SBCSwitchIVRRecordableFilename : public SBCSwitchIVRRecordable
  {
    PCLASSINFO(SBCSwitchIVRRecordableFilename, SBCSwitchIVRRecordable);
    public:
      BOOL Open(const OString & _arg);
      void Record(SBCSwitchIVRChannel & incomingChannel);
      BOOL OnFrame(BOOL isSilence);

    protected:
      PFilePath m_Fn;
  };

  //////////////////////////////////////////////////////////////////

  class SBCSwitchIVRPlayable : public PObject
  {
    PCLASSINFO(SBCSwitchIVRPlayable, PObject);
    public:
      SBCSwitchIVRPlayable()
      { 
        m_Repeat = 1; 
        m_Delay = 0; 
        m_SampleFrequency = 8000; 
        m_AutoDelete = FALSE; 
        m_DelayDone = FALSE; 
      }

      virtual BOOL Open(
        SBCSwitchIVRChannel & /*chan*/, 
        PINDEX _delay, 
        PINDEX _repeat, 
        BOOL _autoDelete
      )
      { 
        m_Delay = _delay; 
        m_Repeat = _repeat; 
        m_AutoDelete = _autoDelete; 
        return TRUE; 
      }

      virtual BOOL Open(
        SBCSwitchIVRChannel & chan, 
        const OString & _arg, 
        PINDEX _delay, 
        PINDEX _repeat, 
        BOOL v
      )
      { 
        m_Arg = _arg; 
        return Open(chan, _delay, _repeat, v); 
      }

      virtual void Play(SBCSwitchIVRChannel & outgoingChannel) = 0;

      virtual void OnRepeat(SBCSwitchIVRChannel & /*outgoingChannel*/){}

      virtual void OnStart(){}

      virtual void OnStop(){}

      virtual void SetRepeat(PINDEX v){ m_Repeat = v; }

      virtual PINDEX GetRepeat() const{ return m_Repeat; }

      virtual PINDEX GetDelay() const{ return m_Delay; }

      

      virtual BOOL ReadFrame(SBCSwitchIVRChannel & channel, void * buf, PINDEX len);

      virtual BOOL Rewind(PChannel *){ return FALSE; }

      

      PINLINE void SetFormat(const OString & _fmt){ m_Format = _fmt; }
      PINLINE void SetSampleFrequency(unsigned _rate){ m_SampleFrequency = _rate; }
      PINLINE const OString & GetIdentifier()const{ return m_Identifier; };
      PINLINE void SetIdentifier( const OString & id ){ m_Identifier = id; };

    protected:
      OString m_Identifier;
      OString m_Arg;
      PINDEX m_Repeat;
      PINDEX m_Delay;
      OString m_Format;
      unsigned m_SampleFrequency;
      BOOL m_AutoDelete;
      BOOL m_DelayDone; // very tacky flag used to indicate when the post-play delay has been done
      friend class SBCSwitchIVRChannel;
  };

  //////////////////////////////////////////////////////////////////

  class SBCSwitchIVRPlayableURL : public SBCSwitchIVRPlayable
  {
    PCLASSINFO(SBCSwitchIVRPlayableURL, SBCSwitchIVRPlayable);
    public:
      BOOL Open(
        SBCSwitchIVRChannel & chan, 
        const OString & _url, 
        PINDEX _delay, 
        PINDEX _repeat, 
        BOOL v
      );
      
      void Play(
        SBCSwitchIVRChannel & 
        outgoingChannel
      );
    protected:
      PURL m_Url;
  };

  //////////////////////////////////////////////////////////////////

  class SBCSwitchIVRPlayableData : public SBCSwitchIVRPlayable
  {
    PCLASSINFO(SBCSwitchIVRPlayableData, SBCSwitchIVRPlayable);
    public:
      BOOL Open(SBCSwitchIVRChannel & chan, const OString & /*_fn*/, PINDEX _delay, PINDEX _repeat, BOOL v);
      void Play(SBCSwitchIVRChannel & outgoingChannel);
      BOOL Rewind(PChannel * chan);
      PINLINE void SetData(const PBYTEArray & _data){ m_Data = _data; };
    protected:
      PBYTEArray m_Data;
  };

  //////////////////////////////////////////////////////////////////


  class SBCSwitchIVRPlayableFilename : public SBCSwitchIVRPlayable
  {
    PCLASSINFO(SBCSwitchIVRPlayableFilename, SBCSwitchIVRPlayable);
    public:
      BOOL Open(SBCSwitchIVRChannel & chan, const OString & _fn, PINDEX _delay, PINDEX _repeat, BOOL _autoDelete);
      void Play(SBCSwitchIVRChannel & outgoingChannel);
      void OnStop();
      virtual BOOL Rewind(PChannel * chan);
    protected:
      PFilePath m_Fn;
  };

  //////////////////////////////////////////////////////////////////

  class SBCSwitchIVRPlayableFilenameList : public SBCSwitchIVRPlayable
  {
    PCLASSINFO(SBCSwitchIVRPlayableFilenameList, SBCSwitchIVRPlayable);
    public:
      BOOL Open(SBCSwitchIVRChannel & chan, const OStringArray & _filenames, PINDEX _delay, PINDEX _repeat, BOOL _autoDelete);
      void Play(SBCSwitchIVRChannel & outgoingChannel)
      { OnRepeat(outgoingChannel); }
      void OnRepeat(SBCSwitchIVRChannel & outgoingChannel);
      void OnStop();
    protected:
      PINDEX m_CurrentIndex;
      OStringArray m_Filenames;
  };

  

  //////////////////////////////////////////////////////////////////

  PQUEUE(SBCSwitchIVRQueue, SBCSwitchIVRPlayable);
}

#endif




