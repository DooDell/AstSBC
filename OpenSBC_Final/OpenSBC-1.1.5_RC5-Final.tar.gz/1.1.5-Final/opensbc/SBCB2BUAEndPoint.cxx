/*
 *
 * SBCB2BUAEndPoint.cxx
 *
 * Open SIP Stack ( OSS )
 *
 * Copyright (c) opensipstack.org.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either expressed or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is OpenSIPStack.
 *
 * The Initial Developer of the Original Code is opensipstack.org.
 *
 * The author of this code is Joegen E. Baclor
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * The OpenSIPStack Library includes some GPL/LGPL code libraries that MAY be 
 * enabled at compile time using the --enable-gpllibs configure switch.  If
 * enabled, the content of this file is published under the terms of GNU 
 * General Public License Version 2.  For a detailed list of the available
 * GPL code, see $(opensipstack)/gnu/README file.
 *
 * $Log: SBCB2BUAEndPoint.cxx,v $
 * Revision 1.33  2009/05/27 12:40:34  joegenbaclor
 * Initial upload of switch related classes
 *
 * Revision 1.32  2009/05/20 08:42:33  joegenbaclor
 * *** empty log message ***
 *
 * Revision 1.31  2009/04/25 05:22:20  joegenbaclor
 * Change FindOutboundProxy parameter to accept uri instead of the entire sip message
 *
 * Revision 1.30  2009/03/16 02:42:02  joegenbaclor
 * Disabled pikes until we make it configurable
 *
 * Revision 1.29  2009/02/14 06:49:38  joegenbaclor
 * Maximized use of time mutex for rtts session list mutual access
 *
 * Revision 1.28  2009/02/13 05:25:16  joegenbaclor
 * removed stateless 503 when rate limit is reached.  bad idea because the transaction may send a new response if a transaction is already active and the new invite is just a retransmission
 *
 * Revision 1.27  2009/02/12 02:36:04  joegenbaclor
 * More call rate sanity check
 *
 * Revision 1.26  2009/02/11 08:12:59  joegenbaclor
 * fixed misplaced mutex signal
 *
 * Revision 1.25  2009/02/11 07:38:08  joegenbaclor
 * Made cancerate sanity check higher.  Used PtimedMutex for deadlock check to avoid deadlocking on deadlock sanity checks!
 *
 * Revision 1.24  2009/02/10 08:16:09  joegenbaclor
 * Fixed HTTP Config crash
 *
 * Revision 1.23  2009/02/04 06:24:26  joegenbaclor
 * Minor bug fixes.  Added auto destruct timer to SoelgySession.  Added ability to disable local-reg and treat all regs as upper reg.
 *
 * Revision 1.22  2009/01/30 11:25:00  joegenbaclor
 * Marking opensipstack major revision concerning IST pending state
 *
 * Revision 1.21  2009/01/29 15:35:38  joegenbaclor
 * removed inbound packet mutex
 *
 * Revision 1.20  2009/01/29 13:25:25  joegenbaclor
 * Changed CANCEL rate from 5 to 30
 *
 * Revision 1.19  2009/01/29 13:15:14  joegenbaclor
 * Implemented new queue for commands comming from b2bua connection towrds the solegy client
 *
 * Revision 1.18  2009/01/29 05:59:01  joegenbaclor
 * Introduced yielding the transport when a certain queue size threshold is reached.
 *
 * Revision 1.17  2009/01/28 18:46:17  joegenbaclor
 * *** empty log message ***
 *
 * Revision 1.16  2009/01/28 05:45:21  joegenbaclor
 * Introduced new pikes for REGISTER, OPTIONS and NOTIFY
 *
 * Revision 1.15  2009/01/28 04:00:49  joegenbaclor
 * added CANCEL rate check
 *
 * Revision 1.14  2009/01/28 02:39:57  joegenbaclor
 * More work on deadlock detection
 *
 * Revision 1.13  2009/01/27 03:26:37  joegenbaclor
 * added deadlock reset mechanism on preconnect
 *
 * Revision 1.12  2009/01/27 02:20:47  joegenbaclor
 * more deadlock tweaks
 *
 * Revision 1.11  2009/01/25 07:49:23  joegenbaclor
 * init m_100TryingConsecutiveAttempts in constructor
 *
 * Revision 1.10  2009/01/25 07:34:57  joegenbaclor
 * More enhancement for last commit
 *
 * Revision 1.9  2009/01/25 07:24:23  joegenbaclor
 * Implemented new deadlock detection using 100 trying consecutive occurence
 *
 * Revision 1.8  2009/01/24 03:39:27  joegenbaclor
 * removed rate limit checking from transport layer.
 *
 * Revision 1.7  2009/01/23 11:14:13  joegenbaclor
 * Aded OnInboundPacket callback
 *
 * Revision 1.6  2009/01/21 10:01:56  joegenbaclor
 * Marking bug fix for solegy START race condition
 *
 * Revision 1.5  2008/12/01 03:52:14  joegenbaclor
 * Upper reg bug fixes
 *
 * Revision 1.4  2008/11/19 04:10:54  joegenbaclor
 * Bug:  Media server cals unable to properly route to media server listener ue to recent
 *  changes in outbound proxy handling
 *
 * Revision 1.3  2008/11/12 13:41:33  joegenbaclor
 * Bug:  We do not rewrite request-uri when using ob proxy routing
 *
 * Revision 1.2  2008/11/03 02:35:09  joegenbaclor
 * Introducing new a la B2BUA-Routes Outbound-Proxy routing and deprecated old global
 *  Outbound-Proxy parameter
 *
 * Revision 1.1  2008/10/27 09:44:04  joegenbaclor
 * Subclassing B2BUA objects to give OpenSBC a more fine grained control
 *
 *
 */

#include "SBCB2BUAEndPoint.h"
#include "SBCConnection.h"
#include "SBCInboundCall.h"
#include "SBCOutboundCall.h"
#include "OSSApplication.h"
#include "SBCConfigParams.h"
using namespace B2BUA;
using namespace Tools;

#define new PNEW 
#define CALL_RATE_TIMER_RESOLUTION 2

SBCB2BUAEndPoint::SBCB2BUAEndPoint(
  SIPUserAgent & ua,
  PINDEX sessionThreadCount,
  PINDEX stackSize
) : B2BUAEndPoint( ua, sessionThreadCount, stackSize )
{
  m_CurrentInviteCounter = 0;
  m_CurrentOutboundInviteCounter = 0;
  m_CurrentCancelCounter = 0;
  m_CurrentRegisterCounter = 0;
  m_CurrentNotifyCounter = 0;
  m_CallRateLimit = 10;
  m_DropInvites = FALSE;
  m_100TryingConsecutiveAttempts = 0;
}

SBCB2BUAEndPoint::~SBCB2BUAEndPoint()
{
}



B2BUAConnection * SBCB2BUAEndPoint::OnCreateB2BUA(
  const SIPMessage & /*request*/,
  const OString & _sessionId,
  B2BUACall * call
)
{
  OString sessionId = _sessionId + "-connection";
  SBCConnection * connection = new SBCConnection( *this, sessionId );
  B2BUserAgent& ua = dynamic_cast<B2BUserAgent&>(m_UserAgent);
  
  if( !ua.OnPostCreateB2BUA( this, connection,call ) )
  {
    delete connection;
    return NULL;
  }

  return connection;
}

CallSession * SBCB2BUAEndPoint::OnCreateServerCallSession(
  SIPMessage & request,
  const OString & sessionId
)
{
  if( !request.IsInvite() )
    return NULL;

  OString toTag = request.GetToTag();
  if( !toTag.IsEmpty() )
  {
    SIPMessage response;
    request.CreateResponse( response, SIPMessage::Code481_TransactionDoesNotExist, "None Existent Session" );
    SendRequest( response, NULL, request.GetTransaction() );
    return NULL;
  }

  /// incoming INVITE... create a session
  SBCInboundCall * call = new SBCInboundCall( *this, request, sessionId );
  call->SetLegIndex( 0 );
  B2BUAConnection * b2bua = CreateB2BUA( request, call );

  if( b2bua == NULL )
  { 
    /// this can only happen if the maximum connection  count has been reached
    SIPMessage response;
    request.CreateResponse( response, SIPMessage::Code500_InternalServerError, call->GetCallAnswerResponseWarning() );
    SendRequest( response, NULL, request.GetTransaction() );
    delete call;
    return NULL;
  }

  call->SetB2BUAConnection( b2bua );

  return call;
}

CallSession * SBCB2BUAEndPoint::OnCreateClientCallSession(
  const ProfileUA & profile,
  const OString & sessionId
)
{
  SBCOutboundCall * call = new SBCOutboundCall( *this, sessionId, profile );
  call->SetLegIndex( 1 );
  call->EnableSessionTimer( m_EnableSessionTimer );
  return call;
}


BOOL SBCB2BUAEndPoint::LoadOutboundProxies( OSSAppConfig & config )
{
  OStringArray proxies;
  for( PINDEX x = 0; x <  config.GetListSize( configKeyOutboundProxiesSection, configKeyOutboundProxies ); x++ )
    proxies.AppendString( config.GetListItem( configKeyOutboundProxiesSection, configKeyOutboundProxies, x ) );

  if( proxies.GetSize() > 0 )
    return m_OutboundProxies.Parse( proxies );

  return FALSE;
}

BOOL SBCB2BUAEndPoint::FindOutboundProxy( 
  const SIPURI & ruri, 
  RouteURI & routeURI 
)
{
  B2BUserAgent & b2bua = dynamic_cast<B2BUserAgent&>(GetUserAgent());
  

  /// Do not set an outbound proxy for call bound to the media server

  if( b2bua.GetMediaServer() != NULL )
  {
    if( b2bua.GetMediaServer()->GetListenerAddress() == ruri.GetAddress() && 
      b2bua.GetMediaServer()->GetListenerPort() == (WORD)ruri.GetPort().AsUnsigned() )
    {
      return FALSE;
    }
  }


  SIPURI route;
  BOOL ok = m_OutboundProxies.FindRoute( ruri, route );
  
  if( ok )
  {
    routeURI.SetLooseRouter( TRUE );
    route.SetUser("");
    routeURI.SetURI( route );
  }

  return ok;
}

BOOL SBCB2BUAEndPoint::OnOutboundPacket( 
  SIPTransportManager & transport, 
  SIPMessage & thePacket 
)
{
#if 0
  m_DropInvites = ++m_CurrentOutboundInviteCounter > 5;   
  VerifyDeadLock( transport, thePacket );
#endif
  return TRUE;
}

void SBCB2BUAEndPoint::DeadLockReset()
{
  if( !m_DeadLockMutex.Wait( 10 ) )
    return;
  m_100TryingConsecutiveAttempts = 0;
  m_DropInvites = FALSE;
  m_DeadLockMutex.Signal();
}

BOOL SBCB2BUAEndPoint::VerifyDeadLock( 
  SIPTransportManager & transport, 
  SIPMessage & thePacket 
)
{
  if( thePacket.IsResponse() && thePacket.GetCSeqMethod() == "INVITE" )
  {
    if( !m_DeadLockMutex.Wait( 10 ) )
      return TRUE;

    if( thePacket.GetStatusCode() == 100 )
      ++m_100TryingConsecutiveAttempts;
    else
      m_100TryingConsecutiveAttempts = 0;

    const PFilePath &appPath = OSSApplication::GetInstance()->GetFile();
    if( m_100TryingConsecutiveAttempts > 5 )
    {
      if( m_100TryingConsecutiveAttempts == 10 )
      {
        LOG( LogWarning(), "!!! OpenSBC is not responding to TEN consecutive INVITES on time !!!" );
      }else if( m_100TryingConsecutiveAttempts == 20 )
      {
        //// Really, really wake them up now
        LOG( LogWarning(), "!!! OpenSBC is not responding to TWENTY consecutive INVITES on time !!!" );
        //PSYSTEMLOG( StdError, "!!! 1st warning - OpenSBC is not responding to 20 consecutive INVITEs.  Please check the system. EXE=" 
        //  << appPath << " PID=" << OSSApplication::GetInstance()->GetProcessID() );
      }else if( m_100TryingConsecutiveAttempts == 50 )
      {
        //// Really, really wake them up now
        LOG( LogWarning(), "!!! OpenSBC is not responding to FIFTY consecutive INVITES on time !!!" );
        PSYSTEMLOG( StdError, "!!! 1st warning - OpenSBC is not responding to 50 consecutive INVITEs now.  Please check the system. EXE=" 
          << appPath << " PID=" << OSSApplication::GetInstance()->GetProcessID() );
      }else if( m_100TryingConsecutiveAttempts >= 100 )
      {
        //// Oops almost sure its a deadlock
        LOG( LogWarning(), "!!! OpenSBC is not responding to ONE HUNDRED consecutive INVITES on time !!!" );
        PSYSTEMLOG( StdError, "!!! 2nd warning - OpenSBC is not responding to 100 consecutive INVITEs now.  Please check the system. EXE=" 
          << appPath << " PID=" << OSSApplication::GetInstance()->GetProcessID() );
        m_DeadLockMutex.Signal();
        return FALSE;
      }else if( m_100TryingConsecutiveAttempts >= 200 )
      {
        //// Kaboom!
        LOG( LogError(), "!!! NO RESPONSE RATE IS TOO HIGH!  APPLICATION ABORTING WITH EXTREME PREJUDICE !!!" );
        PSYSTEMLOG( StdError, "NO RESPONSE RATE IS TOO HIGH!  APPLICATION ABORTING WITH EXTREME PREJUDICE !!! EXE=" 
          << appPath << " PID=" << OSSApplication::GetInstance()->GetProcessID() );
        m_DeadLockMutex.Signal();
        _exit(-1);
        return FALSE;
      }
    }
     m_DeadLockMutex.Signal();
  }
  
 
  return TRUE;
}

BOOL SBCB2BUAEndPoint::OnInboundPacket( 
  SIPTransportManager & transport, 
  SIPMessage & thePacket 
)
{ 
#if 0
  if( thePacket.IsCancel() && !CheckCancelRate( transport, thePacket ) )
    return FALSE;
  else if( thePacket.IsInvite() && !CheckCallRate( transport, thePacket ) )
    return FALSE;
  else if( thePacket.IsRegister() && !CheckRegisterRate( transport, thePacket ) )
    return FALSE;
  else if( thePacket.IsNotify() && !CheckNotifyRate( transport, thePacket ) )
    return FALSE;
  else if( thePacket.IsOptions() && !CheckOptionsRate( transport, thePacket ) )
    return FALSE;
#endif  
  return TRUE;
}

BOOL SBCB2BUAEndPoint::CheckCancelRate(
  SIPTransportManager & transport, 
  SIPMessage & thePacket 
)
{
  {
    /// lets check the health of the event queue
    RCLOCK();
    if( ResourceCounter::m_RC_EventQueue > 30 )
    {
      /// yield the event queue;
      return FALSE;
    }
  }

  int currentCount = ++m_CurrentCancelCounter;
  PInt64 lastReset = m_LastCancelCounterReset.GetTimestamp();
  PTime now;
  
  if( now.GetTimestamp() > lastReset + 1000000 ) // /// this is computed in microseconds
  {
    m_LastCancelCounterReset = now;
    m_CurrentCancelCounter = 0;
  }

  if( m_100TryingConsecutiveAttempts > 100 && currentCount > 20 ) /// 50 calls not answered, 20 calls cancelled.   definitely a deadlock
  {
    const PFilePath &appPath = OSSApplication::GetInstance()->GetFile();
    LOG( LogError(), "!!! NO RESPONSE RATE IS TOO HIGH!  APPLICATION ABORTING WITH EXTREME PREJUDICE !!!" );
    PSYSTEMLOG( StdError, "NO RESPONSE RATE IS TOO HIGH!  APPLICATION ABORTING WITH EXTREME PREJUDICE !!! EXE=" 
      << appPath << " PID=" << OSSApplication::GetInstance()->GetProcessID() );
    _exit(-1);
  }

  return currentCount <= 5;
}


BOOL SBCB2BUAEndPoint::CheckRegisterRate(
  SIPTransportManager & transport, 
  SIPMessage & thePacket 
)
{
  {
    /// lets check the health of the event queue
    RCLOCK();
    if( ResourceCounter::m_RC_EventQueue > 10 && 
        ResourceCounter::m_RC_EventQueue < 20 &&
        ResourceCounter::m_RC_EventQueue % 2 == 0 )
    {
      /// if more than 10, drop every other packets
      return FALSE;
    }else if( ResourceCounter::m_RC_EventQueue > 20 )
    {
      /// yield the event queue;
      return FALSE;
    }
  }

  int currentCount = ++m_CurrentRegisterCounter;
  PInt64 lastReset = m_LastRegisterCounterReset.GetTimestamp();
  PTime now;
  
  if( now.GetTimestamp() > lastReset + 1000000 ) // /// this is computed in microseconds
  {
    m_LastRegisterCounterReset = now;
    m_CurrentRegisterCounter = 0;
  }

  return currentCount <= 5;
}

BOOL SBCB2BUAEndPoint::CheckNotifyRate(
  SIPTransportManager & transport, 
  SIPMessage & thePacket 
)
{
  if( thePacket.GetToTag().IsEmpty() )
  {
    SIPMessage * stateLessResponse = new SIPMessage();
    thePacket.CreateResponse( *stateLessResponse, SIPMessage::Code200_Ok );
    const Via & via = thePacket.GetTopVia();

    if( via.IsBehindNAT() )
    {
      SIPURI srcURI;
      OString srcAddr( thePacket.GetSourceAddress().AsSTLString() );
      OString srcPort( thePacket.GetSourcePort() );
      srcURI.SetHost( srcAddr );
      srcURI.SetPort( srcPort );
      stateLessResponse->SetSendAddress(srcURI);
    }

    if( thePacket.IsEncrypted() )
      stateLessResponse->SetEncryption( TRUE );

    transport.ProcessOutbound( stateLessResponse );

    return FALSE;
  }

  {
    /// lets check the health of the event queue
    RCLOCK();
    if( ResourceCounter::m_RC_EventQueue > 10 && 
        ResourceCounter::m_RC_EventQueue < 20 &&
        ResourceCounter::m_RC_EventQueue % 2 == 0 )
    {
      /// if more than 10, drop every other packets
      return FALSE;
    }else if( ResourceCounter::m_RC_EventQueue > 20 )
    {
      /// yield the event queue;
      return FALSE;
    }
  }

  int currentCount = ++m_CurrentNotifyCounter;
  PInt64 lastReset = m_LastNotifyCounterReset.GetTimestamp();
  PTime now;
  
  if( now.GetTimestamp() > lastReset + 1000000 ) // /// this is computed in microseconds
  {
    m_LastNotifyCounterReset = now;
    m_CurrentNotifyCounter = 0;
  }

  return currentCount <= 5;
}

BOOL SBCB2BUAEndPoint::CheckOptionsRate(
  SIPTransportManager & transport, 
  SIPMessage & thePacket 
)
{
  if( thePacket.GetToTag().IsEmpty() )
  {
    SIPMessage * stateLessResponse = new SIPMessage();
    thePacket.CreateResponse( *stateLessResponse, SIPMessage::Code200_Ok );
    const Via & via = thePacket.GetTopVia();

    if( via.IsBehindNAT() )
    {
      SIPURI srcURI;
      OString srcAddress( thePacket.GetSourceAddress().AsSTLString() );
      OString srcPort( thePacket.GetSourcePort() );
      srcURI.SetHost(srcAddress);
      srcURI.SetPort(srcPort);
      stateLessResponse->SetSendAddress(srcURI);
    }

    if( thePacket.IsEncrypted() )
      stateLessResponse->SetEncryption( TRUE );

    OStringArray allowed;
    allowed.AppendString( "INVITE" );
    allowed.AppendString( "BYE" );
    allowed.AppendString( "ACK" );
    allowed.AppendString( "REFER" );
    allowed.AppendString( "MESSAGE" );
    allowed.AppendString( "INFO" );
    allowed.AppendString( "NOTIFY" );
    allowed.AppendString( "OPTIONS" );
    allowed.AppendString( "PRACK" );
    Allow allow( allowed );
    stateLessResponse->AppendAllow( allow );

    transport.ProcessOutbound( stateLessResponse );

    return FALSE;
  }

  {
    /// lets check the health of the event queue
    RCLOCK();
    if( ResourceCounter::m_RC_EventQueue > 10 && 
        ResourceCounter::m_RC_EventQueue < 20 &&
        ResourceCounter::m_RC_EventQueue % 2 == 0 )
    {
      /// if more than 10, drop every other packets
      return FALSE;
    }else if( ResourceCounter::m_RC_EventQueue > 20 )
    {
      /// yield the event queue;
      return FALSE;
    }
  }

  int currentCount = ++m_CurrentOptionsCounter;
  PInt64 lastReset = m_LastOptionsCounterReset.GetTimestamp();
  PTime now;
  
  if( now.GetTimestamp() > lastReset + 1000000 ) // /// this is computed in microseconds
  {
    m_LastOptionsCounterReset = now;
    m_CurrentOptionsCounter = 0;
  }

  return currentCount <= 5;
}

BOOL SBCB2BUAEndPoint::CheckCallRate( 
  SIPTransportManager & transport, 
  SIPMessage & thePacket 
)
{
  {
    /// lets check the health of the event queue
    RCLOCK();
    if( ResourceCounter::m_RC_EventQueue > 20 && 
        ResourceCounter::m_RC_EventQueue < 30 &&
        ResourceCounter::m_RC_EventQueue % 2 == 0 )
    {
      //PSYSTEMLOG( StdError, "COUNT=" << m_CurrentInviteCounter << " QUEUE=" <<  ResourceCounter::m_RC_EventQueue );
      /// if more than 5, drop every other packets
      return FALSE;
    }else if( ResourceCounter::m_RC_EventQueue > 30 )
    {
      //PSYSTEMLOG( StdError, "COUNT=" << m_CurrentInviteCounter << " QUEUE=" <<  ResourceCounter::m_RC_EventQueue );
      /// yield the event queue;
      return FALSE;
    }
  }

  int currentCount = ++m_CurrentInviteCounter;
  PInt64 lastReset = m_LastInviteCounterReset.GetTimestamp();
  PTime now;
  if( now.GetTimestamp() > lastReset + 1000000 ) /// this is computed in microseconds
  {
    m_LastInviteCounterReset = now;
    m_CurrentInviteCounter = 0;
    m_CurrentOutboundInviteCounter = 0;
    m_DropInvites = FALSE;
  }

  if( m_DropInvites == TRUE )
    return FALSE;
  
  if( currentCount >= 100 )  // 100 CPS.  This is insanely high  
  {
    PSYSTEMLOG( StdError, "COUNT=" << currentCount << " INVITE rate is too high HIGH! Please check appication status." );
  }

  return currentCount < m_CallRateLimit; 
}



