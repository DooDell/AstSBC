/*
 *
 * SBCSIPTrunkReg.cxx
 *
 * Open SIP Stack ( OSS )
 *
 * Copyright (c) opensipstack.org.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either expressed or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is OpenSIPStack.
 *
 * The Initial Developer of the Original Code is opensipstack.org.
 *
 * The author of this code is Joegen E. Baclor
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * The OpenSIPStack Library includes some GPL/LGPL code libraries that MAY be 
 * enabled at compile time using the --enable-gpllibs configure switch.  If
 * enabled, the content of this file is published under the terms of GNU 
 * General Public License Version 2.  For a detailed list of the available
 * GPL code, see $(opensipstack)/gnu/README file.
 *
 * $Log: SBCSIPTrunkReg.cxx,v $
 * Revision 1.12  2009/06/01 03:16:55  joegenbaclor
 * Added outbound call class for sip trunks
 *
 * Revision 1.11  2008/11/25 01:45:24  joegenbaclor
 * Added send-reg attribute to disable sending registration to trunk provider which does
 *  not require it
 *
 * Revision 1.10  2008/11/20 11:02:35  joegenbaclor
 * Depcrecated old SIPMessage URI accessors
 *
 * Revision 1.9  2007/10/17 03:17:39  joegenbaclor
 * More work on sip trunks
 *
 * Revision 1.8  2007/10/02 16:42:56  joegenbaclor
 * Marking initial release of SIP Trunking
 *
 * Revision 1.7  2007/09/12 10:36:15  joegenbaclor
 * Corrected compile errors in linux
 *
 * Revision 1.6  2007/09/12 10:09:39  joegenbaclor
 * Trunks can now send registrations
 *
 * Revision 1.5  2007/09/11 14:29:05  joegenbaclor
 * More trunking work
 *
 * Revision 1.4  2007/09/11 02:31:53  joegenbaclor
 * More work on trunks
 *
 * Revision 1.3  2007/09/04 22:45:31  joegenbaclor
 * Corrected typos
 *
 * Revision 1.2  2007/09/04 21:58:13  joegenbaclor
 * More work on SIP Trunks.
 *
 * Revision 1.1  2007/08/30 03:21:45  joegenbaclor
 * Added SIP Trunk Classes
 *
 *
 */

#include "SBCSIPTrunkReg.h"
#include "SBCSIPTrunkRegSession.h"

#define new PNEW

///////////////////////////////////////////////////////////////////////////////////

SBCSIPTrunkReg::SBCSIPTrunkReg(
  SBCSIPTrunkConfig * config,
  SIPUserAgent & trunk,
  PINDEX sessionThreadCount,
  PINDEX stackSize
) : RegisterSessionManager( trunk, sessionThreadCount, stackSize )
{
  m_Config = NULL;
  OnConfigChanged( config );
  m_TrunkAccounts.DisallowDeleteObjects();
}

SBCSIPTrunkReg::~SBCSIPTrunkReg()
{
  if( m_Config != NULL )
    delete m_Config;

  m_TrunkAccounts.AllowDeleteObjects();
}

void SBCSIPTrunkReg::OnConfigChanged(
  SBCSIPTrunkConfig * config
)
{
  PWaitAndSignal lock( m_ConfigMutex );
  if( m_Config != NULL )
    delete m_Config;

  m_Config = config;

  m_TrunkName = m_Config->GetTrunkName();
  m_TrunkRouteSet = m_Config->GetRouteSet().Tokenise( ",", FALSE );
  m_TrunkDomain = m_Config->GetDomain();
  m_TrunkType = m_Config->GetTrunkType();
  m_TrunkDescription = m_Config->GetTrunkDescription();
  m_TrunkExpires = m_Config->GetExpires();

  PWaitAndSignal lockAccounts( m_TrunkAccountsMutex );
  for( PINDEX i = 0; i < m_Config->GetSize(); i++ )
  {
    SBCSIPTrunkAccountConfig & account = (*m_Config)[i];
    AddTrunkAccount( account );
  }

  /// remove deleted accounts
  OStringArray accountsToRemove;
  for( PINDEX j = 0; j < m_TrunkAccounts.GetSize(); j++ )
  {
    OString user = m_TrunkAccounts.GetDataAt(j).GetUserName();
    ///check if this user is in the current configured account
    BOOL found = FALSE;
    for( PINDEX x = 0; x < m_Config->GetSize(); x++ )
    {
      if( user *= (*m_Config)[x].GetUser() )
      {
        found = TRUE;
        break;
      }
    }
    
    if( !found )
      accountsToRemove.AppendString( user );
  }

  for( PINDEX z = 0; z < accountsToRemove.GetSize(); z++ )
    RemoveTrunkAccount( accountsToRemove[z].c_str() );
}

BOOL SBCSIPTrunkReg::AddTrunkAccount(
  const SBCSIPTrunkAccount & account
)
{
  PWaitAndSignal lock( m_TrunkAccountsMutex );
  if( account.GetUserName().IsEmpty() )
    return FALSE;

  if( HasTrunkAccount( account.GetUserName().c_str() ) )
    return FALSE;

  OnAddTrunkAccount( account );

  return m_TrunkAccounts.SetAt( account.GetUserName().c_str(), new SBCSIPTrunkAccount( account ) );
}

BOOL SBCSIPTrunkReg::RemoveTrunkAccount(
  const char * userName
)
{
  PWaitAndSignal lock( m_TrunkAccountsMutex );

  if( userName == NULL )
    return FALSE;

  SBCSIPTrunkAccount * acct = m_TrunkAccounts.RemoveAt( userName );
  if( acct == NULL )
    return FALSE;

  OnRemoveTrunkAccount( *acct );

  delete acct;

  return TRUE;
}

void SBCSIPTrunkReg::OnAddTrunkAccount(
  const SBCSIPTrunkAccount & account
)
{
  ProfileRegister profile;
  long expires = account.GetExpires();
  if( expires == 0 )
    expires = GetTrunkExpires();

  profile.SetExpireInterval( expires );
  profile.SetUser( account.GetUserName().c_str() );
  profile.SetAccount( account.GetAuthUser().c_str() );
  profile.SetPassword( account.GetPassword().c_str() );
  
  if( GetTrunkRouteSet().GetSize() >= 1 )
    profile.SetServerAddress( GetTrunkRouteSet()[0] );
  else if( !GetTrunkDomain().IsEmpty() )
    profile.SetServerAddress( GetTrunkDomain() );
  else
    return;

  profile.SetDomain( GetTrunkDomain() );

  /// Create our contact URI
  PIPSocket::Address contactAddress;
  WORD contactPort;
  PIPSocket::Address targetAddress;
  WORD targetPort;
  SIPURI serverURI( profile.GetServerAddress() );
  if( !SIPTransport::Resolve( serverURI, targetAddress, targetPort ) )
  {
    PTRACE( 1, "*** SBCSIPTrunkReg::OnAddTrunkAccount *** Unable to resolve address " << serverURI );
    return;
  }

  SIPTransportManager * transport = this->GetUserAgent().GetStack().GetTransportManager();
  
  if( !transport->GetListenerAddress( SIPTransport::UDP, targetAddress, contactAddress, contactPort ) )
  {
    PTRACE( 1, "*** SBCSIPTrunkReg::OnAddTrunkAccount *** Unable to get NIC address for " << serverURI );
    return;
  }
  
  OStringStream contact;
  contact << "sip:" << profile.GetUser() << "@" << contactAddress << ":" << contactPort;
  profile.AppendContact( contact.str() );

  OStringStream sessionId;
  sessionId << "REGISTER-" << profile.GetUser() << ":" << profile.GetAccount() << "@" << profile.GetDomain();

  SIPSession::GCRef autoRef( "SBCSIPTrunkReg::OnAddTrunkAccount" );
  RegisterSession * oldSession = FindGCRefBySessionId<RegisterSession>( sessionId.str(), autoRef );
  
  if(  oldSession != NULL )
    oldSession->Destroy();
 
  ProfileUA uaProfile;
  uaProfile.GetRegistrationProfile() = profile;
  uaProfile.SetUser( profile.GetUser() );
  uaProfile.GetProxyProfile().SetUser( profile.GetUser() );
  uaProfile.GetProxyProfile().SetAccount( profile.GetAccount() );
  uaProfile.GetProxyProfile().SetPassword( profile.GetPassword() );
  uaProfile.GetProxyProfile().SetServerAddress( profile.GetServerAddress() );

  SBCSIPTrunkRegSession * regSession = dynamic_cast<SBCSIPTrunkRegSession *>( CreateClientSession( uaProfile, sessionId.str() ) );
 
  if( regSession != NULL && account.WillSendReg() )
    regSession->StartAutoRegTimer( 5 );
#if 0
  ProfileRegister & profile = GetProfile().GetRegistrationProfile();
  profile.SetUser( (const char *)userName );
  profile.SetAccount( (const char *)userName );
  profile.SetPassword( (const char *)password );
  profile.SetServerAddress( (const char *)uri );

  OString domain = _domain;
  SIPURI serverURI( (const char *)uri );
  if( domain.IsEmpty() )
    domain = serverURI.GetHost();
  
  if( profile.GetContactSize() == 0 )
  {

    PIPSocket::Address contactAddress;
    WORD contactPort;
    PIPSocket::Address targetAddress;
    WORD targetPort;

    if( !SIPTransport::Resolve( serverURI, targetAddress, targetPort ) )
      return FALSE;

    SIPTransportManager * transport = m_OSSUserAgent->GetStack().GetTransportManager();
    
    if( !transport->GetListenerAddress( SIPTransport::UDP, targetAddress, contactAddress, contactPort ) )
      return FALSE;

    OStringStream contact;
    contact << contactAddress << ":" << contactPort;

    profile.AppendContact( contact.str() );
  }

  OStringStream sessionId;
  sessionId << "REGISTER-" << userName << "@" << domain;

  /// destroy the old session if it exists
  SIPSession::GCRef autoRef( "OpalOSSEndPoint::SendRegister" );
  RegisterSession * oldSession = 
    m_OSSUserAgent->GetRegistrar()->FindGCRefBySessionId<RegisterSession>( sessionId.str(), autoRef );
  
  if(  oldSession != NULL )
    oldSession->Destroy();

  GetProfile().GetRegistrationProfile().SetExpireInterval( m_RegisterExpires.GetSeconds() );
  
  RegisterSession * regSession = (RegisterSession*)m_OSSUserAgent->GetRegistrar()->CreateClientSession( GetProfile(), sessionId.str() );

  if( regSession != NULL )
  {
    regSession->SendRegister();
    if( synchronous )
      return m_RegMutex.Wait( OPAL_REGISTRAR_TIMEOUT );  
    return TRUE;
  }

  return FALSE;
#endif
}

void SBCSIPTrunkReg::OnRemoveTrunkAccount(
  const SBCSIPTrunkAccount & /*account*/
)
{
}

BOOL SBCSIPTrunkReg::FindTrunkAccount(
  SBCSIPTrunkAccount & account
)const
{
  PWaitAndSignal lock( m_TrunkAccountsMutex );
  if( account.GetUserName().IsEmpty() )
    return FALSE;
  SBCSIPTrunkAccount * a = m_TrunkAccounts.GetAt( account.GetUserName().c_str() );
  if( a == NULL )
    return FALSE;

  account = *a;
  return TRUE;
}

BOOL SBCSIPTrunkReg::GetIngressRoute(
  const SIPMessage & msg,
  SIPURI & inboundRoute
)
{
  PWaitAndSignal lock( m_TrunkAccountsMutex );
  OString user = msg.GetToURI().GetUser();
  SBCSIPTrunkAccount * account = m_TrunkAccounts.GetAt( user.c_str() );
  if( account == NULL )
    return FALSE;

  inboundRoute = SIPURI( account->GetInboundRoute() );
  return TRUE;
}

BOOL SBCSIPTrunkReg::GetEgressAuthInfo(
  const SIPMessage & msg,
  OString & userName,
  OString & authUser,
  OString & password
)
{
  PWaitAndSignal lock( m_TrunkAccountsMutex );
  const SIPURI & fromURI = msg.GetFromURI();
  /// check if have a match using inbound identity
  for( PINDEX i = 0; i < m_TrunkAccounts.GetSize(); i++ )
  {
    SBCSIPTrunkAccount & account = m_TrunkAccounts.GetDataAt( i );
    SIPURI inboundIndentity( account.GetInboundRoute() );
    if( inboundIndentity.GetUser() *= fromURI.GetUser() )
    {
      if( inboundIndentity.GetHost() *= fromURI.GetHost() )
      {
        userName = account.GetUserName();
        authUser = account.GetAuthUser();
        password = account.GetPassword();
        PTRACE( 1, "*** TRUNK ACCOUNT FOUND (STATIC) *** auth-user=" << authUser << " uri=" << msg.GetFromURI() );
        return TRUE;
      }
    }
  }

  /// we got no hit using inbound identity
  /// check real domain

  if( m_TrunkDomain *= fromURI.GetHost() )
  {
    for( PINDEX i = 0; i < m_TrunkAccounts.GetSize(); i++ )
    {
      SBCSIPTrunkAccount & account = m_TrunkAccounts.GetDataAt( i );
      SIPURI inboundIndentity( account.GetInboundRoute() );
      if( account.GetUserName() *= fromURI.GetUser() )
      {
        userName = account.GetUserName();
        authUser = account.GetAuthUser();
        password = account.GetPassword();
        PTRACE( 1, "*** TRUNK ACCOUNT FOUND (STATIC-EXTERNAL) *** auth-user=" << authUser << " uri=" << msg.GetFromURI() );
        return TRUE;
      }
    }
  }

  

  const SBCSIPTrunkAccountConfig * transient = m_Config->GetActiveTransientAccount();
  if( transient != NULL )
  {
    
    userName = transient->GetUser();
    authUser = transient->GetAuthUser();
    password = transient->GetPassword();
    PTRACE( 1, "*** TRUNK ACCOUNT FOUND (TRANSIENT) *** auth-user=" << authUser << " uri=" << msg.GetFromURI() );
    return TRUE;
  }
  
  PTRACE( 1, "*** NO SIP TRUNK ACCOUNT FOUND *** uri=" << msg.GetFromURI() );

  return FALSE;

}

BOOL SBCSIPTrunkReg::HasTrunkAccount( const char * user )const
{
  PWaitAndSignal lock( m_TrunkAccountsMutex );
  return m_TrunkAccounts.Contains( user );
}

BOOL SBCSIPTrunkReg::OnRequestA1Hash(
  const SIPURI & /*userURL*/,
  OString & /*a1*/,
  RegisterSession & /*session*/
)
{
  return FALSE;
}

/// returns a new Client RegisterSession.  Users may override this function
  /// to return their own implementation of the RegisterSession object
SIPSession * SBCSIPTrunkReg::OnCreateClientSession(
  const ProfileUA & profile,
  const OString & sessionId
)
{
  return new SBCSIPTrunkRegSession( *this, profile, sessionId );
}

//////////////////////////////////////////////////////////////////








