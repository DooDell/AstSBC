#include <ptlib.h>
#include "SBCSNMPHandler.h"
#include "SBCScriptHandler.h"

#if HAS_PYTHON_SAPI

class SNMPThread : PThread
{
  PCLASSINFO( SNMPThread, PThread );
public:
  SNMPThread( SBCSNMPHandler * snmp ) : PThread( 1024 * 10 )
  {
    m_Handler = snmp;
    Resume();
  }

  void Main()
  {
    PYTHON::PythonVariantMap in, out;
    m_Handler->m_Script->PythonEvaluate( "run_snmp", in, out );
  }

  SBCSNMPHandler * m_Handler;
};

SBCSNMPHandler::SBCSNMPHandler( SBCScriptHandler * scripHandler )
{
  m_LastTotalConnection = 0;
  m_LastTotalSeizure = 0;
  m_LastTotalFailures = 0;

  m_Timer.SetNotifier( PCREATE_NOTIFIER( OnTimer ) );
  m_Timer.RunContinuous( PTimeInterval( 60000 ) );

  m_Script = scripHandler;
  new SNMPThread( this );
}

PTimeInterval SNMPApplicationUpTime = PTimer::Tick();

int SBCSNMPHandler::OnSNMPGetInt( 
  const std::string & oid
)
{
  size_t pos = oid.rfind( "." );
  if( pos == std::string::npos )
    return -1;

  std::string element_id = std::string(oid.c_str(), pos, std::string::npos);
  RCLOCK();
  if( element_id == ".4" )
  {
    return ResourceCounter::m_RC_Registration;
  } else if( element_id == ".5" )
  {
    return ResourceCounter::m_RC_TotalRegistration;
  } else if( element_id == ".6" )
  {
    return ResourceCounter::m_RC_Connection;
  } else if( element_id == ".7" )
  {
    return ResourceCounter::m_RC_TotalConnection;
  } else if( element_id == ".8" )
  {
    PWaitAndSignal scopedLock( m_Mutex );
    return (ResourceCounter::m_RC_TotalConnection - m_LastTotalConnection);
  } else if( element_id == ".9" )
  {
    return ResourceCounter::m_RC_TotalSeizure;
  } else if( element_id == ".10" )
  {
    PWaitAndSignal scopedLock( m_Mutex );
    return (ResourceCounter::m_RC_TotalSeizure - m_LastTotalSeizure);
  } else if( element_id == ".11" )
  {
    PWaitAndSignal scopedLock( m_Mutex );
    unsigned long connectionRate = 
      (ResourceCounter::m_RC_TotalConnection - m_LastTotalConnection);
    unsigned long seizureRate = 
      (ResourceCounter::m_RC_TotalSeizure - m_LastTotalSeizure);

    if ( connectionRate == 0 ) 
      return 100; 
    unsigned long connectionRatio = (unsigned long)( ( (double)seizureRate / connectionRate ) * 100 ); 
    if ( connectionRatio > 100 ) 
      return 100; 
    return connectionRatio;
  } else if( element_id == ".12" )
  {
    return ResourceCounter::m_RC_FailedConnection;
  } else if( element_id == ".13" )
  {
    PWaitAndSignal scopedLock( m_Mutex );
    return (ResourceCounter::m_RC_FailedConnection - m_LastTotalFailures);
  } else if( element_id == ".14" )
  {
    PWaitAndSignal scopedLock( m_Mutex );
    unsigned long connectionRate = 
      (ResourceCounter::m_RC_TotalConnection - m_LastTotalConnection);
    unsigned long failureRate = 
      (ResourceCounter::m_RC_FailedConnection - m_LastTotalFailures);

    if ( connectionRate == 0 ) 
      return 100; 
    unsigned long failureRatio = (unsigned long)( ( (double)failureRate / connectionRate ) * 100 ); 
    if ( failureRatio > 100 ) 
      return 100; 
    return failureRatio;
  } else if( element_id == ".15" )
  {
    return (PTimer::Tick().GetSeconds() - ResourceCounter::m_RC_LastConnectionTime);
  } else if( element_id == ".16" )
  {
    return (PTimer::Tick().GetSeconds() - SNMPApplicationUpTime.GetSeconds() );
  } else if( element_id == ".17" )
  {
    return ResourceCounter::m_RC_AverageCallDuration;
  } else if( element_id == ".18" )
  {
    return ResourceCounter::m_RC_HighestCallDuration;
  }

  return -1;
}

void SBCSNMPHandler::OnTimer( 
  PTimer&,
  INT
)
{
  PWaitAndSignal scopedLock( m_Mutex );

  // get the last total connection, seizure and failure for computint
  // their ratio and rates
  m_LastTotalConnection = ResourceCounter::m_RC_TotalConnection;
  m_LastTotalSeizure = ResourceCounter::m_RC_TotalSeizure;
  m_LastTotalFailures = ResourceCounter::m_RC_FailedConnection;
}

#endif



