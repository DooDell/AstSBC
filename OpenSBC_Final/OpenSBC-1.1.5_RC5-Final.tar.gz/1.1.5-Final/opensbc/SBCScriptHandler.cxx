

#include "SBCScriptHandler.h"
#include "SBCSNMPHandler.h"

#if HAS_PYTHON_SAPI

using namespace PYTHON;

char * py_argv[2] = {"OpenSBC", NULL };
SBCScriptHandler::SBCScriptHandler(
  OpenSBC & b2bua
) : PYTHON::PythonScript( 1,  py_argv ),
    m_B2BUA( b2bua )
{
  m_SNMP = NULL;
  m_Initialize = FALSE;
}

SBCScriptHandler::~SBCScriptHandler()
{
  if( m_SNMP == NULL )
    delete m_SNMP;
}

bool SBCScriptHandler::Intialize()
{
  if( m_Initialize )
    return true;

  m_Initialize = TRUE;

  LoadScript( "oss_modules" );
  PythonVariantMap in, out;
  bool ok = PythonEvaluate( "init_modules", in, out );

  if( ok && m_SNMP == NULL )
  {
    m_SNMP = new SBCSNMPHandler( this );
  }

  return ok;
}

bool SBCScriptHandler::OnCPPEvaluate(
  const std::string & funcName,
  PythonVariantMap & in,
  PythonVariantMap & out 
)
{
  if( funcName == "init_modules" )
  {
    PTRACE( 1, "*** PYTHON *** Python Scripting Engine Initialized"  );
    return true;
  }else if( funcName == "snmp.log" )
  {
    if( in.size() > 0 && in.begin()->second.is_type<std::string>())
    {
      std::string trace = in.begin()->second.str();
      PTRACE( 1, "*** SNMP *** " << trace );
    }
    return true;
  }else if( funcName == "snmp.get" )
  {
    if( in.size() > 0 && in.begin()->second.is_type<std::string>() )
    {
      std::string oid = in.begin()->second.str();
      std::string value;
      out[oid] = m_SNMP->OnSNMPGetInt( oid );
    }
    return true;
  }

  return false;
}

#endif





