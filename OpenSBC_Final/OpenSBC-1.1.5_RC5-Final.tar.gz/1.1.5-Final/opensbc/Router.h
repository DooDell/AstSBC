/*
 *
 * Router.h
 *
 * Open SIP Stack ( OSS )
 *
 * Copyright (c) opensipstack.org.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either expressed or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is OpenSIPStack.
 *
 * The Initial Developer of the Original Code is opensipstack.org.
 *
 * The author of this code is Joegen E. Baclor
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * The OpenSIPStack Library includes some GPL/LGPL code libraries that MAY be 
 * enabled at compile time using the --enable-gpllibs configure switch.  If
 * enabled, the content of this file is published under the terms of GNU 
 * General Public License Version 2.  For a detailed list of the available
 * GPL code, see $(opensipstack)/gnu/README file.
 *
 * $Log: Router.h,v $
 * Revision 1.22  2009/05/15 00:23:34  joegenbaclor
 * Corrected bug in enum lookup where enum: scheme is included in dns query.
 *
 * Revision 1.21  2009/05/05 11:37:58  joegenbaclor
 * updated deprecated functions used by xbase
 * updated MSVC 2005 Project files to include XBase classes
 *
 * Revision 1.20  2009/02/03 05:12:10  joegenbaclor
 * Minor tweaks
 *
 * Revision 1.19  2008/09/01 14:44:29  joegenbaclor
 * Commiting interim code for new registrar with SLA support
 *
 * Revision 1.18  2008/02/21 10:18:24  rcolobong
 * Handle multiple routes in ENUMLookup
 *
 * Revision 1.17  2007/11/20 07:06:50  joegenbaclor
 * Added support for Request-URI routing
 *
 * Revision 1.16  2007/09/19 13:08:29  joegenbaclor
 * Added ability to laod route from external xml file
 *
 * Revision 1.15  2007/07/15 12:27:26  joegenbaclor
 * Added capability to route to registered endpoints using static routes
 * Removed unused config parameters
 *
 * Revision 1.14  2007/07/14 07:53:56  joegenbaclor
 * Migrated code to use new STL based string class
 *
 * Revision 1.13  2007/07/07 15:21:17  joegenbaclor
 * Added iproute2 support for linux
 *
 * Revision 1.12  2007/07/06 14:16:36  rcolobong
 * 1. Route by primary codec
 * 2. Support Upstream proxy routing
 *
 * Revision 1.11  2007/06/18 15:30:45  joegenbaclor
 * Implemented Internal DNS Mapping
 *
 * Revision 1.10  2007/06/17 02:49:31  joegenbaclor
 * Introduced Global lock to PHTTPConfig
 *
 * Revision 1.9  2007/06/13 09:22:01  joegenbaclor
 * Added IVR handler
 *
 * Revision 1.8  2007/05/29 17:43:23  joegenbaclor
 * Initial work on auto attendant
 *
 * Revision 1.7  2007/05/14 06:24:40  joegenbaclor
 * Added DNS Failover and ICMP validation
 *
 * Revision 1.6  2007/04/03 04:38:19  joegenbaclor
 * Made sure CALL_TRANSFER_PREFIX is stripped when routing through local registration database
 *
 * Revision 1.5  2007/01/22 10:00:58  joegenbaclor
 * Fixed ProxyRouteRequest
 *
 * Revision 1.4  2007/01/17 00:08:50  joegenbaclor
 * Added SysLog
 *
 * Revision 1.3  2006/11/22 11:33:25  rcolobong
 * 1. Change method FindRoute to HasScheme
 * 2. Fix problem where it "Rounds Robin" in HasScheme method
 *
 * Revision 1.2  2006/10/11 05:04:50  rcolobong
 * Add new method FindRoute where it will search in "OpenSBC Route" based on scheme
 *
 * Revision 1.1  2006/08/14 10:04:59  rcolobong
 * Convert B2BUA to SBC
 * Support MP logging
 *
 * Revision 1.4  2006/08/04 05:14:03  rcolobong
 * 1.  Add getter for Routes
 * 2.  Add support for RTBE Scheme in FindRoute
 *
 * Revision 1.3  2006/07/17 11:36:44  joegenbaclor
 * 1.  More routing enhancements to B2BUA
 *
 * Revision 1.2  2006/07/13 06:53:03  joegenbaclor
 * 1.  Introduced Sanity checks for incoming SIP Message
 * 2.  Corrected bug in SIPURI where enum scheme is not getting recognized.
 * 3.  Added ENUM support to routing
 * 4.  Introduced global routing flag to indicate when and not to rewrite outbound To URI's
 *
 * Revision 1.1  2006/06/20 09:58:11  joegenbaclor
 * *** empty log message ***
 *
 * Revision 1.1  2006/05/17 04:04:48  joegenbaclor
 * Initial upload of OpenSBC files
 *
 *
 */

#ifndef ROUTER_H
#define ROUTER_H

#include "RouteRecord.h"
#include "SIPMessage.h"
#include "B2BUAConnection.h"
#include "RegisterSessionManager.h"
#include "SIPTransportManager.h"
#include "Registrar.h"
#include "SBCXBaseManager.h"

using namespace SIPParser;
using namespace B2BUA;
using namespace UACORE;
using namespace SIPTransports;

class Router : public PObject, public Logger
{
  PCLASSINFO( Router, PObject );

  PLIST( Routes, RouteRecord );
public:

  Router();

  Router( 
    const PXML & routes
  );

  Router( 
    const OStringArray & routes
  );

  Router & operator=( 
    const PXML & routes
  );

  Router & operator=( 
    const OStringArray & routes
  );

  BOOL Parse( 
    const OStringArray & routes
  );

  BOOL Parse( 
    const PXML & routes
  );

  BOOL FindRoute(
    SIPTransportManager & transportManager,
    REGISTRAR::Registrar & regDb,
    const SIPMessage & request,
    B2BUAConnection & connection,
    BOOL useRequestURI = TRUE
#ifdef HAS_XBASE
    , SBCXBaseManager * xbase = NULL
#endif
  );

  BOOL FindRoute(
    const SIPMessage & request,
    SIPURI & target,
    BOOL incrementCurrentRoute = TRUE,
    BOOL compareMethods = FALSE,
    BOOL useRequestURI = TRUE
  );

  BOOL FindRoute( 
    const SIPURI & uri,
    SIPURI & target
  );

  BOOL HasRoute( 
    SIPURI & uri
  );

  BOOL HasScheme(
    const SIPMessage & request,
    const OString & scheme
  );

  BOOL AppendRoute(
    const OString & route
  );

  PINLINE void SetICMPValidate( BOOL validate ){ m_ICMPValidate = validate; };
  PINLINE BOOL WillValidateICMP()const{ return m_ICMPValidate; };
  PINLINE void SetIVRRoute( const SIPURI route ){ m_IVRRoute = route; };
  PINLINE const SIPURI & GetIVRRoute()const{ return m_IVRRoute; };

  PINLINE void EnableMaskTargetURI( BOOL enable = TRUE ) { m_MaskTargetURI = enable; }
  PINLINE void DisableMaskTargetURI() { m_MaskTargetURI = FALSE; }

private:
  BOOL AddConnectionRoute(
    SIPTransportManager & transportManager,
    REGISTRAR::Registrar & regDb,
    const SIPURI & requestURI,
    const SIPURI & routeURI,
    B2BUAConnection & connection
#ifdef HAS_XBASE
    , SBCXBaseManager * xbase = NULL
#endif
  );

protected:
  PMutex m_RoutesMutex;
  Routes m_Routes;
  BOOL m_ICMPValidate;
  BOOL m_MaskTargetURI;
  SIPURI m_IVRRoute;
};
    

#endif






