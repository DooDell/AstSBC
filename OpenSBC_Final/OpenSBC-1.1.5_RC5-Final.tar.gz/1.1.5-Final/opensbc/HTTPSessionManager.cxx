#include "HTTPSessionManager.h"
#include "HTTPSession.h"
#include "OpenSBC.h"

#define new PNEW

HTTPSessionManager::HTTPSessionManager()
{
}

BOOL HTTPSessionManager::Initialize( OpenSBC * sbc )
{
  m_SBC = sbc;
  return TRUE;
}

BOOL HTTPSessionManager::CreateHTTPSession( 
  B2BUAConnection & connection, 
  const SIPURI & httpServer )
{
  HTTPSession * session = new HTTPSession( this, &connection );
  
  session->m_URLAuthResource = PString( httpServer.AsString().c_str() ) + "/" + PString( "auth.php" );
  session->m_URLSetupResource = PString( httpServer.AsString().c_str() ) + "/" + PString( "setup.php" );
  session->m_URLCallStartResource = PString( httpServer.AsString().c_str() ) + "/" + PString( "callstart.php" );
  session->m_URLCallStopResource = PString( httpServer.AsString().c_str() ) + "/" + PString( "callstop.php" );
  session->m_URLIVRResource = PString( httpServer.AsString().c_str() ) + "/" + PString( "ivr.php" );
  
  connection.AttachCallController( session, TRUE );
  return TRUE;
}













































































