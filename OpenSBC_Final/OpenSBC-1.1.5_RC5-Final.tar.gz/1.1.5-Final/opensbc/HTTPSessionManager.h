#ifndef HTTPSESSIONMANAGER_H
#define HTTPSESSIONMANAGER_H

#include <ptlib.h>
#include "B2BUAConnection.h"
#include "HTTPSession.h"


using namespace B2BUA;

class OpenSBC;

class HTTPSessionManager : public PObject
{
  PCLASSINFO( HTTPSessionManager, PObject );
public:
  HTTPSessionManager();

  BOOL Initialize( OpenSBC * sbc );
  
  BOOL CreateHTTPSession( B2BUAConnection & connection, const SIPURI & httpServer );
  OpenSBC * GetSBC() const{ return m_SBC; };
  OpenSBC * m_SBC;
};

#endif












