/*
 *
 * SBCSwitchIVRResource.cxx
 *
 * Open SIP Stack ( OSS )
 *
 * Copyright (c) opensipstack.org.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either expressed or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is OpenSIPStack.
 *
 * The Initial Developer of the Original Code is opensipstack.org.
 *
 * The author of this code is Joegen E. Baclor
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * The OpenSIPStack Library includes some GPL/LGPL code libraries that MAY be 
 * enabled at compile time using the --enable-gpllibs configure switch.  If
 * enabled, the content of this file is published under the terms of GNU 
 * General Public License Version 2.  For a detailed list of the available
 * GPL code, see $(opensipstack)/gnu/README file.
 *
 * $Log: SBCSwitchIVRResource.cxx,v $
 * Revision 1.2  2009/06/03 11:57:16  joegenbaclor
 * Checking in MOH feature
 *
 *
 */


#ifndef SBCSWITHIVRRESOURCE_H
#define SBCSWITHIVRRESOURCE_H

#include "SBCSwitchIVRResource.h"
#include "SBCSwitchIVRChannel.h"
#include "ptclib/http.h"
#include "ptclib/memfile.h"
#define new PNEW
using namespace SWITCH;

BOOL SBCSwitchIVRRecordableFilename::Open(
  const OString & _arg
)
{
  m_Fn=_arg;
  m_ConsecutiveSilence = 0;
  return TRUE;
}

void SBCSwitchIVRRecordableFilename::Record(
  SBCSwitchIVRChannel & outgoingChannel
)
{
  PChannel * chan = NULL;

  // check the file extension and open a .wav or a raw (.sw or .g723) file
  if ((m_Fn.Right(4)).ToLower() == ".wav")
    chan = outgoingChannel.CreateWAVFile(m_Fn, TRUE);
  else {
    PFile * fileChan = new PFile(m_Fn);
    if (fileChan->Open(PFile::WriteOnly))
      chan = fileChan;
    else {
      delete fileChan;
    }
  }

  if (chan == NULL)
    PTRACE(3, "IVR: Cannot open file \"" << m_Fn << "\"");
  else {
    PTRACE(3, "IVR: Recording to file \"" << m_Fn << "\"");
    outgoingChannel.SetWriteChannel(chan, TRUE);
  }

  m_RecordStart  = PTime();
  m_SilenceStart = PTime();
  m_ConsecutiveSilence = 0;
}

BOOL SBCSwitchIVRRecordableFilename::OnFrame(
  BOOL isSilence
)
{
  if (!isSilence) {
    m_SilenceStart = PTime();
    m_ConsecutiveSilence = 0;
  } else {
    m_ConsecutiveSilence++;
    if ( ((m_ConsecutiveSilence % 20) == 0) &&
        (
          ((m_FinalSilence > 0) && ((PTime() - m_SilenceStart).GetMilliSeconds() >= m_FinalSilence)) || 
          ((m_MaxDuration  > 0) && ((PTime() - m_RecordStart).GetMilliSeconds() >= m_MaxDuration))
          )
       )
      return TRUE;
  }

  return FALSE;
}


///////////////////////////////////////////////////////////////

BOOL SBCSwitchIVRPlayable::ReadFrame(
  SBCSwitchIVRChannel & channel, 
  void * _buf, 
  PINDEX origLen
)
{
  BYTE * buf = (BYTE *)_buf;
  PINDEX len = origLen;

  while( len > 0 ) 
  {
    BOOL stat = channel.ReadFrame( buf, len );
    if (stat) 
      return TRUE;
    if (m_Repeat == 0)
      return FALSE;
    else
    {
      Rewind( channel.GetBaseReadChannel() );
      return FALSE;
    }
    PINDEX readLen = channel.GetLastReadCount();
    len -= readLen;
    buf += readLen;
  }

  return TRUE;
}


//////////////////////////////////////////////////////////////////


BOOL SBCSwitchIVRPlayableURL::Open(SBCSwitchIVRChannel & chan, const OString & _url, PINDEX _delay, PINDEX _repeat, BOOL autoDelete)
{
  m_Arg = _url; 
  m_Url = _url.c_str();
  return SBCSwitchIVRPlayable::Open(chan, _delay, _repeat, autoDelete); 
}

void SBCSwitchIVRPlayableURL::Play(SBCSwitchIVRChannel & outgoingChannel)
{
  // open the resource
  PHTTPClient * client = new PHTTPClient;
  PMIMEInfo outMIME, replyMIME;
  int code = client->GetDocument(m_Url, outMIME, replyMIME, FALSE);
  if ((code != 200) || (replyMIME(PHTTP::TransferEncodingTag) *= PHTTP::ChunkedTag))
    delete client;
  else 
    outgoingChannel.SetReadChannel(client, TRUE);
}

//////////////////////////////////////////////////////////////////


BOOL SBCSwitchIVRPlayableData::Open(
  SBCSwitchIVRChannel & chan, 
  const OString & /*_fn*/, 
  PINDEX _delay, 
  PINDEX _repeat, 
  BOOL v
)
{
  return SBCSwitchIVRPlayable::Open(chan, _delay, _repeat, v); 
}

void SBCSwitchIVRPlayableData::Play(
  SBCSwitchIVRChannel & outgoingChannel
)
{
  PMemoryFile * chan = new PMemoryFile(m_Data);
  PTRACE(3, "IVR: Playing " << m_Data.GetSize() << " bytes");
  outgoingChannel.SetReadChannel(chan, TRUE);
}

BOOL SBCSwitchIVRPlayableData::Rewind(
  PChannel * chan
)
{
  PMemoryFile * memfile = dynamic_cast<PMemoryFile *>(chan); 
  if (memfile == NULL) 
    return FALSE; 
  return memfile->SetPosition(0); 
}

//////////////////////////////////////////////////////////////////

BOOL SBCSwitchIVRPlayableFilename::Open(
  SBCSwitchIVRChannel & chan, 
  const OString & _fn, 
  PINDEX _delay, 
  PINDEX _repeat, 
  BOOL _autoDelete
)
{
  OString f = _fn; 
  if( f.Left(5) == "file:" )
    m_Fn = f.Mid(5).c_str();
  else
    m_Fn = f.c_str();

  m_Arg = (const char *)m_Fn;
  if (!PFile::Exists(m_Fn))
    return FALSE;

  return SBCSwitchIVRPlayable::Open(chan, _delay, _repeat, _autoDelete); 
}

void SBCSwitchIVRPlayableFilename::Play(
  SBCSwitchIVRChannel & outgoingChannel
)
{
  PChannel * chan = NULL;

  // check the file extension and open a .wav or a raw (.sw or .g723) file
  if ((m_Fn.Right(4)).ToLower() == ".wav")
    chan = outgoingChannel.CreateWAVFile(m_Fn);
  else 
  {
    PFile * fileChan = new PFile(m_Fn);
    if (fileChan->Open(PFile::ReadOnly))
      chan = fileChan;
    else 
    {
      delete fileChan;
      fileChan = NULL;
    }
  }

  if (chan == NULL)
    PTRACE(3, "IVR: Cannot open file \"" << m_Fn << "\"");
  else {
    PTRACE(3, "IVR: Playing file \"" << m_Fn << "\"");
    outgoingChannel.SetReadChannel(chan, TRUE);
  }
}

void SBCSwitchIVRPlayableFilename::OnStop()
{
  if (m_AutoDelete) 
  {
    PTRACE(3, "IVR: Deleting file \"" << m_Fn << "\"");
    PFile::Remove(m_Fn); 
  }
}

BOOL SBCSwitchIVRPlayableFilename::Rewind(
  PChannel * chan
)
{
  PFile * file = dynamic_cast<PFile *>(chan); 
  if (file == NULL) 
    return FALSE;

  return file->SetPosition(0); 
}

//////////////////////////////////////////////////////////////////

BOOL SBCSwitchIVRPlayableFilenameList::Open(
  SBCSwitchIVRChannel & chan, 
  const OStringArray & _list, 
  PINDEX _delay, 
  PINDEX _repeat, 
  BOOL _autoDelete
)
{
  for(PINDEX i = 0; i < _list.GetSize(); ++i) 
  {
    OString fn = _list[i];
    if (PFile::Exists(fn.c_str()))
      m_Filenames.AppendString(fn);
  }

  if (m_Filenames.GetSize() == 0)
    return FALSE;

  m_CurrentIndex = 0;

  return SBCSwitchIVRPlayable::Open(chan, _delay, ((_repeat >= 0) ? _repeat : 1) * m_Filenames.GetSize(), _autoDelete); 
}

void SBCSwitchIVRPlayableFilenameList::OnRepeat(
  SBCSwitchIVRChannel & outgoingChannel
)
{
  PFilePath fn = m_Filenames[m_CurrentIndex++ % m_Filenames.GetSize()].c_str();

  PChannel * chan = NULL;

  // check the file extension and open a .wav or a raw (.sw or .g723) file
  if ((fn.Right(4)).ToLower() == ".wav")
    chan = outgoingChannel.CreateWAVFile(fn);
  else {
    PFile * fileChan = new PFile(fn);
    if (fileChan->Open(PFile::ReadOnly))
      chan = fileChan;
    else 
    {
      delete fileChan;
      fileChan = NULL;
    }
  }

  if (chan == NULL)
    PTRACE(3, "IVR: Cannot open file \"" << fn << "\"");
  else {
    PTRACE(3, "IVR: Playing file \"" << fn << "\"");
    outgoingChannel.SetReadChannel(chan, TRUE);
  }
}

void SBCSwitchIVRPlayableFilenameList::OnStop()
{
  if (m_AutoDelete)  
  {
    for (PINDEX i = 0; i < m_Filenames.GetSize(); ++i) 
    {
      PTRACE(3, "IVR: Deleting file \"" << m_Filenames[i] << "\"");
      PFile::Remove(m_Filenames[i].c_str()); 
    }
  }
}

//////////////////////////////////////////////////////////////////
#endif


