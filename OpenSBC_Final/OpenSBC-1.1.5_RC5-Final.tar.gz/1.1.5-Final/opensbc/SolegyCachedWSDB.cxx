/*
 *
 * SolegyCachedWSDB.cxx
 *
 * Open SIP Stack ( OSS )
 *
 * Copyright (c) opensipstack.org.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either expressed or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is OpenSIPStack.
 *
 * The Initial Developer of the Original Code is opensipstack.org.
 *
 * The author of this code is Joegen E. Baclor
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * The OpenSIPStack Library includes some GPL/LGPL code libraries that MAY be 
 * enabled at compile time using the --enable-gpllibs configure switch.  If
 * enabled, the content of this file is published under the terms of GNU 
 * General Public License Version 2.  For a detailed list of the available
 * GPL code, see $(opensipstack)/gnu/README file.
 *
 * $Log: SolegyCachedWSDB.cxx,v $
 * Revision 1.8  2009/06/10 06:28:34  joegenbaclor
 * updating VC-8.00 project file
 *
 * Revision 1.7  2009/06/10 00:01:38  joegenbaclor
 * mutexed InternalStop and InternalStop to avoid race conditions for cancelled calls
 *
 * Revision 1.6  2009/06/09 10:33:30  joegenbaclor
 * adjusted setting of callstart
 *
 * Revision 1.5  2009/06/09 09:03:18  joegenbaclor
 * forgot to enqueue SendSignin on auth receipt
 *
 * Revision 1.4  2009/06/09 00:46:57  joegenbaclor
 * Invalidate route-cache if all attempts failed
 *
 * Revision 1.3  2009/06/08 09:52:47  joegenbaclor
 * disconnect if authenticator is present for cached route
 *
 * Revision 1.2  2009/06/08 08:54:01  joegenbaclor
 * *** empty log message ***
 *
 * Revision 1.1  2009/06/08 06:30:45  joegenbaclor
 * Added route caching capability to solegy rtts client
 *
 *
 *
 */


#include "SolegyCachedWSDB.h"
#define new PNEW
#define DNIS_CACHE_LEN_OFFSET 4
using namespace SOLEGY;

#define RTTS_LOG( detail ) \
{ \
  if( m_B2BUAConnection != NULL ) \
  LOG( m_B2BUAConnection->LogInfo(), "=== RTTS: " << detail ); \
}


SolegyCachedWSDB::SolegyCachedWSDB(
  SolegySessionManager * manager,
  SolegySocket * socket,
  B2BUAConnection * sipConnection,
  const char * localSessionId
  ) : SolegyWSDB( manager, socket, sipConnection, localSessionId )
{
  m_HasCachedRoute = FALSE;
  m_SendStartOnCallStart = FALSE;
  m_SendCallStartOnSetup = FALSE;
}

SolegyCachedWSDB::~SolegyCachedWSDB()
{
}

BOOL SolegyCachedWSDB::Start( 
  const SIPMessage & msg  
)
{
  OString dnis = msg.GetRequestURI().GetUser();
  int dnisLen = dnis.GetLength() - DNIS_CACHE_LEN_OFFSET;
  if( dnisLen < 1  )
    return SolegyWSDB::Start( msg );

  m_RouteCache = m_SessionManager->GetRTTSRouteCacheDIR() + "/";
  m_RouteCache += dnis.Left( dnisLen ).c_str();
  m_HasCachedRoute = PFile::Exists( m_RouteCache );
  return SolegyWSDB::Start( msg );
}


BOOL SolegyCachedWSDB::InternalStart( 
  const SIPMessage & msg 
)
{
  if( m_HasCachedRoute )
  {
    RTTS_LOG( "ROUTE-CACHE ENABLED" );
    PWaitAndSignal lock( m_SessionManager->GetRTTSRouteCacheMutex());
    PTextFile rcache( m_RouteCache, PFile::ReadOnly );
    if( !rcache.IsOpen() )
    {
      m_HasCachedRoute = FALSE;
      return SolegyWSDB::InternalStart( msg );
    }
  
    OStringStream packet;
    for(;;)
    {
      PString line;
      if( !rcache.ReadLine( line ) )
        break;
      packet << line << "\r\n";
    }

    SolegyParser::ParseHeader( "ROUTING", m_CachedRoute, packet );

    if( !SolegyParser::ParseRouting( packet.str(), msg, m_RTBERouteList ) )
    {
      m_HasCachedRoute = FALSE;
      return SolegyWSDB::InternalStart( msg );
    }
    return CallConnect();
  }
  return SolegyWSDB::InternalStart( msg );
}

BOOL SolegyCachedWSDB::InternalStop( const SIPMessage & msg )
{
  if( !m_HasCachedRoute )
    return SolegyWSDB::InternalStop( msg );

  m_SessionManager->GetRTTSRouteCacheMutex().Wait();
  BOOL ok = SolegyWSDB::InternalStop( msg );
  m_SessionManager->GetRTTSRouteCacheMutex().Signal();

  return ok;
}

BOOL SolegyCachedWSDB::OnReceived_SETUP( 
  const OString & packet 
)
{
  OString route;
  BOOL updateCache = FALSE;
  if( SolegyParser::ParseHeader( "ROUTING", route, packet ) )
  {
    if( !m_CachedRoute.IsEmpty() && m_CachedRoute != route )
      updateCache = TRUE;
  }

  if( m_DIGEST.IsEmpty() )
  {
    if( !m_HasCachedRoute || updateCache )
    {
      RTTS_LOG( "UPDATING ROUTE-CACHE" );
      PWaitAndSignal lock( m_SessionManager->GetRTTSRouteCacheMutex() );
      PTextFile rcache( m_RouteCache );
      if( rcache.IsOpen() )
      {
        rcache.SetLength(0);
        if( !route.IsEmpty() )
        {
          m_CachedRoute = route;
          rcache.WriteString( packet.c_str() );
        }
      }
    }
  }

  
  BOOL ok =  SolegyWSDB::OnReceived_SETUP( packet );

  if( m_SendCallStartOnSetup )
    InternalOnCallStart();

  return ok;
}


void SolegyCachedWSDB::SetupOutbound( 
  SIPMessage & invite 
)
{
  if( !m_HasCachedRoute )
  {
    SolegySession::SetupOutbound( invite );
    return;
  }

  PWaitAndSignal lock( m_RTBERouteListMutex );
  m_SendStartOnCallStart = TRUE;
  invite.SetXBillingVector( NULL );
  invite.SetXRoutingVector( NULL );

  int count = m_RTBERouteList.GetSize();
  if( count > 0 )
  {
    m_RTBERouteList.DisallowDeleteObjects();
    SIPMessage * route = (SIPMessage *)m_RTBERouteList.RemoveAt(0);
    m_RTBERouteList.AllowDeleteObjects();
    if( route != NULL )
    {
       m_AccountingOff = FALSE;

      SIPURI rURI = route->GetRequestURI();
      const SIPURI &  fURI = route->GetFromURI();

      RTTS_LOG( "Route -> " <<  rURI);

      invite.SetRequestURI( rURI );
      invite.SetFromURI( fURI );
      invite.SetToURI( rURI );

      OString cnamHeader;
      cnamHeader = route->GetInternalHeader( "CNAM" );
      if( !cnamHeader.IsEmpty() )
      {
        From from = invite.GetFrom();
        OStringStream cnam;
        RTTS_LOG( "Setting CNAM - " <<  cnamHeader);
        cnam << '"' << cnamHeader << '"';
        from.SetDisplayName( cnam.str() );
        invite.SetFrom( from );
      }

      

      if( m_B2BUAConnection != NULL && m_B2BUAConnection->IsSafeReference() )
      {
        m_B2BUAConnection->RemoveRoutes();
        m_B2BUAConnection->AddRoute( rURI );

        OString routeSet;
        routeSet = route->GetInternalHeader( "ROUTE-SET" );
        m_B2BUAConnection->SetOutboundRouteSet( routeSet );
      }
      delete route;
    }
  }

  m_SessionManager->ValidateRegisteredRoute( invite );

  m_CurrentOutboundInvite = invite;
  m_CallStartTime = m_CallTryingTime = PTime();
}

void SolegyCachedWSDB::OnAllRouteExhausted()
{
  InvalidateRouteCache();
}

BOOL SolegyCachedWSDB::SendCALLSTART()
{
  if( !m_SendStartOnCallStart || !m_HasCachedRoute )
  {
      //PWaitAndSignal packetmutex( m_PacketQueueMutex );
    PWaitAndSignal timerMutex( m_TimerMutex );

   
    if( m_State == STOP || m_State < SETUP )
    {
      RTTS_LOG( "*** CALL-START ABORT *** Wrong State =" << m_State );
      return FALSE;
    }

    m_CanSendCallStop = TRUE;
    m_State = CALLSTART;

    PTimeInterval diff = m_CallStartTime - m_CallTryingTime;
    m_RingDuration = diff.GetInterval()/1000;

    m_CallTimer.Stop();
    m_CallWarningTimer.Stop();

    SolegyParser::ParseHeader( "BASICCHARGETIMELEFT", m_BASICCHARGETIMELEFT, m_SETUPResponse ); 

    PTimeInterval chargeTime;
    if( m_BASICCHARGETIMELEFT.Find( "E" ) != P_MAX_INDEX )
    {
      if( SolegyParser::ParseHeader( "TIMELEFT", m_TIMELEFT, m_SETUPResponse ) )
          chargeTime = PTimeInterval( 0, m_TIMELEFT.AsInteger() );
    }else if( !m_BASICCHARGETIMELEFT.IsEmpty() )
    {
      chargeTime = PTimeInterval( 0, m_BASICCHARGETIMELEFT.AsInteger() );
    }else
    {
      if( SolegyParser::ParseHeader( "TIMELEFT", m_TIMELEFT, m_SETUPResponse ) )
          chargeTime = PTimeInterval( 0, m_TIMELEFT.AsInteger() );
    }

    if( chargeTime.GetSeconds() < 10 )
    {
      chargeTime = PTimeInterval( 0, 10 );
    }
    
    m_CallTimer = PTimer( chargeTime );
    m_CallTimer.SetNotifier( PCREATE_NOTIFIER( OnCallTimerExpire ) );
    m_CallTimer.Resume();
    LOG( m_B2BUAConnection->LogInfo(), "=== RTTS: Call-Timer=" << chargeTime.GetSeconds() << " seconds" );

    if( chargeTime.GetSeconds() > 60 )
    {
      m_CallWarningTimer = PTimer( (long)(chargeTime.GetMilliSeconds() - 60000) );
      m_CallWarningTimer.SetNotifier( PCREATE_NOTIFIER( OnCallWarningTimerExpire ) );
      m_CallWarningTimer.Resume();
    }
    
    DumpCallState();
    
    OStringStream strm;
    strm << "CALLSTART" << endl;
    PrepareHeader( strm );
    OnPrepareCALLSTARTInfo( strm );
    m_CurrentPacket = strm.str();
    WritePacket();
    StartRetryTimer( CALLSTART_TIMEOUT );

    return TRUE;
  }

  m_CallStartTime = PTime();
  m_SendCallStartOnSetup = TRUE;
  m_SendStartOnCallStart = FALSE;
  m_State = START;
  return SolegyWSDB::InternalStart( m_CurrentInboundInvite );
}


void SolegyCachedWSDB::OnReceived_AUTH_ERROR( 
  const OString & packet 
)
{
  if( m_HasCachedRoute )
    InvalidateRouteCache();
  SolegyWSDB::OnReceived_AUTH_ERROR( packet );
}

void SolegyCachedWSDB::OnReceived_SIGNIN_ERROR( 
  const OString & packet 
)
{
  if( m_HasCachedRoute )
    InvalidateRouteCache();
  SolegyWSDB::OnReceived_SIGNIN_ERROR( packet );
}

void SolegyCachedWSDB::OnReceived_SETUP_ERROR( 
  const OString & packet 
)
{
  if( m_HasCachedRoute )
    InvalidateRouteCache();
  SolegyWSDB::OnReceived_SETUP_ERROR( packet );
}

void SolegyCachedWSDB::InvalidateRouteCache()
{
  PWaitAndSignal lock( m_SessionManager->GetRTTSRouteCacheMutex() );
  if( m_HasCachedRoute )
    PFile::Remove( m_RouteCache, TRUE );
}


BOOL SolegyCachedWSDB::OnReceived_AUTH( const OString & packet )
{
  if( m_HasCachedRoute )
  {
    SolegySession::OnReceived_AUTH( packet );
    /// we dont support authenticators for cached routes
    if( !m_DIGEST.IsEmpty() )
    {
      SolegyCachedWSDB::InvalidateRouteCache();
      return FALSE;
    }
    m_SessionManager->EnqueueEvent( "SendSIGNIN", this );
    return TRUE;
  }else
    return SolegyWSDB::OnReceived_AUTH( packet );  
}






