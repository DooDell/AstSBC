/*
 *
 * Registration.cxx
 *
 * Open SIP Stack ( OSS )
 *
 * Copyright (c) opensipstack.org.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either expressed or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is OpenSIPStack.
 *
 * The Initial Developer of the Original Code is opensipstack.org.
 *
 * The author of this code is Joegen E. Baclor
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * The OpenSIPStack Library includes some GPL/LGPL code libraries that MAY be 
 * enabled at compile time using the --enable-gpllibs configure switch.  If
 * enabled, the content of this file is published under the terms of GNU 
 * General Public License Version 2.  For a detailed list of the available
 * GPL code, see $(opensipstack)/gnu/README file.
 *
 * $Log: Registration.cxx,v $
 * Revision 1.22  2009/06/10 06:28:34  joegenbaclor
 * updating VC-8.00 project file
 *
 * Revision 1.21  2009/04/27 02:41:01  joegenbaclor
 * Fixed Option keep-alive getting sent to private IP
 *
 * Revision 1.20  2009/03/17 02:24:41  joegenbaclor
 * introduced bypassing of ICT responses for fater response time
 *
 * Revision 1.19  2009/03/06 03:17:18  joegenbaclor
 * configurable OPTIONS based NAT keep alive support
 *
 * Revision 1.18  2009/03/03 08:05:44  joegenbaclor
 * *** empty log message ***
 *
 * Revision 1.17  2009/02/09 13:09:17  joegenbaclor
 * using bottom via to determine NAT in registration
 *
 * Revision 1.16  2008/12/01 03:52:14  joegenbaclor
 * Upper reg bug fixes
 *
 * Revision 1.15  2008/11/27 03:25:34  joegenbaclor
 * Made sure we do not use the IP address of the NAT bining in request URIwhen sending
 *  INVITE to NATted UA
 *
 * Revision 1.14  2008/11/20 11:02:34  joegenbaclor
 * Depcrecated old SIPMessage URI accessors
 *
 * Revision 1.13  2008/11/13 03:05:00  joegenbaclor
 * BUG:  User is not set when binding is translated
 *
 * Revision 1.12  2008/11/01 03:51:14  joegenbaclor
 * Mutexed registration list during flushing of registration and removel of records to
 *  avoid race condition on registration list activity
 *
 * Revision 1.11  2008/10/23 05:16:11  joegenbaclor
 * Reimplemented NAT Binding Refresh
 *
 * Revision 1.10  2008/10/06 04:03:32  joegenbaclor
 * More bugs in upper-reg
 *
 * Revision 1.9  2008/10/06 03:07:24  joegenbaclor
 * Fixed bug in auth-pending where unregister requests are considered new registration
 *
 * Revision 1.8  2008/10/06 02:11:52  joegenbaclor
 * More verbose log entry
 *
 * Revision 1.7  2008/09/29 06:31:15  joegenbaclor
 * fixed more upper reg bugs
 *
 * Revision 1.6  2008/09/29 04:03:36  joegenbaclor
 * More work on stateful upper reg
 *
 * Revision 1.5  2008/09/22 05:58:35  joegenbaclor
 * Added stateful upper reg classes
 *
 * Revision 1.4  2008/09/11 15:49:41  joegenbaclor
 * Only Unregister an upper reg record on receipt of a 200 ok
 *
 * Revision 1.3  2008/09/10 03:56:29  joegenbaclor
 * Updated VC2005 build
 *
 * Revision 1.2  2008/09/03 08:03:46  joegenbaclor
 * more work on new upper reg
 *
 * Revision 1.1  2008/08/27 03:02:14  joegenbaclor
 * Adding new registrar code
 *
 *
 */

#include "Registration.h"
#include "Registrar.h"

#define new PNEW
using namespace REGISTRAR;
Registration::Record::Record( 
  const PNotifier & notifier, 
  const SIPMessage & request, 
  Registration & registration,
  int keepAliveInterval,
  BOOL useOptionsKeepAlive ) : m_Registration( registration )
{
  PTime now;
  m_NATCSeq = (int)now.GetTimeInSeconds() / 3600 / 24; //days since epoch
  m_NATRefreshInterval = PTimeInterval( 0, keepAliveInterval );
  m_NATCallId = ParserTools::GenGUID();
  m_UseOptionsNATRefresh = useOptionsKeepAlive;

  LOG_CONTEXT( LogDetail(), request.GetCallId(), 
    "*** REG *** Record CREATED. AOR=" << request.GetFromURI() << " Binding=" <<  request.GetTopContactURI() );

  m_ExpireNotifier = notifier;  
  m_Register = request;

  Expires gExpires;
  BOOL hasGlobalExpires = m_Register.GetExpires( gExpires );

  Contact contact;
  m_Register.GetContactAt( contact, 0 );
  ContactURI uri;
  contact.GetURI( uri, 0 );
 
  OString sExpires;
  BOOL hasLocalExpires = uri.GetParameter( "expires", sExpires );
  if( !hasLocalExpires )
    hasLocalExpires = uri.GetURI().GetParameter( "expires", sExpires );
  
  PInt64 expires = 0;
  if( hasLocalExpires )
    expires = sExpires.AsInteger();
  else if( hasGlobalExpires )
    expires = gExpires.AsInteger();

  if( expires == 0 )
    expires = 3600;

  PTimer::Reset();
  PTimer::SetInterval( 0, (long)expires );
}

Registration::Record::~Record()
{
  m_NATRefreshTimer.Stop();
  PTimer::Stop();
  LOG_CONTEXT( LogDetail(), m_Register.GetCallId(), 
    "*** REG *** Record DESTROYED. AOR=" << m_Register.GetFromURI() << " Binding=" <<  m_Register.GetTopContactURI() );
}

void Registration::Record::Reset( 
  const SIPMessage & request 
)
{
  if( !request.IsRegister() )
    return;
  m_Register = request;
  /// check if the call-id is the same
  /// if it is, check the cseq
  OString cid = request.GetCallId();
  if( m_Register.GetCallId() == cid )
  {
    if( request.GetCSeqNumber() < m_Register.GetCSeqNumber() )
      return;
  }

  PTimer::Stop();

  m_Register = request;
  Expires gExpires;
  BOOL hasGlobalExpires = m_Register.GetExpires( gExpires );

  Contact contact;
  m_Register.GetContactAt( contact, 0 );
  ContactURI uri;
  contact.GetURI( uri, 0 );

  OString sExpires;
  BOOL hasLocalExpires = uri.GetParameter( "expires", sExpires );
  if( !hasLocalExpires )
    hasLocalExpires = uri.GetURI().GetParameter( "expires", sExpires );

  PInt64 expires = 0;
  if( hasLocalExpires )
    expires = sExpires.AsInteger();
  else if( hasGlobalExpires )
    expires = gExpires.AsInteger();

  if( expires == 0 )
    expires = 3600;

  PTimer::Reset();
  PTimer::SetInterval( 0, (long)expires );
  PTimer::SetNotifier( m_ExpireNotifier );
  PTimer::Resume();

  LOG_CONTEXT( LogDetail(), request.GetCallId(), 
    "*** REG *** Record TIMER-RESET. AOR=" << request.GetFromURI() 
    << " Binding=" <<  request.GetTopContactURI()
    << " Expires=" << expires );

  int interval = m_NATRefreshInterval.GetSeconds();
  if( expires > interval && uri.GetURI().IsPrivateNetwork() )
  {
    m_NATRefreshTimer = PTimer( m_NATRefreshInterval );
    m_NATRefreshTimer.SetNotifier( PCREATE_NOTIFIER( OnNATRefresh ) );
    m_NATRefreshTimer.Resume();
  }
}

void Registration::Record::Stop()
{
  PTimer::Stop();
  m_NATRefreshTimer.Stop();
}

ContactURI Registration::Record::GetTranslatedBinding()const
{
  Contact contact;
  m_Register.GetContactAt( contact, 0 );
  ContactURI curi;
  contact.GetURI( curi, 0 );
  if( curi.GetURI().IsPrivateNetwork() )
  {
    const Via & via = m_Register.GetBottomVia();
    {
      PIPSocket::Address received = via.GetReceiveAddress();
      WORD rport = via.GetRPort();
      OString sendAddr = received.AsSTLString() + ":" + OString( rport ); 
      SIPURI translatedURI = curi.GetURI();
      translatedURI.AddParameter( "send-addr", sendAddr );
      curi.SetURI( translatedURI );
    }
  }
  return curi;
}

void Registration::Record::OnNATRefresh( PTimer & timer, INT )
{
  SendNATRefresh();
  timer.Reset();
  timer.Resume();
}

void Registration::Record::SendNATRefresh()
{
  SIPMessage keepAlive;
  ContactURI target = GetTranslatedBinding();
  SIPURI targetURI = target.GetURI();
  OString sendAddr = targetURI.RemoveParameter( "send-addr" );
  SIPURI targetAddress;
  if( !sendAddr.IsEmpty() )
  {
    sendAddr = "sip:" + sendAddr;
    SIPURI targetAddress( sendAddr );
    keepAlive.SetSendAddress( targetAddress );
  }

  if( !m_UseOptionsNATRefresh )
  {
    
    RequestLine requestLine;
    requestLine.SetMethod( "KEEP-ALIVE" );
    requestLine.SetRequestURI( target.GetURI() );
    keepAlive.SetStartLine( requestLine );
    m_Registration.m_Registrar->m_UserAgent.TransportWrite( keepAlive );
  }else
  {
    Contact contact;
    m_Register.GetContactAt( contact, 0 );
    ContactURI curi;
    contact.GetURI( curi, 0 );
    keepAlive.SetNICTNullTransaction( TRUE );
    RequestLine requestLine;
    requestLine.SetMethod( "OPTIONS" );
    requestLine.SetRequestURI( curi.GetURI() );
    keepAlive.SetStartLine( requestLine );
    Via via;
    m_Registration.m_Registrar->m_UserAgent.ConstructVia( target.GetURI().GetAddress(), via, SIPTransport::UDP );
    via.AddParameter( "branch", ParserTools::GenBranchParameter() );
    keepAlive.AppendVia( via );

    ContactURI localContact;
    localContact.SetURI( via.GetURI().GetBasicURI() );
    keepAlive.AppendContact( localContact );

    Subject subject( "NAT Keep Alive" );
    keepAlive.SetSubject( subject );

    keepAlive.SetTo( m_Register.GetTo() );
    From from = m_Register.GetFrom();
    from.AddParameter( "tag", ParserTools::GenTagParameter(), TRUE );
    keepAlive.SetFrom( from );
    CallId callId( m_NATCallId );
    keepAlive.SetCallId( callId );
    CSeq cseq( "OPTIONS", ++m_NATCSeq );
    keepAlive.SetCSeq( cseq );
    m_Registration.m_Registrar->m_UserAgent.SendRequest( keepAlive );
  }
}

//////////////////////////////

Registration::Registration( 
  const SIPURI & uri,
  Registrar * registrar,
  BOOL authorize
)
{
  m_RequireAuthorization = authorize;
  m_URI = uri;
  m_Registrar = registrar;
  m_IsFlushed = FALSE;
  m_RecordList.DisallowDeleteObjects();

  LOG( LogDetail(), "*** REG *** Session CREATED. AOR=" << m_URI );
}

Registration::~Registration()
{
  m_RecordList.AllowDeleteObjects();
  m_RecordList.RemoveAll();
  LOG( LogDetail(), "*** REG *** Session DESTROYED. AOR=" << m_URI );
}

void Registration::OnRecordExpire( PTimer & _record, INT )
{
  PWaitAndSignal reglock( m_Registrar->m_RegistrationListMutex );
  PWaitAndSignal lock(m_RecordListMutex);
  Record & record = dynamic_cast<Record&>(_record);
  SIPMessage & request = record.m_Register;
  Contact contact;
  request.GetContactAt( contact, 0 );
  ContactURI curi;
  contact.GetURI( curi, 0 );
  OString cURI = curi.GetURI().AsString( FALSE, TRUE, TRUE );
  Record * rec = m_RecordList.RemoveAt( cURI.c_str() );
  if( rec != NULL )
  {
    LOG_CONTEXT( LogDetail(), request.GetCallId(), 
      "*** REG *** Record Queued for DELETION. AOR=" << m_URI 
      << " BINDING=" << cURI );
    m_RecordLandFill.Append( rec );
  }

  if( m_RecordList.GetSize() == 0 )
  {
    LOG_CONTEXT( LogDetail(), request.GetCallId(), 
    "*** REG *** Session FLUSHED. AOR=" << m_URI );

    m_Registrar->OnFlushRegistration( this );
  }
}


BOOL Registration::RemoveRecord( 
  const SIPMessage & request,
  OString & contact
)
{
  PWaitAndSignal reglock( m_Registrar->m_RegistrationListMutex );
  PWaitAndSignal lock(m_RecordListMutex);

  OString cid = "NULL";
  if( request.IsValid() )
    cid = request.GetCallId();

  if( m_RecordList.GetSize() == 0 || m_IsFlushed )
    return FALSE;

  if( contact == "*" )
  {
    while(m_RecordList.GetSize() != 0 )
    {
      OString cURI =  (const char *)m_RecordList.GetKeyAt(0);
      Record * rec = m_RecordList.RemoveAt( cURI.c_str() );
      if( rec != NULL )
      {
        rec->Stop();
        m_RecordLandFill.Append( rec );
        LOG_CONTEXT( LogDetail(), cid, 
          "*** REG *** Record Queued for DELETION. AOR=" << m_URI 
          << " BINDING=" << cURI );
      }
    }
   
  }else
  {
    Record * rec = m_RecordList.RemoveAt( contact.c_str() );
    if( rec != NULL )
    {
      rec->Stop();
      m_RecordLandFill.Append( rec );
      LOG_CONTEXT( LogDetail(), cid, 
          "*** REG *** Record Queued for DELETION. AOR=" << m_URI << "BINDING=" << contact  );
    }
  }

  if( m_RecordList.GetSize() == 0 && !m_IsFlushed )
  {
    m_Registrar->OnFlushRegistration( this );
    m_IsFlushed = TRUE;
    LOG_CONTEXT( LogDetail(), cid, 
      "*** REG *** Session FLUSHED. AOR=" << m_URI );
  }

  return TRUE;
}

BOOL Registration::IsUnregister( const SIPMessage & request, OString & contacts )
{
  OString method = request.GetCSeqMethod().ToUpper().Trim();
  if(  method != "REGISTER" )
    return FALSE;

  if( request.GetContactSize() > 0 )
  {
    Contact contact;
    if( !request.GetContactAt( contact, 0 ) )
      return FALSE;
    
    if( contact.GetHeaderBody() *= "*" )
    {
      contacts = "*";
      return TRUE;
    }else /// check if expires == 0
    {
      ContactURI contactURI;
      if( contact.GetURI( contactURI ) )
      {
        OString paramValue;
        if( contactURI.GetParameter( "expires", paramValue ) )
        {
          if( paramValue == "0" )
          {
            contacts = contactURI.GetURI().AsString( FALSE, TRUE, TRUE );
            return TRUE;
          }
        }else if( contactURI.GetURI().GetParameter( "expires", paramValue ) )
        {
          if( paramValue == "0" )
          {
            contacts = contactURI.GetURI().AsString( FALSE, TRUE, TRUE );
            return TRUE;
          }
        }
      }
    }

    if( request.HasExpires() )
    {
      Expires expires;
      if( request.GetExpires( expires ) )
      {
        if( expires.AsInteger() == 0 )
        {
          if( contacts.IsEmpty() )
          {
            ContactURI contactURI;
            if( contact.GetURI( contactURI ) )
              contacts = contactURI.GetURI().AsString( FALSE, TRUE, TRUE );
          }
          return TRUE;
        }
      }
    }

  }

  
  return FALSE;
}

Registration::RequestAction Registration::ProcessRequest( 
  const SIPMessage & request,
  Contact & contacts
)
{
  if( !request.IsRegister() )
    return Ignore;

  /// check if the To URI is equal to ours
  BOOL equal = request.GetToURI() *= m_URI;
  if( !equal )
    return Ignore;

  // check if this message is authorized
  RequestAction authAction = IsAuthorized( request );
  if( authAction != Accept )
    return authAction;

  /// check if this is unregistration
  OString unregister;
  if( IsUnregister( request, unregister ) )
  {
    RemoveRecord( request, unregister );
    ListRecords( contacts );
    return Accept;
  }

  PWaitAndSignal lock(m_RecordListMutex);
  m_RecordLandFill.RemoveAll();

  AddRecord( request, contacts );
  return Accept;
}

BOOL Registration::AddRecord( 
  const SIPMessage & request,
  Contact & contacts,
  BOOL noReset
)
{
  PWaitAndSignal lock(m_RecordListMutex);

  Contact contact;
  request.GetContactAt( contact, 0 );
  ContactURI curi;
  contact.GetURI( curi, 0 );
  OString cURI = curi.GetURI().AsString( FALSE, TRUE, TRUE );

  if( m_RecordList.Contains( cURI.c_str() ) )
  {
    m_RecordList.GetAt( cURI.c_str() )->Reset( request ); 
  }else
  {
    if( !request.IsUnregister() )
    {
      Registration::Record * rec = new Registration::Record(
        PCREATE_NOTIFIER(OnRecordExpire), 
        request,
        *this,
        m_Registrar->m_NATKeepAliveInterval,
        m_Registrar->m_UseOptionsNATKeepAlive 
      );

      if( !rec->m_Register.IsValid()  )
      {
        delete rec;
        return Reject;
      }
      
      m_RecordList.SetAt( cURI.c_str(), rec );
      if( !noReset )
        rec->Reset( request );
    }
  }

  ListRecords( contacts );

  return TRUE;
}

Registration::RequestAction Registration::IsAuthorized( const SIPMessage & request )
{
  if( !m_RequireAuthorization )
    return Accept;
  
  Authorization auth;
  if( request.GetAuthorization(auth) )
  {
    OString authResponse;
    auth.GetParameter( "response", authResponse );
    OString md5Remote = ParserTools::UnQuote( authResponse );
    if( !m_MD5Local.IsEmpty() )
      if( m_MD5Local *= md5Remote )
        return Accept;
    return AuthPending;
  }else
    return Challenge;
}
    


BOOL Registration::ListRecords(
  Contact & contacts
)
{
  PWaitAndSignal lock(m_RecordListMutex);
  for( PINDEX i = 0; i < m_RecordList.GetSize(); i++ )
  {
    Record & record = m_RecordList.GetDataAt(i);
    SIPMessage & request = record.m_Register;
    Contact contact;
    request.GetContactAt( contact, 0 );
    ContactURI curi;
    contact.GetURI( curi, 0 );
    OString expires( record.GetInterval() / 1000 );
    curi.SetParameter( "expires", expires );
    contacts.AddURI( curi );
  }
  return TRUE;
}

BOOL Registration::GetTranslatedBindings( 
  Contact & contacts 
)
{
  PWaitAndSignal lock(m_RecordListMutex);
  for( PINDEX i = 0; i < m_RecordList.GetSize(); i++ )
  {
    Record & record = m_RecordList.GetDataAt(i);

    ContactURI curi = record.GetTranslatedBinding();
    contacts.AddURI( curi );
  }
  return TRUE;
}



