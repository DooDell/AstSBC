#ifndef SBCWARNINGBEEPSTREAMER_H
#define SBCWARNINGBEEPSTREAMER_H

#include <ptclib/dtmf.h>
#include <rtp/rtp.h>
#include "B2BUACall.h"

namespace B2BUA
{
  class SBCInboundCall;

  class SBCWarningBeepStreamer : public PThread
  {
    PCLASSINFO( SBCWarningBeepStreamer, PThread );
  public:
    SBCWarningBeepStreamer( 
      SBCInboundCall * inboundCall
    );

    void Main();

  protected:
    SIPSession::GCRef m_CallRef;
  };
}


#endif

