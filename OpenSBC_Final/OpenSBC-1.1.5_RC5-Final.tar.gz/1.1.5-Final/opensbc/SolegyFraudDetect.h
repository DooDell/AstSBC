#ifndef SOLEGYFRAUDDETECT_H
#define SOLEGYFRAUDDETECT_H

#include "SIPMessage.h"
#include "Logger.h"

using namespace SIPParser;

namespace SOLEGY
{
  class SolegySessionManager;

  class SolegyFraudDetect : public Logger
  {
  public:
    class HostSpoofingInfo : public PObject
    {
      PCLASSINFO( HostSpoofingInfo, PObject );
    public:
      HostSpoofingInfo(){ m_TotalAttempt = 0; };
      virtual ~HostSpoofingInfo(){};
      virtual void PrintOn( ostream & strm )const;
      PSortedStringList m_ViaSendAddress;
      OString m_FromHost;
      int m_TotalAttempt;
    };

    PDICTIONARY( HostSpoofingInfoDict, PString, HostSpoofingInfo );
    PMutex m_HostSpoofingInfoMutex;
    HostSpoofingInfoDict m_HostSpoofingInfo;

    SolegyFraudDetect( 
      SolegySessionManager * manager,
      int alertIntervalInHours = 12
    );

    virtual ~SolegyFraudDetect();

    void ProcessHostSpoofing( 
      const SIPMessage & invite 
    );


    PTimer m_MailAlertTimer;
    PDECLARE_NOTIFIER( PTimer, SolegyFraudDetect, OnMailAlertTimer );
    PDECLARE_NOTIFIER( PThread, SolegyFraudDetect, OnSendMailAlert );
    SolegySessionManager * m_SolegySessionManager;
  };

}
#endif

