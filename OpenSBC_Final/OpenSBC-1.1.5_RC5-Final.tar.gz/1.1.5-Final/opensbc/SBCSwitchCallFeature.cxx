/*
 *
 * SBCSwitchCallFeature.cxx
 *
 * Open SIP Stack ( OSS )
 *
 * Copyright (c) opensipstack.org.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either expressed or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is OpenSIPStack.
 *
 * The Initial Developer of the Original Code is opensipstack.org.
 *
 * The author of this code is Joegen E. Baclor
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * The OpenSIPStack Library includes some GPL/LGPL code libraries that MAY be 
 * enabled at compile time using the --enable-gpllibs configure switch.  If
 * enabled, the content of this file is published under the terms of GNU 
 * General Public License Version 2.  For a detailed list of the available
 * GPL code, see $(opensipstack)/gnu/README file.
 *
 * $Log: SBCSwitchCallFeature.cxx,v $
 * Revision 1.5  2009/06/27 03:18:45  joegenbaclor
 * fixed new line warnings in gcc
 *
 * Revision 1.4  2009/06/15 07:47:39  joegenbaclor
 * added *#98 to handle call queue rejection
 *
 * Revision 1.3  2009/06/15 06:49:35  joegenbaclor
 * fixed bug in moh handler
 *
 * Revision 1.2  2009/06/15 06:38:15  joegenbaclor
 * implemented call queing
 *
 * Revision 1.1  2009/06/03 11:57:16  joegenbaclor
 * Checking in MOH feature
 *
 *
 */

#include "SBCSwitchCallFeature.h"
#include "SBCSwitchConnection.h"
#include "SBCSwitchLeg1.h"
#include "SBCSwitchLeg2.h"
#include "SBCSwitchIVRInterface.h"
#include "OSSApplication.h"
#define new PNEW
using namespace SWITCH;

//////////////////////////////////
SBCSwitchCallFeature::SBCSwitchCallFeature(
  SBCSwitchConnection * conn,
  const OString & fCode
)
{
  m_Connection = conn;
  m_FCode = fCode;
  m_IFace = NULL;
}
////////////////////////////////// 


void SBCSwitchCallFeatureInterface::OnCreateCallFeatures(
  SBCSwitchConnection * conn
)
{
  PWaitAndSignal lock( m_FeatureMapMutex );
  if( m_FeatureMap.GetSize() != 0 )
    return;

  /// Add MOH
  SBCSwitchCallFeature * moh = new SBCSwitchCallFeature_MOH( conn, "00" );
  moh->AttachCallFeatureInterface( this );
  AddFeature( moh);
  /// Add MOH Listen
  SBCSwitchCallFeature * mohListen = new SBCSwitchCallFeature_MOH_Listen( conn, "08" );
  mohListen->AttachCallFeatureInterface( this );
  AddFeature( mohListen );
  /// Add Call Intercept
  SBCSwitchCallFeature * callIntercept = new SBCSwitchCallFeature_Call_Intercept( conn, "99" );
  callIntercept->AttachCallFeatureInterface( this );
  AddFeature( callIntercept );
  /// Add Call Intercept Reject
  SBCSwitchCallFeature * callInterceptReject = new SBCSwitchCallFeature_Call_Intercept_Reject( conn, "98" );
  callInterceptReject->AttachCallFeatureInterface( this );
  AddFeature( callInterceptReject );

}

void SBCSwitchCallFeatureInterface::AddFeature( 
  SBCSwitchCallFeature * feature 
)
{
  PWaitAndSignal lock( m_FeatureMapMutex );
  m_FeatureMap.SetAt( feature->GetFCode().c_str(), feature );
}

SBCSwitchCallFeature * SBCSwitchCallFeatureInterface::OnGetCallFeature(
  SBCB2BUACall * /*call*/,
  const OString & fCode
)
{
  PWaitAndSignal lock( m_FeatureMapMutex );
  return m_FeatureMap.GetAt( fCode.c_str() );
}

////////////////////////////////

SBCSwitchCallFeature_MOH::SBCSwitchCallFeature_MOH(
  SBCSwitchConnection * conn,
  const OString & fCode
  ) : SBCSwitchCallFeature( conn, fCode )
{
  m_HeldLeg = -1;
  m_MusicFile = OSSApplication::GetApplicationDirectory() + "/music/music_on_hold.wav" ;
}
    
BOOL SBCSwitchCallFeature_MOH::Execute( 
  SBCB2BUACall * call
)
{
  SBCSwitchIVRInterface * ivr = NULL;
  if( call->GetLegIndex() == 0 )
    ivr = dynamic_cast<SBCSwitchIVRInterface*>( dynamic_cast<SBCB2BUACall *>(m_Connection->GetLeg2Call()) );
  else if( call->GetLegIndex() == 1 )
    ivr = dynamic_cast<SBCSwitchIVRInterface*>( dynamic_cast<SBCB2BUACall *>(m_Connection->GetLeg2Call()) );

  
  if( ivr == NULL )
    return FALSE;
  
  if( m_HeldLeg == -1 )
  {
    m_HeldLeg = call->GetLegIndex() == 0 ? 1 : 0;
    ivr->PlayFile( m_MusicFile );
    RTP_UDP * peerRTP = (RTP_UDP*)(call->GetRTPSessionManager().GetSession( OpalMediaFormat::DefaultAudioSessionID ));
    ivr->AcquireRTPBridge( m_Connection->GetSwitchMedia()->GetAudioRTPBridge(), peerRTP );
  }else 
  {
    if( call->GetLegIndex() == m_HeldLeg )
      return FALSE;
    m_HeldLeg = -1;
    ivr->ReleaseRTPBridge( m_Connection->GetSwitchMedia()->GetAudioRTPBridge() );
    m_Connection->GetSwitchMedia()->BridgeEndToEnd();
  }
  return TRUE;
}

////////////////////////////////

SBCSwitchCallFeature_MOH_Listen::SBCSwitchCallFeature_MOH_Listen(
  SBCSwitchConnection * conn,
  const OString & fCode
  ) : SBCSwitchCallFeature( conn, fCode )
{
  m_HeldLeg = -1;
  m_MusicFile = OSSApplication::GetApplicationDirectory() + "/music/music_on_hold.wav" ;
}
    
BOOL SBCSwitchCallFeature_MOH_Listen::Execute( 
  SBCB2BUACall * call
)
{
  SBCSwitchIVRInterface * ivr = dynamic_cast<SBCSwitchIVRInterface*>(call);
  
  if( ivr == NULL )
    return FALSE;
  
  if( m_HeldLeg == -1 )
  {
    m_HeldLeg = call->GetLegIndex();
    ivr->PlayFile( m_MusicFile );
    ivr->AcquireRTPBridge( m_Connection->GetSwitchMedia()->GetAudioRTPBridge() );
  }else 
  {
    if( call->GetLegIndex() != m_HeldLeg )
      return FALSE;
    m_HeldLeg = -1;
    ivr->ReleaseRTPBridge( m_Connection->GetSwitchMedia()->GetAudioRTPBridge() );
    m_Connection->GetSwitchMedia()->BridgeEndToEnd();
  }
  return TRUE;
}

////////////////////////////////////
SBCSwitchCallFeature_Call_Intercept::SBCSwitchCallFeature_Call_Intercept(
  SBCSwitchConnection * conn,
  const OString & fCode
) : SBCSwitchCallFeature( conn, fCode )
{
}

BOOL SBCSwitchCallFeature_Call_Intercept::Execute( 
  B2BUA::SBCB2BUACall * call
)
{
  SBCSwitchIVRInterface * ivr = dynamic_cast<SBCSwitchIVRInterface*>(call);
  return ivr->AnswerCallIntercept( TRUE );
}

///////////////////////////////////////////////

SBCSwitchCallFeature_Call_Intercept_Reject::SBCSwitchCallFeature_Call_Intercept_Reject(
  SBCSwitchConnection * conn,
  const OString & fCode
) : SBCSwitchCallFeature( conn, fCode )
{
}

BOOL SBCSwitchCallFeature_Call_Intercept_Reject::Execute( 
  B2BUA::SBCB2BUACall * call
)
{
  SBCSwitchIVRInterface * ivr = dynamic_cast<SBCSwitchIVRInterface*>(call);
  return ivr->AnswerCallIntercept( FALSE );
}

















