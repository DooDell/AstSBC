/*
 *
 * UpperRegistration.cxx
 *
 * Open SIP Stack ( OSS )
 *
 * Copyright (c) opensipstack.org.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either expressed or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is OpenSIPStack.
 *
 * The Initial Developer of the Original Code is opensipstack.org.
 *
 * The author of this code is Joegen E. Baclor
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * The OpenSIPStack Library includes some GPL/LGPL code libraries that MAY be 
 * enabled at compile time using the --enable-gpllibs configure switch.  If
 * enabled, the content of this file is published under the terms of GNU 
 * General Public License Version 2.  For a detailed list of the available
 * GPL code, see $(opensipstack)/gnu/README file.
 *
 * $Log: UpperRegistration.cxx,v $
 * Revision 1.25  2009/06/19 07:05:31  joegenbaclor
 * modified upper reg so that it wont rely on via states.  there are User Agents that
 *  do not return via states in the response
 *
 * Revision 1.24  2009/03/20 04:34:24  joegenbaclor
 * Fixed bug in upper-reg where 200 ok for unregister is not sent out
 *
 * Revision 1.23  2009/03/17 02:24:42  joegenbaclor
 * introduced bypassing of ICT responses for fater response time
 *
 * Revision 1.22  2008/12/12 08:57:20  joegenbaclor
 * Bug fixes in encryption and solegy soho calls
 *
 * Revision 1.21  2008/12/02 09:03:41  joegenbaclor
 * Do not encrypt upper-reg relays
 *
 * Revision 1.20  2008/12/01 03:52:14  joegenbaclor
 * Upper reg bug fixes
 *
 * Revision 1.19  2008/11/28 03:50:01  joegenbaclor
 * UNDO Commit:
 *  replaecd none wide character function to the wide character coutnerpart like isspace
 *  to iswspace
 *
 * Revision 1.18  2008/11/27 03:25:34  joegenbaclor
 * Made sure we do not use the IP address of the NAT bining in request URIwhen sending
 *  INVITE to NATted UA
 *
 * Revision 1.17  2008/11/26 03:59:44  joegenbaclor
 * Bug:  Upper reg not encoding NAT binding in contact-uri
 *
 * Revision 1.16  2008/11/25 12:52:45  joegenbaclor
 * Fixed stateful reg bugs for timing out REGISTER
 *
 * Revision 1.15  2008/11/20 11:02:35  joegenbaclor
 * Depcrecated old SIPMessage URI accessors
 *
 * Revision 1.14  2008/10/22 05:06:25  joegenbaclor
 * Added MPL License Header
 *
 *
 */

#include "UpperRegistration.h"
#include "OpenSBC.h"
#include "SBCConfigParams.h"
#include "Router.h"
#include "StatefulUpperRegistration.h"

#define new PNEW

using namespace REGISTRAR;

UpperRegistration::UpperRegistration( 
  const SIPURI & aor,
  const SIPURI & localBinding,
  const SIPURI & localVia,
  Registrar * registrar
) : Registration( aor, registrar, FALSE )
{
  m_LocalBinding = localBinding;
  m_LocalVia = localVia;
  m_StatefulReg = NULL;
}

UpperRegistration::~UpperRegistration()
{
  if( m_CurrentTRN != NULL )
    m_CurrentTRN->SetBypassHandler( NULL, FALSE );
  delete m_StatefulReg;
}


void UpperRegistration::ProcessRequest(
  const SIPMessage & message,
  SIPTransaction * transaction
)
{
  PWaitAndSignal lock( m_TransactionMutex );
  LOG_CONTEXT( LogDetail(), message.GetCallId(), "UPPER REG: " << "New request being processed" );
  if( m_Registrar->m_UpperRegEnableStateful )
  {
    if( m_StatefulReg == NULL )
      m_StatefulReg = new StatefulUpperRegistration( this );
    LOG_CONTEXT( LogDetail(), message.GetCallId(), "UPPER REG: " << "Configured as stateful" );
    m_StatefulReg->OnProcessStatefulReg( message, transaction );
    return;
  }

  OpenSBC & sbc = dynamic_cast<OpenSBC&>(m_Registrar->m_UserAgent);

  /// check if this is unregistration
  OString unregister;
  if( IsUnregister( message, unregister ) )
  {
    LOG_CONTEXT( LogDetail(), message.GetCallId(), "UPPER REG: Received Unregister Request" );
    m_UnregisterRequest = message;
    RemoveRecord( m_UnregisterRequest, unregister );
  }else
  {
    PWaitAndSignal lock(m_RecordListMutex);
    LOG_CONTEXT( LogDetail(), message.GetCallId(), "UPPER REG: Received Registration Request" );
    m_RecordLandFill.RemoveAll();
    Contact contacts;
    AddRecord( message, contacts, TRUE );
  }

  SIPMessage upperReg = message;
  upperReg.ClearInternalHeaders();
  upperReg.SetEncryption( FALSE );
  
  Via via;
  via.SetAddress( m_LocalVia.GetHost() );
  via.SetPort( (WORD)m_LocalVia.GetPort().AsUnsigned() );
  via.SetBranch( ParserTools::GenBranchParameter() );

  SIPURI targetURI;
  BOOL rewriteRequestURI = m_Registrar->m_UpperRegistrationRoutes->FindRoute( upperReg, targetURI, FALSE );
  BOOL rewriteFromDomain = m_Registrar->m_UpperRegRewriteFromDomain;
  BOOL rewriteToDomain = m_Registrar->m_UpperRegRewriteToDomain;

  /// rewrite the request URI.  
  /// this will happen if there is a route entry in Upper-Reg-Routes
  if( rewriteRequestURI )
  {
    SIPURI target = targetURI.GetBasicURI();
    upperReg.SetRequestURI( target );

    OString domain;
    if( targetURI.GetParameter( "domain", domain ) )
    {
      if( rewriteFromDomain && !domain.IsEmpty() )
      {
        From from = upperReg.GetFrom();

        {
          SIPURI uri = from.GetURI();
          //via.AddParameter( "x-reg-fdomain", uri.GetHost(), TRUE );
          m_RegFromDomain = uri.GetHost();
          uri.SetHost( domain );
          from.SetURI( uri );
          upperReg.SetFrom( from );
        }
      }

      if( rewriteToDomain && !domain.IsEmpty() )
      {
        To to = upperReg.GetTo();

        {
          SIPURI uri = to.GetURI();
          ///via.AddParameter( "x-reg-tdomain", uri.GetHost(), TRUE );
          m_RegToDomain = uri.GetHost();
          uri.SetHost( domain );
          to.SetURI( uri );
          upperReg.SetTo( to );
        }
      }
    }
  }

  Contact contact;
  upperReg.GetContactAt( contact, 0 );
  ContactURI curi;
  contact.GetURI( curi, 0 );


  /// we are going to perform a bit of a trick here
  /// we will encode the original contact URI in the via
  OString cURI = curi.GetURI().AsString( FALSE, TRUE, TRUE );
  OString xRegId = ParserTools::EscapeAsRFC2396( (const char *)PBase64::Encode( cURI.c_str() ) );
  //via.AddParameter( "x-reg-id", xRegId );
  m_RegId = xRegId;
  Via uacVia = upperReg.GetTopVia();
  upperReg.AppendVia( via );

  if( upperReg.HasRoute() )
  {
    SIPURI route = message.GetTopRouteURI();
    if( sbc.GetTransportManager()->IsLocalAddressAndPort( route )  )
      upperReg.PopTopRouteURI();
  }

  /// hijack the binding here
  upperReg.RemoveAllContact();
  SIPURI aliasURI = m_LocalBinding;
  
  OString xAliasCURI = curi.GetURI().AsString( FALSE, TRUE, TRUE );
  if( curi.GetURI().IsPrivateNetwork() )
  {
    OStringStream buff;
    buff << ";send-addr=" << uacVia.GetReceiveAddress() << ":" << uacVia.GetRPort();
    xAliasCURI += buff.str();
  }

  OString xAliasRegId = "x-reg-id-" + ParserTools::EscapeAsRFC2396( xAliasCURI.c_str() );
  aliasURI.SetUser( xAliasRegId );
  curi.SetURI( aliasURI );
  LOG_CONTEXT( LogDetail(), message.GetCallId(), "UPPER REG: Rewrite Contact-URI: " << aliasURI);
  upperReg.AppendContact(curi);

  LOG_CONTEXT( LogDetail(), message.GetCallId(), "UPPER REG: Relaying Registration Request" );
  upperReg.SetEncryption(FALSE);
  transaction->GetManager().FindTransactionAndAddEvent( upperReg, FALSE, 0, this );
}

void UpperRegistration::OnTimerExpire(
  SIPTimerEvent & /*timer*/,
  SIPTransaction * transaction
)
{
  SIPMessage response;
  transaction->GetOpeningRequest().CreateResponse( response, SIPMessage::Code408_RequestTimeout, "Upper Registrar Not Responding" );
  LOG_CONTEXT( LogWarning(), response.GetCallId(), "UPPER REG: *** Request Timeout! ***" );
  OnReceivedMessage( response, transaction );
}

void UpperRegistration::OnReceivedMessage(
  const SIPMessage & message,
  SIPTransaction * transaction
)
{
  PWaitAndSignal lock( m_TransactionMutex );
  /// TODO: save the binding here is the response is a 200 ok
  m_CurrentTRN = NULL;
  if( m_Registrar->m_UpperRegEnableStateful )
  {
    m_StatefulReg->OnProcessStatefulRegResponse( message, transaction );
    return;
  }

  SIPMessage upperRegResponse = message;
  upperRegResponse.ClearInternalHeaders();
  Via via = upperRegResponse.PopTopVia();

  if(  upperRegResponse.Is2xx() )
  {
    //if( !upperRegResponse.IsUnregister() )
    //{
      OString &regId = m_RegId;
      //if( via.GetParameter( "x-reg-id", regId ) )
      if( !regId.IsEmpty() )
      {
        regId = ParserTools::UnescapeAsRFC2396( regId );
        PString uri = PBase64::Decode( regId.c_str() );
        
        PWaitAndSignal lock(m_RecordListMutex);
        Registration::Record * rec = m_RecordList.GetAt( uri );
        if( rec != NULL )
        {
          rec->Reset( rec->m_Register );
          Contact contact;
          rec->m_Register.GetContactAt( contact, 0 );
          ContactURI curi;
          contact.GetURI( curi, 0 );
          OString expires( rec->GetInterval() / 1000 );
          curi.SetParameter( "expires", expires );
          upperRegResponse.RemoveAllContact();
          upperRegResponse.AppendContact( curi );
        }
      }else
      {
        LOG_CONTEXT( LogWarning(), upperRegResponse.GetCallId(), "UPPER REG: *** No x-reg-id parameter in 200 Ok via ***" );
        return;
      }
  }else if( upperRegResponse.GetStatusCode() >= SIPMessage::Code300_MultipleChoices )
  {
    OString & regId = m_RegId;
    //if( via.GetParameter( "x-reg-id", regId ) )
    if( !m_RegId.IsEmpty() )
    {
      regId = ParserTools::UnescapeAsRFC2396( regId );
      OString uri = (const char *)PBase64::Decode( regId.c_str() );
      RemoveRecord( upperRegResponse, uri );
    }
  }

  /// rewrite the to-uri to its original form
  OString & tDomain = m_RegToDomain;
  
  //if( via.GetParameter( "x-reg-tdomain", tDomain ) )
  if( !tDomain.IsEmpty() )
  {
    To to = upperRegResponse.GetTo();

    {
      SIPURI uri = to.GetURI();
      uri.SetHost( tDomain );
      to.SetURI( uri );
      upperRegResponse.SetTo( to );
    }
  }

  /// rewrite the from-uri to its original form
  OString & fDomain = m_RegFromDomain;
  //if( via.GetParameter( "x-reg-fdomain", fDomain ) )
  if( !fDomain.IsEmpty() )
  {
    From from = upperRegResponse.GetFrom();
    if( !fDomain.IsEmpty()  )
    {
      SIPURI uri = from.GetURI();
      uri.SetHost( fDomain );
      from.SetURI( uri );
      upperRegResponse.SetFrom( from );
    }
  }
  
  transaction->GetManager().FindTransactionAndAddEvent( upperRegResponse, FALSE, 0 );    
}





