#include "SBCWarningBeepStreamer.h"
#include "SBCInboundCall.h"

#define new PNEW

using namespace B2BUA;

SBCWarningBeepStreamer::SBCWarningBeepStreamer( 
  SBCInboundCall * inboundCall
) : PThread( 10000, PThread::AutoDeleteThread, PThread::NormalPriority, "SBCWarningBeepStreamer" )
{
  m_CallRef = GCCREATEREF( inboundCall, "SBCWarningBeepStreamer::SBCWarningBeepStreamer", "CallSession" );
  Resume();
}

void SBCWarningBeepStreamer::Main()
{
  SBCInboundCall * call = dynamic_cast<SBCInboundCall *>(m_CallRef.GetObject());
  if( call == NULL )
    return;

  call->OnWarningBeepTermination();
}


