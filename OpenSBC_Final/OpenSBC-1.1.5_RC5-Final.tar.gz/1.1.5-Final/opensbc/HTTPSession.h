#ifndef HTTPSESSION_H
#define HTTPSESSION_H

#include <ptclib/pxml.h>
#include <ptclib/http.h>
#include "B2BUAConnection.h"

using namespace B2BUA;

class HTTPSessionManager;

class HTTPSession : public B2BUAConnection::ExternalCallControl
{
  PCLASSINFO( HTTPSession, B2BUAConnection::ExternalCallControl );
public:
  HTTPSession( 
    HTTPSessionManager * manager,
    B2BUAConnection * sipConnection
  );

  virtual ~HTTPSession();

  virtual void OnIVREvent(
    B2BUAConnection * conn,
    const B2BIVRInterface::B2BIVREvent * evt
  );

  BOOL SendIVREVENT( 
    const B2BIVRInterface::B2BIVREvent * evt,
    PMIMEInfo & replyMIME, 
    OString & reply 
  );

  virtual BOOL Start( const SIPMessage & msg );
  virtual BOOL Stop( const SIPMessage & msg );
  virtual BOOL SetupInbound( const SIPMessage & invite );
  virtual void SetupOutbound( SIPMessage & invite );
  virtual void OnCallStart();
  virtual void OnCallStop();
  virtual void OnTransferReject( const SIPMessage & reject );
  virtual void OnDumpCallAuditTrail();
protected:
  BOOL OnPrepareSIPInfo( PMIMEInfo & sendMIME  );
  BOOL SendAUTH( PMIMEInfo & replyMIME, OString & replyBody );
  BOOL OnPrepareAUTHInfo( PMIMEInfo & sendMIME );
  BOOL OnHandleAuthDeny(PMIMEInfo & replyMIME, OString & replyBody);
  BOOL OnHandleAuthChallenge( const SIPMessage & request );
  BOOL OnHandleAuthPending( const SIPMessage & request );
  BOOL SendSETUP( PMIMEInfo & replyMIME, OString & replyBody );
  BOOL OnPrepareSETUPInfo( PMIMEInfo & sendMIME );
  BOOL SendCALLSTART( OString & reply );
  BOOL OnPrepareCALLSTARTInfo( PMIMEInfo & sendMIME );
  BOOL SendCALLSTOP( OString & reply );
  BOOL OnPrepareCALLSTOPInfo( PMIMEInfo & sendMIME );
  BOOL SendCALLREJECT( OString & reply );
  BOOL OnPrepareCALLREJECTInfo( PMIMEInfo & sendMIME );
  void CallDisconnect( const OString & error );

  PURL m_URLIVRResource;
  PURL m_URLAuthResource;
  PURL m_URLSetupResource;
  PURL m_URLTransferRejectResource;
  PURL m_URLCallStartResource;
  PURL m_URLCallStopResource;

  SIPMessage m_CurrentInboundInvite;
  SIPMessage m_CurrentOutboundInvite;
protected:
  B2BUAConnection * m_B2BUAConnection;
  PMutex m_B2BUAConnectionMutex;
  HTTPSessionManager * m_SessionManager;
  PHTTPClient * m_HTTPClient;
  friend class HTTPSessionManager;

  PStringToString m_IVRCookies;
  BOOL m_AuthPending;
  OString m_A1Hash;
  OString m_Routes;
  PTimer m_CallTimer;
  BOOL m_IsMediaServerCall;
  BOOL m_HasSetupMediaServer;
  PDECLARE_NOTIFIER( PTimer, HTTPSession, OnCallTimerExpire );
};

#endif






































































