/*
 *
 * SBCSwitchIVRChannel.h
 *
 * Open SIP Stack ( OSS )
 *
 * Copyright (c) opensipstack.org.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either expressed or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is OpenSIPStack.
 *
 * The Initial Developer of the Original Code is opensipstack.org.
 *
 * The author of this code is Joegen E. Baclor
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * The OpenSIPStack Library includes some GPL/LGPL code libraries that MAY be 
 * enabled at compile time using the --enable-gpllibs configure switch.  If
 * enabled, the content of this file is published under the terms of GNU 
 * General Public License Version 2.  For a detailed list of the available
 * GPL code, see $(opensipstack)/gnu/README file.
 *
 * $Log: SBCSwitchIVRChannel.h,v $
 * Revision 1.2  2009/06/03 11:57:16  joegenbaclor
 * Checking in MOH feature
 *
 *
 */

#ifndef SBCSWITCHIVRCHANNEL_H
#define SBCSWITCHIVRCHANNEL_H

#include "ptlib.h"
#include "ptclib/url.h"
#include "ptclib/pwavfile.h"
#include "ptlib/pipechan.h"
#include "ptclib/delaychan.h"
#include "opal/mediafmt.h"
#include "opal/mediastrm.h"
#include "SBCSwitchIVRResource.h"
#include "OString.h"

using namespace Tools;

namespace SWITCH
{
  class SBCSwitchIVRChannelInterface;
  class SBCSwitchIVRSession;
  class SBCSwitchIVRChannel : public PDelayChannel
  {
    PCLASSINFO(SBCSwitchIVRChannel, PDelayChannel);
    public:
      SBCSwitchIVRChannel(
        unsigned frameDelay, 
        PINDEX frameSize
      );

      ~SBCSwitchIVRChannel();

      virtual BOOL Open(
        SBCSwitchIVRChannelInterface * session
      );

      // overrides from PIndirectChannel
      virtual BOOL IsOpen() const;
      virtual BOOL Close();
      virtual BOOL Read(void * buffer, PINDEX amount);
      virtual BOOL Write(const void * buf, PINDEX len);

      // new functions
      virtual PWAVFile * CreateWAVFile(const PFilePath & fn, BOOL recording = FALSE);

      

      // Incoming channel functions
      virtual BOOL WriteFrame(
        const void * buf, PINDEX len
      ) = 0;
      
      virtual BOOL IsSilenceFrame(
        const void * buf, PINDEX len
      ) const = 0;

      virtual BOOL QueueRecordable(
        SBCSwitchIVRRecordable * newItem
      );

      BOOL StartRecording(
        const PFilePath & fn, 
        unsigned finalSilence = 3000, 
        unsigned maxDuration = 30000
      );

      BOOL EndRecording();
      
      virtual void OnEndPlay( 
        const OString & identifier 
      );

      // Outgoing channel functions
      virtual BOOL ReadFrame(
        void * buffer, 
        PINDEX amount
      ) = 0;

      virtual PINDEX CreateSilenceFrame(
        void * buffer, PINDEX amount
      ) = 0;
      
      virtual void GetBeepData(
        PBYTEArray &, unsigned
      ) { }

      virtual BOOL QueueResource(
        const OString & id, 
        const PURL & url, 
        PINDEX repeat= 1, 
        PINDEX delay = 0
      );

      virtual BOOL QueuePlayable( 
        const OString & id, 
        const OString & type, 
        const OString & str, 
        PINDEX repeat = 1, 
        PINDEX delay = 0, 
        BOOL autoDelete = FALSE
      );

      virtual BOOL QueuePlayable(
        SBCSwitchIVRPlayable * newItem
      );

      virtual BOOL QueueData( 
        const OString & id, 
        const PBYTEArray & data, 
        PINDEX repeat = 1, 
        PINDEX delay = 0
      );

      virtual BOOL QueueFile(
        const OString & id, 
        const OString & fn, 
        PINDEX repeat = 1, 
        PINDEX delay = 0, 
        BOOL autoDelete = FALSE)
      { 
        return QueuePlayable(id, "File", fn, repeat, delay, autoDelete); 
      }


      virtual void FlushQueue();
      
      virtual BOOL IsPlaying() const   
      { 
        return (m_PlayQueue.GetSize() > 0) || m_IsPlaying ; 
      }

      PINLINE const OString & GetMediaFormat() const { return m_MediaFormat; }
      PINLINE BOOL IsMediaPCM() const { return m_MediaFormat == "PCM-16"; }
      PINLINE BOOL IsRecording() const { return m_IsRecording; }
      PINLINE void SetPause(BOOL _pause) { m_IsPaused = _pause; }
      PINLINE void SetName(const OString & name) { m_ChannelName = name; }
      PINLINE unsigned GetSampleFrequency() const{ return m_SampleFrequency; }
      PINLINE void SetIVRSession( SBCSwitchIVRSession * session ){ m_IVRSession = session; };

    protected:
      SBCSwitchIVRChannelInterface * m_ChannelInterface;
      SBCSwitchIVRSession * m_IVRSession;

      unsigned m_SampleFrequency;
      OString m_MediaFormat;
 
      PMutex m_ChannelWriteMutex;
      PMutex m_ChannelReadMutex;
      BOOL m_IsClosed;

      // Incoming audio variables
      BOOL m_IsRecording;
      SBCSwitchIVRRecordable * m_Recordable;
      unsigned m_FinalSilence;
      unsigned m_SilenceRun;

      // Outgoing audio variables
      BOOL m_IsPlaying;
      PMutex m_QueueMutex;
      SBCSwitchIVRQueue m_PlayQueue;
      SBCSwitchIVRPlayable * m_CurrentPlayItem;

      BOOL m_IsPaused;
      int m_SilentCount;
      int m_TotalData;
      PTimer m_DelayTimer;

      OString m_ChannelName;
  };


  //////////////////////////////////////////////////////////////////

  class SBCSwitchIVRChannelPCM : public SBCSwitchIVRChannel
  {
    PCLASSINFO(SBCSwitchIVRChannelPCM, SBCSwitchIVRChannel);

    public:
      SBCSwitchIVRChannelPCM();

    protected:
      virtual BOOL WriteFrame(const void * buf, PINDEX len);
      virtual BOOL ReadFrame(void * buffer, PINDEX amount);
      virtual PINDEX CreateSilenceFrame(void * buffer, PINDEX amount);
      virtual BOOL IsSilenceFrame(const void * buf, PINDEX len) const;
      virtual void GetBeepData(PBYTEArray & data, unsigned ms);
  };

  class SBCSwitchIVRChannelG7231 : public SBCSwitchIVRChannel
  {
    PCLASSINFO(SBCSwitchIVRChannelG7231, SBCSwitchIVRChannel);

    public:
      SBCSwitchIVRChannelG7231();

    protected:
      virtual BOOL WriteFrame(const void * buf, PINDEX len);
      virtual BOOL ReadFrame(void * buffer, PINDEX amount);
      virtual PINDEX CreateSilenceFrame(void * buffer, PINDEX amount);
      virtual BOOL IsSilenceFrame(const void * buf, PINDEX len) const;
      virtual void GetBeepData(PBYTEArray & data, unsigned ms);
  };

  class SBCSwitchIVRChannelG729 : public SBCSwitchIVRChannel
  {
    PCLASSINFO(SBCSwitchIVRChannelG729, SBCSwitchIVRChannel);

    public:
      SBCSwitchIVRChannelG729();

    protected:
      virtual BOOL WriteFrame(const void * buf, PINDEX len);
      virtual BOOL ReadFrame(void * buffer, PINDEX amount);
      virtual PINDEX CreateSilenceFrame(void * buffer, PINDEX amount);
      virtual BOOL IsSilenceFrame(const void * buf, PINDEX len) const;
      virtual void GetBeepData(PBYTEArray & data, unsigned ms);
  };
}

#endif

