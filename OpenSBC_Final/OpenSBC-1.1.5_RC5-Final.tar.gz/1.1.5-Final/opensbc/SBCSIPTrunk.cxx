/*
 *
 * SBCSIPTrunk.cxx
 *
 * Open SIP Stack ( OSS )
 *
 * Copyright (c) opensipstack.org.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either expressed or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is OpenSIPStack.
 *
 * The Initial Developer of the Original Code is opensipstack.org.
 *
 * The author of this code is Joegen E. Baclor
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * The OpenSIPStack Library includes some GPL/LGPL code libraries that MAY be 
 * enabled at compile time using the --enable-gpllibs configure switch.  If
 * enabled, the content of this file is published under the terms of GNU 
 * General Public License Version 2.  For a detailed list of the available
 * GPL code, see $(opensipstack)/gnu/README file.
 *
 * $Log: SBCSIPTrunk.cxx,v $
 * Revision 1.15  2009/03/26 06:32:26  joegenbaclor
 * Added NAT port forwarding support
 *
 * Revision 1.14  2009/03/13 02:52:14  joegenbaclor
 * fixing compile errors in gcc
 *
 * Revision 1.13  2009/03/13 02:26:18  joegenbaclor
 * In this revision, we moved listener configuration to its own
 * page allowing all listeners to be configured seperately.
 * Previous behavior only allowed the main listener to be configured.
 * We have also added a out of dialog handler in the backdoor trunk
 * to allow unsolcited messages like OPTIONS and NOTIFY to passthrough.
 * Both of these functionalities are still under testing.
 *
 * Revision 1.12  2008/12/22 06:51:46  joegenbaclor
 * Application Timers for Alerting and Connect is causing a deadlock on connection destruction.
 * To address this issue, we modified opensipstack to take care of the timers in the ICT Layer.
 *
 * Revision 1.11  2007/10/30 16:39:36  joegenbaclor
 * Modified default thread count for trunks
 *
 * Revision 1.10  2007/10/17 03:17:39  joegenbaclor
 * More work on sip trunks
 *
 * Revision 1.9  2007/10/15 10:37:49  joegenbaclor
 * Minor bug fixes
 *
 * Revision 1.8  2007/10/05 07:14:01  joegenbaclor
 * Introduced new method OnInitialConfigChanged to SIP Trunk to be called on startup
 *
 * Revision 1.7  2007/10/02 16:42:56  joegenbaclor
 * Marking initial release of SIP Trunking
 *
 * Revision 1.6  2007/10/02 06:25:18  joegenbaclor
 * Changed default MS port to 5068
 *
 * Revision 1.5  2007/10/02 06:10:16  joegenbaclor
 * Allowed application layer to set the listener port of the media server
 *
 * Revision 1.4  2007/10/01 16:17:27  joegenbaclor
 * Added transport status page in http admin
 *
 * Revision 1.3  2007/09/12 10:09:39  joegenbaclor
 * Trunks can now send registrations
 *
 * Revision 1.2  2007/09/04 21:58:13  joegenbaclor
 * More work on SIP Trunks.
 *
 * Revision 1.1  2007/08/30 03:21:45  joegenbaclor
 * Added SIP Trunk Classes
 *
 *
 */

#include "SBCSIPTrunk.h"
#include "OString.h"
#include "Version.h"
#include "SBCConfigParams.h"
#include "B2BUAConnection.h"
#include "B2BUAEndPoint.h"
#include "Encryption.h"
#include "SIPUDPTransport.h"
#include "SBCSIPTrunkReg.h"
#include "SBCSIPTrunkEndPoint.h"
#include "SBCSIPTrunkRoutingHandler.h"
using namespace SIPTransports;

#define new PNEW


SBCSIPTrunk::SBCSIPTrunk(
  SBCTrunkProcess * trunkProcess
  ) : SBCTrunk( trunkProcess )
{
  m_UserAgentName = "SIP Trunk";
  m_HasInitConfig = FALSE;
  SBCSIPTrunkEndPoint * ep = new SBCSIPTrunkEndPoint( *this);
  trunkProcess->SetEndPoint( ep );
  SetEndPoint( ep );

  B2BUserAgent::Proxy * proxy = 
    new B2BUserAgent::Proxy( *this, 1, 1024 * 2 );

  SetProxy( proxy );

  m_TrunkRegManager = NULL;
}

SBCSIPTrunk::~SBCSIPTrunk()
{
}

B2BRoutingInterface * SBCSIPTrunk::OnCreateRoutingInterface()
{
  return new SBCSIPTrunkRoutingHandler( *this );
}

void SBCSIPTrunk::OnInitialConfigChanged( 
  OSSAppConfig & config,
  const char * _section 
)
{
  OString section( _section );
  PString trunkConfig = config.GetString( configKeySIPTrunkSection, configKeySIPTrunkConfig, "" );

  if( m_HasInitConfig  )
    return;

  m_HasInitConfig = TRUE;

  int workerThreadCount = 1;
  
  
  
  //B2BUAConnection::SetSeizeTimeout( config.GetInteger( configKeySection, configKeySeizeTimeout, 0 ) );
  //B2BUAConnection::SetAlertingTimeout( config.GetInteger( configKeySection, configKeyAlertingTimeout, 0 ) );
  
  // Enable Feature SIP Session Timers
  GetB2BUAEndPoint()->EnableSessionTimer( FALSE );

  Encryption::Engine::m_Key = (const char *)config.GetString( configKeySection, configKeyEncryptionKey, Encryption::Engine::m_DefKey );
  OString encMode = config.GetString( configKeySection, configKeyEncryption, "XOR" );
  if( encMode *= "XOR" )
    Encryption::Engine::m_Type = Encryption::Engine::Type_XOR;
  else if( encMode *= "DiffShift" )
    Encryption::Engine::m_Type = Encryption::Engine::Type_DiffShift;

 
  m_AcceptAllCalls = TRUE;

  PStringArray privacyDomains;
  for( PINDEX i = 0; i <  config.GetListSize( configKeyPrivacyTrustedDomainSection, configKeyPrivacyDomain ); i++ )
    privacyDomains.AppendString( config.GetListItem( configKeyPrivacyTrustedDomainSection, configKeyPrivacyDomain, i ) );
  AddPrivacyTrustedDomains( privacyDomains, TRUE );
  SetPrivacyDefaultRealm( config.GetString( configKeyPrivacyTrustedDomainSection, configKeyPrivacyDefaultRealm, "" ) );

  OpenSBC * mainSBC = GetTrunkProcess()->GetTrunkManager()->GetMainProcess()->GetSBC();
  SIPURI bindAddress((const char *)config.GetString( configKeySIPTransportSection, configKeyTrunkInterfaceAddress, "sip:*:5064" ));
  PIPSocket::Address iface = PIPSocket::Address( bindAddress.GetHost() );
  if( !iface.IsValid() )
    iface = mainSBC->GetTransportManager()->GetDefaultInterfaceAddress( FALSE );
  WORD port = (WORD)bindAddress.GetPort().AsUnsigned();
  GetDefaultProfile().GetTransportProfile().EnableUDP( iface, port  );

#if ENABLE_TCP_TRANSPORT
  GetDefaultProfile().GetTransportProfile().EnableTCP( iface, port  );
#endif

  Initialize( workerThreadCount );

  m_RoutingHandler->RefreshStaticRoutes();

  if( m_TrunkRegManager == NULL )
    m_TrunkRegManager = new SBCSIPTrunkRegManager( trunkConfig, *this );

  SIPUDPTransport * transport = dynamic_cast<SIPUDPTransport*>( GetB2BUAEndPoint()->GetTransportManager()->GetUDPTransport() );

  PIPSocket::Address laddr;
  WORD lport;
  transport->GetDefaultListenerAddress( laddr, lport );
  OStringStream listenerAddr;
  listenerAddr << "sip:" << laddr << ":" << port;
  this->GetMainTrunk()->SetSIPTrunkURI( listenerAddr.str().c_str() );
}

void SBCSIPTrunk::OnConfigChanged( 
  OSSAppConfig & config,
  const char * _section  
)
{
  OString section( _section );
  PString trunkConfig = config.GetString( configKeySIPTrunkSection, configKeySIPTrunkConfig, "" );

  if( m_HasInitConfig && m_TrunkRegManager != NULL )
  {
    if( section *= configKeySIPTrunkSection )
      m_TrunkRegManager->OnConfigChanged( trunkConfig );

    return;
  }
}

void SBCSIPTrunk::InitTrunkDomains(
  const char * /*config*/
)
{
}

void SBCSIPTrunk::ProcessEvent(
    SIPStackEvent * event
)
{
  TransactionId transactionId = event->GetTransactionId();
  OString method = transactionId.GetMethod().ToUpper();
  if( method *= "REGISTER" )
  {
    m_TrunkRegManager->ProcessStackEvent( event );
  }else
  {
    m_EndPoint->ProcessStackEvent( m_Proxy, event );
  }
}





