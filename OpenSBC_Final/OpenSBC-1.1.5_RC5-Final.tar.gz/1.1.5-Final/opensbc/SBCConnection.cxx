/*
 *
 * SBCConnection.cxx
 *
 * Open SIP Stack ( OSS )
 *
 * Copyright (c) opensipstack.org.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either expressed or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is OpenSIPStack.
 *
 * The Initial Developer of the Original Code is opensipstack.org.
 *
 * The author of this code is Joegen E. Baclor
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * The OpenSIPStack Library includes some GPL/LGPL code libraries that MAY be 
 * enabled at compile time using the --enable-gpllibs configure switch.  If
 * enabled, the content of this file is published under the terms of GNU 
 * General Public License Version 2.  For a detailed list of the available
 * GPL code, see $(opensipstack)/gnu/README file.
 *
 * $Log: SBCConnection.cxx,v $
 * Revision 1.32  2009/05/12 09:34:43  joegenbaclor
 * Fixed bug in solegy route index
 *
 * Revision 1.31  2009/05/02 04:43:37  joegenbaclor
 * Force sedning of BYE when re-INVITE fails.
 *
 * Revision 1.30  2009/04/15 12:27:31  joegenbaclor
 * *** empty log message ***
 *
 * Revision 1.29  2009/04/13 05:48:57  joegenbaclor
 * Removed transport pool
 *
 * Revision 1.28  2009/04/13 03:25:51  joegenbaclor
 * Using session events to trigger accounting send request
 *
 * Revision 1.27  2009/04/06 04:08:41  joegenbaclor
 * Using sIPSessionEvent to signal RTTS packet arrival
 *
 * Revision 1.26  2009/04/02 08:12:20  joegenbaclor
 * Fixed RTTS Client bugs
 *
 * Revision 1.25  2009/03/17 02:24:42  joegenbaclor
 * introduced bypassing of ICT responses for fater response time
 *
 * Revision 1.24  2009/03/05 03:20:21  joegenbaclor
 * Got rid of some compiler warnings in visual studio 2005
 *
 * Revision 1.23  2009/02/18 12:55:11  joegenbaclor
 * Late media support
 *
 * Revision 1.22  2009/02/13 05:25:16  joegenbaclor
 * removed stateless 503 when rate limit is reached.  bad idea because the transaction may send a new response if a transaction is already active and the new invite is just a retransmission
 *
 * Revision 1.21  2009/02/06 09:50:38  joegenbaclor
 * Added email alert notification support
 *
 * Revision 1.20  2009/02/04 06:24:26  joegenbaclor
 * Minor bug fixes.  Added auto destruct timer to SoelgySession.  Added ability to disable local-reg and treat all regs as upper reg.
 *
 * Revision 1.19  2009/02/02 06:13:50  joegenbaclor
 * implemented 3xx handler
 *
 * Revision 1.18  2009/01/29 15:35:38  joegenbaclor
 * removed inbound packet mutex
 *
 * Revision 1.17  2009/01/28 02:39:57  joegenbaclor
 * More work on deadlock detection
 *
 * Revision 1.16  2009/01/27 03:26:37  joegenbaclor
 * added deadlock reset mechanism on preconnect
 *
 * Revision 1.15  2009/01/20 09:17:01  joegenbaclor
 * logging aesthetics
 *
 * Revision 1.14  2009/01/15 09:37:45  joegenbaclor
 * Changed failover behavior for RTTS calls
 *
 * Revision 1.13  2009/01/12 04:50:01  joegenbaclor
 * We modified two things in this commit.  The first is to handle CANCEL requests arriving before an in INVITE is sent out to the upstream termination. Previous implementation did not handle this case properly which results to the call still being attempted even after it was aborted by the caller.  The second bug fix is we introduced m_LocallyAuthenticated in the B2BUAConnection layer so that the SBC can determine cases where both the SBC and the upstream termination both challenged the INVITE resulting to a double authentication.  Although RFC 3261 allows this, we yet have to see UAs that can handle authentication from two realms.  In most cases this call would end up in bad state so its better to just destroy the connection when this happens.
 *
 * Revision 1.12  2009/01/08 12:14:32  joegenbaclor
 * Added state cookie support to allow calls to be disconnected upon restart of osbc
 *
 * Revision 1.11  2009/01/03 12:14:24  joegenbaclor
 * Reimplemented DestroyConenction to enqueue a session event instead to avoid further race conditons and dead locks.
 * We also implemented B2BUAConnection::IsSafeReference() to further guaranty the integrity of connection pointers.
 *
 * Revision 1.10  2008/12/22 06:51:46  joegenbaclor
 * Application Timers for Alerting and Connect is causing a deadlock on connection destruction.
 * To address this issue, we modified opensipstack to take care of the timers in the ICT Layer.
 *
 * Revision 1.9  2008/12/18 03:52:03  joegenbaclor
 * Introduced new failover rule.
 *
 * Revision 1.8  2008/12/17 04:51:35  joegenbaclor
 * Introduced a new handler for cancelled calls in SBCConnection. As opposed to
 * the old behavior of blindly sending CANCEL to the UAS while abruptly destroying the
 * call, the new handler would wait for final response from the UAS before the call
 * is queued for deletion.  Hopefully this would eradicate the chances of race conditions
 * that may happen when multiple methods are interrupted by a call to cancel.
 *
 * Revision 1.7  2008/12/16 12:53:12  joegenbaclor
 * Undo last commit.  Introduced double locking in DestroyConneciton() instead
 *
 * Revision 1.6  2008/12/16 12:37:12  joegenbaclor
 * Modified SBCConnection::EnforceDisconnectedState() to not call DestroyConnection()
 * directl for this may result to a deadlock of two threads are trying to destroy
 * the connection at the same time
 *
 * Revision 1.5  2008/12/01 03:52:14  joegenbaclor
 * Upper reg bug fixes
 *
 * Revision 1.4  2008/10/30 09:54:24  joegenbaclor
 * Fixed missing setstate in 4xx responses resulting to ghost sessions
 *
 * Revision 1.3  2008/10/29 06:24:20  joegenbaclor
 * Addded SBCWArningBeepStreamer class
 * Bug fixes in rtts session destruction
 *
 * Revision 1.2  2008/10/27 10:23:41  joegenbaclor
 * Subclassing B2BUA objects to give OpenSBC a more fine grained control
 *
 * Revision 1.1  2008/10/27 09:44:04  joegenbaclor
 * Subclassing B2BUA objects to give OpenSBC a more fine grained control
 *
 *
 */

#include "SBCConnection.h"
#include "SDPLazyParser.h"
#include "SBCInboundCall.h"
#include "SBCOutboundCall.h"
#include "SBCB2BUAEndPoint.h"
#include "SolegySession.h"

#define new PNEW

using namespace B2BUA;
using namespace SDP;
using namespace B2BUA;
using namespace SOLEGY;

SBCConnection::SBCConnection(
    B2BUAEndPoint & ep,
    const OString & sessionId
) : B2BUAConnection( ep, sessionId )
{
  m_IsAbandoned = FALSE;
}

SBCConnection::~SBCConnection()
{
  if( m_CallController != NULL )
    delete m_CallController;
}

BOOL SBCConnection::IsMerged(
  B2BUACall & call,
  const SIPMessage & message
)
{
  if( m_IsMergedConnection && message.IsResponse() && OnReceivedResponseToMergedInvite( call, message ) )
    return TRUE;
  else if( message.IsCancel() && call.IsMergedCall() && OnReceivedMergedCancel( call, message ) )
    return TRUE;

  return FALSE;
}

void SBCConnection::HandleLeg1PreConnect(
  B2BUACall & call,
  const SIPMessage & msg
)
{
  
  B2BUserAgent& b2bUA = (B2BUserAgent&)GetSessionManager().GetUserAgent();
  if( msg.IsCancel() )
  {
    m_IsAbandoned = TRUE;
    b2bUA.OnCallAbandoned( *this, call, msg );
    HandleAbandonedState( call, msg );
  }else if( msg.IsInvite() )
  {
    /// we got a new invite while the call is still in preconnect
    /// This is probably because this INVITE is a forked of
    /// the previous invite but with a different r-uri
    
    SIPURI oldRURI, newRURI;
    const SIPMessage & oldInvite = call.GetCurrentUASInvite();
    oldInvite.GetRequestURI( oldRURI );
    msg.GetRequestURI( newRURI );

    if( oldRURI.GetUser() != newRURI.GetUser() )
    {
      /// ok different users.  lets check if this is actually a fork
      if( msg.GetFromTag() *= oldInvite.GetFromTag() )
      {
        /// ok this is a fork...
        OnReceivedMergedInvite( call, msg );
      }else
      {
        SIPMessage requestPending;
        msg.CreateResponse( requestPending, SIPMessage::Code491_RequestPending );
        call.SendRequest( requestPending, msg.GetTransaction() );
      }
    }else
    {
      if( m_SessionState != LocalAuthenticationPending )
      {
        SIPMessage requestPending;
        msg.CreateResponse( requestPending, SIPMessage::Code491_RequestPending );
        call.SendRequest( requestPending, msg.GetTransaction() );
      }
    }
  }
}

BOOL SBCConnection::HandleLeg2PreConnect_1xx(
  B2BUACall & call,
  const SIPMessage & msg
)
{
  if( m_IsAbandoned )
  {
    LOG( LogWarning(), "Ignoring 1xx Ok for Cancelled Call" );
    return FALSE;
  }

  B2BUserAgent& b2bUA = (B2BUserAgent&)GetSessionManager().GetUserAgent();
  m_SessionState = Proceeding;
  // ok now we are ringing
  // stop connecting timer and start
  // alerting timer
  //StopAlertingTimer();
  b2bUA.OnAlerting( *this, call, msg );

  if( m_IsExpectingSDPInACK )
    OnIncomingSDPOffer( call, msg );
  else
    OnIncomingSDPAnswer( call, msg );

  if( msg.HasSDP() )
  {
      if( m_IVRContext != NULL )
      IVROnOpenChannel( m_IVRContext );
  }

  return TRUE;
}

BOOL SBCConnection::HandleLeg2PreConnect_2xx(
  B2BUACall & call,
  const SIPMessage & message
)
{
  if( m_IsAbandoned )
  {
    LOG( LogWarning(), "Ignoring 200 Ok for Cancelled Call" );
    return FALSE;
  }

  LOG( LogInfo(), "*** CALL ESTABLISHED *** " );
  SIPMessage msg = message;
  m_SessionState = Connected;

  if( m_IsExpectingSDPInACK )
    OnIncomingSDPOffer( call, msg );
  else
    OnIncomingSDPAnswer( call, msg );

  if( m_IVRContext )
    IVROnOpenChannel( m_IVRContext );

  // check if we would post a warning message
  if( !m_200OkWarning.GetHeaderBody().IsEmpty() )
  {
    // for now we would overrider warning messages
    // with our warning message
    msg.SetWarning( m_200OkWarning );
  }

  if( m_SendSessionKeepAlive )
  {
    GetLeg1Call()->StartSessionKeepAlive( GetKeepAliveInterval() * 1000 );
    GetLeg2Call()->StartSessionKeepAlive( GetKeepAliveInterval() * 1000 );
  }
  return TRUE;
}

void SBCConnection::HandleLeg2PreConnect_3xx(
  B2BUACall & call,
  const SIPMessage & msg
)
{
  B2BUserAgent& b2bUA = (B2BUserAgent&)GetSessionManager().GetUserAgent();
  int statusCode = msg.GetStatusCode();
  if( statusCode < 300 || statusCode >= 400 || m_HasReceivedSDP )
  {
    m_SessionState = Disconnected;
    GetLeg1Call()->SendB2BReject( msg );
    return;
  }
  // check if we should fail over

  SIPMessage newInvite = m_Leg1Call->GetRequest();
  PWaitAndSignal routelock( m_RoutesMutex );
  if( m_Routes.GetSize() >= 1 )
  {
    /// append the Catch all route if defined
    if( m_Routes.GetSize() == 1 && m_UseCatchAllRoute )
    {
      LOG( LogDetail(), "*** TRYING CATCH ALL ROUTE *** " << GetCatchAllRoute() );
      m_Routes.Append( new SIPURI( GetCatchAllRoute() ) );
      m_UseCatchAllRoute = FALSE; /// make sure we dont use it twice
    }else if( m_Routes.GetSize() == 1 && m_WillSendAnnouncement )
    {
      LOG( LogDetail(), "*** SENDING ANNOUNEMENT *** " << GetAnnouncementServerURI() );
      m_Routes.Append( new SIPURI( GetAnnouncementServerURI() ) );
      m_WillSendAnnouncement = FALSE; /// make sure we dont use it twice
    }
      
    // destroy first leg 2 connection
    if( m_Leg2Call != NULL )
    {
      DetachCall( m_Leg2Call->GetCallId(), TRUE );
      m_Leg2Call->Destroy();
      m_Leg2Call = NULL;
    }

    /// Pop the last route that was used prior to fail-over
    if( m_Routes.GetSize() > 0 )
      m_Routes.RemoveAt( 0 );

    LOG( LogInfo(), "*** UPSTREAM REJECT *** Code=" << msg.GetStatusCode() );
    

    if( m_CallController != NULL )
    {
      m_CallController->OnTransferReject( msg );
      return;
    }else if( m_Routes.IsEmpty() && msg.GetContactSize() > 0 )
    {
      /// empty route.  let's honor the redirect
      int contactCount = msg.GetContactSize();
      for( int i = 0; i < contactCount; i++ )
      {
        Contact contact;
        msg.GetContactAt( contact, i );
        int uriCount = contact.GetSize();
        for( int j = uriCount; i < uriCount; j++ )
        {
          ContactURI uri;
          contact.GetURI( uri, j );
          m_Routes.Append( new SIPURI( uri.GetURI() ) );
        }
      }
    }

    if( !m_Routes.IsEmpty() )
    {
      b2bUA.OnRejected( *this, call, msg );
      LOG( LogInfo(), "Connection: Failing over to other routes: Error " << msg.GetStatusCode() );
      Reason reason;
      OStringStream reasonText;
      reasonText << "SIP ;" << "cause=" << msg.GetStatusCode() << " ;" << "text=\"Call Redirect\"";   
      reason.SetHeaderBody( reasonText.str() );
      newInvite.SetReason( reason );
      OnSetupOutbound( newInvite );
      return;
    }else
    {
      m_SessionState = Disconnected;
      SIPMessage response;
      newInvite.CreateResponse( response, SIPMessage::Code480_TemporarilyNotAvailable );
      GetLeg1Call()->SendB2BReject( response );
    }
  } 

}

void SBCConnection::HandleLeg2PreConnect_4xx_6xx(
  B2BUACall & call,
  const SIPMessage & msg
)
{
  B2BUserAgent& b2bUA = (B2BUserAgent&)GetSessionManager().GetUserAgent();
  int statusCode = msg.GetStatusCode();
  
  if( statusCode == 487 || m_HasReceivedSDP )
  {
    m_SessionState = Disconnected;
    GetLeg1Call()->SendB2BReject( msg );
    return;
  }

  // check if we should fail over
  if( statusCode != 401 && statusCode != 407 ) /// Not a redirect NOR a challenge
  {
    SIPMessage newInvite = m_Leg1Call->GetRequest();
    PWaitAndSignal routelock( m_RoutesMutex );
    if( m_Routes.GetSize() >= 1 )
    {
      /// append the Catch all route if defined
      if( m_Routes.GetSize() == 1 && m_UseCatchAllRoute )
      {
        LOG( LogDetail(), "*** TRYING CATCH ALL ROUTE *** " << GetCatchAllRoute() );
        m_Routes.Append( new SIPURI( GetCatchAllRoute() ) );
        m_UseCatchAllRoute = FALSE; /// make sure we dont use it twice
      }else if( m_Routes.GetSize() == 1 && m_WillSendAnnouncement )
      {
        LOG( LogDetail(), "*** SENDING ANNOUNEMENT *** " << GetAnnouncementServerURI() );
        m_Routes.Append( new SIPURI( GetAnnouncementServerURI() ) );
        m_WillSendAnnouncement = FALSE; /// make sure we dont use it twice
      }
        
      // destroy first leg 2 connection
      if( m_Leg2Call != NULL )
      {
        DetachCall( m_Leg2Call->GetCallId(), TRUE );
        m_Leg2Call->Destroy();
        m_Leg2Call = NULL;
      }

      /// Pop the last route that was used prior to fail-over
      if( m_Routes.GetSize() > 0 )
        m_Routes.RemoveAt( 0 );

      LOG( LogInfo(), "*** UPSTREAM REJECT *** Code=" << msg.GetStatusCode() );
      
      if( statusCode >= SIPMessage::Code400_BadRequest )
      {
        if( m_CallController != NULL )
        {
          m_CallController->OnTransferReject( msg );
          return;
        }else if( !m_Routes.IsEmpty() && statusCode != SIPMessage::Code487_RequestCancelled )
        {
          b2bUA.OnRejected( *this, call, msg );
          LOG( LogInfo(), "Connection: Failing over to other routes: Error " << msg.GetStatusCode() );
          Reason reason;
          OStringStream reasonText;
          reasonText << "SIP ;" << "cause=" << msg.GetStatusCode() << " ;" << "text=\"Call Fail-Over\"";   
          reason.SetHeaderBody( reasonText.str() );
          newInvite.SetReason( reason );
          OnSetupOutbound( newInvite );
          return;
        }
      }
    } 
  }else
  {
    if(  (statusCode == 401 || statusCode == 407) && m_LocallyAuthenticated )
    {
      LOG( LogWarning(), "Double Authentication Attempt by both SBC and Upstream!!!" );
      LOG( LogInfo(), "*** UPSTREAM REJECT *** Code=" << msg.GetStatusCode() );
      m_SessionState = Disconnected;
      b2bUA.OnRejected( *this, call, msg );
    }else if( statusCode == 401 || statusCode == 407 ) 
    {
      HandleLeg2PreConnectAuthentication( call, msg );
      return;
    }
  }

  m_SessionState = Disconnected;
  GetLeg1Call()->SendB2BReject( msg );
}

void SBCConnection::HandleLeg2PreConnectAuthentication(
  B2BUACall & /*call*/,
  const SIPMessage & msg
)
{
  int statusCode = msg.GetStatusCode();
  m_SessionState = RemoteAuthenticationPending;
  StartAutoDestructTimer( 32000 );
  SIPMessage challenge;
  if( statusCode == 401 )
  {
    GetLeg1Call()->GetCurrentUASInvite().CreateResponse( challenge, SIPMessage::Code401_Unauthorized, "", TRUE );
    WWWAuthenticate auth;
    if( msg.GetWWWAuthenticate( auth ) )
      challenge.SetWWWAuthenticate( auth );
  }else if( statusCode == 407 )
  {
    GetLeg1Call()->GetCurrentUASInvite().CreateResponse( challenge, SIPMessage::Code407_ProxyAuthenticationRequired, "", TRUE );
    ProxyAuthenticate auth;
    if( msg.GetProxyAuthenticate( auth ) )
      challenge.SetProxyAuthenticate( auth );
  }

  GetLeg1Call()->SendRequest( challenge, GetLeg1Call()->GetCurrentUASInvite().GetTransaction() );
}

void SBCConnection::HandleLeg2PreConnect(
  B2BUACall & call,
  const SIPMessage & msg
)
{
  if( msg.GetCSeqMethod() *= "INVITE" )
  {
    if( msg.Is1xx() )
    {
      if( msg.GetStatusCode() == 100 )
      {
        m_SessionState = Trying;
        return;
      }else
        if( !HandleLeg2PreConnect_1xx( call, msg ) )
          return;
    }else if( msg.Is2xx() )
    {
      if( !HandleLeg2PreConnect_2xx( call, msg ) )
        return;
    }else if( msg.Is3xx() )
    {
      HandleLeg2PreConnect_3xx( call, msg );
      return;
    }else if( !msg.IsRequest()   ) // 3xx - 6xx
    {
      HandleLeg2PreConnect_4xx_6xx( call, msg );
      return;
    }
    GetLeg1Call()->AnswerB2BCall( call, msg );
  }
}

void SBCConnection::OnHandlePreConnectState( 
  B2BUACall & call,
  const SIPMessage & message
)
{
  if( IsMerged( call, message ) )
    return;

  if( m_IsAbandoned )
  {
    HandleAbandonedState( call, message );
    return;
  }

  if( call.GetLegIndex() == 0 )
  {
    HandleLeg1PreConnect( call, message );
  }else if( call.GetLegIndex() == 1 )
  {
    HandleLeg2PreConnect( call, message );
  }

  if( m_SessionState == Disconnected )
  {
    EnforceDisconnectedState( message );    
  } 
}

void SBCConnection::HandleAbandonedState(
  B2BUACall & call,
  const SIPMessage & msg
)
{
  if( call.GetLegIndex() == 0 && msg.IsCancel() )
  {
    SIPMessage ok;
    msg.CreateResponse( ok, SIPMessage::Code200_Ok );
    call.SendRequest( ok, msg.GetTransaction() );
    SIPMessage reqCancelled;
    call.GetRequest().CreateResponse( reqCancelled, SIPMessage::Code487_RequestCancelled );
    call.SendRequest( reqCancelled, call.GetRequest().GetTransaction() );
    
    if( m_SessionState < Connected )
    {
        B2BUACall * leg2Call = GetLeg2Call();
        if( leg2Call != NULL )
        {
          LOG( LogInfo(), "*** CALL ABANDONED *** Sending CANCEL " << GetSessionId() );    
          leg2Call->SendCancel();
        }else
        {
          LOG( LogInfo(), "*** CALL ABANDONED *** Destroying Connection " << GetSessionId() );   
          m_SessionState = Disconnected;
        }
    }
    
    
  }else if( call.GetLegIndex() == 1  )
  {
    if( msg.IsResponse() )
    {
      if( msg.GetCSeqMethod() *= "INVITE" )
      {
        if( msg.Is1xx() )
        {
          if( msg.GetStatusCode() == 100 )
          {
            m_SessionState = Trying;
          }else
          {
            m_SessionState = Proceeding;
          }
          return;
        }else if( msg.GetStatusCode() >= 200 && msg.GetStatusCode() < 300 )
        {
          m_SessionState = Connected;
          call.SetState( CallSession::StateConnected );
          call.InitializeDialogAsUAC( call.GetCurrentUACInvite(), msg );
          call.SendAck( msg );
          call.SendBye();
          m_SessionState = Disconnected;
          EnforceDisconnectedState( msg ); 
        }else
        {
          m_SessionState = Disconnected;
          EnforceDisconnectedState( msg ); 
        }
      }
    }else if( msg.IsBye() )
    {
      /// for some reason we have seen implementations that sends a BYE instead of replying
      /// to an INVITE with an error final response!  
      m_SessionState = Disconnected;
      EnforceDisconnectedState( msg ); 
    }
  }
}

void SBCConnection::EnforceDisconnectedState( 
  const SIPMessage & message 
)
{
  ResourceCounter::IncrementFailedConnection();
  StopCallTimer();
  DestroyConnection( message );  
}


void SBCConnection::OnHandleStateConnected( 
  B2BUACall & call,
  const SIPMessage & msg
)
{
  if( m_IsAbandoned )
  {
    HandleAbandonedState( call, msg );
    return;
  }

  B2BUAConnection::OnHandleStateConnected( call, msg );

  if( msg.GetStatusCode() >= 300  && msg.GetCSeqMethod() == "INVITE" )
  {
    /// Disconnect the call if we receive a 3xx->6xx response for re-invite
    LOG( LogWarning(), "!!! Re-INVITE FAILURE !!!" );
    
    m_SessionState = Disconnected;
    call.SendBye( "Re-INVITE Failure" );

    B2BUACall * otherEnd = NULL;;
    if( call.GetLegIndex() == 1 )
      otherEnd = m_Leg1Call;
    else
      otherEnd = m_Leg2Call;
    
    otherEnd->SendBye( "Re-INVITE Failure" );

    EnforceDisconnectedState( msg ); 
    return;
  }
}

void SBCConnection::WarnTransferUAC()
{
  dynamic_cast<SBCInboundCall*>(GetLeg1Call())->WarnTransferUAC();
}

void SBCConnection::OnFinalizeCallDestruction( 
  SIPSessionEvent & event 
)
{
  B2BUAConnection::OnFinalizeCallDestruction( event );
}

void SBCConnection::OnSessionEvent(
  SIPSessionEvent & sessionEvent
)
{
  if( sessionEvent.GetEvent() < B2BUAConnection::NumSessionEvent )
  {
    B2BUAConnection::OnSessionEvent( sessionEvent );
    return;
  }

  SolegySession * control = dynamic_cast<SolegySession*>(m_CallController);
  

  switch( sessionEvent.GetEvent() )
  {
  case SBCConnection::Event_InitializeCallControl:
    if( control == NULL )
    {
      LOG( LogError(), "No External-Call-Control is available to handle Event_InitializeCallControl" );
      return;
    }
    control->InternalStart( sessionEvent.GetMessage() );
    break;
  case SBCConnection::Event_ProcessCallArrivalQueue:
    ProcessCallArrivalQueue();
    break;
  case SBCConnection::Event_OnReceivedAccountingPacket:
    {
    if( control == NULL )
    {
      LOG( LogError(), "No External-Call-Control is available to handle Event_OnReceivedAccountingPacket" );
      return;
    }

    OString * packet = reinterpret_cast<OString *>(sessionEvent.GetApplicationData());
    if( packet != NULL )
    {
      control->ProcessPacket( *packet );
      delete packet;
    }
    }
    break;
  case Event_OnSendAccountingAuth:
    if( control == NULL )
    {
      LOG( LogError(), "No External-Call-Control is available to handle Event_OnSendAccountingAuth" );
      return;
    }
    control->SendAUTH();
    break;
  case Event_OnSendAccountingSignIn:
    if( control == NULL )
    {
      LOG( LogError(), "No External-Call-Control is available to handle Event_OnSendAccountingSignIn" );
      return;
    }
    control->SendSIGNIN();
    break;
  case Event_OnSendAccountingSetup:
    if( control == NULL )
    {
      LOG( LogError(), "No External-Call-Control is available to handle Event_OnSendAccountingSetup" );
      return;
    }
    control->SendSETUP();
    break;
  case Event_OnSendAccountingCallStart:
    if( control == NULL )
    {
      LOG( LogError(), "No External-Call-Control is available to handle Event_OnSendAccountingCallStart" );
      return;
    }
    control->InternalOnCallStart();
    break;
  case Event_OnSendAccountingCallStop:
    if( control == NULL )
    {
      LOG( LogError(), "No External-Call-Control is available to handle Event_OnSendAccountingCallStop" );
      return;
    }
    control->InternalOnCallStop();
    break;
  case Event_OnSendAccountingError:
    if( control == NULL )
    {
      LOG( LogError(), "No External-Call-Control is available to handle Event_OnSendAccountingError" );
      return;
    }
    control->SendERROR(-1);
    break;
  case Event_OnSendAccountingStop:
    if( control == NULL )
    {
      LOG( LogError(), "No External-Call-Control is available to handle Event_OnSendAccountingStop" );
      return;
    }
    control->InternalStop( sessionEvent.GetMessage() );
    break;
  case Event_OnTransferReject:
    if( control == NULL )
    {
      LOG( LogError(), "No External-Call-Control is available to handle Event_OnTransferReject" );
      return;
    }
    control->InternalOnTransferReject( sessionEvent.GetMessage() );
    break;
  case Event_OnDumpAuditTrail:
    if( control == NULL )
    {
      LOG( LogError(), "No External-Call-Control is available to handle Event_OnDumpAuditTrail" );
      return;
    }
    control->InternalOnDumpCallAuditTrail();
    break;
  }
  
}









