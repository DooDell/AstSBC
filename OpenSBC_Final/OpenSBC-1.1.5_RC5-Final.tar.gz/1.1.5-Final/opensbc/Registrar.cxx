/*
 *
 * Registrar.cxx
 *
 * Open SIP Stack ( OSS )
 *
 * Copyright (c) opensipstack.org.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either expressed or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is OpenSIPStack.
 *
 * The Initial Developer of the Original Code is opensipstack.org.
 *
 * The author of this code is Joegen E. Baclor
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * The OpenSIPStack Library includes some GPL/LGPL code libraries that MAY be 
 * enabled at compile time using the --enable-gpllibs configure switch.  If
 * enabled, the content of this file is published under the terms of GNU 
 * General Public License Version 2.  For a detailed list of the available
 * GPL code, see $(opensipstack)/gnu/README file.
 *
 * $Log: Registrar.cxx,v $
 * Revision 1.21  2009/03/24 11:23:33  joegenbaclor
 * uploading authenticator support for solegy wholesale
 *
 * Revision 1.20  2009/03/14 11:19:02  joegenbaclor
 * added authenticator support in solegy auth
 *
 * Revision 1.19  2009/03/06 03:17:18  joegenbaclor
 * configurable OPTIONS based NAT keep alive support
 *
 * Revision 1.18  2009/02/04 06:24:26  joegenbaclor
 * Minor bug fixes.  Added auto destruct timer to SoelgySession.  Added ability to disable local-reg and treat all regs as upper reg.
 *
 * Revision 1.17  2009/01/29 05:59:01  joegenbaclor
 * Introduced yielding the transport when a certain queue size threshold is reached.
 *
 * Revision 1.16  2009/01/27 09:01:01  joegenbaclor
 * Encountered deadlock in STOP
 *
 * Revision 1.15  2008/11/20 11:02:34  joegenbaclor
 * Depcrecated old SIPMessage URI accessors
 *
 * Revision 1.14  2008/10/06 03:07:24  joegenbaclor
 * Fixed bug in auth-pending where unregister requests are considered new registration
 *
 * Revision 1.13  2008/10/06 02:11:52  joegenbaclor
 * More verbose log entry
 *
 * Revision 1.12  2008/10/05 14:01:41  joegenbaclor
 * Added logging to upper-reg
 * Fixed unquoted realm parameter in proxy authentication
 *
 * Revision 1.11  2008/09/30 09:48:56  joegenbaclor
 * IVR Prompt Manager releated code
 *
 * Revision 1.10  2008/09/29 06:31:15  joegenbaclor
 * fixed more upper reg bugs
 *
 * Revision 1.9  2008/09/22 05:58:35  joegenbaclor
 * Added stateful upper reg classes
 *
 * Revision 1.8  2008/09/12 09:49:44  joegenbaclor
 * - Upper registration bug fixes.
 * - Bring back support for upper reg routing
 * - Bring back support for upper-reg domain rewrite
 *
 * Revision 1.7  2008/09/09 03:31:24  joegenbaclor
 * Upper Registration bug fixes
 *
 * Revision 1.6  2008/09/07 04:20:04  joegenbaclor
 * Got rid of linux compile warnings
 *
 * Revision 1.5  2008/09/04 01:50:21  joegenbaclor
 * 1.  Provided NULL verification of records 2. Corrected typo
 *
 * Revision 1.4  2008/09/04 01:13:16  joegenbaclor
 * Finalized routing via registrar for SLA support
 * Used SetInternalHeader connection method instead of the unsafe AddInternalHeader
 *
 * Revision 1.3  2008/09/02 06:59:19  joegenbaclor
 * *** empty log message ***
 *
 * Revision 1.2  2008/09/02 04:57:39  joegenbaclor
 * Added new upper reg classes
 *
 * Revision 1.1  2008/08/27 03:02:14  joegenbaclor
 * Adding new registrar code
 *
 *
 */


#include "Registrar.h"
#include "UpperRegistrar.h"
#include "OpenSBC.h"
#include "Router.h"
#include "SBCConfigParams.h"

#define new PNEW 
//Events
class RegEvent : public PObject
{
public:
  SIPMessage message;
  SIPTransaction * transaction;
  int action;
};

using namespace REGISTRAR;

Registrar::Registrar( 
  SIPUserAgent & userAgent, 
  BOOL createUpperReg ) : m_UserAgent( userAgent )
{
  m_AcceptAllReg = FALSE;
  m_NATKeepAliveInterval = 15;
  m_UseOptionsNATKeepAlive = FALSE;

  m_EventQueue = new EventQueue( PCREATE_NOTIFIER( OnProcessEvent ), 1 );

  if( createUpperReg )
  {
    m_UpperRegistrar = new UpperRegistrar( userAgent, this );
    m_UpperRegistrationRoutes = new Router();
    m_LandFillCollector = PTimer( 60000 );
    m_LandFillCollector.SetNotifier( PCREATE_NOTIFIER( OnClearLandFill ) );
    m_LandFillCollector.Resume();
  }else
  {
    m_UpperRegistrationRoutes = NULL;
    m_UpperRegistrar = NULL;
  }
  
  m_EnableUpperReg = m_UpperRegistrar != NULL;
  
  m_AllRegAsUpperReg = FALSE;
  m_UpperRegRewriteFromDomain = FALSE;
  m_UpperRegRewriteToDomain = FALSE;
  m_UpperRegEnableStateful = FALSE;
}

Registrar::~Registrar()
{
  m_LandFillCollector.Stop();
  delete m_EventQueue;
  delete m_UpperRegistrar;
  delete m_UpperRegistrationRoutes;
}

void Registrar::OnParseUpperRegRoutes()
{
  PWaitAndSignal configLock( PHTTPConfig::m_HTTPConfigMutex );
  OpenSBC & sbc = dynamic_cast<OpenSBC&>(m_UserAgent);
  OSSAppConfig * config = sbc.GetAppConfig();

  m_UpperRegRewriteFromDomain = config->GetBoolean( configKeyUpperRegistrarSection, configKeyUpperRegRewriteFromDomain, FALSE );
  m_UpperRegRewriteToDomain = config->GetBoolean( configKeyUpperRegistrarSection, configKeyUpperRegRewriteToDomain, FALSE );
  m_UpperRegEnableStateful = config->GetBoolean( configKeyUpperRegistrarSection, configKeyEnableStatefulReg, FALSE );
  m_AllRegAsUpperReg = config->GetBoolean( configKeyUpperRegistrarSection, configKeyAllRegAsUpperReg, FALSE );
  
  OStringArray upperRegistrationRoutes;
  for( PINDEX j = 0; j <  config->GetListSize( configKeyUpperRegistrarSection, configKeyB2BUARouteList ); j++ )
    upperRegistrationRoutes.AppendString( config->GetListItem( configKeyUpperRegistrarSection, configKeyB2BUARouteList, j ) );

  if( upperRegistrationRoutes.GetSize() > 0 )
    m_UpperRegistrationRoutes->Parse( upperRegistrationRoutes );
}

void Registrar::OnReceivedMessage(
  const SIPMessage & message,
  SIPTransaction * transaction
)
{ 
  OpenSBC& sbc = dynamic_cast<OpenSBC&>(m_UserAgent);
  SIPURI ruri = message.GetRequestURI();
  if( (!sbc.GetTransportManager()->IsLocalAddressAndPort( ruri ) || m_AllRegAsUpperReg) && m_EnableUpperReg )
  {
    if( sbc.GetUAMode() == B2BUserAgent::B2BUpperRegMode )
    {
      LOG_CONTEXT( LogInfo(), message.GetCallId(), "*** UPPER REG *** " << message.GetToURI() );
      m_UpperRegistrar->OnReceivedMessage( message, transaction );
      return;
    }/*else if( sbc.GetUAMode() == B2BUserAgent::B2BOnlyMode )
    {
      LOG_CONTEXT( LogInfo(), message.GetCallId(), "*** UPPER REG REJECTED (Mode:B2BOnlyMode)*** " << message.GetToURI() );
      SIPMessage * response = new SIPMessage();
      message.CreateResponse( *response, SIPMessage::Code403_Forbidden, "Unknown Domain" );
      transaction->EnqueueEvent(new SIPEvent( response ));
    }*/
    
  }
  
  if( !message.IsRegister() )
  {
    SIPMessage * response = new SIPMessage();
    message.CreateResponse( *response, SIPMessage::Code400_BadRequest );
    transaction->EnqueueEvent(new SIPEvent( response ));
    return;
  }
  
  LOG_CONTEXT( LogInfo(), message.GetCallId(), "*** LOCAL REG *** " << message.GetToURI() );

  PWaitAndSignal lock( m_RegistrationListMutex );

  /// Clean the land fill as a free ride.  This is good.  
  /// we dont need a separate thread just to clean the garbage
  m_RegistrationLandFill.RemoveAll();  

  OString uri = message.GetToURI().AsString( FALSE, TRUE, FALSE );

  Registration * registration = m_RegistrationList.GetAt( uri.c_str() );
  if( registration == NULL )
  {
    LOG_CONTEXT( LogDetail(), message.GetCallId(), "*** LOCAL REG *** Creating new Registration" );
    registration = new Registration( message.GetToURI(), this, !m_AcceptAllReg );
    m_RegistrationList.SetAt( uri.c_str(), registration );
  }

  Contact contact;
  Registration::RequestAction action = registration->ProcessRequest( message, contact );
  if( action == Registration::Accept  )
  {
    LOG_CONTEXT( LogDetail(), message.GetCallId(), "*** LOCAL REG *** Registration Accepted" );
    SIPMessage * response = new SIPMessage();
    message.CreateResponse( *response, SIPMessage::Code200_Ok );
    if( contact.GetSize() > 0 )
    {
      ContactList clist;
      clist.Append( contact );
      response->SetContactList( clist );
    }
    transaction->EnqueueEvent(new SIPEvent( response ));
  }else if( action == Registration::Challenge )
  {
    LOG_CONTEXT( LogDetail(), message.GetCallId(), "*** LOCAL REG *** Registration being challenged" );
    Authorization auth;
    //let us send a challenge
    const To & to = message.GetTo();

    WWWAuthenticate wwwAuth;
    MD5::Nonce opaque;
    MD5::Nonce nonce( message.GetCallId().c_str() );

    wwwAuth.SetLeadString( "Digest" );
    wwwAuth.AddParameter( "realm", ParserTools::Quote( to.GetURI().GetHost() ) );
    wwwAuth.AddParameter( "nonce", nonce.AsQuotedString() );
    wwwAuth.AddParameter( "opaque", opaque.AsQuotedString() );
    wwwAuth.AddParameter( "algorithm", "MD5" );
    
    SIPMessage * response = new SIPMessage();
    
    message.CreateResponse( *response, SIPMessage::Code401_Unauthorized );
    response->SetWWWAuthenticate( wwwAuth );
    transaction->EnqueueEvent(new SIPEvent( response ));
  }else if ( action == Registration::AuthPending )
  {
    LOG_CONTEXT( LogDetail(), message.GetCallId(), "*** LOCAL REG *** Registration being authenticated" );
    RegEvent * evt = new RegEvent();
    evt->action = Registration::AuthPending;
    evt->message = message;
    evt->transaction = transaction;
    if( !m_EventQueue->EnqueueEvent( evt ) )
      delete evt;
  }
}

void Registrar::OnProcessEvent( EventQueue &, INT _evt )
{
  RegEvent * evt = reinterpret_cast<RegEvent*>(_evt);
  if( evt == NULL )
    return;

  Registration::RequestAction action = static_cast<Registration::RequestAction>(evt->action);
  if( action == Registration::AuthPending )
  {
    OnAuthPending( evt->message, evt->transaction );
  }

   delete evt;
}

void Registrar::OnAuthPending(
  const SIPMessage & message,
  SIPTransaction * transaction
)
{
  OpenSBC& sbc = dynamic_cast<OpenSBC&>(m_UserAgent);
  
  SIPURI account;
  if( !sbc.FindLocalDomainAccount( message.GetToURI(), account ) )
  {
    LOG_CONTEXT( LogDetail(), message.GetCallId(), "*** LOCAL REG *** Registration Rejected" );
    SIPMessage * response = new SIPMessage();
    message.CreateResponse( *response, SIPMessage::Code403_Forbidden );
    transaction->EnqueueEvent(new SIPEvent( response ));
  }else
  {
    Authorization auth;
    message.GetAuthorization( auth );
    MD5::Nonce nonce( message.GetCallId().c_str() );
    OString uri;
    auth.GetParameter( "uri", uri );
    MD5::A2Hash a2( "REGISTER", uri );
    OString accountA1 = account.AsA1Hash();
    MD5::MD5Authorization hash( accountA1, nonce, a2 );
    OString md5Local =  hash.AsString();

    OString authResponse;
    auth.GetParameter( "response", authResponse );
    OString md5Remote = ParserTools::UnQuote( authResponse );
    if( md5Local *= md5Remote )
    {
      LOG_CONTEXT( LogDetail(), message.GetCallId(), "*** LOCAL REG *** Registration Authorized" );

      OString id = message.GetToURI().AsString( FALSE, TRUE, FALSE );
      Registration * registration = m_RegistrationList.GetAt( id.c_str() );
      if( registration == NULL )
      {
        registration = new Registration( message.GetToURI(), this, !m_AcceptAllReg );
        m_RegistrationList.SetAt( id.c_str(), registration );
      }

      OString unregister;
      Contact contact;
      if( registration->IsUnregister( message, unregister ) )
      {
         registration->RemoveRecord( message, unregister );
         registration->ListRecords( contact );
      }else
      {      
        registration->AddRecord( message, contact );
        registration->SetMD5Local( md5Local );
      }

      SIPMessage * response = new SIPMessage();
      message.CreateResponse( *response, SIPMessage::Code200_Ok );
      if( contact.GetSize() > 0 )
      {
        ContactList clist;
        clist.Append( contact );
        response->SetContactList( clist );
      }
      transaction->EnqueueEvent(new SIPEvent( response ));
    }else
    {
      LOG_CONTEXT( LogDetail(), message.GetCallId(), "*** LOCAL REG *** Registration Rejected" );
      SIPMessage * response = new SIPMessage();
      message.CreateResponse( *response, SIPMessage::Code403_Forbidden );
      transaction->EnqueueEvent(new SIPEvent( response ));
    }
  }
}


void Registrar::OnFlushRegistration( Registration * reg )
{
  PWaitAndSignal lock( m_RegistrationListMutex );
  m_RegistrationLandFill.Append( reg );
  m_RegistrationList.DisallowDeleteObjects();
  OString uri = reg->GetURI().AsString( FALSE, TRUE, FALSE );
  m_RegistrationList.RemoveAt( uri.c_str() );
  m_RegistrationList.AllowDeleteObjects();
}

void Registrar::OnClearLandFill( PTimer & timer, INT )
{
  PWaitAndSignal lock( m_RegistrationListMutex );
  m_RegistrationLandFill.RemoveAll(); 
  timer.Reset();
  timer.SetInterval( 60000 );
  timer.Resume();
}

BOOL Registrar::FindRegistrationBinding(
  const SIPMessage & request,
  Contact & contact
)
{
  if( request.IsResponse() )
    return FALSE;

  SIPURI aor = request.GetRequestURI();
  OString uri = aor.AsString( FALSE, TRUE, FALSE );

  Registration * registration = m_RegistrationList.GetAt( uri.c_str() );
  if( registration == NULL )
  {
    aor = request.GetToURI();
    uri = aor.AsString( FALSE, TRUE, FALSE );
    registration = m_RegistrationList.GetAt( uri.c_str() );
    if( registration == NULL )
      return FALSE;
  }

  return registration->GetTranslatedBindings( contact );
}

BOOL Registrar::FindRegistration(
  const SIPURI & aor,
  SIPMessage & reg
)
{
  OString uri = aor.AsString( FALSE, TRUE, FALSE );

  Registration * registration = m_RegistrationList.GetAt( uri.c_str() );
  if( registration == NULL || registration->GetSize() == 0 )
    return FALSE;
  
  reg = (*registration)[0].m_Register;
  reg.AddInternalHeader( "REG-COUNT", OString( registration->GetSize() ) );

  return TRUE;
}



