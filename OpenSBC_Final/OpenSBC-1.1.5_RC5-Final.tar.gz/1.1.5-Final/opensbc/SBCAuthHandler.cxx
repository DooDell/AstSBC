/*
 *
 * SBCAuthHandler.cxx
 * 
  * Open SIP Stack ( OSS )
 *
 * Copyright (c) opensipstack.org.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either expressed or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is OpenSIPStack.
 *
 * The Initial Developer of the Original Code is opensipstack.org.
 *
 * The author of this code is Joegen E. Baclor
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * The OpenSIPStack Library includes some GPL/LGPL code libraries that MAY be 
 * enabled at compile time using the --enable-gpllibs configure switch.  If
 * enabled, the content of this file is published under the terms of GNU 
 * General Public License Version 2.  For a detailed list of the available
 * GPL code, see $(opensipstack)/gnu/README file.
 *
 * $Log: SBCAuthHandler.cxx,v $
 * Revision 1.18  2008/11/20 11:02:34  joegenbaclor
 * Depcrecated old SIPMessage URI accessors
 *
 * Revision 1.17  2008/10/05 14:01:41  joegenbaclor
 * Added logging to upper-reg
 * Fixed unquoted realm parameter in proxy authentication
 *
 * Revision 1.16  2008/08/04 14:00:37  joegenbaclor
 * Reverting Revision 1.117.  It's resulting to a deadlock. We need a better way of assuring
 *  the connection pointer is valid without using mutexes
 *
 * Revision 1.15  2008/08/02 15:34:40  joegenbaclor
 * More HTTP Session work
 *
 * Revision 1.14  2007/12/21 09:48:07  joegenbaclor
 * Added ability to preserve the transaction via the incoming SIP message.  This pointer may be provided to SendRequest so that responses can avoid another search of the transaction from the transaction db.
 *
 * Revision 1.13  2007/12/05 06:17:43  joegenbaclor
 * Added banned host to ACL
 *
 * Revision 1.12  2007/12/04 16:03:14  joegenbaclor
 * Added Access List Verification
 *
 * Revision 1.11  2007/10/24 08:50:31  joegenbaclor
 * Implemented initial FMC support
 *
 * Revision 1.10  2007/07/14 07:53:56  joegenbaclor
 * Migrated code to use new STL based string class
 *
 * Revision 1.9  2007/07/07 15:21:17  joegenbaclor
 * Added iproute2 support for linux
 *
 * Revision 1.8  2007/04/24 02:51:25  joegenbaclor
 * Fixed privacy bug where domain/host is not encoded with the identity
 *
 * Revision 1.7  2007/02/19 08:49:34  joegenbaclor
 * Changes PAssertedIdentity from RouteURI to ContactURI
 *
 * Revision 1.6  2007/02/16 11:09:20  joegenbaclor
 * More work on privacy
 *
 * Revision 1.5  2007/02/15 02:51:44  joegenbaclor
 * Completed trusted domain and proxy authentication support
 *
 * Revision 1.4  2007/02/14 11:22:09  joegenbaclor
 * Added Trusted Domain section
 *
 * Revision 1.3  2007/01/17 00:08:55  joegenbaclor
 * Added SysLog
 *
 * Revision 1.2  2006/08/29 07:45:42  rcolobong
 * Remove warning messages in Windows
 *
 * Revision 1.1  2006/08/14 10:04:59  rcolobong
 * Convert B2BUA to SBC
 * Support MP logging
 *
 * Revision 1.1  2006/07/11 14:34:38  joegenbaclor
 * Initial upload
 *
 *
 */

#include "B2BUA.h"
#include "SBCAuthHandler.h"
#include "B2BUACall.h"
#include "B2BUAConnection.h"
#include "SBCConfigParams.h"
#define new PNEW

using namespace UACORE;
using namespace B2BUA;



SBCAuthHandler::SBCAuthHandler(  
  OpenSBC & b2bua 
) : B2BAuthInterface( b2bua )
{
}

SBCAuthHandler::~SBCAuthHandler()
{
}

SBCAuthHandler::B2BAuthResponse SBCAuthHandler::B2BAuthenticate(
  B2BUAConnection & connection,
  SIPMessage & request,
  ProxyAuthenticate & proxyAuthenticate
)
{
  OpenSBC & sbc = dynamic_cast<OpenSBC&>(GetB2BUA());
  
  if( sbc.WillAcceptAllCalls() )
    return B2BAuthInterface::AuthAccept; /// just accept every call
  else
  {
    if( sbc.IsTrustedDomain( request.GetFrom().GetURI() ) )
      return B2BAuthInterface::AuthAccept;
  }

  if( request.HasProxyAuthorization() )
  {
    ProxyAuthorization auth;
    if( !request.GetProxyAuthorization( auth ) )
    {
      PTRACE( 1, "No Proxy Authorization Header in request" );
      return B2BAuthInterface::AuthReject;
    }

    // WWW-Authenticate: Digest realm=voip.homeunix.org, nonce="48818999e02f8258f3c15c88f7c904e7", opaque="8d99e89591b57e262601a894391e4fe8", algorithm=MD5
    // Authorization: Digest username="2222", realm="voip.homeunix.org", algorithm=MD5, uri="sip:voip.homeunix.org", nonce="48818999e02f8258f3c15c88f7c904e7", opaque="8d99e89591b57e262601a894391e4fe8", response="b06feaf34eea2bd75533bea986e5fab8"
    OString userName;
    OString realm;
    OString uri;
    OString nonce;
    OString opaque;
    OString response;

    if( !auth.GetParameter( "username", userName ) )
    {
      PTRACE( 1, "No User Name specified in AUTHORIZATION" );
      return B2BAuthInterface::AuthReject;
    }

    if( !auth.GetParameter( "realm", realm ) )
    {
      PTRACE( 1, "No Realm specified in AUTHORIZATION" );
      return B2BAuthInterface::AuthReject;
    }

    if( !auth.GetParameter( "uri", uri ) )
    {
      PTRACE( 1, "No URI specified in AUTHORIZATION" );
      return B2BAuthInterface::AuthReject;;
    }

    if( !auth.GetParameter( "nonce", nonce ) )
    {
      PTRACE( 1, "No NONCE specified in AUTHORIZATION" );
      return B2BAuthInterface::AuthReject;
    }

    if( !auth.GetParameter( "response", response ) )
    {
      PTRACE( 1, "No Authorization response in AUTHORIZATION" );
      return B2BAuthInterface::AuthReject;
    }

    OString a1;
    OStringStream userURI;
    userURI << "sip:" << ParserTools::UnQuote( userName ) << "@" << ParserTools::UnQuote( realm );

    SIPURI account;
    SIPURI uuri(userURI.str());
    if( !sbc.FindLocalDomainAccount( uuri, account ) )
      return B2BAuthInterface::AuthReject;

    a1 = account.AsA1Hash();

    MD5::A2Hash a2( request.GetMethod(), uri );
    MD5::MD5Authorization localAuth = MD5::MD5Authorization( a1, ParserTools::UnQuote(nonce), a2 );
    
    OString md5Local =  localAuth.AsString();///MD5::MD5Authorization::Construct( a1.AsString(), ParserTools::UnQuote( nonce ), a2.AsString() );
    
    OString md5Remote = ParserTools::UnQuote( response ); 


    if( md5Local != md5Remote )
    {
      PTRACE( 1,  "Authorization token did not match: " 
        << " Local [" << md5Local << "]" << " Remote [" << md5Remote );

      LOG_IF_DEBUG( LogWarning(), "Authorization token did not match: " 
        << " Local [" << md5Local << "]" << " Remote [" << md5Remote );

      return B2BAuthInterface::AuthReject;
    }
    
    OnPostB2BAuthentication(
      connection,
      request,
      account );


    return B2BAuthInterface::AuthAccept;
  }


  
  /// we didn't find an authorization and this aint a trusted call 

  MD5::Nonce opaque;
  MD5::Nonce nonce;

  SIPParser::From from;
  OString host = request.GetFrom().GetURI().GetHost();

  if( host.ToLower().Trim() == "anonymous.invalid" && !sbc.GetPrivacyDefaultRealm().IsEmpty() )
    host = sbc.GetPrivacyDefaultRealm();
    
  proxyAuthenticate.SetLeadString( "Digest" );
  proxyAuthenticate.AddParameter( "realm", ParserTools::Quote( host ) );
  proxyAuthenticate.AddParameter( "nonce", nonce.AsQuotedString() );
  proxyAuthenticate.AddParameter( "opaque", opaque.AsQuotedString() );
  proxyAuthenticate.AddParameter( "algorithm", "MD5" );

  return B2BAuthInterface::AuthChallenge;
}

BOOL SBCAuthHandler::RequireAuthorizationHash(
  const SIPURI & userURL,
  OString & a1,
  RegisterSession & session
)
{
  OpenSBC & sbc = dynamic_cast<OpenSBC&>(GetB2BUA());
  /// dont process the auth if sbc wants to accept all regs
  if( sbc.WillAcceptAllRegistration() )
    return TRUE;

  SIPURI account;
  if( !sbc.FindLocalDomainAccount( userURL, account ) )
    return FALSE;

  /// Check if the device is capable of Fixed Mobile Convergence
  session.SetFMCCapableDevice( account.FindParameter( "fmc" ) != P_MAX_INDEX  );

  a1 = account.AsA1Hash();
  return TRUE;

}



void SBCAuthHandler::OnPostB2BAuthentication(
  B2BUAConnection & /*connection*/,
  SIPMessage & request,
  const SIPURI & uri
)
{
  OpenSBC & sbc = dynamic_cast<OpenSBC&>(GetB2BUA());

  /// check privacy
  if( request.HasPrivacy() )
  {
    Privacy privacy;
    request.GetPrivacy( privacy );

    if( privacy.GetHeaderBody().Trim() *= "id" )
    {
      SIPURI domainEntry;
      BOOL isTrusted = sbc.IsPrivacyTrustedDomain( uri, domainEntry );
      PAssertedIdentity identity;

      /// now we process trusted
      if( isTrusted )
      {
        ///check if we have a preferred identity
        if( request.GetPPreferredIdentitySize() > 0 )
        {
          PPreferredIdentity preferred = request.GetPPreferredIdentityAt(0);
          identity.SetHeaderBody( preferred.GetHeaderBody() );
          request.RemoveAllPAssertedIdentities();
          request.RemoveAllPPreferredIdentities();
          request.AppendPAssertedIdentity( identity );
        }else if( request.GetPAssertedIdentitySize() > 0 )
        {
          PAssertedIdentity preferred = request.GetPAssertedIdentityAt(0);
          request.RemoveAllPAssertedIdentities();
          request.RemoveAllPPreferredIdentities();
          request.AppendPAssertedIdentity( preferred );
        }else /// didn't provide  anything so lets use the account identity
        {
          OString accountIdentity;
          if( !uri.GetParameter( "identity", accountIdentity ) )
            accountIdentity = uri.GetUser() + "@" + uri.GetHost();
          else
            accountIdentity = accountIdentity + "@" + uri.GetHost();

          SIPURI identityURI(  accountIdentity );
          ContactURI curi;
          curi.SetURI( identityURI );
          identity.AddURI( curi );

          request.RemoveAllPAssertedIdentities();
          request.RemoveAllPPreferredIdentities();
          request.AppendPAssertedIdentity( identity );
        }
      }else
      {
          OString accountIdentity;
          if( !uri.GetParameter( "identity", accountIdentity ) )
            accountIdentity = uri.GetUser() + "@" + uri.GetHost();
          else
            accountIdentity = accountIdentity + "@" + uri.GetHost();

          SIPURI identityURI(  accountIdentity );
          ContactURI curi;
          curi.SetURI( identityURI );
          identity.AddURI( curi );

          request.RemoveAllPAssertedIdentities();
          request.RemoveAllPPreferredIdentities();
          request.AppendPAssertedIdentity( identity );
      }
    }
  }
}

void SBCAuthHandler::OnAuthorized(
  const SIPMessage & request,
  RegisterSession & session 
)
{
  if(  session.IsFMCCapableDevice() )
  {
    PTRACE( 1, "Detected FMC Capable Device Registration" );
    
    /// flag so that hand-off will only happen once per registration
    session.SetFMCCapableDevice( FALSE );
    /// check if the main trunk has a call from this guy
    OpenSBC & sbc = dynamic_cast<OpenSBC&>(GetB2BUA());
    SIPSession::GCRef gcRef = sbc.GetB2BUAEndPoint()->FindGCRefByRemoteURI( request.GetToURI() );
    if( gcRef != NULL )
    {
      B2BUACall * call = dynamic_cast<B2BUACall *>( gcRef.GetObject() );
      if( call != NULL )
      {
        //PWaitAndSignal conn_lock( call->GetB2BUAConnectionMutex() );
        B2BUAConnection * conn = call->GetB2BUAConnection();
        if( conn != NULL )
          conn->TransferCallLocal( request.GetToURI(), call );
      }
    }
  }
}

void SBCAuthHandler::RefreshAccessList()
{
  OSSAppConfig * config = dynamic_cast<OpenSBC&>(GetB2BUA()).GetAppConfig();
  
  /// lock the config to make sure noone can change data via http admin until we are done
  PWaitAndSignal configLock( PHTTPConfig::m_HTTPConfigMutex );

  int aclSize = config->GetListSize( configKeyHostAccessListSection, configKeyTrustedHosts );
  OStringArray networkBlocks;
  for( PINDEX i = 0; i < aclSize; i++ )
    networkBlocks.AppendString( config->GetListItem( configKeyHostAccessListSection, configKeyTrustedHosts, i ) );

  m_AccessList.AddNetworkBlocks( networkBlocks );

  aclSize = config->GetListSize( configKeyHostAccessListSection, configKeyBannedHosts );
  OStringArray bannedNetworkBlocks;
  for( PINDEX i = 0; i < aclSize; i++ )
    bannedNetworkBlocks.AppendString( config->GetListItem( configKeyHostAccessListSection, configKeyBannedHosts, i ) );

  m_AccessList.AddBannedNetworkBlocks( bannedNetworkBlocks );

}

BOOL SBCAuthHandler::B2BVerifyAccessList(
  B2BUAConnection & /*connection*/,
  SIPMessage & invite,
  OString & warning
)
{
  OSSAppConfig * config = dynamic_cast<OpenSBC&>(GetB2BUA()).GetAppConfig();
  
  /// lock the config to make sure noone can change data via http admin until we are done
  PWaitAndSignal configLock( PHTTPConfig::m_HTTPConfigMutex );

  if( invite.GetViaSize() == 0 )
    return FALSE;

  const Via &via = invite.GetTopVia();
  PIPSocket::Address addr = via.GetReceiveAddress();


  if( config->GetBoolean( configKeyHostAccessListSection, configKeyTrustAllHosts, TRUE ) )
  {
    if( config->GetBoolean( configKeyHostAccessListSection, configKeyBanSelectedHosts, TRUE ) )
    {
      if( m_AccessList.IsBannedHost( addr ) )
      {
        OStringStream w;
        w << "Warning: 399 " << addr << " \"Is Not Allowed In Our Access List\"";
        warning = w.str();
        return FALSE;
      }
    }
    return TRUE;
  }



  BOOL trusted = FALSE;

  if( config->GetBoolean( configKeyHostAccessListSection, configKeyBanSelectedHosts, TRUE ) )
  {
    if( m_AccessList.IsBannedHost( addr ) )
    {
      OStringStream w;
      w << "Warning: 399 " << addr << " \"Is Not Allowed In Our Access List\"";
      warning = w.str();
      return FALSE;
    }
  }

  trusted = m_AccessList.IsKnownHost( addr ); 
  
  if( !trusted )
  {
    OStringStream w;
    w << "Warning: 399 " << addr << " \"Is Not Allowed In Our Access List\"";
    warning = w.str();
  }

  return trusted;
}

///////////////////////

void SBCAuthHandler::HandleRequireWWWAuthenticate(
  OnRequireWWWAuthenticate * evt 
)
{
  const SIPMessage & request = evt->GetSIPRequest();
  SIPSession * session = dynamic_cast<SIPSession*>(evt->GetSession().GetObject());
  

  if( !request.IsRegister() || session == NULL )  /// this should not happen but just in case we will treat this as a noop
    return;

  OpenSBC & sbc = dynamic_cast<OpenSBC&>(GetB2BUA());

  if( sbc.WillAcceptAllRegistration() )
  {
    SIPMessage ok;
    request.CreateResponse( ok, SIPMessage::Code200_Ok );
    EnqueueWWWAuthenticateResponse( *session, ok );
    return;
  }

  Authorization auth;
  if( !request.GetAuthorization( auth ) )
  {
    //let us send a challenge
    const To & to = request.GetTo();


    SIPMessage unauthorized;
    request.CreateResponse( unauthorized, SIPMessage::Code401_Unauthorized );

    WWWAuthenticate wwwAuth;
    MD5::Nonce opaque;
    MD5::Nonce nonce;
    wwwAuth.SetLeadString( "Digest" );
    wwwAuth.AddParameter( "realm", ParserTools::Quote( to.GetURI().GetHost() ) );
    wwwAuth.AddParameter( "nonce", nonce.AsQuotedString() );
    wwwAuth.AddParameter( "opaque", opaque.AsQuotedString() );
    wwwAuth.AddParameter( "algorithm", "MD5" );
    unauthorized.SetWWWAuthenticate( wwwAuth );
    EnqueueWWWAuthenticateResponse( *session, unauthorized );
    return;
  }
  
  OString userName, realm, uri, nonce, opaque, response, a1;

  if( !auth.GetParameter( "username", userName ) ||
      !auth.GetParameter( "realm", realm ) ||
      !auth.GetParameter( "uri", uri ) ||
      !auth.GetParameter( "nonce", nonce ) ||
      !auth.GetParameter( "response", response ))
  {
    /// send a 400 bad request
    SIPMessage badRequest;
    request.CreateResponse( badRequest, SIPMessage::Code400_BadRequest );
    EnqueueWWWAuthenticateResponse( *session, badRequest );
    return;
  }

  OStringStream userURI;
  userURI << "sip:" << ParserTools::UnQuote( userName ) << "@" << ParserTools::UnQuote( realm );
  SIPURI userURL( userURI.str() );

  SIPURI account;
  if( !sbc.FindLocalDomainAccount( userURL, account ) )
  {
    SIPMessage forbidden;
    request.CreateResponse( forbidden, SIPMessage::Code403_Forbidden, "No Account Found" );
    EnqueueWWWAuthenticateResponse( *session, forbidden );
    return;
  }

  MD5::A2Hash a2( "REGISTER", uri );
  OString accountA1 = account.AsA1Hash();
  MD5::MD5Authorization hash( accountA1, nonce, a2 );

  OString md5Local =  hash.AsString();
  OString md5Remote = ParserTools::UnQuote( response );

  if( md5Local *= md5Remote )
  {
    SIPMessage ok;
    request.CreateResponse( ok, SIPMessage::Code200_Ok );
    EnqueueWWWAuthenticateResponse( *session, ok );
    return;
  }else
  {
    SIPMessage forbidden;
    request.CreateResponse( forbidden, SIPMessage::Code403_Forbidden, "Invalid Password Supplied" );
    EnqueueWWWAuthenticateResponse( *session, forbidden );
    return;
  }
}

