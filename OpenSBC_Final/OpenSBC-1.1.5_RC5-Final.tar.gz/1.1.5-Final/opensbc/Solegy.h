/*
 *
 * Solegy.h
 *
 * Open SIP Stack ( OSS )
 *
 * Copyright (c) opensipstack.org.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either expressed or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is OpenSIPStack.
 *
 * The Initial Developer of the Original Code is opensipstack.org.
 *
 * The author of this code is Joegen E. Baclor
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * The OpenSIPStack Library includes some GPL/LGPL code libraries that MAY be 
 * enabled at compile time using the --enable-gpllibs configure switch.  If
 * enabled, the content of this file is published under the terms of GNU 
 * General Public License Version 2.  For a detailed list of the available
 * GPL code, see $(opensipstack)/gnu/README file.
 *
 * $Log: Solegy.h,v $
 * Revision 1.42  2009/06/19 09:59:22  joegenbaclor
 * Implemented temporary ban on no funds
 *
 * Revision 1.41  2009/06/18 08:10:49  joegenbaclor
 * implementing event queue reqind for rtts
 *
 * Revision 1.40  2009/06/08 06:30:45  joegenbaclor
 * Added route caching capability to solegy rtts client
 *
 * Revision 1.39  2009/04/14 02:00:10  joegenbaclor
 * Reverting Thread-based transport
 *
 * Revision 1.33  2009/03/13 02:26:19  joegenbaclor
 * In this revision, we moved listener configuration to its own
 * page allowing all listeners to be configured seperately.
 * Previous behavior only allowed the main listener to be configured.
 * We have also added a out of dialog handler in the backdoor trunk
 * to allow unsolcited messages like OPTIONS and NOTIFY to passthrough.
 * Both of these functionalities are still under testing.
 *
 * Revision 1.32  2009/02/23 14:26:18  joegenbaclor
 * Added solegy fraud detection class
 *
 * Revision 1.31  2009/02/12 02:36:04  joegenbaclor
 * More call rate sanity check
 *
 * Revision 1.30  2009/02/09 01:30:02  joegenbaclor
 * minor tweaks
 *
 * Revision 1.29  2009/02/06 09:50:38  joegenbaclor
 * Added email alert notification support
 *
 * Revision 1.28  2009/02/03 05:58:06  joegenbaclor
 * Added ability to not send PING for aggregated RTTS sessions
 *
 * Revision 1.27  2009/02/03 05:12:10  joegenbaclor
 * Minor tweaks
 *
 * Revision 1.26  2009/01/29 13:15:14  joegenbaclor
 * Implemented new queue for commands comming from b2bua connection towrds the solegy client
 *
 * Revision 1.25  2009/01/26 02:16:21  joegenbaclor
 * Ok found why RTTS Client gets deleted unexpectedly.  We are using m_CurrentRTTSIndex which is getting reset when we introduced fwest load rtbe routing
 *
 * Revision 1.24  2009/01/25 04:46:05  joegenbaclor
 * Introduced capability to use only the RTTS server with the lowest load
 *
 * Revision 1.23  2009/01/20 03:38:35  joegenbaclor
 * We modified SolegySessionManager::EnqueueEvent to check if the current packet is read from the same  active socket for the session.  If it came from a different socket other thatn the current socket, it will be silently dropped.  This will prevent the race condition brought about by START failover wherein a response  from the previous START attempt maybe interpreted as a response for the new failover ATTEMPT.  This would have been ok if Solegy RTTS allows START packet to have incrementing SEQ parameter since it can be dropped as stale.
 *
 * Revision 1.22  2009/01/09 12:32:16  joegenbaclor
 * In this build we introduced state cookies for Solegy Calls.  The state cookie would allow OpenSBC to disconnect  calls (both BYE and CALLSTOP) after a restart or a crash happen by reconstructing dialog and RTTS state using the cookie data.  The cookie is created on CALLSTART and will be deleted on CALLSTOP.  When a crash happens, calls may stay  connected making it impossible to bill reliably.  Disconnecting calls on restart would minimize the possibility of runaway calls.
 *
 * Revision 1.21  2009/01/08 12:14:32  joegenbaclor
 * Added state cookie support to allow calls to be disconnected upon restart of osbc
 *
 * Revision 1.20  2008/11/12 08:54:15  joegenbaclor
 * Bug:  Delay registrar evaluation for a solegy controlled domain
 *
 * Revision 1.19  2008/11/12 04:23:46  joegenbaclor
 * Feature: Added registration list to be checked for registered calls
 *
 * Revision 1.18  2008/11/11 02:54:47  joegenbaclor
 * Feature:  Introducing RTTS aggregation of groomer and osbc
 * Bug:  Disconnect calls if ParseRouting has an empty result set
 *
 * Revision 1.17  2008/11/07 08:46:42  joegenbaclor
 * Used EventQueue for Recon post instead
 *
 * Revision 1.16  2008/11/04 02:06:08  joegenbaclor
 * Use separate thread for Recon Informer
 *
 * Revision 1.15  2008/10/22 05:06:25  joegenbaclor
 * Added MPL License Header
 *
 *
 */

#ifndef SOLEGY_H
#define SOLEGY_H

#include "SolegySession.h"
#include "SolegyFraudDetect.h"
#include "Router.h"
#include "Logger.h"
#include <ptlib/sockets.h>
#include <ptclib/inetmail.h>


namespace SOLEGY
{
  using namespace Tools;
  class SolegySessionManager : public PObject, public Logger
  {
    PCLASSINFO( SolegySessionManager, PObject );
  public:

    class ConnectionEvent : public PObject
    {
      PCLASSINFO( ConnectionEvent, PObject );
    public:
      enum EventType
      {
        START,
        STOP,
        CALLSTART,
        CALLSTOP,
        DUMPCAT,
        TRANSFERREJECT
      };

      ConnectionEvent( EventType type, SolegySession * session )
      {
        m_Type = type;
        m_Session = session;
        m_RetryCount = 0;
      }

      ConnectionEvent( EventType type, const SIPMessage & msg, SolegySession * session )
      {
        m_Type = type;
        m_SIPMessage = msg;
        m_Session = session;
        m_RetryCount = 0;
      }

      SIPMessage m_SIPMessage;
      EventType m_Type;
      SolegySession * m_Session;
      int m_RetryCount;
    };

    SolegySessionManager();

    virtual ~SolegySessionManager();

    BOOL Initialize( OpenSBC * sbc );

    BOOL SetSTUNServer( const OString & stunServer );

    BOOL AddRTTSInstance(
      const OString & address,
      BOOL enablePingTimer = TRUE
    );

    BOOL AddRTTSInstance(
      const PIPSocket::Address & address,
      WORD port,
      BOOL enablePingTimer = TRUE
    );

    void DumpCDRRecon( SolegySession * session );

    BOOL SendMailAlert( const PString & subject, const PString & body, const PString & list );

    BOOL CreateMediaServerSession( B2BUAConnection & connection );
    BOOL CreateWSDBSession( B2BUAConnection & connection, const SIPURI &routeParam, const SIPMessage * invite = NULL );
    BOOL CreateCNAMSession( B2BUAConnection & connection );

    SolegySocket * GetTransportWithFewestLoad();
    SolegySocket * GetNextAvailableTransport();
    SolegySocket * GetNextAvailableTransport( 
      const OStringArray & rttsList 
    );
    SolegySocket * GetSpecificTransport(
      const SIPURI & transport,
      BOOL addIfMissing,
      BOOL enablePingTimer = TRUE
    );

    BOOL ProcessRead();

    const PIPSocket::Address & GetRTTSClientAddress()const{ return m_RTTSClientAddress; };

    void EnqueueEvent( 
      const PIPSocket::Address & rttsServer,
      WORD rttsPort,
      const PString & packet ,
      int retryCount = 0
    );

    void EnqueueEvent( 
      const PString & packet,
      int retryCount = 0
    );

    void EnqueueEvent( 
      const PString & packet,
      SolegySession * session
    );

    void EnqueueConnectionEvent( 
      SolegySessionManager::ConnectionEvent * _event
    );

    BOOL DumpCATLog( 
      const char * log 
    );
    
    BOOL OpenCATLog();

    OpenSBC * GetSBC() const{ return m_SBC; };

    BOOL AnnounceRTBEError(
      const OString & errorPacket,
      SolegySession * session,
      const OString & eventId,
      const OString & promptDir = "solegy",
      const OString & language = "english"
    );

    BOOL IsLBHost( const SIPURI & uri )const;

    BOOL IsRoutableDomain( 
      const SIPMessage & invite 
    )const;
    
    BOOL ValidateRegisteredRoute(
      SIPMessage & invite 
    );

    PINLINE const PFilePath & GetRTTSStateDIR()const{ return m_RTTSStateDIR; };
    PINLINE const PFilePath & GetRTTSRouteCacheDIR()const{ return m_RTTSRouteCacheDIR; };
    PINLINE PMutex & GetRTTSRouteCacheMutex(){ return  m_RTTSRouteCacheMutex; };
    
  protected:
    void ValidateRTTSState();
    class ReconPostData : public PObject
    {
      PCLASSINFO( ReconPostData, PObject );
    public:
      PMIMEInfo sendMIME;
      PURL url;
    };

    PDirectory m_SolegyHomeDir;
    PDirectory m_CDRReconDir;

    public:
    EQ::EventQueue * m_EventProcessor;
    PDECLARE_NOTIFIER( EQ::EventQueue, SolegySessionManager, OnProcessEvent );

    EQ::EventQueue * m_ConnectionEventProcessor;
    PDECLARE_NOTIFIER( EQ::EventQueue, SolegySessionManager, OnProcessConnectionEvent );

    protected:
    PDECLARE_NOTIFIER( PThread, SolegySessionManager, ProcessRead );
    PMutex m_RTTSMutex;
    PDICTIONARY( RTTSCollection, PString, SolegySocket );
    OStringArray m_RTTSServerList;
    RTTSCollection m_RTTSClientList;
    PSTUNClient * m_STUNClient;
    BOOL m_ExitRead;
    BOOL m_IsReading;
    WORD m_PortBase;
    WORD m_PortMax;
    DWORD m_CurrentRTTSIndex;
    BOOL m_IsStartUp;
    OpenSBC * m_SBC;

    PHTTPClient m_ReconInformer;
    PLIST( ReconfInformerResourceList, PURL );
    int m_ReconInformerCurrentIndex;
    ReconfInformerResourceList m_ReconfInformerResource;
    PMutex m_ReconfInformerResourceMutex;

    PMutex m_LBHostListMutex;
    PLIST( LBHostList, SIPURI );
    LBHostList m_LBHostList;

    PMutex m_RegistrarDomainListMutex;
    PSortedStringList m_RegistrarDomainList;

    PDICTIONARY(  RTTSSessionList, PString, SolegySession );
    PTimedMutex m_RTTSSessionListMutex;
    RTTSSessionList m_RTTSSessionList;
    PIPSocket::Address m_RTTSClientAddress;
    PTextFile * m_CATLog;
    PTime m_CATDate;
    PMutex m_CATMutex;
    PFilePath m_CATDIR;
    PFilePath m_RTTSStateDIR;
    PFilePath m_RTTSRouteCacheDIR;
    PMutex m_RTTSRouteCacheMutex;
    PSyncPoint m_ExitSync;
    PSyncPoint m_ReadExitSync;
    Router m_CustomErrorPrompts;
    EventQueue * m_ReconQueue;
    BOOL m_UseFewestLoadServer;
    PString m_CurrentRTBEPacket;
    SolegyFraudDetect * m_FraudDetector;
    friend class SolegySession;
    PDICTIONARY( NoFundHostList, PString, PTime );
    PMutex m_NoFundHostListMutex;
    NoFundHostList m_NoFundHostList;
    PDECLARE_NOTIFIER( EventQueue, SolegySessionManager, OnCDRReconPostEvent );
  };
}
#endif


