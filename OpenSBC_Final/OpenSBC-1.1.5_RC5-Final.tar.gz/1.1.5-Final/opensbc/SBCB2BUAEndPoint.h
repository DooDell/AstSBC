/*
 *
 * SBCB2BUAEndPoint.h
 *
 * Open SIP Stack ( OSS )
 *
 * Copyright (c) opensipstack.org.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either expressed or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is OpenSIPStack.
 *
 * The Initial Developer of the Original Code is opensipstack.org.
 *
 * The author of this code is Joegen E. Baclor
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * The OpenSIPStack Library includes some GPL/LGPL code libraries that MAY be 
 * enabled at compile time using the --enable-gpllibs configure switch.  If
 * enabled, the content of this file is published under the terms of GNU 
 * General Public License Version 2.  For a detailed list of the available
 * GPL code, see $(opensipstack)/gnu/README file.
 *
 * $Log: SBCB2BUAEndPoint.h,v $
 * Revision 1.15  2009/04/25 05:22:20  joegenbaclor
 * Change FindOutboundProxy parameter to accept uri instead of the entire sip message
 *
 * Revision 1.14  2009/02/12 02:36:04  joegenbaclor
 * More call rate sanity check
 *
 * Revision 1.13  2009/02/11 07:38:08  joegenbaclor
 * Made cancerate sanity check higher.  Used PtimedMutex for deadlock check to avoid deadlocking on deadlock sanity checks!
 *
 * Revision 1.12  2009/01/29 15:35:38  joegenbaclor
 * removed inbound packet mutex
 *
 * Revision 1.11  2009/01/28 05:45:21  joegenbaclor
 * Introduced new pikes for REGISTER, OPTIONS and NOTIFY
 *
 * Revision 1.10  2009/01/28 04:00:49  joegenbaclor
 * added CANCEL rate check
 *
 * Revision 1.9  2009/01/28 02:39:57  joegenbaclor
 * More work on deadlock detection
 *
 * Revision 1.8  2009/01/27 03:26:37  joegenbaclor
 * added deadlock reset mechanism on preconnect
 *
 * Revision 1.7  2009/01/27 02:20:47  joegenbaclor
 * more deadlock tweaks
 *
 * Revision 1.6  2009/01/25 07:24:23  joegenbaclor
 * Implemented new deadlock detection using 100 trying consecutive occurence
 *
 * Revision 1.5  2009/01/24 03:39:27  joegenbaclor
 * removed rate limit checking from transport layer.
 *
 * Revision 1.4  2009/01/23 11:14:13  joegenbaclor
 * Aded OnInboundPacket callback
 *
 * Revision 1.3  2008/11/03 02:35:09  joegenbaclor
 * Introducing new a la B2BUA-Routes Outbound-Proxy routing and deprecated old global
 *  Outbound-Proxy parameter
 *
 * Revision 1.2  2008/10/27 11:02:28  joegenbaclor
 * Corrected typo
 *
 * Revision 1.1  2008/10/27 09:44:04  joegenbaclor
 * Subclassing B2BUA objects to give OpenSBC a more fine grained control
 *
 *
 */

#ifndef SBCB2BUAENDPOINT_H
#define SBCB2BUAENDPOINT_H

#include "B2BUAEndPoint.h"
#include "OSSAppConfig.h"
#include "Router.h"

using namespace Tools;

namespace B2BUA
{
  class SBCB2BUAEndPoint : public B2BUAEndPoint
  {
    PCLASSINFO( SBCB2BUAEndPoint, B2BUAEndPoint );
  
  public:
    SBCB2BUAEndPoint(
      SIPUserAgent & ua,
      PINDEX sessionThreadCount,
      PINDEX stackSize
    );

    virtual ~SBCB2BUAEndPoint();

    virtual B2BUAConnection * OnCreateB2BUA(
      const SIPMessage & request,
      const OString & sessionId,
      B2BUACall * session
    );

    virtual CallSession * OnCreateServerCallSession(
      SIPMessage & request,
      const OString & sessionId
    );

    virtual CallSession * OnCreateClientCallSession(
      const ProfileUA & profile,
      const OString & sessionId
    );

    virtual BOOL OnInboundPacket( 
      SIPTransportManager & transport, 
      SIPMessage & thePacket 
    );

    virtual BOOL OnOutboundPacket( 
      SIPTransportManager & me, 
      SIPMessage & thePacket 
    );

    BOOL LoadOutboundProxies( 
      OSSAppConfig & config 
    );

    BOOL FindOutboundProxy( 
      const SIPURI & uri, 
      RouteURI & route 
    );

    void DeadLockReset();
    PINLINE void SetCallRateLimit( int limit ){ m_CallRateLimit = limit; };
    PINLINE int GetCallRateLimit()const{ return m_CallRateLimit; }; 
  protected:
    int m_CurrentInviteCounter;
    int m_CurrentOutboundInviteCounter;
    PTime m_LastInviteCounterReset;
    int m_CallRateLimit;
    BOOL m_DropInvites;
    BOOL CheckCallRate( 
      SIPTransportManager & transport, 
      SIPMessage & thePacket 
    );

    int m_CurrentCancelCounter;
    PTime m_LastCancelCounterReset;
    BOOL CheckCancelRate(
      SIPTransportManager & transport, 
      SIPMessage & thePacket 
    );

    int m_CurrentRegisterCounter;
    PTime m_LastRegisterCounterReset;
    BOOL CheckRegisterRate(
      SIPTransportManager & transport, 
      SIPMessage & thePacket 
    );

    int m_CurrentNotifyCounter;
    PTime m_LastNotifyCounterReset;
    BOOL CheckNotifyRate(
      SIPTransportManager & transport, 
      SIPMessage & thePacket 
    );

    int m_CurrentOptionsCounter;
    PTime m_LastOptionsCounterReset;
    BOOL CheckOptionsRate(
      SIPTransportManager & transport, 
      SIPMessage & thePacket 
    );

    PTimedMutex m_DeadLockMutex;
    int m_100TryingConsecutiveAttempts;
    BOOL VerifyDeadLock( 
      SIPTransportManager & transport, 
      SIPMessage & thePacket 
    );

    Router m_OutboundProxies;
  };
}

#endif


