/*
 *
 * UpperRegistrar.cxx
 *
 * Open SIP Stack ( OSS )
 *
 * Copyright (c) opensipstack.org.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either expressed or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is OpenSIPStack.
 *
 * The Initial Developer of the Original Code is opensipstack.org.
 *
 * The author of this code is Joegen E. Baclor
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * The OpenSIPStack Library includes some GPL/LGPL code libraries that MAY be 
 * enabled at compile time using the --enable-gpllibs configure switch.  If
 * enabled, the content of this file is published under the terms of GNU 
 * General Public License Version 2.  For a detailed list of the available
 * GPL code, see $(opensipstack)/gnu/README file.
 *
 * $Log: UpperRegistrar.cxx,v $
 * Revision 1.11  2009/03/14 11:19:02  joegenbaclor
 * added authenticator support in solegy auth
 *
 * Revision 1.10  2009/03/02 04:53:34  joegenbaclor
 * Fixed bug in upper registration as reported by kiaser where x-lite  is not able to register when stateful reg is in effect
 *
 * Revision 1.9  2008/10/22 05:06:25  joegenbaclor
 * Added MPL License Header
 *
 *
 */

#include "UpperRegistrar.h"
#include "UpperRegistration.h"
#include "OpenSBC.h"

using namespace REGISTRAR;

#define new PNEW

UpperRegistrar::UpperRegistrar( 
  SIPUserAgent & userAgent,
  Registrar * registrar
) : Registrar( userAgent, FALSE )
{
  m_Registrar = registrar;
}

void UpperRegistrar::OnReceivedMessage(
  const SIPMessage & message,
  SIPTransaction * transaction
)
{
  if( !message.IsRegister() )
  {
    OnReceivedNoneRegisterRequest( message, transaction );
    return;
  }

  SIPURI targetURI = message.GetRequestURI();
  OpenSBC & sbc = dynamic_cast<OpenSBC &>( m_UserAgent );
  PIPSocket::Address listenerAddress = 0;
  WORD listenerPort = 5060;
  
  if( !sbc.GetTransportManager()->GetListenerAddress( SIPTransport::UDP, targetURI.GetAddress(), listenerAddress, listenerPort ) )
  {
    SIPMessage * response = new SIPMessage();
    message.CreateResponse( *response, SIPMessage::Code500_InternalServerError );
    transaction->EnqueueEvent(new SIPEvent( response ));
    return;
  }

  SIPURI contactUri = message.GetContactTopURI();
  contactUri.SetHost( listenerAddress.AsString() );
  contactUri.SetPort( OString( sbc.GetBackDoorPort() ) );

  PWaitAndSignal lock( m_Registrar->m_RegistrationListMutex );

  /// Clean the land fill as a free ride.  This is good.  
  /// we dont need a separate thread just to clean the garbage
  m_Registrar->m_RegistrationLandFill.RemoveAll();  

  OString aor = message.GetToURI().AsString( FALSE, TRUE, FALSE );

  UpperRegistration * registration = dynamic_cast<UpperRegistration*>(m_Registrar->m_RegistrationList.GetAt( aor.c_str() ));
  if( registration == NULL  )
  {
    if( message.IsUnregister() )
    {
      LOG( LogWarning(), "!!! GOT UNREGISTER FOR A **NON-EXISTING** SESSION !!!" ); 
      SIPMessage * response = new SIPMessage();
      message.CreateResponse( *response, SIPMessage::Code404_NotFound );
      transaction->EnqueueEvent(new SIPEvent( response ));
      return;
    }else
    {
      SIPURI localVia( listenerAddress, listenerPort );
      registration = new UpperRegistration( message.GetToURI(), contactUri, localVia, m_Registrar );
      m_Registrar->m_RegistrationList.SetAt( aor.c_str(), registration );
    }
  }else
  {
    if( message.IsUnregister() )
    {
      LOG( LogWarning(), "!!! GOT UNREGISTER FOR AN EXISTING SESSION !!!" ); 
    }
  }

  registration->ProcessRequest( message, transaction );
}

void UpperRegistrar::OnReceivedNoneRegisterRequest(
  const SIPMessage & message,
  SIPTransaction * transaction
)
{
  if( !message.GetToTag().IsEmpty() )
  {
    /// we must not process mid-dialog request here
    return;
  }

  PWaitAndSignal lock( m_Registrar->m_RegistrationListMutex );

  /// Clean the land fill as a free ride.  This is good.  
  /// we dont need a separate thread just to clean the garbage
  m_Registrar->m_RegistrationLandFill.RemoveAll();  

  OString aor = message.GetToURI().AsString( FALSE, TRUE, FALSE );

  UpperRegistration * registration = dynamic_cast<UpperRegistration*>(m_Registrar->m_RegistrationList.GetAt( aor.c_str() ));
  if( registration == NULL  )
  {
    LOG( LogWarning(), "!!! GOT NONE REGISTER REQUEST FOR A **NON-EXISTING** SESSION !!!" ); 
      SIPMessage * response = new SIPMessage();
      message.CreateResponse( *response, SIPMessage::Code404_NotFound );
      transaction->EnqueueEvent(new SIPEvent( response ));
      return;
  }
  
  registration->ProcessRequest( message, transaction );
}

void UpperRegistrar::OnFlushRegistration( Registration * reg )
{
  m_Registrar->OnFlushRegistration( reg );
}



