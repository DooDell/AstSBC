/*
 *
 * Router.cxx
 *
 * Open SIP Stack ( OSS )
 *
 * Copyright (c) opensipstack.org.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either expressed or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is OpenSIPStack.
 *
 * The Initial Developer of the Original Code is opensipstack.org.
 *
 * The author of this code is Joegen E. Baclor
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * The OpenSIPStack Library includes some GPL/LGPL code libraries that MAY be 
 * enabled at compile time using the --enable-gpllibs configure switch.  If
 * enabled, the content of this file is published under the terms of GNU 
 * General Public License Version 2.  For a detailed list of the available
 * GPL code, see $(opensipstack)/gnu/README file.
 *
 * $Log: Router.cxx,v $
 * Revision 1.42  2009/05/28 13:18:14  joegenbaclor
 * Added from-host support for enum
 *
 * Revision 1.41  2009/05/15 00:23:34  joegenbaclor
 * Corrected bug in enum lookup where enum: scheme is included in dns query.
 *
 * Revision 1.40  2009/05/05 11:37:58  joegenbaclor
 * updated deprecated functions used by xbase
 * updated MSVC 2005 Project files to include XBase classes
 *
 * Revision 1.39  2009/04/13 02:48:13  joegenbaclor
 * *** empty log message ***
 *
 * Revision 1.38  2009/02/10 08:16:09  joegenbaclor
 * Fixed HTTP Config crash
 *
 * Revision 1.37  2008/11/20 11:02:34  joegenbaclor
 * Depcrecated old SIPMessage URI accessors
 *
 * Revision 1.36  2008/09/04 01:13:16  joegenbaclor
 * Finalized routing via registrar for SLA support
 * Used SetInternalHeader connection method instead of the unsafe AddInternalHeader
 *
 * Revision 1.35  2008/09/01 14:44:29  joegenbaclor
 * Commiting interim code for new registrar with SLA support
 *
 * Revision 1.34  2008/08/29 06:21:21  joegenbaclor
 * Added paralllel forking support
 *
 * Revision 1.33  2008/07/27 15:27:01  joegenbaclor
 * more work on HTTP classes
 *
 * Revision 1.32  2008/07/01 12:27:00  joegenbaclor
 * Added Solegy debit module
 *
 * Revision 1.31  2008/06/02 08:42:29  joegenbaclor
 * Merging-in Solegy required patches
 *
 * Revision 1.30  2008/04/22 02:06:56  joegenbaclor
 *  Tracker # 29 -  Included port when looking up enum servers.
 *
 * Revision 1.29  2008/04/09 02:47:31  joegenbaclor
 * 1.  Added PTRACE in Route.cxx to indicate failure to resolve address returned by FindRoute
 * 2.  Fixed possibility of media server listener address binding to 0.0.0.0
 *
 * Revision 1.28  2008/02/28 13:36:15  rcolobong
 * Added feature to rewrite the FROM domain to a specific domain in the B2BUA routes
 *
 * Revision 1.27  2008/02/21 10:18:24  rcolobong
 * Handle multiple routes in ENUMLookup
 *
 * Revision 1.26  2008/02/10 01:37:55  joegenbaclor
 * added new logs to indicate enum success and the route returned
 *
 * Revision 1.25  2008/02/10 01:35:35  joegenbaclor
 * corrected some typos
 *
 * Revision 1.24  2008/02/10 01:31:16  joegenbaclor
 * added log to indicate ENUM lookup errors
 *
 * Revision 1.23  2008/01/28 02:03:11  rcolobong
 * Fix minor bugs in enum domain-squat
 *
 * Revision 1.22  2008/01/24 01:43:52  joegenbaclor
 * Added flag for enum routes to allow rewriting of from domain to squat in the domain resolved through enum
 *
 * Revision 1.21  2007/11/20 07:06:50  joegenbaclor
 * Added support for Request-URI routing
 *
 * Revision 1.20  2007/11/18 16:53:51  joegenbaclor
 * Added support for merged requests ending up in the same connection
 *
 * Revision 1.19  2007/11/14 09:58:16  rcolobong
 * Added support for prefix stripping
 *
 * Revision 1.18  2007/09/19 13:08:29  joegenbaclor
 * Added ability to laod route from external xml file
 *
 * Revision 1.17  2007/07/15 12:27:26  joegenbaclor
 * Added capability to route to registered endpoints using static routes
 * Removed unused config parameters
 *
 * Revision 1.16  2007/07/14 07:53:56  joegenbaclor
 * Migrated code to use new STL based string class
 *
 * Revision 1.15  2007/07/07 15:21:17  joegenbaclor
 * Added iproute2 support for linux
 *
 * Revision 1.14  2007/07/06 14:16:36  rcolobong
 * 1. Route by primary codec
 * 2. Support Upstream proxy routing
 *
 * Revision 1.13  2007/06/18 15:30:36  joegenbaclor
 * Implemented Internal DNS Mapping
 *
 * Revision 1.12  2007/06/17 02:49:25  joegenbaclor
 * Introduced Global lock to PHTTPConfig
 *
 * Revision 1.11  2007/06/13 09:22:01  joegenbaclor
 * Added IVR handler
 *
 * Revision 1.10  2007/05/29 17:43:17  joegenbaclor
 * Initial work on auto attendant
 *
 * Revision 1.9  2007/05/14 06:24:31  joegenbaclor
 * Added DNS Failover and ICMP validation
 *
 * Revision 1.8  2007/04/03 06:06:48  rcolobong
 * 1. Add new method GetAllTargetURIList
 * 2. Update handling of MaxSession in SIPURI parameter
 *
 * Revision 1.7  2007/04/03 04:38:12  joegenbaclor
 * Made sure CALL_TRANSFER_PREFIX is stripped when routing through local registration database
 *
 * Revision 1.6  2007/01/22 10:00:58  joegenbaclor
 * Fixed ProxyRouteRequest
 *
 * Revision 1.5  2007/01/17 00:08:44  joegenbaclor
 * Added SysLog
 *
 * Revision 1.4  2007/01/08 07:13:23  joegenbaclor
 * Added ability to run SBC in pure proxy or pure b2b modes
 *
 * Revision 1.3  2006/11/22 11:33:25  rcolobong
 * 1. Change method FindRoute to HasScheme
 * 2. Fix problem where it "Rounds Robin" in HasScheme method
 *
 * Revision 1.2  2006/10/11 05:04:50  rcolobong
 * Add new method FindRoute where it will search in "OpenSBC Route" based on scheme
 *
 * Revision 1.1  2006/08/14 10:04:59  rcolobong
 * Convert B2BUA to SBC
 * Support MP logging
 *
 * Revision 1.5  2006/08/04 05:14:03  rcolobong
 * 1.  Add getter for Routes
 * 2.  Add support for RTBE Scheme in FindRoute
 *
 * Revision 1.4  2006/07/17 11:36:44  joegenbaclor
 * 1.  More routing enhancements to B2BUA
 *
 * Revision 1.3  2006/07/13 06:53:03  joegenbaclor
 * 1.  Introduced Sanity checks for incoming SIP Message
 * 2.  Corrected bug in SIPURI where enum scheme is not getting recognized.
 * 3.  Added ENUM support to routing
 * 4.  Introduced global routing flag to indicate when and not to rewrite outbound To URI's
 *
 * Revision 1.2  2006/06/23 10:30:54  joegenbaclor
 * This revision marks the first successful call transfer via REFER by OpenB2BUA
 *
 * Revision 1.1  2006/06/20 09:58:11  joegenbaclor
 * *** empty log message ***
 *
 * Revision 1.2  2006/05/19 06:30:37  joegenbaclor
 * 1.  Fixed bug in SIPHeaderB where tag may not be parsed properly if no < > enclosure is present
 * 2.  Various enhancements to OpenSBC and proxy session
 *
 * Revision 1.1  2006/05/17 04:04:48  joegenbaclor
 * Initial upload of OpenSBC files
 *
 *
 */

#include "Router.h"
#include "SDPLazyParser.h"

using namespace SDP;

#define new PNEW

Router::Router()
{
  m_ICMPValidate = FALSE;
  m_MaskTargetURI = FALSE;
}

Router::Router( 
  const OStringArray & routes
)
{
  m_ICMPValidate = FALSE;
  m_MaskTargetURI = FALSE;
  Parse( routes );
}

Router::Router( 
  const PXML & routes
)
{
  m_ICMPValidate = FALSE;
  m_MaskTargetURI = FALSE;
  Parse( routes );
}

Router & Router::operator=( 
  const OStringArray & routes
)
{
  Parse( routes );
  return *this;
}

Router & Router::operator=( 
  const PXML & routes
)
{
  Parse( routes );
  return *this;
}

BOOL Router::Parse( 
  const OStringArray & routes
)
{
  PWaitAndSignal lock( m_RoutesMutex );

  if( routes.GetSize() == 0 )
    return FALSE;

  m_Routes.RemoveAll();

  for( PINDEX i = 0; i < routes.GetSize(); i++ )
    AppendRoute( routes[i] );

  return m_Routes.GetSize() != 0;
}

BOOL Router::Parse( 
  const PXML & routes
)
{
  OStringArray r;
  for( PINDEX i = 0;;i++ )
  {
    PXMLElement * route = routes.GetElement( "route", i );
    if( route == NULL )
      break;

    OStringStream strm;
    strm << "[" << route->GetAttribute( "filter" ) << "] " << route->GetData();
    r.AppendString( strm.str() );
  }
  return Parse( r );
}

BOOL Router::AppendRoute(
  const OString & route
)
{
  PWaitAndSignal lock( m_RoutesMutex );

  RouteRecord * rec = new RouteRecord( this );
  if( !rec->Parse( route ) )
    delete rec;
  else
  {
    PTRACE( 1, "Appending route: " << *rec );
    m_Routes.Append( rec );
    return TRUE;
  }

  return FALSE;
}

BOOL Router::FindRoute(
  const SIPMessage & request,
  SIPURI & target,
  BOOL incrementCurrentRoute,
  BOOL compareMethods,
  BOOL useRequestURI
)
{
  PWaitAndSignal lock( m_RoutesMutex );

  if( !request.IsRequest() )
    return FALSE;

  /// get the To URI
  SIPURI to; 
  if( useRequestURI )
  {
    request.GetRequestURI( to );
    if( to.GetUser().IsEmpty() )
      to = request.GetToURI();
  }else
  {
    to = request.GetToURI();
  }

  OString userName = to.GetUser();

  BOOL ok = FALSE;
  for( PINDEX i = 0; i < m_Routes.GetSize(); i++ )
  {
    ok = FALSE;
    if(  m_Routes[i] *= to )
    {
      if( incrementCurrentRoute )
      {
        ok = m_Routes[i].GetTargetURI( target );
      }else
      {
        ok = m_Routes[i].GetTargetURI( target, 0 );
      }

      if( ok )
      {
        if( target.GetUser().IsEmpty() )
          target.SetUser( userName );

        if( compareMethods )
        {
          /// check if the target uri has a method specified
          OString method;
          if( target.GetParameter( "method", method ) )
          {
            method = ParserTools::UnQuote( method );
            LOG( LogDebug(), "method=" << method << "request.method=" << request.GetMethod() );
            if( request.GetMethod() *= method )
              break;
            else
              continue;
          }else
          {
            LOG( LogDebug(), "method=?" << "request.method=" << request.GetMethod() );
            if( request.IsInvite() )
              break;
            else
              continue;  //searching
          }
        }

        break;
      }
    }
  }

  
  if( ok )
  {
    PIPSocket::Address addr;
    WORD port = 0;

    if( !SIPTransport::Resolve( target, addr, port, SIPTransport::UDP, m_ICMPValidate ) )
      return FALSE;

    if( target.GetUser().IsEmpty() )
      target.SetUser( to.GetUser() );

    PTRACE( 1, "-->> From: " << request.GetFromURI() 
    << " Target: " << request.GetMethod() << " " << target );
  }else
  {
    PTRACE( 1, "*** NO STATIC ROUTE DEFINED *** From: " << request.GetFromURI()  
      <<  " Target: " <<  to );
  }

  return ok;
}

BOOL Router::FindRoute(
  SIPTransportManager & transportManager,
  REGISTRAR::Registrar & regDb,
  const SIPMessage & invite,
  B2BUAConnection & connection,
  BOOL useRequestURI
#ifdef HAS_XBASE
  , SBCXBaseManager * xbase
#endif
)
{
  PWaitAndSignal lock( m_RoutesMutex );

  SIPURI to; 
  if( useRequestURI )
  {
    invite.GetRequestURI( to );
    if( to.GetUser().IsEmpty() )
      to = invite.GetToURI();
  }else
  {
    to = invite.GetToURI();
  }

  OString targetName = to.GetUser();

  /// get the From URI
  const SIPURI & from = invite.GetFromURI();
  OString userName = from.GetUser();

  // get primary media codec here
  SDPLazyParser sdpParser = invite.GetBody();

  // value required for media format
  int payloadType = 0;
  OString formatName;
  SIP::SIPURI mediaURI;
  OString primaryCodec;

  // Get Media Offset
  if( sdpParser.GetMediaFormat( SDPLazyParser::Audio, 0, 0,
    payloadType, formatName, mediaURI ) )
  {
    primaryCodec = formatName;
  }

  BOOL ok = FALSE;
  for( PINDEX i = 0; i < m_Routes.GetSize(); i++ )
  {
    if( m_Routes[i] *= to )
    {
      if( m_Routes[i].HasPrimaryCodec() )
      {
        if( !(primaryCodec *= m_Routes[i].GetPrimaryCodec()) )
          continue;
      }

      if( m_Routes[i].HasRewriteFromDomain() )
      {
        connection.SetInternalHeader( "REWRITE-FROM-DOMAIN", 
          m_Routes[i].GetRewriteFromDomain() );
      }

      if( m_Routes[i].IsParallelFork() )
        connection.SetInternalHeader( "PARALLEL-FORK", "T" );

      const OStringArray & routes = m_Routes[i].GetTargetURIList();
      ok = routes.GetSize() != 0;

      if( ok )
      {
        for( PINDEX j = 0; j < routes.GetSize(); j++ )
        {
          SIPURI routeURI( routes[j] );
          
          if( routeURI.GetScheme() *= "enum" )
          {
            PStringArray enumServer;
            PStringArray routeURIs;
            BOOL domainSquat = (routeURI.FindParameter( "domain-squat" ) != P_MAX_INDEX);


            enumServer.AppendString( routeURI.GetHost().c_str() );

            if( !SIPTransport::ENUMLookup(
              enumServer,
              targetName,
              routeURIs ) )
            {
              LOG( LogWarning(), "ENUM Lookup failed. E164=" << targetName << " SERVER=" <<  enumServer );
              OString altRoute;
              if( routeURI.GetParameter( "alt", altRoute ) && !altRoute.IsEmpty() )
              {
                routeURI = altRoute;
                LOG( LogWarning(), "ENUM Failover Route: " << routeURI );
              }else
                continue;
            }else
            {
              for( PINDEX k = 0; k < routeURIs.GetSize(); ++k )
              {
                SIPURI enumResultURI = OString( routeURIs[k] );
                LOG( LogInfo(), "ENUM Lookup OK. E164=" << targetName << " SERVER=" <<  enumServer << " ROUTE=" << enumResultURI );
                
                if( domainSquat )
                  enumResultURI.AddParameter( "domain-squat", "true" );
                else
                {
                  OString fromHost = routeURI.GetParameter( "from-host" );
                  if( !fromHost.IsEmpty() )
                    enumResultURI.AddParameter( "from-host", fromHost );
                }
                
                if( !AddConnectionRoute( transportManager, regDb, to, enumResultURI, connection ) )
                  return FALSE;
              }

              continue;
            }

            if( domainSquat )
              routeURI.AddParameter( "domain-squat", "true" );
          }

          if( !AddConnectionRoute( 
            transportManager, 
            regDb, 
            to, 
            routeURI, 
            connection
#ifdef HAS_XBASE
            ,xbase
#endif
            ))
          {
            return FALSE;
          }
        }
      }
      break;
    }
  }

  return ok;

}

BOOL Router::HasRoute( 
  SIPURI & to 
)
{
  PWaitAndSignal lock( m_RoutesMutex );


  BOOL ok = FALSE;
  for( PINDEX i = 0; i < m_Routes.GetSize(); i++ )
  {
    if(  m_Routes[i] *= to )
    {
      ok = TRUE;
      break;
    }
  }

  return ok;
}

BOOL Router::FindRoute( 
  const SIPURI & uri,
  SIPURI & target
)
{
  PWaitAndSignal lock( m_RoutesMutex );

  BOOL ok = FALSE;
  for( PINDEX i = 0; i < m_Routes.GetSize(); i++ )
  {
    if(  m_Routes[i] *= uri )
    {
      const OStringArray & routes = m_Routes[i].GetTargetURIList();
      if( routes.GetSize() != 0 )
      {
        ok = TRUE;
        target = routes[0];
      }
      break;
    }
  }

  if( ok && target.GetUser().IsEmpty() )
    target.SetUser( uri.GetUser() );

  return ok;
}


BOOL Router::HasScheme(
  const SIPMessage & request,
  const OString & scheme
)
{
  PWaitAndSignal lock( m_RoutesMutex );

  if( !request.IsRequest() )
    return FALSE;

  /// get the To URI
  SIPURI to = request.GetToURI();

  OString userName = to.GetUser();
  
  for( PINDEX index = 0; index < m_Routes.GetSize(); ++index )
  {
    if( m_Routes[index] *= to )
      return m_Routes[index].HasScheme( scheme );
  }

  return FALSE;
}

BOOL Router::AddConnectionRoute(
  SIPTransportManager & transportManager,
  REGISTRAR::Registrar & regDb,
  const SIPURI & requestURI,
  const SIPURI & route,
  B2BUAConnection & connection
#ifdef HAS_XBASE
  , SBCXBaseManager * xbase
#endif
)
{

  SIPURI routeURI( route );
  OString targetName = requestURI.GetUser();
  
  #ifdef HAS_XBASE
    if( xbase != NULL )
    {
      if( routeURI.GetScheme() *= "xbase" )
      {
        OStringArray xbaseRoutes;
        OString prefixLen = routeURI.GetParameter( "prefix-len" );
        OString xbaseKey = requestURI.GetUser();
        if( xbaseKey.IsEmpty() )
          return FALSE;

        if( !prefixLen.IsEmpty() )
        {
          int startIdx = prefixLen.AsInteger();
          if( startIdx > 0 && startIdx < xbaseKey.GetLength() )
            xbaseKey = xbaseKey.Mid( startIdx );
        }

        if( routeURI.GetHost() *= "lata" )
        {
          xbase->FindLATACarrier( xbaseKey, xbaseRoutes );
        }else if( routeURI.GetHost() *= "npanxx" )
        {
          xbase->FindNPANXX( xbaseKey, xbaseRoutes );
        }

        for( PINDEX i = 0; i < xbaseRoutes.GetSize(); i++ )
        {
          SIPURI xbaseRoute( xbaseRoutes[i] );
          AddConnectionRoute( transportManager, regDb, requestURI, xbaseRoute, connection );
        }

        return TRUE;
      }
    }
  #endif //HAS_XBASE

  BOOL isSIPURI = routeURI.GetScheme().Left(3) == "sip";
  if( isSIPURI )
  {
    if( routeURI.GetUser().IsEmpty() )
    {
      routeURI.SetUser( targetName );
    } else
    {
      PINDEX less = routeURI.GetUser().Find( "(" );
      PINDEX greater = routeURI.GetUser().Find( ")" );

      if( less == 0 && greater != P_MAX_INDEX && greater >= less )
      {
        OString tempUser = routeURI.GetUser();
        OString buff = tempUser.Mid( less+1 , greater-less-1 );

        // remove the "()" in our RouteURI
        tempUser = tempUser.Mid( greater-less+1 );
        routeURI.SetUser( tempUser );
        int buffLen = buff.GetLength();

        if( buff[0] == '-' && buff[buffLen - 1] == '-' )
        {
          targetName = targetName.Mid( buffLen );
        }else if( targetName.Find( buff.c_str() ) == 0 )
        {
          targetName.Replace( buff, "" );
        }
      }

      if( !m_MaskTargetURI && 
        routeURI.GetUser().Find("*") != P_MAX_INDEX )
      {
        OString tempUser = routeURI.GetUser();
        tempUser.Replace( "*", targetName );
        routeURI.SetUser( tempUser );
      }
    }
  }

  PIPSocket::Address verifiedAddress;
  WORD verifiedPort = 0;
  if( isSIPURI && SIPTransport::Resolve( routeURI, verifiedAddress, verifiedPort, SIPTransport::UDP, m_ICMPValidate ) )
  {
    /// IMPORTANT NOTE:  The next block signifies that B2BUA Route entry points back to OpenSBC
    /// In some circumstances, it can be desirable to be able to map certain routes
    /// to a registered user.   Example [sip:1111*] sip:2222@localdomain
    /// in the above example, calls going to 1111 will automatically be routed to 2222
    /// if 2222 is registered.  It must also be noted that this functionality is not forked.
    /// Thus even if there are multiple bindings for the AOR, OpenSBC will ignore the rest
    /// of the binding and use the current primary registrarion.
    if( isSIPURI && transportManager.IsLocalAddressAndPort( routeURI ) )
    {
      /// check if there is a registration 
      SIPMessage registration;
      if( regDb.FindRegistration( routeURI, registration ) )
      {
        Contact contact;
        if( !registration.GetContactAt( contact, 0 ) )
          return FALSE;

        ContactURI contactURI;
        contact.GetURI( contactURI );
        SIPURI targetURI = contactURI.GetURI();

        /// check the via if this is a NATted registration
        Via via;
        if( registration.GetViaAt( registration.GetViaSize() - 1, via ) 
          && via.IsBehindNAT()  
          )
        {
          targetURI.SetHost( via.GetReceiveAddress().AsString() );
          targetURI.SetPort( OString( via.GetRPort() ) );
        }

        if( registration.IsEncrypted() )
          targetURI.AddParameter( "ENCRYPTED", "TRUE" );

        connection.AddRoute( targetURI );
      }
    }else
    {
      /// just add any none SIP route.  Custom call control handlers will be used for this
      connection.AddRoute( routeURI );
    }
  }else
  {
    if( isSIPURI )
    {
      PTRACE( 1, "*** ROUTE DISCARDED *** Unable to resolve " << routeURI << " to a valid IP Address." );
      return FALSE;
    }
    /// just add any none SIP route.  Custom call control handlers will be used for this
    connection.AddRoute( routeURI );
  }

  return connection.GetRoutes().GetSize() > 0;
}
