/*
 *
 * SolegyDebit.cxx
 *
 * Open SIP Stack ( OSS )
 *
 * Copyright (c) opensipstack.org.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either expressed or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is OpenSIPStack.
 *
 * The Initial Developer of the Original Code is opensipstack.org.
 *
 * The author of this code is Joegen E. Baclor
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * The OpenSIPStack Library includes some GPL/LGPL code libraries that MAY be 
 * enabled at compile time using the --enable-gpllibs configure switch.  If
 * enabled, the content of this file is published under the terms of GNU 
 * General Public License Version 2.  For a detailed list of the available
 * GPL code, see $(opensipstack)/gnu/README file.
 *
 * $Log: SolegyDebit.cxx,v $
 * Revision 1.60  2009/05/12 11:06:21  joegenbaclor
 * Fixing bug in latest commit
 *
 * Revision 1.59  2009/05/12 09:34:43  joegenbaclor
 * Fixed bug in solegy route index
 *
 * Revision 1.58  2009/04/14 02:00:10  joegenbaclor
 * Reverting Thread-based transport
 *
 * Revision 1.52  2009/03/14 11:19:02  joegenbaclor
 * added authenticator support in solegy auth
 *
 * Revision 1.51  2009/02/17 03:49:29  joegenbaclor
 * Fixed m_TERMINATINGHOST race condition between SetupOutbound() and SendError() functions
 *
 * Revision 1.50  2009/01/27 09:01:02  joegenbaclor
 * Encountered deadlock in STOP
 *
 * Revision 1.49  2009/01/20 06:33:42  joegenbaclor
 * Delayed connection destruction until solegy session destructor.  Got rid of the connection mutex because we are assured of a valid pointer within the lifetime of
 *  solegy session object
 *
 * Revision 1.48  2009/01/16 09:03:24  joegenbaclor
 * start the number-collect grammar during balance announcement
 *
 * Revision 1.47  2009/01/15 05:42:52  joegenbaclor
 * call OnReceived_SETUP_ERROR if no route is returned by SETUP
 *
 * Revision 1.46  2009/01/14 07:47:28  joegenbaclor
 * Changed default welcome prompt from welcome.wav to hello.wav
 *
 * Revision 1.45  2009/01/14 02:11:11  joegenbaclor
 * Marking Solegy Sesion mem leak fix
 *
 * Revision 1.44  2009/01/03 12:14:24  joegenbaclor
 * Reimplemented DestroyConenction to enqueue a session event instead to avoid further race conditons and dead locks.
 * We also implemented B2BUAConnection::IsSafeReference() to further guaranty the integrity of connection pointers.
 *
 * Revision 1.43  2008/12/12 08:57:20  joegenbaclor
 * Bug fixes in encryption and solegy soho calls
 *
 * Revision 1.42  2008/12/06 05:10:16  joegenbaclor
 * Fixed bug where premature call cancelation for IVR calls may result to the b2bua connection
 *  not getting destroyed.
 *
 * Revision 1.41  2008/11/19 04:10:54  joegenbaclor
 * Bug:  Media server cals unable to properly route to media server listener ue to recent
 *  changes in outbound proxy handling
 *
 * Revision 1.40  2008/10/22 05:06:25  joegenbaclor
 * Added MPL License Header
 *
 *
 */

#include "SolegyDebit.h"
#include "OpenSBC.h"
#include "SBCRoutingHandler.h"
#include "SBCConfigParams.h"

#define new PNEW

using namespace SOLEGY;

#define RTTS_LOG( detail ) \
{ \
  if( m_B2BUAConnection != NULL && m_B2BUAConnection->IsSafeReference() ) \
  LOG( m_B2BUAConnection->LogInfo(), "RTTS: (MS) " << detail ); \
}

SolegyDebit::SolegyDebit( 
  SolegySessionManager * manager,
  SolegySocket * socket,
  B2BUAConnection * sipConnection,
  const char * localSessionId
) : SolegySession( manager, socket, sipConnection, localSessionId )
{
  m_InvalidPinRetry = 0;
  m_InputTimeout = 10000;
  m_IsPINLess = FALSE;
  m_IVR = new SolegyPromptManager( this );
}

SolegyDebit::~SolegyDebit()
{
  delete m_IVR;
}

void SolegyDebit::OnIVREvent(
  B2BUAConnection * conn,
  const B2BIVRInterface::B2BIVREvent * evt
)
{
  if( evt == NULL || conn == NULL  )
    return;

  B2BIVRInterface::B2BIVREvent::Type type = evt->GetType();

  switch( type )
  {
    case B2BIVRInterface::B2BIVREvent::Event_IVROnOpenChannel:
      {
        if( m_State != RESET )
        {
          RTTS_LOG( "Processing Event_IVROnOpenChannel" ); 
          SolegyParser::ParseHeader( "GreetingDelay", m_AUTHResponse, m_GreetingDelay );
          int silence = m_GreetingDelay.AsInteger();
          
          if( silence < 1000 )
            silence = 1000;
          
          IVRAnnounce_Welcome( silence );
          if( m_State == AUTH )
          {
            if( !m_IsPINLess )
              IVRAnnounce_CollectPin();
          }
        }else
        {
          ///anounce I'm sorry here
          IVRAnnounce_CallTransferError();
        }
      }
      break;
    case B2BIVRInterface::B2BIVREvent::Event_IVROnEndPlaying:
      {
        
        //m_PromptTimer.Stop();

        const B2BIVRInterface::OnEndPlaying * eventObject = static_cast<const B2BIVRInterface::OnEndPlaying *>(evt);
        RTTS_LOG( "Processing Event_IVROnEndPlaying - " << eventObject->m_Identifier ); 
        if( eventObject->m_Identifier == "call-transfer" )
          Do_CALLTRANSFER( m_DIALSTRING );
        else if( eventObject->m_Identifier == "balance-prompt"  )
        {
          if( m_EnableDirectDial == "1" )
            Validate_TELNUMBER( m_DIALSTRING );
          else if( m_EnableNumberPrompt == "1" )
            IVRAnnounce_CollectNumber();
          else if( m_EnableDirectDial == "0" && m_EnableNumberPrompt == "0" )
            IVRAnnounce_GoodBye( "normal-call-clearing" );
        }else if( eventObject->m_Identifier == "call-error-reset" )
        {
          if( m_EnableDirectDial == "1" )
          {
            CallDisconnect( "RTTS-0000:  Normal Call Clearing" );
          }else
          {
            m_SessionManager->EnqueueEvent( "SendSIGNIN", this );
          }
        }else if( eventObject->m_Identifier == "goodbye-invalid-pin" )
        {
          CallDisconnect( "RTTS-8018:  PIN Retry Exceeded" );
        }else if( eventObject->m_Identifier == "goodbye-error-no-funds" )
        {
          CallDisconnect( "RTTS-8013:  No Funds Left" );
        }else if( eventObject->m_Identifier == "goodbye-normal-call-clearing" )
        {
          CallDisconnect( "RTTS-0000:  Normal Call Clearing" );
        }else if( eventObject->m_Identifier == "greeting" && m_State == SIGNIN )
        {
          /// 1.  If EnableDirectDial is present and is TRUE, then EnableNumberPrompt is NOT used
          /// 2.  If both are NOT present, then EnableNumberPrompt is TRUE and EnableDirectDial is FALSE
          /// 3.  If both are present and both are FALSE, then call says good-bye after announcing balance
          if( m_EnableDirectDial == "1" )
            m_EnableNumberPrompt = "0";

          if( m_EnableBalancePrompt == "1" )
            IVRAnnounce_Balance();
        }else if( eventObject->m_Identifier == "greeting" && m_State == AUTH && m_IsPINLess )
        {
          m_SessionManager->EnqueueEvent( "SendSIGNIN", this );
        }
      }

      break;
    //case B2BIVRInterface::B2BIVREvent::Event_IVROnUserInput:
    //  break;
    case B2BIVRInterface::B2BIVREvent::Event_IVROnEndCollection:
      {
        const B2BIVRInterface::OnEndCollection * eventObject = static_cast<const B2BIVRInterface::OnEndCollection *>(evt);
      
        RTTS_LOG( "*** DIGITS COLLECTED *** - " << eventObject->m_GrammarId << "[" << eventObject->m_GrammarBuffer << "]" ); 

        if( eventObject->m_GrammarId == "pin-collect" )
        {
          Validate_PIN( eventObject->m_GrammarBuffer );
        }else if( eventObject->m_GrammarId == "number-collect" )
        {
          Validate_TELNUMBER( eventObject->m_GrammarBuffer );
        }
      }
      break;
    case B2BIVRInterface::B2BIVREvent::Event_IVROnTransferReject:
      break;
    case B2BIVRInterface::B2BIVREvent::Event_IVRContextDetach:
      if( m_State < SETUP )
        CallDisconnect( "RTTS-0000:  Normal Call Clearing" );
      break;
    default:
      break;
  } 
}

void SolegyDebit::HandlePreAuthenticatedCall()
{
  /// this is called after the call has been received by the IVR and the greeting has finsihed playing
  /// this may happen if there is no need to get the PIN from the user and instead, just collect the number, 
  /// play the balance or not at all


}

#if 0
void SolegyDebit::OnPromptTimeout( PTimer &, INT )
{
  RTTS_LOG( "Prompt Failure - TIMEOUT" );
  if( m_B2BUAConnection != NULL && m_B2BUAConnection->IsSafeReference() )
  {
    const SIPMessage & invite = m_B2BUAConnection->GetCallArrivalQueue().GetMessage();
    SIPMessage response;
    OString error = "RTTS-8888 IVR Prompt Error";

    invite.CreateResponse( response, SIPMessage::Code480_TemporarilyNotAvailable, error );
    m_B2BUAConnection->GetLeg1Call()->SendRequest( response );
    m_B2BUAConnection->DestroyConnection( response );
  }
}
#endif

void SolegyDebit::IVRAnnounce_Welcome( int silence )
{
  SolegyPrompt prompt( SolegyPrompt::TypePhrase, SolegyPrompt::PR_PRH_WELCOME, "greeting", 0 );
  m_IVR->IVRAnnounce( prompt, silence );
}

void SolegyDebit::IVRAnnounce_CollectPin( int silence )
{
  SolegyPrompt prompt( SolegyPrompt::TypePhrase, SolegyPrompt::PR_PRH_ENTER_PIN, "enter-pin", 0 );
  m_IVR->IVRAnnounce( prompt, silence );
  m_IVR->IVRCollect( "pin-collect", 20, '#' );
}

void SolegyDebit::IVRAnnounce_InvalidPin( int silence )
{
  SolegyPrompt prompt( SolegyPrompt::TypePhrase, SolegyPrompt::PR_PRH_INVALID_PIN, "invalid-pin", 0 );
  m_IVR->IVRAnnounce( prompt, silence );
}

void SolegyDebit::IVRAnnounce_InvalidNumber( int silence )
{
  SolegyPrompt prompt( SolegyPrompt::TypePhrase, SolegyPrompt::PR_PRH_INVALID_NUMBER, "invalid-number", 0 );
  m_IVR->IVRAnnounce( prompt, silence );
}

void SolegyDebit::IVRAnnounce_CallTransferError( int silence )
{
  SolegyPrompt prompt( SolegyPrompt::TypeError, SolegyPrompt::PR_ERROR_CALL_FAILED, "call-error-reset", 0 );
  m_IVR->IVRAnnounce( prompt, silence );
}

void SolegyDebit::IVRAnnounce_AccountDepleted( int silence )
{
  SolegyPrompt prompt( SolegyPrompt::TypeError, SolegyPrompt::PR_ERROR_ACCOUNT_DEPLETED, "error-no-funds", 0 );
  m_IVR->IVRAnnounce( prompt, silence );
}

void SolegyDebit::IVRAnnounce_GoodBye( const OString & reasonId, int silence )
{
  OString id = "goodbye";
  if( !reasonId.IsEmpty() )
  {
    id += "-";
    id += reasonId;
  }
  SolegyPrompt prompt( SolegyPrompt::TypePhrase, SolegyPrompt::PR_PRH_GOOD_BYE, id.c_str(), 0 );
  m_IVR->IVRAnnounce( prompt, silence );
}

void SolegyDebit::IVRAnnounce_WelcomeAndCollectPin( int silence )
{
  IVRAnnounce_Welcome( silence );
  IVRAnnounce_CollectPin();
}

void SolegyDebit::IVRAnnounce_Balance( int silence )
{
  if( m_BALANCE.IsEmpty() || m_BALANCE.GetLength() < 5 )
    return;

  SolegyPrompt prompt( SolegyPrompt::TypePhrase, SolegyPrompt::PR_PRH_INFORM_BALANCE, "you-have", 0 );
  m_IVR->IVRAnnounce( prompt, silence );
  m_IVR->IVRAnnounceCurrency( "balance-prompt", m_BALANCE );
  if( m_EnableDirectDial != "1" )
    m_IVR->IVRCollect( "number-collect", 20, '#' );
}

void SolegyDebit::IVRAnnounce_CollectNumber( int silence )
{
  SolegyPrompt prompt( SolegyPrompt::TypePhrase, SolegyPrompt::PR_PRH_ENTER_NUMBER, "enter-number", 0 );
  m_IVR->IVRAnnounce( prompt, silence );
  m_IVR->IVRCollect( "number-collect", 20, '#' );
}

void SolegyDebit::IVRAnnounce_BalanceAndCollectNumber( int silence )
{
  if( m_BALANCE.IsEmpty() || m_BALANCE.GetLength() < 5 )
    return;

  SolegyPrompt prompt( SolegyPrompt::TypePhrase, SolegyPrompt::PR_PRH_INFORM_BALANCE, "you-have", 0 );
  m_IVR->IVRAnnounce( prompt, silence );
  m_IVR->IVRAnnounceCurrency( "", m_BALANCE );

  IVRAnnounce_CollectNumber();
}

void SolegyDebit::IVRAnnounce_CallDuration( int silence )
{
  OString enableDurationPrompt;
  if( SolegyParser::ParseHeader( "EnableDurationPrompt", enableDurationPrompt, m_AUTHResponse ) && enableDurationPrompt == "1")
  {
    if( SolegyParser::ParseHeader( "BASICBLOCKSLEFT", m_BASICBLOCKSLEFT, m_SETUPResponse ) )
    {
      int bleft = m_BASICBLOCKSLEFT.AsInteger();
      int tleft = bleft;

      if( SolegyParser::ParseHeader( "TIMELEFT", m_TIMELEFT, m_SETUPResponse ) )
        tleft = m_TIMELEFT.AsInteger();

      OString timeleft;
      if( tleft > bleft )
        timeleft = OString( tleft / 60 );
      else
        timeleft = OString( bleft / 60 );

      OStringArray words;
      if( !timeleft.IsEmpty() )
      {
        SolegyPrompt prompt( SolegyPrompt::TypePhrase, SolegyPrompt::PR_PRH_INFORM_TALK_TIME, "you-have", 0 );
        m_IVR->IVRAnnounce( prompt, silence );
        PTimeInterval interval( 0, 0, timeleft.AsUnsigned() );
        m_IVR->IVRAnnounceInterval( "timeleft", interval );
      }
    }
  }
}

void SolegyDebit::IVRAnnounce_CallTransfer( int silence )
{
  if( m_EnableNumberPrompt == "0" && m_EnableDirectDial == "0" )
  {
    IVRAnnounce_GoodBye( "normal-call-clearing" );
  }else
  {
    SolegyPrompt prompt( SolegyPrompt::TypePhrase, SolegyPrompt::PR_PRH_INFORM_CALL_TRANSFER, "call-transfer", 0 );
    m_IVR->IVRAnnounce( prompt, silence );
  }
}

void SolegyDebit::Validate_PIN( const OString & pin )
{
  RTTS_LOG( "Validating PIN" );
  m_ACCOUNTID = pin;
  if( m_ACCOUNTID.IsEmpty() )
  {
    RTTS_LOG( "PIN is EMPTY" );
    if( m_B2BUAConnection != NULL && m_B2BUAConnection->IsSafeReference() )
    {
      if( !m_EnableDigestProcessing )
      {
        if( ++m_InvalidPinRetry < 3 )
        {
          IVRAnnounce_InvalidPin();
          IVRAnnounce_CollectPin();
        }else
        {
          IVRAnnounce_InvalidPin();
          IVRAnnounce_GoodBye( "invalid-pin" );
        }
      }
    }
  }else
  {
    m_SessionManager->EnqueueEvent( "SendSIGNIN", this );
  }
}

BOOL SolegyDebit::OnPrepareSIGNINInfo(
  OStringStream & strm
)
{
  if( m_State == AUTHPENDING )
  {
    if( m_B2BUAConnection != NULL && m_B2BUAConnection->IsSafeReference() )
    {
      const SIPMessage & invite = m_B2BUAConnection->GetCallArrivalQueue().GetMessage();
      ProxyAuthorization auth;
      if( !invite.GetProxyAuthorization( auth ) )
        return FALSE;

      if( !auth.GetParameter( "username", m_USERNAME ) )
        return FALSE;

      if( !auth.GetParameter( "realm", m_REALM ) )
        return FALSE;

      ParserTools::UnQuote( m_USERNAME );
      ParserTools::UnQuote( m_REALM );

      m_EnableDigestProcessing = TRUE;
    };

    strm << "USERNAME=" << m_USERNAME << endl;
    strm << "REALM=" << m_REALM << endl;
  }else
  {
    strm << "ACCOUNTID=" << m_ACCOUNTID << endl;
  }
  
  return TRUE;
}

void SolegyDebit::OnReceived_SIGNIN_ERROR( const OString & packet )
{ 
  if( m_B2BUAConnection != NULL && m_B2BUAConnection->IsSafeReference() )
  {
    if( !m_EnableDigestProcessing )
    {
      if( ++m_InvalidPinRetry < 3 )
      {
        IVRAnnounce_InvalidPin();
        IVRAnnounce_CollectPin();
      }else
      {
        IVRAnnounce_InvalidPin();
        IVRAnnounce_GoodBye( "invalid-pin" );
      }
    }else
    {
      SolegySession::OnReceived_SIGNIN_ERROR( packet );
    }
  }
}

void SolegyDebit::OnReceived_SETUP_ERROR( const OString & /*packet*/ )
{
  if( m_B2BUAConnection != NULL && m_B2BUAConnection->IsSafeReference() )
  {
    IVRAnnounce_InvalidNumber();
    IVRAnnounce_CollectNumber( 500 );
  } 
}

BOOL SolegyDebit::OnReceived_SIGNIN( const OString & packet )
{
  if( SolegySession::OnReceived_SIGNIN( packet ) )
  {
    SolegyParser::ParseHeader( "BALANCE", m_BALANCE, m_SIGNINResponse );
    if( !m_EnableDigestProcessing )
    {
      OString enableBalancePrompt;
      SolegyParser::ParseHeader( "EnableBalancePrompt", enableBalancePrompt, m_AUTHResponse );
      if( enableBalancePrompt == "1" )
      {
        IVRAnnounce_Balance();
      }else
      {
        IVRAnnounce_CollectNumber();
      }
    }else
    {
      if( m_B2BUAConnection != NULL && m_B2BUAConnection->IsSafeReference() )
        if( ProcessDigest( packet ) )
          m_B2BUAConnection->ProcessCallArrivalQueue();
    }

    return TRUE;
  }

  return FALSE;
}

void SolegyDebit::Validate_TELNUMBER( const OString & number )
{
  m_DIALSTRING = number;
  RTTS_LOG( "Validating TELLNUMBER" );
  if( m_DIALSTRING.IsEmpty() )
  {
    if( m_B2BUAConnection != NULL && m_B2BUAConnection->IsSafeReference() )
    {
      IVRAnnounce_InvalidNumber();
      IVRAnnounce_CollectNumber( 500 );
    } 
  }else
  {
    m_SessionManager->EnqueueEvent( "SendSETUP", this );
  }
}

void SolegyDebit::Do_CALLTRANSFER( const OString & number )
{
  RTTS_LOG( "Performing CALL TRANSFER" );
  if( m_B2BUAConnection != NULL && m_B2BUAConnection->IsSafeReference() )
    m_B2BUAConnection->IVRTransferCall( number, FALSE );
}

BOOL SolegyDebit::OnPrepareSETUPInfo(
  OStringStream & strm
)
{
  strm << "DIALSTRING=" << m_DIALSTRING << endl;
  return TRUE;
}

BOOL SolegyDebit::OnReceived_SETUP( const OString & packet )
{
  if( !SolegySession::OnReceived_SETUP( packet ) )
    return FALSE;

  PWaitAndSignal lock( m_RTBERouteListMutex );

  SolegyParser::ParseHeader( "TIMELEFT", m_TIMELEFT, packet );
  if( m_TIMELEFT.AsInteger() == 0 )
  {
    IVRAnnounce_AccountDepleted();
    IVRAnnounce_GoodBye( "error-no-funds" );
    return TRUE;
  }


  if( m_RTBERouteList.GetSize()<= 0 )
  {
    if( m_B2BUAConnection != NULL && m_B2BUAConnection->IsSafeReference() )
    {
      const SIPMessage & invite = m_B2BUAConnection->GetCallArrivalQueue().GetMessage();

      if( SolegyParser::ParseRouting( packet, invite, m_RTBERouteList ) )
      {
        IVRAnnounce_CallDuration();
        IVRAnnounce_CallTransfer();
      }

      if( m_RTBERouteList.GetSize() <= 0 )
      {
        OnReceived_SETUP_ERROR( packet );
      }
    }
  }else
  {
    OnReceived_SETUP_ERROR( packet );
  }

  return TRUE;
}



BOOL SolegyDebit::OnReceived_AUTH( const OString & packet )
{
  if( !SolegySession::OnReceived_AUTH( packet ) )
    return FALSE;

  m_IVR->InitFromAUTH( packet );

  SolegyParser::ParseHeader( "EnableDurationPrompt", m_EnableDurationPrompt, m_AUTHResponse );
  SolegyParser::ParseHeader( "EnableNumberPrompt", m_EnableNumberPrompt, m_AUTHResponse );
  SolegyParser::ParseHeader( "EnableBalancePrompt", m_EnableBalancePrompt, m_AUTHResponse );
  SolegyParser::ParseHeader( "EnableDirectDial", m_EnableDirectDial, m_AUTHResponse );

  if( SolegyParser::ParseHeader( "AUTHORIZED", m_AUTHORIZED, m_AUTHResponse ) )
  {
    SolegyParser::ParseHeader( "ACCOUNTID", m_ACCOUNTID, m_AUTHResponse );
    if( m_AUTHORIZED *= "TRUE" )
      m_IsPINLess = !m_ACCOUNTID.IsEmpty();
  }

  OString inputTimeout;
  if( SolegyParser::ParseHeader( "InputTimeout", inputTimeout, m_AUTHResponse ) )
  {
    m_InputTimeout = inputTimeout.AsInteger();
    if( m_InputTimeout < 5000 || m_InputTimeout > 30000 )
      m_InputTimeout = 5000;
  }
  if( m_EnableDirectDial != "1" && m_EnableNumberPrompt.IsEmpty() )
  {
    m_EnableNumberPrompt = "1";
    m_EnableDirectDial = "0";
  }
  if( m_B2BUAConnection != NULL && m_B2BUAConnection->IsSafeReference() )
  {
    const SIPMessage & invite = m_B2BUAConnection->GetCallArrivalQueue().GetMessage();
    if( m_EnableDirectDial == "1" )
      m_DIALSTRING =  invite.GetRequestURI().GetUser();
  }

  if( !m_IsPINLess && m_EnableUserAuth == "1" )
  {
    if( m_B2BUAConnection != NULL && m_B2BUAConnection->IsSafeReference() )
    {
      const SIPMessage & invite = m_B2BUAConnection->GetCallArrivalQueue().GetMessage();
      AuthenticateInbound( invite );
    }
  }else
  {
    CallConnect();
  }

  return TRUE;
}

void SolegyDebit::SetupOutbound( SIPMessage & invite )
{
  PWaitAndSignal lock( m_RTBERouteListMutex );

  if( m_State == RESET )
  {
    invite.SetXBillingVector( NULL );
    invite.SetXRoutingVector( NULL );

    SIPURI rURI = invite.GetRequestURI();
    if( m_B2BUAConnection != NULL && m_B2BUAConnection->IsSafeReference() )
    {
      m_B2BUAConnection->RemoveRoutes();
      m_B2BUAConnection->AddRoute( rURI );
    }
    return;
  }else if( m_State != SETUP )
  {
    OpenSBC * sbc = m_SessionManager->GetSBC();
    SIPURI ms( sbc->GetMediaServer()->GetListenerAddress(), sbc->GetMediaServer()->GetListenerPort() );
    ms.SetUser( invite.GetRequestURI().GetUser() );
    invite.SetRequestURI( ms );
    return;
  }

  SolegySession::SetupOutbound( invite );
}

BOOL SolegyDebit::SetupInbound( const SIPMessage & invite )
{
  m_CurrentInboundInvite = invite;
  return TRUE;
}

BOOL SolegyDebit::Start( const SIPMessage & /*msg*/ )
{
  if( m_State == START )
  {
    m_SessionManager->EnqueueEvent( "SendSTART", this );
    return TRUE;
  }else if( m_State == AUTHPENDING )
  {
    m_SessionManager->EnqueueEvent( "SendSIGNIN", this );
    return TRUE;
  }

  return FALSE;
}

void SolegyDebit::CallDisconnect( const OString & error )
{
  if( m_B2BUAConnection != NULL && m_B2BUAConnection->IsSafeReference() )
  {
    const SIPMessage & invite = m_B2BUAConnection->GetCallArrivalQueue().GetMessage();
    SIPMessage response;
    invite.CreateResponse( response, SIPMessage::Code480_TemporarilyNotAvailable, error );
    if( m_B2BUAConnection->GetSessionState() < B2BUAConnection::Connected )
    {
      OpenSBC * sbc = m_SessionManager->GetSBC();
      BOOL enableErrorAnnounce = sbc->GetAppConfig()->GetBoolean( configMediaServerSection, configKeyEnableAnnouncementService, FALSE );
      //
      ///re-route to the announcement server
      if( !enableErrorAnnounce )
        m_B2BUAConnection->GetLeg1Call()->SendRequest( response );
      else
      {
        OpenSBC * sbc = m_SessionManager->GetSBC();
        SIPURI annc( sbc->GetMediaServer()->GetListenerAddress(), sbc->GetMediaServer()->GetListenerPort() );
        annc.SetUser( "annc" );
        annc.AddParameter( "play", "prompts/basic/cant_complete.wav" );
        m_B2BUAConnection->RemoveRoutes();
        m_B2BUAConnection->AddRoute( annc );
        m_B2BUAConnection->ProcessCallArrivalQueue();
      }
    }else
    {
      OStringStream reasonText;
      reasonText << "SIP ;" << "cause="  << SIPMessage::Code480_TemporarilyNotAvailable << " ;" << "text=\"" << error << "\"";
      m_B2BUAConnection->GetLeg1Call()->SendBye( reasonText.str().c_str() );
    }
    m_B2BUAConnection->DestroyConnection( response );
  }
}

void SolegyDebit::OnTransferReject( const SIPMessage & reject )
{
  PWaitAndSignal lock( m_RTBERouteListMutex );
  RTTS_LOG( "CALL TRANSFER Rejected" );
  if( m_RTBERouteList.GetSize() > 0 )
  {
    /// try another route
    if( m_B2BUAConnection != NULL && m_B2BUAConnection->IsSafeReference() )
    {
      m_ErrorString = SolegyParser::ConvertRTTSErrorToString( SolegyParser::ConvertSIPToRTTSError( reject ) );
      
      PString errorCmd = "SendERROR" + PString( m_CurrentRouteIndex );
      m_SessionManager->EnqueueEvent( errorCmd, this );
      ++m_CurrentRouteIndex;

      m_State = SETUP ;  // reset the state to setup
      SIPMessage invite = m_CurrentOutboundInvite;
      invite.ClearInternalHeaders();
      invite.SetEncryption( FALSE );
      SetupOutbound( invite );
      m_B2BUAConnection->SetSessionState( B2BUAConnection::Transferring );
      m_B2BUAConnection->OnSetupOutbound( invite );
    }
  }else
  {
    /// transfer the call back to media server and announce the error
    OpenSBC * sbc = m_SessionManager->GetSBC();
    SIPURI stateRescueURI( sbc->GetMediaServer()->GetListenerAddress(), sbc->GetMediaServer()->GetListenerPort() );
    stateRescueURI.SetUser( "state-rescue" );
    
    Reason reason;
    OStringStream reasonText;
    reasonText << "SIP ;" << "cause=" << reject.GetStatusCode() << " ;" << "text=\"Call State-Rescue\"";   
    reason.SetHeaderBody( reasonText.str() );

    SIPMessage invite = m_CurrentOutboundInvite;
    invite.ClearInternalHeaders();
    invite.SetEncryption( FALSE );
    invite.SetRequestURI( stateRescueURI );
    invite.SetReason( reason );

    m_State = RESET ;  // reset the state to setup
    if( m_B2BUAConnection != NULL && m_B2BUAConnection->IsSafeReference() )
    {
      /// BOOKMARK
      if( m_B2BUAConnection->GetLeg2Call() != NULL )
      {
        m_B2BUAConnection->RemoveRoutes();
        m_B2BUAConnection->AddRoute( stateRescueURI );
        m_B2BUAConnection->TransferCallLocal( invite, m_B2BUAConnection->GetLeg2Call() );
      }else
      {
        CallDisconnect( "Unknown Critical Server Error" );
      }
    }
  }
}


void SolegyDebit::OnIVRPromptTimeout( )
{
  RTTS_LOG( "Prompt Failure - TIMEOUT" );
  if( m_B2BUAConnection != NULL && m_B2BUAConnection->IsSafeReference() )
  {
    const SIPMessage & invite = m_B2BUAConnection->GetCallArrivalQueue().GetMessage();
    SIPMessage response;
    OString error = "RTTS-8888 IVR Prompt Error";

    invite.CreateResponse( response, SIPMessage::Code480_TemporarilyNotAvailable, error );
    m_B2BUAConnection->GetLeg1Call()->SendRequest( response );
    m_B2BUAConnection->DestroyConnection( response );
  }
}





















