/*
 *
 * Registration.h
 *
 * Open SIP Stack ( OSS )
 *
 * Copyright (c) opensipstack.org.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either expressed or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is OpenSIPStack.
 *
 * The Initial Developer of the Original Code is opensipstack.org.
 *
 * The author of this code is Joegen E. Baclor
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * The OpenSIPStack Library includes some GPL/LGPL code libraries that MAY be 
 * enabled at compile time using the --enable-gpllibs configure switch.  If
 * enabled, the content of this file is published under the terms of GNU 
 * General Public License Version 2.  For a detailed list of the available
 * GPL code, see $(opensipstack)/gnu/README file.
 *
 * $Log: Registration.h,v $
 * Revision 1.10  2009/03/06 03:17:18  joegenbaclor
 * configurable OPTIONS based NAT keep alive support
 *
 * Revision 1.9  2008/12/01 03:52:14  joegenbaclor
 * Upper reg bug fixes
 *
 * Revision 1.8  2008/10/23 05:16:11  joegenbaclor
 * Reimplemented NAT Binding Refresh
 *
 * Revision 1.7  2008/10/06 02:11:52  joegenbaclor
 * More verbose log entry
 *
 * Revision 1.6  2008/10/05 14:01:41  joegenbaclor
 * Added logging to upper-reg
 * Fixed unquoted realm parameter in proxy authentication
 *
 * Revision 1.5  2008/09/22 05:58:35  joegenbaclor
 * Added stateful upper reg classes
 *
 * Revision 1.4  2008/09/11 15:49:41  joegenbaclor
 * Only Unregister an upper reg record on receipt of a 200 ok
 *
 * Revision 1.3  2008/09/05 03:54:45  joegenbaclor
 * reactivation registration status using new registrar.
 *
 * Revision 1.2  2008/09/03 08:03:46  joegenbaclor
 * more work on new upper reg
 *
 * Revision 1.1  2008/08/27 03:02:14  joegenbaclor
 * Adding new registrar code
 *
 *
 */

#ifndef REGISTRATION_H
#define REGISTRATION_H

#include "SIPMessage.h"
#include "Logger.h"

using namespace SIPParser;
using namespace Tools;

namespace REGISTRAR
{
class Registrar;
class Registration : public PObject, public Logger
{
  PCLASSINFO( Registration, PObject );
public:
  class Record : public PTimer, public Logger
  {
    PCLASSINFO( Record, PTimer );
  public:
    Record( 
      const PNotifier & notifier, 
      const SIPMessage & request, 
      Registration & registration,
      int keepAliveInterval = 15,
      BOOL useOptionsKeepAlive = FALSE );

    ~Record();
    
    void Reset( 
      const SIPMessage & request 
    );

    void SendNATRefresh();

    void Stop();

    ContactURI GetTranslatedBinding()const;

    Registration & m_Registration;
    SIPMessage m_Register;
    PNotifier m_ExpireNotifier;

    PTimer m_NATRefreshTimer;
    PTimeInterval m_NATRefreshInterval;
    BOOL m_UseOptionsNATRefresh;
    int m_NATCSeq;
    OString m_NATCallId;
    PDECLARE_NOTIFIER( PTimer, Record, OnNATRefresh );
  };

  enum RequestAction
  {
    Challenge,
    AuthPending,
    Reject,
    TooBrief,
    Ignore,
    Accept
  };

  Registration( 
    const SIPURI & uri,
    Registrar * registrar,
    BOOL requireAuthorization
  );

  ~Registration(); 

  RequestAction ProcessRequest( 
    const SIPMessage & request,
    Contact & contacts
  );

  virtual BOOL AddRecord( 
    const SIPMessage & request,
    Contact & contacts,
    BOOL noReset = FALSE
  );
  
  virtual BOOL RemoveRecord( 
    const SIPMessage & request,
    OString & contacts
  );

  virtual BOOL ListRecords(
    Contact & contacts
  );

  virtual RequestAction IsAuthorized( 
    const SIPMessage & request 
  );

  virtual BOOL GetTranslatedBindings( 
    Contact & contact 
  );

  static BOOL IsUnregister( const SIPMessage & request, OString & contacts );

  PINLINE void SetMD5Local( const OString & md5 ){ m_MD5Local = md5; };
  PINLINE const SIPURI & GetURI()const{ return m_URI; };
  PINLINE Record & operator[](PINDEX index){ return m_RecordList.GetDataAt(index); };
  PINLINE PINDEX GetSize()const{ return m_RecordList.GetSize(); };

  BOOL m_IsFlushed;
  SIPURI m_URI;
  PDICTIONARY( RecordList, PCaselessString, Record );
  PMutex m_RecordListMutex;
  RecordList m_RecordList;
  PLIST( RecordLandFill, Record );
  RecordLandFill m_RecordLandFill;
  Registrar * m_Registrar;
  BOOL m_RequireAuthorization;
  OString m_MD5Local;
  PDECLARE_NOTIFIER( PTimer, Registration, OnRecordExpire );
};
};
#endif


