/*
 *
 * SBCSIPTrunkConfig.h
 *
 * Open SIP Stack ( OSS )
 *
 * Copyright (c) opensipstack.org.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either expressed or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is OpenSIPStack.
 *
 * The Initial Developer of the Original Code is opensipstack.org.
 *
 * The author of this code is Joegen E. Baclor
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * The OpenSIPStack Library includes some GPL/LGPL code libraries that MAY be 
 * enabled at compile time using the --enable-gpllibs configure switch.  If
 * enabled, the content of this file is published under the terms of GNU 
 * General Public License Version 2.  For a detailed list of the available
 * GPL code, see $(opensipstack)/gnu/README file.
 *
 * $Log: SBCSIPTrunkConfig.h,v $
 * Revision 1.4  2008/11/25 01:45:24  joegenbaclor
 * Added send-reg attribute to disable sending registration to trunk provider which does
 *  not require it
 *
 * Revision 1.3  2007/10/17 03:17:39  joegenbaclor
 * More work on sip trunks
 *
 * Revision 1.2  2007/09/11 14:29:05  joegenbaclor
 * More trunking work
 *
 * Revision 1.1  2007/09/04 21:58:13  joegenbaclor
 * More work on SIP Trunks.
 *
 *
 */

#ifndef SBCSIPTRUNKCONFIG_H
#define SBCSIPTRUNKCONFIG_H

#include <ptlib.h>
#include <ptclib/pxml.h>
#include "OString.h"

using namespace Tools;

class SBCSIPTrunkAccountConfig : public PObject
{
  PCLASSINFO( SBCSIPTrunkAccountConfig, PObject );
public:
  SBCSIPTrunkAccountConfig(
    PXMLElement * config
  );

  OString GetUser()const;

  OString GetAuthUser()const;

  OString GetPassword()const;

  OString GetInboundRoute()const;

  long GetExpires()const;

  BOOL IsEnabled()const;

  BOOL WillSendReg()const;

  PDICTIONARY( Collection, PCaselessString, SBCSIPTrunkAccountConfig );

protected:
  PXMLElement * m_Config;
};

class SBCSIPTrunkConfig : public PObject
{
  PCLASSINFO( SBCSIPTrunkConfig, PObject );
public:

  SBCSIPTrunkConfig( 
    PXMLElement * config
  );

  OString GetTrunkName()const;
  
  OString GetRouteSet()const;
  
  OString GetDomain()const;
  
  OString GetTrunkType()const;
  
  OString GetTrunkDescription()const;

  long GetExpires()const;
  
  BOOL IsTrunkEnabled()const;

  SBCSIPTrunkAccountConfig & operator[]( PINDEX i );

  const SBCSIPTrunkAccountConfig * operator[]( const char * name );
  const SBCSIPTrunkAccountConfig * GetActiveTransientAccount();
  PINLINE PINDEX GetSize()const{ return m_Accounts.GetSize(); };
  PINLINE PINDEX GetTransientSize()const{ return m_TransientAccounts.GetSize(); };

protected:
  PMutex m_AccountsMutex;
  SBCSIPTrunkAccountConfig::Collection m_Accounts;
  SBCSIPTrunkAccountConfig::Collection m_TransientAccounts;
  PINDEX m_TransientAccountIndex;
  PXMLElement * m_Config;
};

#endif








