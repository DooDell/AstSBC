/*
 *
 * SBCSwitchRTPBridge.cxx
 *
 * Open SIP Stack ( OSS )
 *
 * Copyright (c) opensipstack.org.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either expressed or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is OpenSIPStack.
 *
 * The Initial Developer of the Original Code is opensipstack.org.
 *
 * The author of this code is Joegen E. Baclor
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * The OpenSIPStack Library includes some GPL/LGPL code libraries that MAY be 
 * enabled at compile time using the --enable-gpllibs configure switch.  If
 * enabled, the content of this file is published under the terms of GNU 
 * General Public License Version 2.  For a detailed list of the available
 * GPL code, see $(opensipstack)/gnu/README file.
 *
 * $Log: SBCSwitchRTPSession.cxx,v $
 * Revision 1.3  2009/06/03 11:57:16  joegenbaclor
 * Checking in MOH feature
 *
 * Revision 1.2  2009/06/01 09:47:28  joegenbaclor
 * more IVR related work
 *
 * Revision 1.1  2009/05/27 12:40:34  joegenbaclor
 * Initial upload of switch related classes
 *
 *
 */


#include "SBCSwitchRTPSession.h"
#include "SDPLazyParser.h"

using namespace SWITCH;
using namespace B2BUA;
using namespace SDP;

SBCSwitchRTPSession::SBCSwitchRTPSession(
  unsigned id,                       ///<  Session ID for RTP channel
  unsigned int timeOutThreshold      ///<  Number of read timeouts before ReadData() fails. 0 means ReadData() won't fail even when timing out indefinitely.
) : RTP_UDP( id, timeOutThreshold ) 
{
  m_RFC2833PayLoad = RTP_DataFrame::IllegalPayloadType;
  m_MediaPayLoad = RTP_DataFrame::IllegalPayloadType;
  m_RFC2833ReceiveComplete = FALSE;
  m_RFC2833ReceivedTone = 0;
  m_RFC2833ReceivedDuration = 0;
  m_RFC2833ReceiveTimestamp = 0;
  m_RTPInterface = NULL;
  m_DTMFInterface = NULL;
}

RTP_Session::SendReceiveStatus SBCSwitchRTPSession::OnReceiveData(
  const RTP_DataFrame & frame
)
{
  SendReceiveStatus status = RTP_UDP::OnReceiveData( frame );
  if( status == e_ProcessPacket )
  {
    if (frame.GetPayloadType() == m_RFC2833PayLoad)
    {
      OnReceiveRFC2833Frame( frame );
    }else
    {
      OnProcessRTPDataFrame( frame );
    }
  }
  return status;
}


RTP_Session::SendReceiveStatus SBCSwitchRTPSession::OnReceiveControl(
  RTP_ControlFrame & frame
)
{
  SendReceiveStatus status = RTP_UDP::OnReceiveControl( frame );
  if( status == e_ProcessPacket )
  {
  }
  return status;
}

void SBCSwitchRTPSession::OnReceiveRFC2833Frame(
  const RTP_DataFrame & frame
)
{
  static const char RFC2833Table1Events[] = "0123456789*#ABCD!";
  if (frame.GetPayloadSize() < 4) {
    PTRACE(1, "RFC2833: Ignoring packet, too small.");
    return;
  }

  const BYTE * payload = frame.GetPayloadPtr();
  if (payload[0] >= sizeof(RFC2833Table1Events)-1) {
    PTRACE(2, "RFC2833: Ignoring packet, unsupported event.");
    return;
  }

  m_RFC2833ReceivedTone = RFC2833Table1Events[payload[0]];
  m_RFC2833ReceivedDuration = (payload[2]<<8) + payload[3];

  unsigned timestamp = frame.GetTimestamp();
  if (m_RFC2833ReceiveTimestamp != timestamp) {
    PTRACE(1, "RFC2833: Received end tone=" << m_RFC2833ReceivedTone << " duration=" << m_RFC2833ReceivedDuration);
    // Starting a new event.
    m_RFC2833ReceiveTimestamp = timestamp;
    m_RFC2833ReceiveComplete = FALSE;
    OpalRFC2833Info info(m_RFC2833ReceivedTone, m_RFC2833ReceivedDuration, timestamp);
    OnReceiveRFC2833Tone( info );
  }else
  {
    if (m_RFC2833ReceiveComplete) 
    {
      PTRACE(3, "RFC2833: Ignoring duplicate packet.");
      return;
    }
  }
  if ((payload[1]&0x80) == 0) {
    PTRACE(3, "RFC2833: Ignoring packet, not end of event.");
    return;
  }

  m_RFC2833ReceiveComplete = TRUE;
  
}

void SBCSwitchRTPSession::OnReceiveRFC2833Tone(
  const OpalRFC2833Info & tone 
)
{
  if( m_DTMFInterface != NULL )
    m_DTMFInterface->OnDTMFReceiveRFC2833Tone( tone );
}

void SBCSwitchRTPSession::OnProcessRTPDataFrame(
  const RTP_DataFrame & frame
)
{
  if( m_MediaPayLoad == RTP_DataFrame::IllegalPayloadType )
  {
    m_MediaPayLoad = frame.GetPayloadType();
    if( m_RTPInterface != NULL )
    {
      SDPLazyParser sdp = m_RTPInterface->GetRemoteSDP();
      OString formatName;
      if( sdp.GetPayloadNameFromType( GetSessionID() == OpalMediaFormat::DefaultAudioSessionID ?
        SDPLazyParser::Audio : SDPLazyParser::Video, 0, m_MediaPayLoad, formatName ) )
      {
        m_RTPInterface->OnRTPMediaPayloadKnown( GetSessionID(), m_MediaPayLoad, formatName );
      }
    }
  }else if( m_MediaPayLoad != frame.GetPayloadType() )
  {
  }
}





