/*
 *
 * SBCSwitchIVRChannel.h
 *
 * Open SIP Stack ( OSS )
 *
 * Copyright (c) opensipstack.org.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either expressed or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is OpenSIPStack.
 *
 * The Initial Developer of the Original Code is opensipstack.org.
 *
 * The author of this code is Joegen E. Baclor
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * The OpenSIPStack Library includes some GPL/LGPL code libraries that MAY be 
 * enabled at compile time using the --enable-gpllibs configure switch.  If
 * enabled, the content of this file is published under the terms of GNU 
 * General Public License Version 2.  For a detailed list of the available
 * GPL code, see $(opensipstack)/gnu/README file.
 *
 * $Log: SBCSwitchIVRChannel.cxx,v $
 * Revision 1.3  2009/06/03 11:57:16  joegenbaclor
 * Checking in MOH feature
 *
 *
 */

#include "SBCSwitchIVRChannel.h"
#include "SBCSwitchIVRSession.h"
#include "SBCSwitchIVRResource.h"
#define new PNEW

using namespace SWITCH;

SBCSwitchIVRChannel::SBCSwitchIVRChannel(
  unsigned frameDelay, 
  PINDEX frameSize
  ) : PDelayChannel(DelayReadsAndWrites, frameDelay, frameSize)
{
  m_IVRSession = NULL; 
  m_ChannelInterface = NULL;

  m_SampleFrequency = 8000;
  m_IsClosed          = FALSE;

  m_IsRecording       = FALSE;
  m_Recordable      = NULL;

  m_IsPlaying         = FALSE;
  m_SilentCount     = 20;         // wait 20 frames before playing the OGM
  m_IsPaused          = FALSE;
  m_CurrentPlayItem = NULL;
}

SBCSwitchIVRChannel::~SBCSwitchIVRChannel()
{
  Close();
}

BOOL SBCSwitchIVRChannel::Open(
  SBCSwitchIVRChannelInterface * session
)
{
  m_CurrentPlayItem = NULL;
  m_ChannelInterface = session;
  return TRUE;
}

// overrides from PIndirectChannel
BOOL SBCSwitchIVRChannel::IsOpen() const
{
  return !m_IsClosed;
}

BOOL SBCSwitchIVRChannel::Close()
{
  if (!m_IsClosed) 
  {
    EndRecording();
    FlushQueue();
    m_IsClosed = TRUE; 
    PDelayChannel::Close(); 
  }
  return TRUE; 
}

BOOL SBCSwitchIVRChannel::Read(void * buffer, PINDEX amount)
{
  // assume we are returning silence
  BOOL done         = FALSE;
  BOOL silenceStuff = FALSE;
  BOOL delayDone    = FALSE;

  while (!done && !silenceStuff) 
  {
    if (m_IsClosed)
      return FALSE;

    {
      PWaitAndSignal m(m_ChannelReadMutex);

      // if we are paused or in a delay, then do return silence
      if (m_IsPaused || m_DelayTimer.IsRunning()) {
        silenceStuff = TRUE;
        break;
      }

      // if we are returning silence frames, then decrement the frame count
      // and continue returning silence
      if (m_SilentCount > 0) {
        m_SilentCount--;
        silenceStuff = TRUE;
        break;
      }

      // try and read data from the underlying channel
      if (GetBaseReadChannel() != NULL) {

        PWaitAndSignal m(m_QueueMutex);

        // see if the item needs to repeat
        PAssert(m_CurrentPlayItem != NULL, "current IVR play item disappeared");
 
        
        // if the read succeeds, we are done
        if(m_CurrentPlayItem->ReadFrame(*this, buffer, amount)) 
        {
          m_TotalData += amount;
          delayDone = TRUE;
          done = TRUE;
          break;
        } 

        // if a timeout, send silence
        if (GetErrorCode(LastReadError) == Timeout) 
        {
          silenceStuff = TRUE;
          break;
        }

        // repeat the item if needed
        if (m_CurrentPlayItem->GetRepeat() > 0) 
        {
          if( m_CurrentPlayItem->GetRepeat() != P_MAX_INDEX )
            m_CurrentPlayItem->SetRepeat(m_CurrentPlayItem->GetRepeat()-1);
          m_CurrentPlayItem->OnRepeat(*this);
          continue;
        } 

        PTRACE(3, "IVR: Finished playing " << m_TotalData << " bytes");
        PDelayChannel::Close();

        // see if end of queue delay specified
        PINDEX delay = 0;
        if (!m_CurrentPlayItem->m_DelayDone) {
          delay = m_CurrentPlayItem->GetDelay();
          if (delay != 0) 
          {
            PTRACE(3, "IVR: Delaying for " << delay);
            m_DelayTimer = delay;
            m_CurrentPlayItem->m_DelayDone = TRUE;
            continue;
          }
        }

        // stop the current item
        m_CurrentPlayItem->OnStop();
        OnEndPlay( m_CurrentPlayItem->GetIdentifier() );
        delete m_CurrentPlayItem;
        m_CurrentPlayItem = NULL;
      }

      // check the queue for the next action
      {
        PWaitAndSignal m(m_QueueMutex);

        // if nothing in the queue (which is weird as something just stopped playing)
        // then trigger the VXML and send silence
        m_CurrentPlayItem = m_PlayQueue.Dequeue();
        if (m_CurrentPlayItem == NULL)
        {
          silenceStuff = TRUE;
          break;
        }

        // start the new item
        m_CurrentPlayItem->OnStart();
        m_CurrentPlayItem->Play(*this);
        SetReadTimeout(frameDelay);
        m_TotalData = 0;
      }
    }
  }
  
  // start silence frame if required
  // note that this always requires a delay
  if (silenceStuff) {
    lastReadCount = CreateSilenceFrame(buffer, amount);
  }

  // make sure we always do the correct delay
  if (!delayDone)
    Wait(amount, nextReadTick);

  return TRUE;
}

BOOL SBCSwitchIVRChannel::Write(const void * buf, PINDEX len)
{
  if( m_IsClosed )
    return FALSE;

  m_ChannelWriteMutex.Wait();


  // let the recordable do silence detection
  if( m_Recordable != NULL && m_Recordable->OnFrame(IsSilenceFrame(buf, len))) {
    PTRACE(1, "IVR: Recording finished due to silence");
    EndRecording();
  }

  // if nothing is capturing incoming data, then fake the timing and return
  if(( m_Recordable == NULL) && (GetBaseWriteChannel() == NULL)) {
    lastWriteCount = len;
    m_ChannelWriteMutex.Signal();
    PDelayChannel::Wait(len, nextWriteTick);
    return TRUE;
  }

  // write the data and do the correct delay
  if (!WriteFrame(buf, len)) 
    EndRecording();
  else
    m_TotalData += lastWriteCount;

  m_ChannelWriteMutex.Signal();

  return TRUE;
}

      // new functions
PWAVFile * SBCSwitchIVRChannel::CreateWAVFile(
  const PFilePath & fn, 
  BOOL recording
)
{
  PWAVFile * wav = PWAVFile::format( m_MediaFormat.c_str() );
  if (wav == NULL) 
  {
    PTRACE(1, "IVR: WAV file format " << m_MediaFormat << " not known");
    return NULL;
  }

  wav->SetAutoconvert();
  if (!wav->Open(fn, 
                 recording ? PFile::WriteOnly : PFile::ReadOnly,
                 PFile::ModeDefault))
                 PTRACE(1, "IVR: Could not open WAV file " << wav->GetName());

  else if (recording) {
    wav->SetChannels(1);
    wav->SetSampleRate(8000);
    wav->SetSampleSize(16);
    return wav;
  } 
  
  else if (!wav->IsValid())
    PTRACE(1, "IVR: WAV file header invalid for " << wav->GetName());

  else if (wav->GetSampleRate() != m_SampleFrequency)
    PTRACE(1, "IVR: WAV file has unsupported sample frequency " << wav->GetSampleRate());

  else if (wav->GetChannels() != 1)
    PTRACE(1, "IVR: WAV file has unsupported channel count " << wav->GetChannels());

  else {
    wav->SetAutoconvert();   /// enable autoconvert
    PTRACE(4, "IVR: Opened WAV file " << wav->GetName());
    return wav;
  }

  delete wav;
  return NULL;
}

// Incoming channel functions

BOOL SBCSwitchIVRChannel::QueueRecordable(
  SBCSwitchIVRRecordable * newItem
)
{
  m_TotalData = 0;
  // shutdown any existing recording
  EndRecording();

  // insert the new recordable
  PWaitAndSignal mutex(m_ChannelWriteMutex);
  m_Recordable = newItem;
  m_IsRecording = TRUE;
  m_TotalData = 0;
  newItem->OnStart();
  newItem->Record(*this);
  SetReadTimeout(frameDelay);
  return TRUE;
}

BOOL SBCSwitchIVRChannel::StartRecording(
  const PFilePath & fn, 
  unsigned finalSilence, 
  unsigned maxDuration
)
{
  SBCSwitchIVRRecordableFilename * recordable = new SBCSwitchIVRRecordableFilename();
  if (!recordable->Open((const char *)fn)) {
    delete recordable;
    return FALSE;
  }

  recordable->SetFinalSilence(finalSilence);
  recordable->SetMaxDuration(maxDuration);
  return QueueRecordable(recordable);
}

BOOL SBCSwitchIVRChannel::EndRecording()
{
  PWaitAndSignal mutex(m_ChannelWriteMutex);

  if( m_Recordable != NULL ) 
  {
    PTRACE(3, "IVR: Finished recording " << m_TotalData << " bytes");

    PDelayChannel::Close();
    m_Recordable->OnStop();
    delete m_Recordable;
    m_Recordable = NULL;
    PTRACE(3, "IVR: Recording finished");
  }

  return TRUE;
}

void SBCSwitchIVRChannel::OnEndPlay( 
  const OString & identifier 
)
{
  PTRACE(3, "IVR: Done playing " << identifier );
  if( m_IVRSession != NULL )
    m_IVRSession->OnEndPlay( identifier );
}

// Outgoing channel functions

BOOL SBCSwitchIVRChannel::QueueData( 
  const OString & id, 
  const PBYTEArray & data, 
  PINDEX repeat, 
  PINDEX delay
)
{
  PTRACE(3, "IVR: Enqueueing " << data.GetSize() << " bytes for playing");
  SBCSwitchIVRPlayableData * item = new SBCSwitchIVRPlayableData();
  item->SetIdentifier( id );
  if (item == NULL) {
    PTRACE(1, "VXML\tCannot find playable of type 'PCM Data'");
    delete item;
    return FALSE;
  }

  if (!item->Open(*this, "", delay, repeat, TRUE)) {
    PTRACE(1, "IVR: Cannot open playable of type 'PCM Data'");
    delete item;
    return FALSE;
  }

  if (QueuePlayable(item))
    return TRUE;

  delete item;
  return FALSE;
}

BOOL SBCSwitchIVRChannel::QueueResource(
  const OString & id, 
  const PURL & url, 
  PINDEX repeat, 
  PINDEX delay
)
{
  if (url.GetScheme() *= "file")
    return QueuePlayable( id, "File", (const char *)url.AsFilePath(), repeat, delay, FALSE);
  else
    return QueuePlayable( id, "URL", (const char *)url.AsString(), repeat, delay);
}

BOOL SBCSwitchIVRChannel::QueuePlayable( 
  const OString & id,
  const OString & type,
  const OString & arg, 
  PINDEX repeat, 
  PINDEX delay, 
  BOOL autoDelete
)
{
  PTRACE(3, "IVR: Enqueueing playable " << type << " with arg " << arg << " for playing");
  SBCSwitchIVRPlayable * item = NULL;
  if( type == "File" )
    item = new SBCSwitchIVRPlayableFilename();
  else if( type == "URL" )
    item = new SBCSwitchIVRPlayableURL();

  
  if (item == NULL) 
  {
    PTRACE(1, "IVR: Cannot find playable of type " << type);
    delete item;
    return FALSE;
  }

  item->SetIdentifier( id );

  if (!item->Open(*this, arg, delay, repeat, autoDelete)) {
    PTRACE(1, "IVR: Cannot open playable of type " << type << " with arg " << arg);
    delete item;
    return FALSE;
  }

  if (QueuePlayable(item))
    return TRUE;

  delete item;
  return FALSE;
}

BOOL SBCSwitchIVRChannel::QueuePlayable(
  SBCSwitchIVRPlayable * newItem
)
{
  newItem->SetSampleFrequency(m_SampleFrequency);
  PWaitAndSignal mutex(m_QueueMutex);
  m_PlayQueue.Enqueue(newItem);
  return TRUE;
}


void SBCSwitchIVRChannel::FlushQueue()
{
  PWaitAndSignal mutex(m_ChannelReadMutex);

  if (GetBaseReadChannel() != NULL)
    PDelayChannel::Close();

  PWaitAndSignal m(m_QueueMutex);

  SBCSwitchIVRPlayable * qItem;
  while ((qItem = m_PlayQueue.Dequeue()) != NULL) 
  {  
    qItem->OnStop();
    delete qItem;
  }

  if( m_CurrentPlayItem != NULL ) 
  {
    OnEndPlay( m_CurrentPlayItem->GetIdentifier() );
    m_CurrentPlayItem->OnStop();
    delete m_CurrentPlayItem;
    m_CurrentPlayItem = NULL;
  }
}

//////////////////////////////////////////////////////////////////

SBCSwitchIVRChannelPCM::SBCSwitchIVRChannelPCM()
: SBCSwitchIVRChannel(30, 480)
{
  m_MediaFormat    = IVR_PCM16;
}

BOOL SBCSwitchIVRChannelPCM::WriteFrame(
  const void * buf, 
  PINDEX len
)
{
  return PDelayChannel::Write(buf, len);
}

BOOL SBCSwitchIVRChannelPCM::ReadFrame(
  void * buffer, 
  PINDEX amount
)
{
  PINDEX len = 0;
  while (len < amount)  
  {
    if (!PDelayChannel::Read(len + (char *)buffer, amount-len))
      return FALSE;
    len += GetLastReadCount();
  }
  return TRUE;
}

PINDEX SBCSwitchIVRChannelPCM::CreateSilenceFrame(
  void * buffer, 
  PINDEX amount
)
{
  memset(buffer, 0, amount);
  return amount;
}

BOOL SBCSwitchIVRChannelPCM::IsSilenceFrame(
  const void * buf, 
  PINDEX len
) const
{
  // Calculate the average signal level of this frame
  int sum = 0;

  const short * pcm = (const short *)buf;
  const short * end = pcm + len/2;
  while (pcm != end) 
  {
    if (*pcm < 0)
      sum -= *pcm++;
    else
      sum += *pcm++;
  }

  // calc average
  unsigned level = sum / (len / 2);

  return level < 500; // arbitrary level
}

void SBCSwitchIVRChannelPCM::GetBeepData(
  PBYTEArray & data, 
  unsigned ms
)
{
  static short beepData[] = { 0, 18784, 30432, 30400, 18784, 0, -18784, -30432, -30400, -18784 };
  data.SetSize(0);
  while (data.GetSize() < (PINDEX)((ms * 8) / 2)) {
    PINDEX len = data.GetSize();
    data.SetSize(len + sizeof(beepData));
    memcpy(len + data.GetPointer(), beepData, sizeof(beepData));
  }
}


      
