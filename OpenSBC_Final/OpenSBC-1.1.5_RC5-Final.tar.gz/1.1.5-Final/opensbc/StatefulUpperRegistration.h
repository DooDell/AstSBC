/*
 *
 * StatefulUpperRegistration.h
 *
 * Open SIP Stack ( OSS )
 *
 * Copyright (c) opensipstack.org.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either expressed or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is OpenSIPStack.
 *
 * The Initial Developer of the Original Code is opensipstack.org.
 *
 * The author of this code is Joegen E. Baclor
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * The OpenSIPStack Library includes some GPL/LGPL code libraries that MAY be 
 * enabled at compile time using the --enable-gpllibs configure switch.  If
 * enabled, the content of this file is published under the terms of GNU 
 * General Public License Version 2.  For a detailed list of the available
 * GPL code, see $(opensipstack)/gnu/README file.
 *
 * $Log: StatefulUpperRegistration.h,v $
 * Revision 1.5  2009/06/19 07:05:31  joegenbaclor
 * modified upper reg so that it wont rely on via states.  there are User Agents that
 *  do not return via states in the response
 *
 * Revision 1.4  2008/10/22 05:06:25  joegenbaclor
 * Added MPL License Header
 *
 *
 */

#ifndef STATEFULREG_H
#define STATEFULREG_H

#include "Registration.h"
#include "SIPUserAgent.h"
#include "NoneInviteClientTransaction.h"
#include "NoneInviteServerTransaction.h"
#include "Logger.h"

namespace REGISTRAR
{
  class UpperRegistration;

  class StatefulUpperRegistration : public PObject, public Logger
  {
    PCLASSINFO( StatefulUpperRegistration, PObject );
  public:

    enum RegState
    {
      StateIdle,
      StateTrying,
      StateAuthenticating,
      StateRegistered
    };

    StatefulUpperRegistration( 
      UpperRegistration * reg 
    );

    void OnProcessStatefulReg(
      const SIPMessage & message,
      SIPTransaction * transaction
    );

    void OnForwardStatefulReg(
      const SIPMessage & message,
      SIPTransaction * transaction
    );

    void OnRefreshStatefulReg(
      const SIPMessage & message,
      SIPTransaction * transaction
    );

    void OnProcessStatefulRegResponse(
      const SIPMessage & message,
      SIPTransaction * transaction
    );

    void OnHandleStatefulRegIdle(
      const SIPMessage & message,
      SIPTransaction * transaction
    );

    void OnHandleStatefulRegTrying(
      const SIPMessage & message,
      SIPTransaction * transaction
    );

    void OnHandleStatefulRegAuthenticating(
      const SIPMessage & message,
      SIPTransaction * transaction
    );

    void OnHandleStatefulRegRegistered(
      const SIPMessage & message,
      SIPTransaction * transaction
    );
    
    UpperRegistration * m_Registration;
    SIPMessage m_StatefulRegRequest;
    DWORD m_StatefulRegCSeq;
    PTimer m_RetryTimer;
    RegState m_RegState;

    OString m_RegFromDomain;
    OString m_RegToDomain;
    OString m_RegId;
  };
};

#endif

