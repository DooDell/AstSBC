/*
 *
 * SBCRoutingHandler.cxx
 *
 * Open SIP Stack ( OSS )
 *
 * Copyright (c) opensipstack.org.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either expressed or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is OpenSIPStack.
 *
 * The Initial Developer of the Original Code is opensipstack.org.
 *
 * The author of this code is Joegen E. Baclor
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * The OpenSIPStack Library includes some GPL/LGPL code libraries that MAY be 
 * enabled at compile time using the --enable-gpllibs configure switch.  If
 * enabled, the content of this file is published under the terms of GNU 
 * General Public License Version 2.  For a detailed list of the available
 * GPL code, see $(opensipstack)/gnu/README file.
 *
 *
 * $Log: SBCRoutingHandler.cxx,v $
 * Revision 1.108  2009/06/01 09:30:02  joegenbaclor
 * bug in last commit for siptrunks
 *
 * Revision 1.107  2009/05/27 12:40:34  joegenbaclor
 * Initial upload of switch related classes
 *
 * Revision 1.106  2009/05/05 11:37:58  joegenbaclor
 * updated deprecated functions used by xbase
 * updated MSVC 2005 Project files to include XBase classes
 *
 * Revision 1.105  2009/03/26 06:32:26  joegenbaclor
 * Added NAT port forwarding support
 *
 * Revision 1.104  2009/03/22 23:42:48  joegenbaclor
 * Added configurable interface table support
 *
 * Revision 1.103  2009/02/16 03:44:07  joegenbaclor
 * Allowed setting of from host.  Deprecated Full mode
 *
 * Revision 1.102  2009/02/10 14:29:14  joegenbaclor
 * *** empty log message ***
 *
 * Revision 1.101  2009/02/10 08:16:09  joegenbaclor
 * Fixed HTTP Config crash
 *
 * Revision 1.100  2009/02/09 13:18:21  joegenbaclor
 * using top via instead of bottom via to determine NAT target
 *
 * Revision 1.99  2009/02/06 09:50:38  joegenbaclor
 * Added email alert notification support
 *
 * Revision 1.98  2009/02/04 06:24:26  joegenbaclor
 * Minor bug fixes.  Added auto destruct timer to SoelgySession.  Added ability to disable local-reg and treat all regs as upper reg.
 *
 * Revision 1.97  2009/01/24 15:21:15  joegenbaclor
 * Solegy logging improvements
 *
 * Revision 1.96  2009/01/21 10:01:56  joegenbaclor
 * Marking bug fix for solegy START race condition
 *
 * Revision 1.95  2009/01/03 12:14:24  joegenbaclor
 * Reimplemented DestroyConenction to enqueue a session event instead to avoid further race conditons and dead locks.
 * We also implemented B2BUAConnection::IsSafeReference() to further guaranty the integrity of connection pointers.
 *
 * Revision 1.94  2008/12/01 03:52:14  joegenbaclor
 * Upper reg bug fixes
 *
 * Revision 1.93  2008/11/25 15:11:52  joegenbaclor
 * Deprecated SetRewriteRequestURI().  We should always rewrite it!
 *
 * Revision 1.92  2008/11/20 11:02:35  joegenbaclor
 * Depcrecated old SIPMessage URI accessors
 *
 * Revision 1.91  2008/11/12 08:54:15  joegenbaclor
 * Bug:  Delay registrar evaluation for a solegy controlled domain
 *
 * Revision 1.90  2008/11/11 02:54:47  joegenbaclor
 * Feature:  Introducing RTTS aggregation of groomer and osbc
 * Bug:  Disconnect calls if ParseRouting has an empty result set
 *
 * Revision 1.89  2008/11/03 02:35:09  joegenbaclor
 * Introducing new a la B2BUA-Routes Outbound-Proxy routing and deprecated old global
 *  Outbound-Proxy parameter
 *
 * Revision 1.88  2008/09/29 08:02:08  joegenbaclor
 * fixed upper-reg routing
 *
 * Revision 1.87  2008/09/12 09:49:44  joegenbaclor
 * - Upper registration bug fixes.
 * - Bring back support for upper reg routing
 * - Bring back support for upper-reg domain rewrite
 *
 * Revision 1.86  2008/09/09 03:31:25  joegenbaclor
 * Upper Registration bug fixes
 *
 * Revision 1.85  2008/09/04 03:09:56  joegenbaclor
 * reactivation upper reg using new scheme
 *
 * Revision 1.84  2008/09/04 01:13:16  joegenbaclor
 * Finalized routing via registrar for SLA support
 * Used SetInternalHeader connection method instead of the unsafe AddInternalHeader
 *
 * Revision 1.83  2008/09/01 14:44:29  joegenbaclor
 * Commiting interim code for new registrar with SLA support
 *
 * Revision 1.82  2008/08/04 02:45:43  joegenbaclor
 * introduced cnam only solegy handler
 *
 * Revision 1.81  2008/07/24 12:05:48  joegenbaclor
 * Added Solegy Wholesale/SOHO support
 *
 * Revision 1.80  2008/07/01 12:27:00  joegenbaclor
 * Added Solegy debit module
 *
 * Revision 1.79  2008/06/27 11:32:27  joegenbaclor
 * Added check if voice files indeed exist for error announcement
 *
 * Revision 1.78  2008/06/16 08:10:39  joegenbaclor
 * Added default 4xx,5xx,6xx announcement error maps
 *
 * Revision 1.77  2008/06/16 05:49:14  joegenbaclor
 * Completing Announcement-Error-Map support
 *
 * Revision 1.76  2008/06/15 03:38:38  joegenbaclor
 * Some improvements in announcement handling
 *
 * Revision 1.75  2008/06/14 04:08:05  joegenbaclor
 * Added new config parameters for annoucement server
 *
 * Revision 1.74  2008/06/02 08:42:29  joegenbaclor
 * Merging-in Solegy required patches
 *
 * Revision 1.73  2008/04/28 09:31:56  joegenbaclor
 * HTTP admin aesthetics.
 * Allowed User-Agent header to be configurable
 * Incremented release version
 *
 * Revision 1.72  2008/04/25 06:25:03  rcolobong
 * Support disabling/enabling encryption during upper registration
 *
 * Revision 1.71  2008/04/01 05:13:40  rcolobong
 * Corrected the default values of 'Rewrite Request URI'
 *
 * Revision 1.70  2008/03/27 03:31:02  joegenbaclor
 * Added more fine grained NAT detection parameters as suggested by Mike Wengrov
 *
 * Revision 1.69  2008/03/17 11:12:14  rcolobong
 * Fix bug in proxy only mode when calling a registered number
 *
 * Revision 1.68  2008/01/18 05:28:49  joegenbaclor
 * Added Oubound Proxy assignement for B2BUA calls
 *
 * Revision 1.67  2008/01/17 13:03:31  rcolobong
 * Fix possible deadllock in OnInternalResolveAddress
 *
 * Revision 1.66  2007/12/04 16:03:14  joegenbaclor
 * Added Access List Verification
 *
 * Revision 1.65  2007/12/03 07:00:30  joegenbaclor
 * Made sure XFER twords a remote domain are never checked against local registration database
 *
 * Revision 1.64  2007/12/03 06:14:22  joegenbaclor
 * Bug fixes for last commit
 *
 * Revision 1.63  2007/12/01 07:55:21  joegenbaclor
 * Made sure To URI is rewritten when getting xfer attempts
 *
 * Revision 1.62  2007/11/18 16:53:51  joegenbaclor
 * Added support for merged requests ending up in the same connection
 *
 * Revision 1.61  2007/11/07 10:21:10  joegenbaclor
 * various patches for interop issues revealed in SIPIT 21
 *
 * Revision 1.60  2007/11/03 08:00:29  joegenbaclor
 * Added domain alias support for upper reg
 *
 * Revision 1.59  2007/10/23 16:53:56  joegenbaclor
 * bug fix for last commit
 *
 * Revision 1.58  2007/10/23 16:35:30  joegenbaclor
 * more work on refer-to caching
 *
 * Revision 1.57  2007/10/23 16:00:02  joegenbaclor
 * using cache to preserve Refer-To instead of encoding it in the user name
 *
 * Revision 1.56  2007/10/23 14:14:50  joegenbaclor
 * Using hex strings instead of base 64 to encode refer-to during call transfers
 *
 * Revision 1.55  2007/10/15 10:37:49  joegenbaclor
 * Minor bug fixes
 *
 * Revision 1.54  2007/10/02 16:42:56  joegenbaclor
 * Marking initial release of SIP Trunking
 *
 * Revision 1.53  2007/09/26 14:27:21  joegenbaclor
 * SBCRoutingHandler now redirects Trunk calls to the trunk listener address
 *
 * Revision 1.52  2007/09/23 14:50:45  joegenbaclor
 * Added new config params to flag resolution of To and R-RUIs in B2BUA and Ralay routes
 *
 * Revision 1.51  2007/09/19 13:08:29  joegenbaclor
 * Added ability to laod route from external xml file
 *
 * Revision 1.50  2007/09/19 08:56:28  joegenbaclor
 * aesthetics
 *
 * Revision 1.49  2007/08/28 01:25:19  joegenbaclor
 * Completed recording SIP signals for CALEA in pcap format
 *
 * Revision 1.48  2007/08/25 12:17:32  joegenbaclor
 * commiting initial CALEA working alpha code
 *
 * Revision 1.47  2007/08/25 09:08:42  joegenbaclor
 * More work on CALEA trunk
 *
 * Revision 1.46  2007/08/24 01:14:42  joegenbaclor
 * scrapped previous code for upstream proxy handling
 *
 * Revision 1.45  2007/08/22 04:07:08  joegenbaclor
 * Changed B2BRouteCallRedirect to also check the static routes if no registration was found
 *
 * Revision 1.44  2007/08/16 13:25:50  joegenbaclor
 * More work on trunking
 *
 * Revision 1.43  2007/08/08 07:36:08  joegenbaclor
 * Added SBCTrunk classes
 * Removed singleton factory for OSSAppConfig
 *
 * Revision 1.42  2007/08/07 12:58:59  joegenbaclor
 * Made sure we set media proxy mode for routes that are behind NAT
 *
 * Revision 1.41  2007/07/15 12:27:26  joegenbaclor
 * Added capability to route to registered endpoints using static routes
 * Removed unused config parameters
 *
 * Revision 1.40  2007/07/14 07:53:56  joegenbaclor
 * Migrated code to use new STL based string class
 *
 * Revision 1.39  2007/07/07 15:21:17  joegenbaclor
 * Added iproute2 support for linux
 *
 * Revision 1.38  2007/07/06 14:18:25  rcolobong
 * Add Upstream Proxy Route feature
 *
 * Revision 1.37  2007/07/03 17:18:08  joegenbaclor
 * Got rid of compile warnings in unix builds
 *
 * Revision 1.36  2007/06/29 08:20:49  joegenbaclor
 * Removed constness for request param in B2BRouteRequest and RouteLocalRegistration to allow the target address to be set early for the request
 *
 * Revision 1.35  2007/06/18 15:30:54  joegenbaclor
 * Implemented Internal DNS Mapping
 *
 * Revision 1.34  2007/06/17 02:49:50  joegenbaclor
 * Introduced Global lock to PHTTPConfig
 *
 * Revision 1.33  2007/06/06 16:20:54  joegenbaclor
 * Commiting Media Server Related Changes
 *
 * Revision 1.32  2007/05/29 17:43:29  joegenbaclor
 * Initial work on auto attendant
 *
 * Revision 1.31  2007/05/18 12:17:09  joegenbaclor
 * Added DNS routing support for B2BOnlyMode
 *
 * Revision 1.30  2007/05/18 04:21:33  joegenbaclor
 * Set backdoor contact  for registers in B2BUpperRegMode
 *
 * Revision 1.29  2007/05/18 01:24:01  joegenbaclor
 * 1.  Added separate useragent to handle B2BUpperReg backdoor
 * 2.  Modified routing for B2BUpperReg
 * 3.  Corrected bug in ParserTools::GetCompactHeader()
 *
 * Revision 1.28  2007/05/15 12:18:50  joegenbaclor
 * allowed direct DNS routing of upper REGISTER in B2BUpperRegMode
 *
 * Revision 1.27  2007/05/14 06:24:49  joegenbaclor
 * Added DNS Failover and ICMP validation
 *
 * Revision 1.26  2007/04/10 06:32:00  joegenbaclor
 * Added new Encryption Mode
 *
 * Revision 1.25  2007/04/04 05:57:39  joegenbaclor
 * Fixed bug where user part of the r-uri is not set when routing through the registration database and the UA is behind NAT.
 *
 * Revision 1.24  2007/04/03 04:38:25  joegenbaclor
 * Made sure CALL_TRANSFER_PREFIX is stripped when routing through local registration database
 *
 * Revision 1.23  2007/03/28 09:09:21  joegenbaclor
 * Fixed bug in upper registration
 *
 * Revision 1.22  2007/03/22 09:09:39  joegenbaclor
 * Some logging aesthetics
 *
 * Revision 1.21  2007/03/08 01:51:52  joegenbaclor
 * Disallowed rewrite of startline for URI resolving to a remote host
 *
 * Revision 1.20  2007/02/16 11:09:20  joegenbaclor
 * More work on privacy
 *
 * Revision 1.19  2007/02/08 07:21:40  joegenbaclor
 * Corrected bug in RouteProxyRequest where calls to GetContactTopURI may return a NULL
 *  reference
 *
 * Revision 1.18  2007/02/07 01:14:16  joegenbaclor
 * sync laucher related codes
 *
 * Revision 1.17  2007/02/01 07:18:24  joegenbaclor
 * Brought back record route for FullMode
 *
 * Revision 1.16  2007/01/22 13:12:11  joegenbaclor
 * Updated VC710 project files
 *
 * Revision 1.15  2007/01/22 10:00:58  joegenbaclor
 * Fixed ProxyRouteRequest
 *
 * Revision 1.14  2007/01/19 08:20:29  joegenbaclor
 * Added check for none routable proxy request s
 *
 * Revision 1.13  2007/01/18 06:06:56  joegenbaclor
 * Incremented Build Number for latest development release
 *
 * Revision 1.12  2007/01/17 00:09:02  joegenbaclor
 * Added SysLog
 *
 * Revision 1.11  2007/01/15 10:06:57  joegenbaclor
 * More on XML-RPC Registration Queries
 *
 * Revision 1.10  2007/01/15 09:24:47  joegenbaclor
 * Added capability to find Registraton via XML-RPC
 *
 * Revision 1.9  2007/01/12 10:50:05  joegenbaclor
 * minor proxy bug fixes
 * more launcher code
 *
 * Revision 1.8  2007/01/11 10:00:26  joegenbaclor
 * more launcher code
 *
 * Revision 1.7  2007/01/10 05:00:39  joegenbaclor
 * Added B2BUpperReg mode.
 *
 * Revision 1.6  2006/12/21 08:56:59  joegenbaclor
 * Added pid in b2bua log file name
 * Fixed bug in proxy relay where startline URI is not rewritten if a static route is
 *  not found
 *
 * Revision 1.5  2006/12/14 02:18:37  rcolobong
 * Fix bug on OnRecordRouteShift causing an assertion failure during for loop
 *
 * Revision 1.4  2006/11/23 11:24:27  joegenbaclor
 * Added capability to route none INVITE requests like instant messages
 *
 * Revision 1.3  2006/11/22 11:41:01  rcolobong
 * 1. Update handling on Upper Registration
 * 2. Override method on OnOrphanedMessage
 * 3. Create new handling for route-shift in Record Routes Header
 *
 * Revision 1.2  2006/10/11 06:32:58  rcolobong
 * Seperate method for routing using local registration.
 *
 * Revision 1.1  2006/08/14 10:05:01  rcolobong
 * Convert B2BUA to SBC
 * Support MP logging
 *
 * Revision 1.7  2006/08/04 05:48:58  rcolobong
 * 1.  Add Getter for StaticRoutes
 * 2.  Add virtual to method RefreshStaticRoutes
 * 3.  RefreshStaticRoutes is not invoke during construction
 *
 * Revision 1.6  2006/07/19 02:19:13  joegenbaclor
 * 1.  Bug fixes concerning B2BUA destruction during during 3xx, 4xx, 5xx, 6xx local response
 * 2.  Fixed bug where Route header is never removed from outbound Invite resulting that may result to a loop when
 *      Inbound Invite has a Route header present
 * 3.  Added RemoveAllRoutes() in SIPMessage
 *
 * Revision 1.5  2006/07/13 06:53:03  joegenbaclor
 * 1.  Introduced Sanity checks for incoming SIP Message
 * 2.  Corrected bug in SIPURI where enum scheme is not getting recognized.
 * 3.  Added ENUM support to routing
 * 4.  Introduced global routing flag to indicate when and not to rewrite outbound To URI's
 *
 * Revision 1.4  2006/07/11 13:59:34  joegenbaclor
 * Completed Proxy functionalities for B2BUA
 *
 * Revision 1.3  2006/07/10 06:29:36  joegenbaclor
 * Completed crude Registration support for B2BUA
 *
 * Revision 1.2  2006/07/03 15:29:44  joegenbaclor
 * Started merging OpenB2BUA into OpenSBC
 *
 */

#include "SBCRoutingHandler.h"
#include "SBCMediaHandler.h"
#include "SIPTransportTools.h"
#include "SBCConfigParams.h"
#include "SBCSIPTrunk.h"
#include "SBCXBaseManager.h"

#ifdef P_LINUX
#if ENABLE_GPL_LIBS
#include "IPRoute.h"
#endif
#endif

#define new PNEW



SBCRoutingHandler::SBCRoutingHandler(  
  OpenSBC & b2bua 
) : B2BRoutingInterface( b2bua )
{
  if( SIPSrvRecord::m_InternalResolver ==  NULL )
  {
    m_Resolver = new Resolver( this );
    SIPSrvRecord::SetInternalResolver( m_Resolver );
    SIPTransportManager::SetExternalRouteTableAnalyzer( this );
  }
}

SBCRoutingHandler::~SBCRoutingHandler()
{
}

void SBCRoutingHandler::RefreshDNSMap()
{
  OSSAppConfig * config = dynamic_cast<OpenSBC&>(GetB2BUA()).GetAppConfig();
  OStringArray dnsMap;
  for( PINDEX y = 0; y <  config->GetListSize( configKeyDNSMapSection, configKeyInternalDNSMap ); y++ )
    dnsMap.AppendString( config->GetListItem( configKeyDNSMapSection, configKeyInternalDNSMap, y ) );
  
  if( dnsMap.GetSize() > 0 )
    m_InternalDNSMap.Parse( dnsMap );
}

void SBCRoutingHandler::RefreshCALEAMap()
{
  OSSAppConfig * config = dynamic_cast<OpenSBC&>(GetB2BUA()).GetAppConfig();
  OString caleaFilter = config->GetString( configKeyCALEASection, configKeyCALEAFilter, "" );
  if( !caleaFilter.IsEmpty() )
    m_CALEAFilter = caleaFilter.Tokenise( ",", FALSE );
}

void SBCRoutingHandler::RefreshStaticRoutes()
{
  OSSAppConfig * config = dynamic_cast<OpenSBC&>(GetB2BUA()).GetAppConfig();
  
  /// lock the config to make sure noone can change data via http admin until we are done
  PWaitAndSignal configLock( PHTTPConfig::m_HTTPConfigMutex );

  BOOL hasMediaServer = GetB2BUA().GetMediaServer() != NULL;
  
  OStringArray routes;

  if( hasMediaServer )
  {
    PIPSocket::Address ivrListener = GetB2BUA().GetMediaServer()->GetListenerAddress();
    WORD ivrPort = GetB2BUA().GetMediaServer()->GetListenerPort();
    SIPURI ivrRoute( ivrListener, ivrPort );
    ivrRoute.SetUser( "annc" );
    m_StaticRoutes.SetIVRRoute( ivrRoute );

    
    OStringStream autoAttendantRoute;
    autoAttendantRoute << "[sip:" 
                       << config->GetString( configMediaServerSection, configKeyAutoAttendantNumber, "5000" ) 
                       << "@*] ivr";
    PTRACE( 1, "Automatically appending Auto-Attendant Route..." << autoAttendantRoute.str() );
    routes.AppendString( autoAttendantRoute );

    if( config->GetBoolean( configMediaServerSection, configKeyEnableAnnouncementService, FALSE ) )
    {
      OString announcementServiceRoute( "[sip:annc@*] ivr" );
      routes.AppendString( announcementServiceRoute );
      PTRACE( 1, "Automatically appending Announcement-Service Route..." << announcementServiceRoute );

      GetB2BUA().GetB2BUAEndPoint()->SetAnnouncementserverURI( ivrRoute );
      GetB2BUA().GetB2BUAEndPoint()->SetWillSendAnnouncement( TRUE );
    }else
    {
      GetB2BUA().GetB2BUAEndPoint()->SetWillSendAnnouncement( FALSE );
    }
  }
  
  BOOL useExternalB2BUAroute = config->GetBoolean( configKeyB2BUASection, configKeyB2BUARouteUserExternalXML, FALSE );;

  if( !useExternalB2BUAroute )
  {
    for( PINDEX i = 0; i <  config->GetListSize( configKeyB2BUASection, configKeyB2BUARouteList ); i++ )
      routes.AppendString( config->GetListItem( configKeyB2BUASection, configKeyB2BUARouteList, i ) );

    if( routes.GetSize() > 0 )
      m_StaticRoutes.Parse( routes );
  }else
  {
    PXML externalXML;
    PString path = config->GetString( configKeyB2BUASection, configKeyB2BUARouteUserExternalXMLPath, "b2bua-route.xml" );
    if( path.IsEmpty() || !externalXML.LoadFile( path ) )
    {
      for( PINDEX i = 0; i <  config->GetListSize( configKeyB2BUASection, configKeyB2BUARouteList ); i++ )
        routes.AppendString( config->GetListItem( configKeyB2BUASection, configKeyB2BUARouteList, i ) );

      if( routes.GetSize() > 0 )
        m_StaticRoutes.Parse( routes );
    }else
    {
      PTRACE( 1, "Using " << path << " to load B2BUA Routes" );
      m_StaticRoutes.Parse( externalXML );
    }
  }

  m_StaticRoutes.SetICMPValidate( config->GetBoolean( 
        configKeyB2BUASection, 
        configKeyB2BICMPValidation, FALSE ) );

  OStringArray relayRoutes;
  for( PINDEX x = 0; x <  config->GetListSize( configKeyRelayRouteSection, configKeyB2BUARouteList ); x++ )
    relayRoutes.AppendString( config->GetListItem( configKeyRelayRouteSection, configKeyB2BUARouteList, x ) );

  if( relayRoutes.GetSize() > 0 )
    m_RelayRoutes.Parse( relayRoutes );

  m_RelayRoutes.SetICMPValidate( config->GetBoolean( 
        configKeyRelayRouteSection, 
        configKeyRelayICMPValidation, FALSE ) );

}

void SBCRoutingHandler::RefreshInterfaceTable()
{
  OSSAppConfig * config = dynamic_cast<OpenSBC&>(GetB2BUA()).GetAppConfig();
  /// lock the config to make sure no one can change data via http admin until we are done
  PWaitAndSignal configLock( PHTTPConfig::m_HTTPConfigMutex );
  OStringArray routes;
  for( PINDEX i = 0; i <  config->GetListSize( configKeySIPTransportSection, configKeyInterfaceRouteList ); i++ )
    routes.AppendString( config->GetListItem( configKeySIPTransportSection, configKeyInterfaceRouteList, i ) );
  
  if( routes.GetSize() > 0 )
    m_InterfaceTable.Parse( routes );
}

BOOL SBCRoutingHandler::B2BRouteRequest(
  SIPMessage & request,
  SIPURI  & route
)
{
  /// lock the config to make sure no one can change data via http admin until we are done
  PWaitAndSignal configLock( PHTTPConfig::m_HTTPConfigMutex );

  const To & to = request.GetTo();

  SIPURI uri = to.GetURI();
  OString user = uri.GetUser();
  OString callId = request.GetCallId();

  LOG_CONTEXT( LogInfo(), callId, "Routing URI " << uri << "through local registration database" );

  SIPMessage registration;

  OpenSBC & sbc = dynamic_cast<OpenSBC&>(GetB2BUA());
  REGISTRAR::Registrar * registrar = sbc.GetLocalRegistrar();

  if( !registrar->FindRegistration( uri, registration ) )
  {
    LOG_CONTEXT( LogInfo(), callId, "*** NO ROUTE ** URI " << uri << "through local registration database" );
    return FALSE;
  }

  return RouteLocalRegistration( route, request, registration );
}

BOOL SBCRoutingHandler::B2BRouteMergedInvite(
  SIPMessage & invite,
  SIPURI & route
)
{
  SIPURI uri;
  invite.GetRequestURI( uri );

  SIPMessage registration;
  OpenSBC & sbc = dynamic_cast<OpenSBC&>(GetB2BUA());
  REGISTRAR::Registrar * registrar = sbc.GetLocalRegistrar();
  if( registrar->FindRegistration( uri, registration ) )
    return RouteLocalRegistration( route, invite, registration, NULL );

  LOG_CONTEXT( LogInfo(), invite.GetCallId(), "*** NO ROUTE ** URI " << uri << "through local registration database" );
  return m_StaticRoutes.FindRoute( uri, route );
}

BOOL SBCRoutingHandler::B2BRouteCallRedirect(
  B2BUAConnection & /*connection*/,
  B2BUACall & /*call*/,
  SIPMessage & invite
)
{
  /// lock the config to make sure no one can change data via http admin until we are done
  PWaitAndSignal configLock( PHTTPConfig::m_HTTPConfigMutex );

  To to = invite.GetTo();

  SIPURI uri;
  invite.GetRequestURI( uri );
  
  OString user = uri.GetUser();
  OString callId = invite.GetCallId();

  SIPMessage registration;
  SIPURI route;

  OSSAppConfig * config = dynamic_cast<OpenSBC&>(GetB2BUA()).GetAppConfig();
  BOOL rewriteToURI = config->GetBoolean( 
      configKeyB2BUASection, 
      configKeyB2BUARewriteToURI, FALSE );

  OpenSBC & sbc = dynamic_cast<OpenSBC&>(GetB2BUA());
  REGISTRAR::Registrar * registrar = sbc.GetLocalRegistrar();

  if( !registrar->FindRegistration( uri, registration ) )
  {
    LOG_CONTEXT( LogInfo(), callId, "*** NO ROUTE ** URI " << uri << "through local registration database" );
    
    if( m_StaticRoutes.FindRoute( uri, route ) )
    {
      invite.SetRequestURI( route );
           
      if( rewriteToURI )
      {
        to.SetURI( route );
        invite.SetTo( to );
      }
      return TRUE;
    }

    return FALSE;
  }

  
  if( RouteLocalRegistration( route, invite, registration ) )
  {
    invite.SetRequestURI( route );
    if( rewriteToURI )
    {
      to.SetURI( route );
      invite.SetTo( to );
    }
    return TRUE;
  }

  return FALSE;
}



#ifndef CALL_TRANSFER_PREFIX 
#define CALL_TRANSFER_PREFIX "xfer-oss-"
#endif

BOOL SBCRoutingHandler::B2BRouteCall(
  B2BUAConnection & connection,
  SIPMessage & invite,
  BOOL _ignoreRegistrations
)
{
  /// check if invite has a routing vector
  XRoutingVector * routeVector = invite.GetXRoutingVector();
  if( routeVector != NULL )
  {
    SIPURI customRoute( "wsdb:localhost" );
    connection.AddRoute( customRoute, &invite );
    return TRUE;
  }
  
  /// lock the config to make sure no one can change data via http admin until we are done
  PWaitAndSignal configLock( PHTTPConfig::m_HTTPConfigMutex );

  BOOL ignoreRegistrations = _ignoreRegistrations;
  
  OpenSBC & sbc = dynamic_cast<OpenSBC&>(GetB2BUA());
  REGISTRAR::Registrar * registrar = sbc.GetLocalRegistrar();

  To to = invite.GetTo();

  SIPURI uri = to.GetURI();
  OString user = uri.GetUser();
  OString callId = invite.GetCallId();
  PIPSocket::Address verifiedAddress;
  WORD verifiedPort = 0;

  if( !ignoreRegistrations && sbc.GetSolegyManager() != NULL )
  {
    /// check if this domain is a solegy controlled domain
    ignoreRegistrations = sbc.GetSolegyManager()->IsRoutableDomain( invite );
    if( ignoreRegistrations )
    {
      LOG_CONTEXT( LogInfo(), callId, "Delaying Registar Routing for a Solegy Routable Domain - " << uri );
    }
  }
  
 
  
 

  SIPURI reqURI;
  invite.GetRequestURI( reqURI );
  if( !reqURI.GetUser().IsEmpty() )
    uri.SetUser( reqURI.GetUser() );
  

  OString  transferPrefix = CALL_TRANSFER_PREFIX;

  

  if( user.Left( transferPrefix.GetLength() ) == transferPrefix )
  {
    LOG_CONTEXT( LogInfo(), callId, "Stripping Call Transfer Prefix for " << uri );
    OString xferTo = user.Mid( transferPrefix.GetLength() );
   
    if( !xferTo.IsEmpty() )
    {
        CacheObject * xferCache = m_ReferCache.RemoveAt( xferTo, FALSE );
        if( xferCache != NULL )
        {
         

          reqURI = uri =  dynamic_cast<ReferTo*>(xferCache->GetObject())->GetURI().GetBasicURI();
          invite.SetRequestURI( uri );
          to.SetURI( uri );
          invite.SetTo( to );
          LOG_CONTEXT( LogInfo(), callId, "*** XFER-CACHE FOUND *** for uri=" <<uri );
          delete xferCache;
          /// we ignore registrations for call towards a remote domain
          ignoreRegistrations = m_B2BUA.GetUAMode() == B2BUserAgent::B2BUpperRegMode && !m_B2BUA.GetTransportManager()->IsLocalAddressAndPort( uri );
        }else
        {
          LOG_CONTEXT( LogWarning(), callId, "*** XFER-CACHE NOT FOUND!!! *** id=" << xferTo );
        }
    }   
  }

  //check first if the invite has a "SBC-Force-Route" custom header
  SIPHeader forceRoute( "SBC-Force-Route" );
  if( invite.PopCustomHeader( "SBC-Force-Route", forceRoute ) )
  {
    SIPURI frURI = forceRoute.GetHeaderBody();
    if( SIPTransport::Resolve( frURI, verifiedAddress, verifiedPort, SIPTransport::UDP, FALSE ) )
    {
      LOG_CONTEXT( LogInfo(), callId, "*** Using Force-Route URI *** " << frURI << " as route" );
      connection.AddRoute( frURI );
      return TRUE;
    }
  }
  
  OSSAppConfig * config = dynamic_cast<OpenSBC&>(GetB2BUA()).GetAppConfig();
  


  SIPMessage registration;

  if( GetB2BUA().GetUAMode() == B2BUserAgent::B2BOnlyMode && 
      dynamic_cast<OpenSBC&>(GetB2BUA()).GetAppConfig()->GetType() == OSSAppConfig::XMLRPCClientProvider 
  )
  {
    LOG_CONTEXT( LogInfo(), callId, "Fetching route through XML RPC for URI " << uri );
    OpenSBCDaemon * app = dynamic_cast<OpenSBCDaemon*>(OSSApplication::GetInstance());
    OString serverURL = app->GetExtendedArgs().GetParameter( "xml-rpc-registrar" );
    LOG_CONTEXT( LogInfo(), callId, "Using remote XML-RPC registrar at " << serverURL );
    BOOL ok = FALSE;
    if( !serverURL.IsEmpty() )
    {
      PArray<PStringToString>  cmd;
      PArray<PStringToString>  response;
      PStringToString * cmdParams = new PStringToString();
      cmdParams->SetAt( "URI", uri.AsString() );
      cmd.SetAt( 0, cmdParams );
      config->SendRequest( "Registrar.FindRegistration", cmd, response, serverURL.c_str() );
      PStringToString * responseParams = static_cast<PStringToString*>(response.GetAt(0));
      if( responseParams != NULL )
      {
        PString * reg = responseParams->GetAt( "Registration" );
        if( reg == NULL || reg->IsEmpty() )
        {
          LOG_CONTEXT( LogInfo(), callId, "*** NO ROUTE *** through XML RPC for URI " << uri );
          ok = FALSE;
        }else
        {
          LOG_CONTEXT( LogInfo(), callId, "*** ROUTE FOUND *** through XML RPC for URI " << uri );
          connection.AddRoute( SIPURI((const char *)*reg) );
          return TRUE;
        }
      }
    }

    if( !ok )
    {
      BOOL rewriteToURI = config->GetBoolean( 
        configKeyB2BUASection, 
        configKeyB2BUARewriteToURI, FALSE );

      /*
      BOOL rewriteRequestURI = config->GetBoolean(
        configKeyB2BUASection,
        configKeyB2BUARewriteRequestURI, TRUE );
      */
      BOOL insertRouteHeader = config->GetBoolean(
        configKeyB2BUASection,
        configKeyB2BUAInsertRouteHeader, FALSE );

      /// deprecated: connection.SetRewriteRequestURI( rewriteRequestURI );
      connection.SetInsertRouteHeader( insertRouteHeader );
      connection.SetRewriteToURI( rewriteToURI );

      PString fromDomain = config->GetString( configKeyB2BUASection, configKeyB2BUARewriteFromDomain, "" );
      connection.SetFromDomain( (const char *)fromDomain );

     ///BOOKMARK
#ifdef HAS_XBASE
      OpenSBC & sbc = dynamic_cast<OpenSBC&>(GetB2BUA());
#endif
      return m_StaticRoutes.FindRoute(
        *(GetB2BUA().GetStack().GetTransportManager()),
        *registrar, 
        invite, 
        connection,
        TRUE
#ifdef HAS_XBASE
        , sbc.GetXBaseManager() 
#endif
        );
    }
  }else if( ignoreRegistrations || !registrar->FindRegistration( reqURI, registration )  )
  {
    LOG_CONTEXT( LogDebug(), callId, "*** NO REGISTRATION FOUND *** Fetching route through local database URI " << reqURI );
    BOOL rewriteToURI = config->GetBoolean( 
      configKeyB2BUASection, 
      configKeyB2BUARewriteToURI, FALSE );

      BOOL insertRouteHeader = config->GetBoolean(
        configKeyB2BUASection,
        configKeyB2BUAInsertRouteHeader, FALSE );

      /// deprecated: connection.SetRewriteRequestURI( rewriteRequestURI );
      connection.SetInsertRouteHeader( insertRouteHeader );
      connection.SetRewriteToURI( rewriteToURI );

      PString fromDomain = config->GetString( configKeyB2BUASection, configKeyB2BUARewriteFromDomain, "" );
      connection.SetFromDomain( (const char *)fromDomain );

    BOOL found = FALSE;
    
    {
      SIPURI ruri = invite.GetRequestURI();
      OString userString = ruri.GetUser();
      if( userString.Left( 9 ) == "x-reg-id-" )
      {
        OString xAliasRegId = userString.Mid( 9 );
        OString xAliasCURI = ParserTools::UnescapeAsRFC2396( xAliasRegId );
        SIPURI targetURI( xAliasCURI );
        connection.AddRoute( targetURI );
        connection.SetMediaProxyIfPrivate( FALSE );
        /// deprecated: connection.SetRewriteRequestURI( TRUE );

        LOG_CONTEXT( LogInfo(), callId, "*** UPPER REGISTRATION FOUND *** -->> Callee: " << invite.GetFromURI() 
          << " AOR: " << invite.GetRequestURI() << " BINDING: " << targetURI );

        found = TRUE;
      }
    }

    if( !found )
    {
      OpenSBC & sbc = dynamic_cast<OpenSBC&>(GetB2BUA());
      REGISTRAR::Registrar * registrar = sbc.GetLocalRegistrar();

      found = m_StaticRoutes.FindRoute( 
        *(GetB2BUA().GetStack().GetTransportManager()),
        *registrar, 
        invite, 
        connection,
        TRUE
#ifdef HAS_XBASE
        , sbc.GetXBaseManager() 
#endif
        );
    }

    BOOL b2buaResolveToURI = config->GetBoolean( configKeyB2BUASection, configKeyB2BUAResolveToURI, FALSE );
    BOOL b2buaResolveRequestURI = config->GetBoolean( configKeyB2BUASection, configKeyB2BUAResolveRequestURI, FALSE );

    if( !found )
    {
      LOG_CONTEXT( LogInfo(), callId, "*** NO STATIC ROUTE *** URI " << uri );
      if( ignoreRegistrations )
      {
        SIPURI routeURI;
        invite.GetRequestURI( routeURI );
        
        if( !GetB2BUA().GetStack().GetTransportManager()->IsLocalAddressAndPort( routeURI ) && b2buaResolveRequestURI )
        {
          if( SIPTransport::Resolve( routeURI, verifiedAddress, verifiedPort, SIPTransport::UDP, FALSE ) )
          {
            LOG_CONTEXT( LogInfo(), callId, "*** Using Request URI *** " << routeURI << " as route" );
            connection.AddRoute( routeURI );
            return TRUE;
          }
        }else if( b2buaResolveToURI )
        {
          /// I know it's a bit strange to route using the to URI but it seems a common implementation mistake
          /// so we just have to live with it.
          routeURI = invite.GetToURI();
          if( !GetB2BUA().GetStack().GetTransportManager()->IsLocalAddressAndPort( routeURI ) )
          {
            if( SIPTransport::Resolve( routeURI, verifiedAddress, verifiedPort, SIPTransport::UDP, FALSE ) )
            {
              LOG_CONTEXT( LogInfo(), callId, "*** Using To URI *** " << routeURI << " as route" );
              connection.AddRoute( routeURI );
              return TRUE;
            }
          }
        }
      }else
      {
        found = RouteLocalRegistration( connection, invite, registration );
        if( !found )
        {
          SIPURI routeURI;
          invite.GetRequestURI( routeURI );
          verifiedAddress = 0;
          verifiedPort = 0;
          
          if( !GetB2BUA().GetStack().GetTransportManager()->IsLocalAddressAndPort( routeURI ) && b2buaResolveRequestURI )
          {
            ///  the request-URI is bound for a remote address.  Use it.
            if( SIPTransport::Resolve( routeURI, verifiedAddress, verifiedPort, SIPTransport::UDP, FALSE ) )
            {
              LOG_CONTEXT( LogInfo(), callId, "*** Using Request URI *** " << routeURI << " as route" );
              connection.AddRoute( routeURI );
              return TRUE;
            }
          }else if( b2buaResolveToURI )  
          {
            /// I know it's a bit strange to route using the to URI but it seems a common implementation mistake
            /// so we just have to live with it.
            routeURI = invite.GetToURI();
            if( !GetB2BUA().GetStack().GetTransportManager()->IsLocalAddressAndPort( routeURI ) )
            {
              if( SIPTransport::Resolve( routeURI, verifiedAddress, verifiedPort, SIPTransport::UDP, FALSE ) )
              {
                LOG_CONTEXT( LogInfo(), callId, "*** Using To URI *** " << routeURI << " as route" );
                connection.AddRoute( routeURI );
                return TRUE;
              }
            }
          }
        }
      }
    }else
    {
      for( int i = 0; i < connection.GetRoutes().GetSize(); i++ )
      {
        LOG_CONTEXT( LogInfo(), callId, "*** STATIC ROUTE FOUND *** " << uri << " >>> " << connection.GetRoutes()[i] );
      }
    }
    return found;
  }

  return RouteLocalRegistration( connection, invite, registration );;
  
}


ProxySession::RoutePolicy SBCRoutingHandler::RouteProxyRequest(
  ProxySession & session,
  SIPMessage & request
)
{
  /// lock the config to make sure no one can change data via http admin until we are done
  PWaitAndSignal configLock( PHTTPConfig::m_HTTPConfigMutex );

  //// check to TO header if it resolves to this proxy
  const To & to = request.GetTo();

  SIPURI toURI = to.GetURI();
  SIPURI targetURI = to.GetURI();
  OString callId = request.GetCallId();

  RequestLine requestLine = request.GetRequestLine();
  SIPURI oldURI = requestLine.GetRequestURI();

  OpenSBC & sbc = dynamic_cast<OpenSBC&>(GetB2BUA());
  REGISTRAR::Registrar * registrar = sbc.GetLocalRegistrar();

  OSSAppConfig * config = dynamic_cast<OpenSBC&>(GetB2BUA()).GetAppConfig();
  BOOL proxyResolveToURI = config->GetBoolean( configKeyRelayRouteSection, configKeyProxyResolveToURI, FALSE );

  if( !request.IsRequest() )
  {
    OnRecordRouteShift( request );
  }else if( !request.IsCancel() && !request.IsAck() )
  {
    BOOL relay = FALSE;
    BOOL allowRoundRobin = request.IsInvite();
   

    if( !m_AppRelayRoutes.FindRoute( request, targetURI, allowRoundRobin, TRUE ) )
    {
      if( m_RelayRoutes.FindRoute( request, targetURI, allowRoundRobin, TRUE ) )
        relay = TRUE;
    }else
    {
      relay = TRUE;
    }

    if( relay  )
    {
      /// this means we can relay the toURI;
      session.SetCreateDialog();
      session.SetDialogPeerAddress( targetURI.AsString() );

      PTRACE( 1, "*** PROXY *** Allowing To-URI" << targetURI << " to be Proxied" );

      RouteURI recordRoute;
      SIPURI routeURI;

      PIPSocket::Address targetAddress, listenerAddress;
      WORD targetPort = 0, listenerPort = 0;

      if( !SIPTransport::Resolve( targetURI, targetAddress, targetPort ) )
      {
        PTRACE( 1, "*** PROXY *** Unable to resolve target UA for  " << request.GetStartLine() );
        return ProxySession::RouteReject;
      }

      if( !GetB2BUA().GetStack().GetTransportManager()->GetListenerAddress(
        SIPTransport::UDP, targetAddress, listenerAddress, listenerPort ) )
      {
        PTRACE( 1, "*** PROXY *** Unable to identify a network interface for  " << request.GetStartLine() );
        return ProxySession::RouteReject; 
      }

      routeURI.SetHost( listenerAddress.AsString() );
      routeURI.SetPort( OString( listenerPort ) );

      Contact contact;
      if( request.GetContactAt( contact, 0 ) )
      {
        ContactURI curi;
        if( contact.GetURI( curi ) )
        {
          if( SIPTransport::IsPrivateNetwork( listenerAddress ) && !SIPTransport::IsPrivateNetwork( curi.GetURI().GetAddress() ) )
          {
            /// public to private routing... lets tag the record route
            PIPSocket::Address shiftAddress;
            WORD shiftPort;

            GetB2BUA().GetStack().GetTransportManager()->GetListenerAddress(
              SIPTransport::UDP, request.GetTopContactURI().GetAddress(), shiftAddress, shiftPort );
            OString routeShift = shiftAddress.AsString() + ":" + OString( shiftPort );

            routeURI.AddParameter( "route-shift", routeShift );
          }
        }
      }

      recordRoute.SetURI( routeURI );
      recordRoute.SetLooseRouter( TRUE );
      PTRACE( 1, "*** PROXY *** Appending Record-Route " <<  routeURI );
      request.AppendRecordRoute( recordRoute );

      oldURI.SetHost( targetURI.GetHost() );
      oldURI.SetPort( targetURI.GetPort() );
      requestLine.SetRequestURI( oldURI );
      request.SetStartLine( requestLine );

      return ProxySession::RouteBySession;
    }else
    {
      /// check if the request URI resolves to us
      RequestLine rq = request.GetRequestLine();
      {
        SIPURI rqURI = rq.GetRequestURI();
        if( session.GetTransportManager()->IsLocalAddressAndPort( rqURI ) )
        {
          SIPMessage registration;
          if( registrar->FindRegistration( rqURI, registration ) )
          { 
            SIPURI tempURI;
            if( RouteLocalRegistration( tempURI, request,  registration ) )
            {
              LOG_CONTEXT( LogInfo(), callId, "*** PROXY *** URI " << rqURI << " route through local registration database" );
              rq.SetRequestURI( tempURI );
              request.SetStartLine( rq );
            } else
            {
              LOG_CONTEXT( LogError(), callId, "*** PROXY *** URI " << rqURI << " unable to route through local registration database" );
              return ProxySession::RouteReject;
            }
          } else if( !session.GetTransportManager()->IsLocalAddressAndPort( request.GetToURI() ) )
          {
            PTRACE( 1, "*** PROXY *** " << rqURI << " Resolves to this host.  Using To-URI as Request-URI" );
            SIPURI uri( request.GetToURI().AsString( FALSE, FALSE ) );
            uri.SetUser( rq.GetRequestURI().GetUser() );
            rq.SetRequestURI( uri );
            request.SetStartLine( rq );
          }else
          {
            return ProxySession::RouteReject;
          }
        }else if( !proxyResolveToURI )
        {
          /// we are configured to not allow a relay
          PTRACE( 1, "*** PROXY *** Not Allowing relay to " << targetURI );
          return ProxySession::RouteReject;
        }
      }
    }
  }else if(  ( request.IsCancel() || request.IsAck() ) )
  {
    targetURI = session.GetDialogPeerAddress();
    targetURI.SetUser( oldURI.GetUser() );
    requestLine.SetRequestURI( targetURI );
    request.SetStartLine( requestLine );

    /// se if we could resolve the resulting request
    PIPSocket::Address newTarget;
    WORD newPort = 0;
    if( SIPTransport::Resolve( request, newTarget, newPort ) )
    {
      if( session.GetTransportManager()->IsLocalAddressAndPort( newTarget, newPort ) )
      {
        /// request resolves to us ....
        session.SetSessionRejectResponse( SIPMessage::Code481_TransactionDoesNotExist );
        return ProxySession::RouteReject;
      } 
    }else
    {
      /// we are unable to resolve this address
      session.SetSessionRejectResponse( SIPMessage::Code481_TransactionDoesNotExist );
      return ProxySession::RouteReject;
    }

  }else
  {
    return RouteProxyNISTRequest( session, request );
  }
    
  return ProxySession::RouteBySession;
}

ProxySession::RoutePolicy SBCRoutingHandler::RouteProxyNISTRequest(
  ProxySession & session,
  SIPMessage & request
)
{
  /// lock the config to make sure no one can change data via http admin until we are done
  PWaitAndSignal configLock( PHTTPConfig::m_HTTPConfigMutex );

  /// se if we could resolve the resulting request
  PIPSocket::Address newTarget;
  WORD newPort = 0;
  if( SIPTransport::Resolve( request, newTarget, newPort ) )
  {
    if( session.GetTransportManager()->IsLocalAddressAndPort( newTarget, newPort ) )
    {
      /// request resolves to us ....
      session.SetSessionRejectResponse( SIPMessage::Code481_TransactionDoesNotExist );
      return ProxySession::RouteReject;
    }
  }else
  {
    session.SetSessionRejectResponse( SIPMessage::Code404_NotFound );
    return ProxySession::RouteReject;
  }

  return ProxySession::RouteBySession;
}

void SBCRoutingHandler::OnOrphanedMessage(
  SIPMessage & message
)
{
  if( !message.IsRequest() )
    OnRecordRouteShift( message );
}

BOOL SBCRoutingHandler::RouteLocalRegistration( 
  B2BUAConnection & connection,
  SIPMessage & invite,
  const SIPMessage & registration
)
{
  /// lock the config to make sure no one can change data via http admin until we are done
  //PWaitAndSignal configLock( PHTTPConfig::m_HTTPConfigMutex );

  OString callId = invite.GetCallId();
  SIPURI requestURI = invite.GetRequestURI();

  {
    SIPURI ruri = invite.GetRequestURI();
    OString userString = ruri.GetUser();
    if( userString.Left( 9 ) == "x-reg-id-" )
    {
      OString xAliasRegId = userString.Mid( 9 );
      OString xAliasCURI = ParserTools::UnescapeAsRFC2396( xAliasRegId );
      SIPURI targetURI( xAliasCURI );
      connection.AddRoute( targetURI );
      connection.SetMediaProxyIfPrivate( FALSE );
      /// deprecated: connection.SetRewriteRequestURI( TRUE );
      LOG_CONTEXT( LogInfo(), callId, "*** UPPER REGISTRATION FOUND *** -->> Callee: " << invite.GetFromURI() 
        << " AOR: " << invite.GetRequestURI() << " BINDING: " << targetURI );

      return TRUE;
    }
  }

  /// check if this request is bound for upper reg
  if( !GetB2BUA().GetTransportManager()->IsLocalAddressAndPort( requestURI ) )
  {
    if( m_B2BUA.GetUAMode() == B2BUserAgent::B2BUpperRegMode )
    {
      OpenSBC & sbc = dynamic_cast<OpenSBC&>(GetB2BUA());
      REGISTRAR::Registrar * registrar = sbc.GetLocalRegistrar();
      
      SIPURI targetURI;
      if( registrar->m_UpperRegistrationRoutes->FindRoute( invite.GetRequestURI(), targetURI ) )
      {
        connection.AddRoute( targetURI.GetBasicURI() );
        OString domain;
        if( targetURI.GetParameter( "domain", domain ) )
        {
          if( registrar->m_UpperRegRewriteFromDomain && !domain.IsEmpty() )
          {
            From from = invite.GetFrom();
            {
              SIPURI uri = from.GetURI();
              uri.SetHost( domain );
              from.SetURI( uri );
              invite.SetFrom( from );
            }
          }

          if( registrar->m_UpperRegRewriteFromDomain && !domain.IsEmpty() )
          {
            To to = invite.GetTo();
            {
              SIPURI uri = to.GetURI();
              uri.SetHost( domain );
              to.SetURI( uri );
              invite.SetTo( to );
            }
          }
        }
      }else
      {
        connection.AddRoute( invite.GetRequestURI() );
      }

      connection.SetMediaProxyIfPrivate( FALSE );

      LOG_CONTEXT( LogInfo(), callId, "*** UPPER REGISTRATION RELAY *** -->> Callee: " << invite.GetFromURI() 
          << " AOR: " << invite.GetRequestURI() << " BINDING: " << invite.GetRequestURI() );
      return TRUE;
    }
  }
  
  OString regcount = registration.GetInternalHeader( "REG-COUNT" );
  if( !regcount.IsEmpty() && regcount.AsInteger() > 1 )
  {
    // ok we have multiple routes
    // use the new machanism to find multiple bindings
    OpenSBC & sbc = dynamic_cast<OpenSBC&>(GetB2BUA());
    REGISTRAR::Registrar * registrar = sbc.GetLocalRegistrar();
    
    Contact contacts;
    if( !registrar->FindRegistrationBinding( invite, contacts ) )
      return FALSE;
    
    int count = contacts.GetSize();
    if( count == 0 )
      return FALSE;

    for( PINDEX i = 0; i < count; i++ )
    {
      SIPURI targetURI;
      ContactURI contactURI;
      contacts.GetURI( contactURI, i );
      targetURI = contactURI.GetURI();

      LOG_CONTEXT( LogInfo(), callId, "*** MULTIPLE REGISTRATION FOUND *** -->> Callee: " << invite.GetFromURI() 
        << " AOR: " << invite.GetRequestURI() << " BINDING: " << targetURI );

      connection.AddRoute( targetURI );
     
    }

    SIPHeader parallelFork( "PARALLEL-FORK", "T" );
    connection.SetInternalHeader( "PARALLEL-FORK", parallelFork );
    
    /// TODO:  In the future, let the registrar tell us when to proxy or not 
    /// based on whether any of the binding is NATted
    connection.SetMediaProxyIfPrivate( FALSE );

  }else
  {
    /// there is only one route.  
    /// Use old scheme and bind to the REGISTER
    SIPURI targetURI;
    if( !RouteLocalRegistration( targetURI, invite, registration, &connection ) )
      return FALSE;
    connection.AddRoute( targetURI );
    invite.SetSendAddress( targetURI );
  }

  return TRUE;
}

BOOL SBCRoutingHandler::RouteLocalRegistration(
  SIPURI & targetURI,
  SIPMessage & request,
  const SIPMessage & registration,
  B2BUAConnection * connection
)
{
  /// lock the config to make sure no one can change data via http admin until we are done
  //PWaitAndSignal configLock( PHTTPConfig::m_HTTPConfigMutex );

  if( !ExtractTargetURI( targetURI, registration, connection ) )
    return FALSE;

  OString callId = request.GetCallId();

  LOG_CONTEXT( LogInfo(), callId, "*** SINGLE REGISTRATION FOUND *** -->> Callee: " << request.GetFromURI() 
    << " AOR: " << request.GetRequestURI() << " BINDING:" << targetURI );

  return TRUE;
}

BOOL SBCRoutingHandler::ExtractTargetURI(
  SIPURI & targetURI,
  const SIPMessage & registration,
  B2BUAConnection * connection
)
{
  if( registration.GetContactSize() == 0 )
    return FALSE;

  Contact contact;
  if( !registration.GetContactAt( contact, 0 ) )
    return FALSE;
  
  ContactURI contactURI;
  contact.GetURI( contactURI );
  targetURI = contactURI.GetURI();
    
  /// check the via if this is a NATted registration
  const Via & via = registration.GetTopVia();
  if( via.IsBehindNAT() ) 
  {
    targetURI.SetHost( via.GetReceiveAddress().AsString() );
    targetURI.SetPort( OString( via.GetRPort() ) );
  }

  BOOL createOnlyIfPrivate = TRUE;
  SIPURI viaURI;
  viaURI = via.GetURI();
  
  if( createOnlyIfPrivate && GetSBC().GetSBCMediaHandler()->GetProxyPrivateContact() )
  {
    if( registration.GetContactSize() > 0 )
      createOnlyIfPrivate = !registration.GetTopContactURI().IsPrivateNetwork();
  }
  
  if( createOnlyIfPrivate && GetSBC().GetSBCMediaHandler()->GetProxyViaReceived() )
  {
    if( registration.GetViaSize() > 0 )
    {
      PIPSocket::Address received = via.GetReceiveAddress();
      PIPSocket::Address host = viaURI.GetAddress();
      createOnlyIfPrivate = (host == received);
    }
  }

  if( createOnlyIfPrivate && GetSBC().GetSBCMediaHandler()->GetProxyViaSendAddress() )
  {
    if( registration.GetViaSize() > 0 )
    {
      PIPSocket::Address host = viaURI.GetAddress();
      createOnlyIfPrivate = !host.IsRFC1918();
    }
  }

  if( createOnlyIfPrivate && GetSBC().GetSBCMediaHandler()->GetProxyViaRPort() )
  {
    createOnlyIfPrivate = (via.GetRPort() == via.GetPort());
  }

  if( connection != NULL )
    connection->SetMediaProxyIfPrivate( createOnlyIfPrivate );

  if( registration.IsEncrypted() )
    targetURI.AddParameter( "encrypted", "true" );

  return TRUE;
}

void SBCRoutingHandler::OnRecordRouteShift(
  SIPMessage & msg
)
{
  if( !msg.IsRequest() )
  {
    PINDEX routeCount = msg.GetRecordRouteSize();
    RecordRouteList oldList;
    msg.GetRecordRouteList( oldList );
    RecordRouteList newList;
    BOOL willReplaceRoutes = FALSE;

    for( PINDEX i = routeCount - 1; i >= 0; i-- )
    {
      RecordRoute recordRoute = msg.GetRecordRouteAt( i );
      RecordRoute newRoute;
      BOOL willReplaceEntry = FALSE;
      for( PINDEX j = 0; j < recordRoute.GetSize(); j++ )
      {
        RouteURI routeURI;
        OString routeShift;
        recordRoute.GetURI( routeURI, j );
        if( routeURI.GetURI().GetParameter( "route-shift", routeShift ) && !routeShift.IsEmpty() )
        { 
          willReplaceEntry = willReplaceRoutes = TRUE;
          RouteURI ruri;
          SIPURI suri( routeShift );
          ruri.SetURI( suri );
          ruri.SetLooseRouter( TRUE );
          newRoute.AddURI( ruri );
        }else
        {
          newRoute.AddURI( routeURI );
        }
      }
      newList.Append( newRoute );
    }

    if( willReplaceRoutes )
      msg.SetRecordRouteList( newList );
  }
}


BOOL SBCRoutingHandler::OnInternalResolveAddress(
  const OString & domain,
  OString & result
)
{
  SIPURI target;
  SIPURI current = domain;
  if( m_InternalDNSMap.FindRoute( current, target ) )
  {
    result = target.AsString();
    return TRUE;
  }else
    result = domain;
  return FALSE;
}

BOOL SBCRoutingHandler::OnGetRouteTableEntry(
  const PIPSocket::Address & destination,
  PIPSocket::Address & source,
  PIPSocket::Address & route,
  OString & device
)
{
  SIPURI iface;
  SIPURI dest;
  dest.SetHost( destination.AsSTLString() );
  if( m_InterfaceTable.FindRoute( dest, iface ) )
  {
    source = iface.GetAddress();
    if( source.IsValid() )
    {
      OString external; 
      if( iface.GetParameter( "external",  external ) )
        route = PIPSocket::Address( external.c_str() );
      return TRUE;
    }
  }else
  {
    dest.SetHost( "*" );
    if( m_InterfaceTable.FindRoute( dest, iface ) )
    {
      source = iface.GetAddress();
      if( source.IsValid() )
      {
        OString external; 
        if( iface.GetParameter( "external",  external ) )
          route = PIPSocket::Address( external.c_str() );
        return TRUE;
      }
    }
  }

#ifdef P_LINUX
#if ENABLE_GPL_LIBS
  PIPSocket::Address gateway;
  BOOL ok = IPRoute::GetRoute( destination, gateway, device, source );
  LOG( LogInfo(), "*** IPROUTE2 INFO *** " << "dev=" << device << " iface=" << source << " route=" << gateway << " dest=" << destination );
  return ok;
#else
  return FALSE;
#endif
#endif
  
#ifdef WIN32
  device = ""; route = 0;
  return SIPTransportTools::GetBestInterfaceAddress( destination, source );
#endif
  
  return FALSE;
}


BOOL SBCRoutingHandler::IsCALEAMonitoredCall(
    SIPMessage & invite
)
{

  /// check if the invite has a Calea-Filter custom header

  SIPHeader cFilter( "SBC-Calea-Filter" );
  if( invite.PopCustomHeader( "SBC-Calea-Filter", cFilter ) )
  {
    if( cFilter.GetHeaderBody() *= "off" )
      return FALSE;
  }

  PWaitAndSignal configLock( PHTTPConfig::m_HTTPConfigMutex );
  OString toURI = invite.GetToURI().AsString( FALSE );
  OString fromURI = invite.GetFromURI().AsString( FALSE );
  for( PINDEX i = 0; i < m_CALEAFilter.GetSize(); i++ )
  {
    
    OString wild = m_CALEAFilter[i];
    if( ParserTools::WildCardCompare( wild.c_str(), toURI.c_str() ) )
    {
      LOG( LogInfo(), "*** CALEA *** Found filter " << wild << " matching " <<  toURI.c_str() );
      return TRUE;
    }else if( ParserTools::WildCardCompare( wild.c_str(), fromURI.c_str() ) ){
      LOG( LogInfo(), "*** CALEA *** Found filter " << wild << " matching " <<  fromURI.c_str() );
      return TRUE;
    }
  }
  return FALSE;
}


