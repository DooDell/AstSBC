/*
 *
 * SBCRoutingHandler.h
 * 
  * Open SIP Stack ( OSS )
 *
 * Copyright (c) opensipstack.org.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either expressed or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is OpenSIPStack.
 *
 * The Initial Developer of the Original Code is opensipstack.org.
 *
 * The author of this code is Joegen E. Baclor
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * The OpenSIPStack Library includes some GPL/LGPL code libraries that MAY be 
 * enabled at compile time using the --enable-gpllibs configure switch.  If
 * enabled, the content of this file is published under the terms of GNU 
 * General Public License Version 2.  For a detailed list of the available
 * GPL code, see $(opensipstack)/gnu/README file.
 *
 * $Log: SBCRoutingHandler.h,v $
 * Revision 1.24  2009/03/22 23:42:48  joegenbaclor
 * Added configurable interface table support
 *
 * Revision 1.23  2009/02/10 08:16:09  joegenbaclor
 * Fixed HTTP Config crash
 *
 * Revision 1.22  2008/11/03 02:35:09  joegenbaclor
 * Introducing new a la B2BUA-Routes Outbound-Proxy routing and deprecated old global
 *  Outbound-Proxy parameter
 *
 * Revision 1.21  2008/09/12 09:49:44  joegenbaclor
 * - Upper registration bug fixes.
 * - Bring back support for upper reg routing
 * - Bring back support for upper-reg domain rewrite
 *
 * Revision 1.20  2008/01/18 05:28:49  joegenbaclor
 * Added Oubound Proxy assignement for B2BUA calls
 *
 * Revision 1.19  2007/12/04 16:03:14  joegenbaclor
 * Added Access List Verification
 *
 * Revision 1.18  2007/11/18 16:53:51  joegenbaclor
 * Added support for merged requests ending up in the same connection
 *
 * Revision 1.17  2007/08/25 09:08:42  joegenbaclor
 * More work on CALEA trunk
 *
 * Revision 1.16  2007/08/24 01:14:42  joegenbaclor
 * scrapped previous code for upstream proxy handling
 *
 * Revision 1.15  2007/08/22 04:07:08  joegenbaclor
 * Changed B2BRouteCallRedirect to also check the static routes if no registration was found
 *
 * Revision 1.14  2007/08/07 12:58:59  joegenbaclor
 * Made sure we set media proxy mode for routes that are behind NAT
 *
 * Revision 1.13  2007/07/14 07:53:56  joegenbaclor
 * Migrated code to use new STL based string class
 *
 * Revision 1.12  2007/07/07 15:21:17  joegenbaclor
 * Added iproute2 support for linux
 *
 * Revision 1.11  2007/07/06 14:18:25  rcolobong
 * Add Upstream Proxy Route feature
 *
 * Revision 1.10  2007/06/29 08:20:49  joegenbaclor
 * Removed constness for request param in B2BRouteRequest and RouteLocalRegistration to allow the target address to be set early for the request
 *
 * Revision 1.9  2007/06/18 15:31:01  joegenbaclor
 * Implemented Internal DNS Mapping
 *
 * Revision 1.8  2007/05/18 01:24:10  joegenbaclor
 * 1.  Added separate useragent to handle B2BUpperReg backdoor
 * 2.  Modified routing for B2BUpperReg
 * 3.  Corrected bug in ParserTools::GetCompactHeader()
 *
 * Revision 1.7  2007/02/16 11:09:20  joegenbaclor
 * More work on privacy
 *
 * Revision 1.6  2007/01/22 10:00:58  joegenbaclor
 * Fixed ProxyRouteRequest
 *
 * Revision 1.5  2007/01/17 00:09:08  joegenbaclor
 * Added SysLog
 *
 * Revision 1.4  2006/11/23 11:24:37  joegenbaclor
 * Added capability to route none INVITE requests like instant messages
 *
 * Revision 1.3  2006/11/22 11:41:01  rcolobong
 * 1. Update handling on Upper Registration
 * 2. Override method on OnOrphanedMessage
 * 3. Create new handling for route-shift in Record Routes Header
 *
 * Revision 1.2  2006/10/11 06:32:58  rcolobong
 * Seperate method for routing using local registration.
 *
 * Revision 1.1  2006/08/14 10:05:01  rcolobong
 * Convert B2BUA to SBC
 * Support MP logging
 *
 * Revision 1.4  2006/08/04 05:48:58  rcolobong
 * 1.  Add Getter for StaticRoutes
 * 2.  Add virtual to method RefreshStaticRoutes
 * 3.  RefreshStaticRoutes is not invoke during construction
 *
 * Revision 1.3  2006/07/11 13:59:34  joegenbaclor
 * Completed Proxy functionalities for B2BUA
 *
 * Revision 1.2  2006/07/03 15:29:46  joegenbaclor
 * Started merging OpenB2BUA into OpenSBC
 *
 * Revision 1.1  2006/06/20 09:58:11  joegenbaclor
 * *** empty log message ***
 *
 *
 */

#ifndef B2BROUTINGHANDLER_H
#define B2BROUTINGHANDLER_H

#include "OpenSBC.h"
#include "Router.h"

class SBCRoutingHandler : public B2BRoutingInterface
{
  PCLASSINFO( SBCRoutingHandler, B2BRoutingInterface );
public:

  SBCRoutingHandler(  
    OpenSBC & b2bua 
  );

  virtual ~SBCRoutingHandler();

  virtual BOOL B2BRouteCall(
    B2BUAConnection & connection,
    SIPMessage & invite,
    BOOL ignoreRegistrations = FALSE
  );

  virtual BOOL B2BRouteRequest(
    SIPMessage & request,
    SIPURI  & route
  );

  virtual BOOL B2BRouteMergedInvite(
    SIPMessage & invite,
    SIPURI & route
  );

  virtual BOOL B2BRouteCallRedirect(
    B2BUAConnection & connection,
    B2BUACall & call,
    SIPMessage & invite
  );

  virtual ProxySession::RoutePolicy RouteProxyRequest(
    ProxySession & session,
    SIPMessage & request
  );

  virtual ProxySession::RoutePolicy RouteProxyNISTRequest(
    ProxySession & session,
    SIPMessage & request
  );

  virtual void OnOrphanedMessage(
    SIPMessage & message
  );

  ProxySession::RoutePolicy RouteProxyInvite(
    ProxySession & session,
    SIPMessage & request,
    const SIPURI & target
  );

  ProxySession::RoutePolicy RouteProxyRegister(
    ProxySession & session,
    SIPMessage & request,
    const SIPURI & target
  );

  BOOL RouteLocalRegistration( 
    B2BUAConnection & connection,
    SIPMessage & invite,
    const SIPMessage & registration
  );

  BOOL RouteLocalRegistration(
    SIPURI & route,
    SIPMessage & request,
    const SIPMessage & registration,
    B2BUAConnection * connection = NULL
  );

   /// allows implementors to have a custom resolution routine for DNS
  BOOL OnInternalResolveAddress(
    const OString & domain,
    OString & result
  );

  BOOL ExtractTargetURI(
    SIPURI & route,
    const SIPMessage & registration,
    B2BUAConnection * connection = NULL
  );

  void OnRecordRouteShift(
    SIPMessage & msg
  );
  
  BOOL OnGetRouteTableEntry(
    const PIPSocket::Address & destination,
    PIPSocket::Address & source,
    PIPSocket::Address & route,
    OString & device 
  );

  void RefreshStaticRoutes();

  void RefreshDNSMap();

  void RefreshCALEAMap();

  void RefreshInterfaceTable();

  BOOL IsCALEAMonitoredCall(
    SIPMessage & invite
  );

  PINLINE OpenSBC & GetSBC(){ return (OpenSBC &)m_B2BUA; };
  PINLINE Router GetStaticRoutes() { return m_StaticRoutes; };
  PINLINE Router GetRelayRoutes() { return m_RelayRoutes; };
  PINLINE Router GetAppStaticRoutes() { return m_AppStaticRoutes; };
  PINLINE Router GetAppUpperRegistrationRoutes() { return m_AppUpperRegistrationRoutes; };
  PINLINE Router GetAppRelayRoutes() { return m_AppRelayRoutes; };
  PINLINE BOOL AppendAppRelayRoutes( const OString & route ){ return m_AppRelayRoutes.AppendRoute( route ); };
private:
  Router m_StaticRoutes;
  Router m_RelayRoutes;
  Router m_InternalDNSMap;
  Router m_InterfaceTable;

  Router m_AppStaticRoutes;
  Router m_AppUpperRegistrationRoutes;
  Router m_AppRelayRoutes;
  
  OStringArray m_CALEAFilter;
};


#endif


