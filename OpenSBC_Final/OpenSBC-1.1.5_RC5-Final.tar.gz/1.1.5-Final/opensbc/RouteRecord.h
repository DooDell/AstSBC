/*
 *
 * RouteRecord.h
 *
  * Copyright (c) opensipstack.org.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either expressed or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is OpenSIPStack.
 *
 * The Initial Developer of the Original Code is opensipstack.org.
 *
 * The author of this code is Joegen E. Baclor
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * The OpenSIPStack Library includes some GPL/LGPL code libraries that MAY be 
 * enabled at compile time using the --enable-gpllibs configure switch.  If
 * enabled, the content of this file is published under the terms of GNU 
 * General Public License Version 2.  For a detailed list of the available
 * GPL code, see $(opensipstack)/gnu/README file.
 *
 * $Log: RouteRecord.h,v $
 * Revision 1.11  2009/02/10 08:16:09  joegenbaclor
 * Fixed HTTP Config crash
 *
 * Revision 1.10  2008/08/29 06:21:21  joegenbaclor
 * Added paralllel forking support
 *
 * Revision 1.9  2008/02/28 13:36:15  rcolobong
 * Added feature to rewrite the FROM domain to a specific domain in the B2BUA routes
 *
 * Revision 1.8  2007/07/14 07:53:56  joegenbaclor
 * Migrated code to use new STL based string class
 *
 * Revision 1.7  2007/07/07 15:21:17  joegenbaclor
 * Added iproute2 support for linux
 *
 * Revision 1.6  2007/07/06 14:16:36  rcolobong
 * 1. Route by primary codec
 * 2. Support Upstream proxy routing
 *
 * Revision 1.5  2007/05/29 17:43:11  joegenbaclor
 * Initial work on auto attendant
 *
 * Revision 1.4  2007/04/03 06:06:48  rcolobong
 * 1. Add new method GetAllTargetURIList
 * 2. Update handling of MaxSession in SIPURI parameter
 *
 * Revision 1.3  2007/01/22 10:00:58  joegenbaclor
 * Fixed ProxyRouteRequest
 *
 * Revision 1.2  2006/11/22 11:33:25  rcolobong
 * 1. Change method FindRoute to HasScheme
 * 2. Fix problem where it "Rounds Robin" in HasScheme method
 *
 * Revision 1.1  2006/08/14 10:04:59  rcolobong
 * Convert B2BUA to SBC
 * Support MP logging
 *
 * Revision 1.2  2006/07/11 13:59:34  joegenbaclor
 * Completed Proxy functionalities for B2BUA
 *
 * Revision 1.1  2006/06/20 09:58:11  joegenbaclor
 * *** empty log message ***
 *
 * Revision 1.1  2006/05/17 04:04:48  joegenbaclor
 * Initial upload of OpenSBC files
 *
 *
 */

#ifndef ROUTERECORD_H
#define ROUTERECORD_H

#include "SIPURI.h"
#include "B2BUAConnection.h"

using namespace SIPParser;
using namespace B2BUA;

class Router;

class RouteRecord : public PObject
{
  PCLASSINFO( RouteRecord, PObject );
private:
  /*
  class RouteHandler : public PObject
  {
    PCLASSINFO( RouteHandler, PObject );
  public:
    RouteHandler( RouteRecord & );
    virtual ~RouteHandler();
  private:
    RouteRecord * m_RouteRecord;
  }; // class RouteHandler
  */
public:

  RouteRecord( Router * router );

  RouteRecord( 
    const OString & routeRec,
    Router * router
  );

  RouteRecord( 
    const RouteRecord & routeRec
  );

  RouteRecord & operator=(
    const OString & routeRec
  );

  RouteRecord & operator=(
    const RouteRecord & routeRec
  );

  BOOL SetRouteURI(
    const OString & uri
  );
  
  const OString & GetRouteURI()const;

  BOOL GetTargetURI( 
    SIPURI & target
  );

  BOOL GetTargetURI( 
    SIPURI & target,
    PINDEX index
  );

  BOOL AppendTargetURI(
    const SIPURI & target
  );

  BOOL RemoveTargetURI(
    PINDEX index
  );

  BOOL HasScheme(
    const OString& scheme
  );

  BOOL operator*=(
    const SIPURI & uri
  );

  BOOL operator*=(
    const OString & uri
  );

  PINDEX GetTargetURICount()const;

  OStringArray GetTargetURIList() const;
  OStringArray GetAllTargetURIList() const;

  BOOL Parse( 
    const OString & routeRec
  );

  /*
  virtual BOOL ReferenceRoute(
    B2BUAConnection & connection
  );*/

  virtual void PrintOn( ostream & strm )const;

  PINLINE const OString & GetPrimaryCodec() const { return m_PrimaryCodec; }

  PINLINE BOOL HasPrimaryCodec() const { return !m_PrimaryCodec.IsEmpty(); }

  PINLINE const OString & GetRewriteFromDomain() const { return m_RewriteFromDomain; }

  PINLINE BOOL HasRewriteFromDomain() const { return !m_RewriteFromDomain.IsEmpty(); }

  PINLINE BOOL IsParallelFork()const{ return m_IsParallelFork; };
protected:
  PINLINE void IncrementCurrentSession() { ++m_CurrentSession; }
  PINLINE void DecrementCurrentSession() { --m_CurrentSession; }
  
private:
  void UpdateMaxSession( SIPURI & uri );
  void UpdatePrimaryCodec( SIPURI & uri );
  void UpdateRewriteFromDomain( SIPURI & uri );
  void UpdateIsParallelFork( SIPURI & uri );

protected:
  OString m_RouteURI;
  PAtomicInteger m_MaxSession;
  PAtomicInteger m_CurrentSession;
  OString m_PrimaryCodec;
  OString m_RewriteFromDomain;
  BOOL m_IsParallelFork;

  OStringArray m_Targets;
  PIntArray m_TargetsSubIndex;
  PAtomicInteger m_CurrentTargetIndex;
  Router * m_Router;
  //friend class RouteHandler;
};

#endif




