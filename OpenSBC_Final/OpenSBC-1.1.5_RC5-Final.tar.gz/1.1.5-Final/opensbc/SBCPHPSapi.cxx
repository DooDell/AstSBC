/*
 *
 * SBCPHPSapi.h
 * 
 * Open SIP Stack ( OSS )
 *
 * Copyright (c) opensipstack.org.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either expressed or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is OpenSIPStack.
 *
 * The Initial Developer of the Original Code is opensipstack.org.
 *
 * The author of this code is Joegen E. Baclor
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * The OpenSIPStack Library includes some GPL/LGPL code libraries that MAY be 
 * enabled at compile time using the --enable-gpllibs configure switch.  If
 * enabled, the content of this file is published under the terms of GNU 
 * General Public License Version 2.  For a detailed list of the available
 * GPL code, see $(opensipstack)/gnu/README file.
 *
 * $Log: SBCPHPSapi.cxx,v $
 * Revision 1.9  2008/07/14 05:13:08  joegenbaclor
 * More work on solegy debit
 *
 * Revision 1.8  2008/03/14 05:53:31  joegenbaclor
 * Fixed visual studio 2005 compile errors
 *
 * Revision 1.7  2008/03/13 06:02:27  joegenbaclor
 * Completed new GCC build environment with PHP and Python support
 *
 * Revision 1.6  2008/03/12 05:53:20  joegenbaclor
 * GCC Problem: Used implicit casting of variant string using str() function instead of template based cast operator
 *
 * Revision 1.5  2008/03/12 03:36:55  joegenbaclor
 * More GCC compile fixes for python and variant class
 *
 * Revision 1.4  2008/03/11 15:00:40  joegenbaclor
 * PHP Build fixes
 *
 * Revision 1.3  2008/03/11 09:16:09  joegenbaclor
 * Fixed linux compilation errors due to python and php enhancements
 *
 * Revision 1.2  2008/03/11 07:05:37  joegenbaclor
 * Completed support for cookies and session variables
 *
 * Revision 1.1  2008/03/11 02:10:03  joegenbaclor
 * Revised PHP Sapi implementation and removed python from configure script check
 *
 *
 */



#include "SBCPHPSapi.h"
#include <stdlib.h>

#if HAS_PHP_SAPI

#ifdef WIN32
#pragma message("*** PHP SAPI Enabled ***")
#endif

extern "C"
{
  #ifdef PHP_WIN32
  #define HAVE_SOCKLEN_T
  #undef strcasecmp
  #undef strncasecmp
  #endif
  
  #include "php.h"
  #include "php_main.h"
  #include "php_variables.h"
  #include "SAPI.h"
  #include "php_globals.h"
  #include "ext/standard/info.h"
  #include "zend_alloc.h"
  #include "ext/standard/basic_functions.h"
  #include "TSRM/TSRM.h"
}

#ifdef _MSC_VER
#ifndef _WIN32_WCE
#pragma comment(lib, "./php/php-bin/php5embed.lib")
#pragma comment(lib, "./php/php-bin/dev/php5ts.lib" )
#endif // !_WIN32_WCE
#endif

class php_exception: public std::exception
{
public:
  php_exception( const std::string & w )
  {
    m_What = w;
  }

  ~php_exception()throw(){}

  const char* what() const throw()
  {
    return m_What.c_str();
  }

  std::string m_What;
};

class PHPArray
{
public:
  PHPArray()
  {
    MAKE_STD_ZVAL(php_array);
    array_init(php_array);
    can_delete_ptr = true;
  }

  PHPArray(zval * _php_array)
  {
    php_array = _php_array;
    array_init(php_array);
    can_delete_ptr = false;
  }

  ~PHPArray()
  {
    if( can_delete_ptr )
      zval_ptr_dtor(&php_array);
  }

  void push_back( const char * str )
  {
    add_next_index_string(php_array, const_cast<char*>(str), 1);
  }

  void push_back( long val )
  {
    add_next_index_long(php_array, val);
  }

  void push_back( bool val )
  {
    add_next_index_bool(php_array, val);
  }

  void push_back( double val )
  {
    add_next_index_double(php_array, val);
  }

  void push_back_null()
  {
    add_next_index_null(php_array);
  }

  void set_at( unsigned long index, const char * str )
  {
    add_index_string(php_array, index, const_cast<char*>(str), 1);
  }

  void set_at( unsigned long index, long val )
  {
    add_index_long(php_array, index, val);
  }

  void set_at( unsigned long index, bool val )
  {
    add_index_bool(php_array, index, val);
  }

  void set_at( unsigned long index, double val )
  {
    add_index_double(php_array, index, val);
  }

  void set_at_null( unsigned long index )
  {
    add_index_null(php_array, index);
  }

  void set_at( const char * id, int str_len, const char * str )
  {
    add_assoc_string_ex(php_array, const_cast<char*>(id), str_len + 1, const_cast<char*>(str), 1);
  }

  void set_at( const char * id, int str_len, long val )
  {
    add_assoc_long_ex(php_array, const_cast<char*>(id), str_len + 1, val);
  }

  void set_at( const char * id, int str_len, bool val )
  {
    add_assoc_bool_ex(php_array, const_cast<char*>(id), str_len + 1, val);
  }

  void set_at( const char * id, int str_len, double val )
  {
    add_assoc_double_ex(php_array, const_cast<char*>(id), str_len + 1, val);
  }

  void set_at_null( const char * id, int str_len  )
  {
    add_assoc_null_ex(php_array, const_cast<char*>(id), str_len + 1);
  }

private:
  bool can_delete_ptr;
  zval * php_array;
};

#ifdef WIN32
#pragma warning(disable: 4244)
#endif

static PHP_FUNCTION(oss_evaluate)
{
  zval ***args = NULL;
	int nargs = ZEND_NUM_ARGS();

	if (nargs) 
  {
		args = (zval ***)safe_emalloc(sizeof(zval *), nargs, 0);
		zend_get_parameters_array_ex(nargs, args);
	}else
  {
    // there should at least be one argument
    RETURN_NULL();
  }
  
  std::string funcName;
  PHPVariantMap in, out;

  zval temp = **args[0];
  zval_copy_ctor(&temp);
  convert_to_string(&temp);
  funcName = Z_STRVAL_P((&temp));
  zval_dtor(&temp);

  for( int i = 1; i < nargs; i++ )
  {   
    if( Z_TYPE_P(*args[i])==IS_ARRAY )
    {
      HashTable *arr_hash  = Z_ARRVAL_P(*args[i]);
      //int array_count = zend_hash_num_elements(arr_hash);
      HashPosition pointer;
      zval **data;
      for(  zend_hash_internal_pointer_reset_ex(arr_hash, &pointer); 
            zend_hash_get_current_data_ex(arr_hash, (void**) &data, &pointer) == SUCCESS; 
            zend_hash_move_forward_ex(arr_hash, &pointer)) 
      {
          zval temp;
          char *key;
          uint key_len;
          ulong index;
          
          std::string first;
          PHPVariant second;

          if (zend_hash_get_current_key_ex(arr_hash, &key, (uint*)&key_len, &index, 0, &pointer) == HASH_KEY_IS_STRING) 
          {
            first = std::string(key, key_len);
          } else 
          {
            char array_index_buf[10];
            char index_buf[10];
            sprintf( index_buf, "%d", (int)i );
            sprintf( array_index_buf, "%d", (int)index );
            //::itoa( i, index_buf, 10 );
            //::itoa( index, array_index_buf, 10 );
            std::string h1 = std::string( index_buf );
            std::string h2 = std::string( array_index_buf );
            first = "[" + h1 + "," + h2 + "]"; 
          }

          temp = **data;
          zval_copy_ctor(&temp);
          //convert_to_string(&temp);
          //second = Z_STRVAL_P((&temp));

          switch( Z_TYPE_P(&temp) )
          {    
            case IS_LONG:
              second = (long)Z_LVAL_P(&temp);
              break;
            case IS_DOUBLE:
              second = (double)Z_DVAL_P(&temp);
              break;
            case IS_BOOL:
              second = (bool)Z_BVAL_P(&temp);
              break;
            case IS_STRING:
              second = Z_STRVAL_P(&temp);
              break;
            case IS_ARRAY: // none supported types
            case IS_NULL:
            case IS_OBJECT:
            case IS_RESOURCE:
            case IS_CONSTANT:
            case IS_CONSTANT_ARRAY:
              throw php_exception( "PHP Script Returned Unsupported Type" );
          }

          zval_dtor(&temp);
          in[first] = second;
      }

    }else if( Z_TYPE_P(*args[i])==IS_STRING )
    {
      zval arg_temp = **args[i];
      zval_copy_ctor(&arg_temp);
      PHPVariant second;

      switch( Z_TYPE_P(&arg_temp) )
      {    
        case IS_LONG:
          second = (long)Z_LVAL_P(&arg_temp);
          break;
        case IS_DOUBLE:
          second = (double)Z_DVAL_P(&arg_temp);
          break;
        case IS_BOOL:
          second = (bool)Z_BVAL_P(&arg_temp);
          break;
        case IS_STRING:
          second = Z_STRVAL_P(&arg_temp);
          break;
        case IS_ARRAY: // none supported types
        case IS_NULL:
        case IS_OBJECT:
        case IS_RESOURCE:
        case IS_CONSTANT:
        case IS_CONSTANT_ARRAY:
          throw php_exception( "PHP Script Returned Unsupported Type" );
      }

      zval_dtor(&arg_temp);
      
      char buf[5];
      sprintf( buf, "%d",(int)i );
      //::itoa( i, buf, 10 );
      std::string first( buf );

      in[first] = second;
    }
  }

	if (args) 
		efree(args);

  HTTP_CONTROL_BLOCK_PTR control_block;
	control_block = (HTTP_CONTROL_BLOCK_PTR) SG(server_context);

  if( control_block == NULL )
    RETURN_NULL();
  
  if( !control_block->PHP_evaluate( funcName, in, out ) )
    RETURN_NULL();

  PHPArray param_arg( return_value ); 
  for( PHPVariantMap::iterator iter = out.begin(); iter != out.end(); iter++ )
  {
    //ret_val.set_at( iter->first.c_str(), (int)iter->first.length(), iter->second );

    if ( iter->second.is_type<int>() )
    {
      param_arg.set_at( iter->first.c_str(), (int)iter->first.length(), (long)iter->second );
    }
    else if ( iter->second.is_type<double>() )
    {
      param_arg.set_at( iter->first.c_str(), (int)iter->first.length(), (double)iter->second );
    }else if ( iter->second.is_type<long>() )
    {
      param_arg.set_at( iter->first.c_str(), (int)iter->first.length(), (long)iter->second );
    }
    else if ( iter->second.is_type<std::string>() )
    {
      std::string str_value = str_value = iter->second.str();
      param_arg.set_at( iter->first.c_str(), (int)iter->first.length(), str_value.c_str() );
    }else if( iter->second.is_type<bool>() )
    {
      param_arg.set_at( iter->first.c_str(), (int)iter->first.length(), (bool)iter->second );//MAKE_STD_ZVAL(zvalue);
    }else
    {
      throw php_exception( "PHP Function Parameter Unknown Type" );
    }
  }

}


static function_entry oss_functions[] = {
    PHP_FE(oss_evaluate, NULL)
    {NULL, NULL, NULL}
};

static zend_module_entry oss_web_module = {
	STANDARD_MODULE_HEADER,
	"OpenSIPStack Web Module",
	oss_functions,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	STANDARD_MODULE_PROPERTIES
};

static int oss_zend_ub_write(const char *str, uint str_length TSRMLS_DC)
{
  //DWORD num_bytes = str_length;

	HTTP_CONTROL_BLOCK_PTR control_block;
	control_block = (HTTP_CONTROL_BLOCK_PTR) SG(server_context);

  if( control_block == NULL )
    return 0;

  std::string line_str( str, str_length );
  if( !control_block->PHP5_echo( line_str ) )
		php_handle_aborted_connection();

  return str_length;
}

static int oss_sapi_header_handler(sapi_header_struct *sapi_header, sapi_headers_struct *sapi_headers TSRMLS_DC)
{
	return SAPI_HEADER_ADD;
}

static void oss_accumulate_header_length(sapi_header_struct *sapi_header, uint *total_length TSRMLS_DC)
{
  *total_length += sapi_header->header_len+2;
}

static void oss_concat_header(sapi_header_struct *sapi_header, char **combined_headers_ptr TSRMLS_DC)
{
  memcpy(*combined_headers_ptr, sapi_header->header, sapi_header->header_len);
	*combined_headers_ptr += sapi_header->header_len;
	**combined_headers_ptr = '\r';
	(*combined_headers_ptr)++;
	**combined_headers_ptr = '\n';
	(*combined_headers_ptr)++;
}

static int oss_sapi_send_headers(sapi_headers_struct *sapi_headers TSRMLS_DC)
{
  uint total_length = 2;		/* account for the trailing \r\n */
	char *combined_headers, *combined_headers_ptr;
	HTTP_CONTROL_BLOCK_PTR control_block;
	control_block = (HTTP_CONTROL_BLOCK_PTR) SG(server_context);

  if( control_block == NULL )
    return SAPI_HEADER_SENT_SUCCESSFULLY;

	sapi_header_struct default_content_type;
	
 	if (SG(sapi_headers).send_default_content_type) {
		sapi_get_default_content_type_header(&default_content_type TSRMLS_CC);
		oss_accumulate_header_length(&default_content_type, (uint *) &total_length TSRMLS_CC);
	}
	zend_llist_apply_with_argument(&SG(sapi_headers).headers, (llist_apply_with_arg_func_t) oss_accumulate_header_length, (void *) &total_length TSRMLS_CC);

	/* Generate headers */
	combined_headers = (char *) emalloc(total_length+1);
	combined_headers_ptr = combined_headers;
	if (SG(sapi_headers).send_default_content_type) {
		oss_concat_header(&default_content_type, (char**) &combined_headers_ptr TSRMLS_CC);
		sapi_free_header(&default_content_type); /* we no longer need it */
	}
	zend_llist_apply_with_argument(&SG(sapi_headers).headers, (llist_apply_with_arg_func_t) oss_concat_header, (void *) &combined_headers_ptr TSRMLS_CC);
	*combined_headers_ptr++ = '\r';
	*combined_headers_ptr++ = '\n';
	*combined_headers_ptr = 0;

  control_block->m_RequestStructure.http_response_code = SG(sapi_headers).http_response_code;
  control_block->m_RequestStructure.sapi_send_headers = std::string( combined_headers, total_length );

	efree(combined_headers);
	if (SG(sapi_headers).http_status_line) {
		efree(SG(sapi_headers).http_status_line);
		SG(sapi_headers).http_status_line = 0;
	}
	return SAPI_HEADER_SENT_SUCCESSFULLY;
}

static int oss_php_startup(sapi_module_struct *sapi_module)
{
  if (php_module_startup(sapi_module, &oss_web_module, 1)==FAILURE)
		return FAILURE;
	else
		return SUCCESS;
}

static int oss_sapi_read_post(char *buffer, uint count_bytes TSRMLS_DC)
{
  HTTP_CONTROL_BLOCK_PTR control_block;
  unsigned long total_read = -1;
	control_block = (HTTP_CONTROL_BLOCK_PTR) SG(server_context);
  if( control_block == NULL )
    return 0;

  if( control_block->m_RequestStructure.entity_body.length() == 0 || control_block->m_RequestStructure.has_read_post_data )
    return total_read;

  std::string postData = control_block->m_RequestStructure.entity_body;

  total_read = (unsigned long)postData.length();
  memcpy( buffer, postData.c_str(), total_read );
  control_block->m_RequestStructure.has_read_post_data = true;
  return total_read;
}

static char *oss_sapi_read_cookies(TSRMLS_D)
{
  HTTP_CONTROL_BLOCK_PTR control_block;
	control_block = (HTTP_CONTROL_BLOCK_PTR) SG(server_context);

  if( control_block == NULL )
    return NULL;

  PString cookie = control_block->m_RequestStructure.mime_info.GetString( "Cookie", "" );
  if( !cookie.IsEmpty() )
  {
    char *tmp_variable_buf = (char *) emalloc(cookie.GetLength()+1);
    memcpy(tmp_variable_buf, (const char *)cookie, cookie.GetLength()+1 );
    tmp_variable_buf[cookie.GetLength()] = 0;
    return tmp_variable_buf;
  }


	return NULL;
}

static void oss_sapi_register_variables(zval *track_vars_array TSRMLS_DC)
{
}



static sapi_module_struct oss_sapi_module = {
	"OSS_HTTP_SAPI",				/* name */
	"OpenSIPStack Web Module",				/* pretty name */

	oss_php_startup,			/* startup */
	php_module_shutdown_wrapper,		/* shutdown */
	NULL,					/* activate */
	NULL,					/* deactivate */
	oss_zend_ub_write,			/* unbuffered write */
	NULL,					/* flush */
	NULL,					/* get uid */
	NULL,					/* getenv */
	php_error,				/* error handler */
	oss_sapi_header_handler,		/* header handler */
	oss_sapi_send_headers,		/* send headers handler */
	NULL,					/* send header handler */
	oss_sapi_read_post,			/* read POST data */
	oss_sapi_read_cookies,		/* read Cookies */
	oss_sapi_register_variables,	/* register server variables */
	NULL,					/* Log message */
	NULL,					/* Get request time */

	STANDARD_SAPI_MODULE_PROPERTIES
};

static void init_request_info(HTTP_CONTROL_BLOCK_PTR control_block TSRMLS_DC)
{
  SG(server_context) = control_block;

	SG(request_info).request_method  = (char *)/*estrdup*/(control_block->m_RequestStructure.request_method.c_str());
	SG(request_info).query_string    = (char *)/*estrdup*/(control_block->m_RequestStructure.query_string.c_str());
	SG(request_info).path_translated = (char *)/*estrdup*/(control_block->m_RequestStructure.path_translated.c_str());
	SG(request_info).request_uri     = (char *)/*estrdup*/(control_block->m_RequestStructure.request_uri.c_str());
	SG(request_info).content_type    = (char *)/*estrdup*/(control_block->m_RequestStructure.content_type.c_str());
	SG(request_info).content_length  = control_block->m_RequestStructure.content_length;
	SG(request_info).auth_user       = (char *)/*estrdup*/(control_block->m_RequestStructure.auth_user.c_str());
	SG(request_info).auth_password   = (char *)/*estrdup*/(control_block->m_RequestStructure.auth_password.c_str());
	SG(sapi_headers).http_response_code = control_block->m_RequestStructure.http_response_code;
}

int oss_php5_handle_request(HTTP_CONTROL_BLOCK_PTR control_block)
{
  zend_file_handle file_handle = {0};
	TSRMLS_FETCH();
  int ret = 0;
  zend_first_try 
  {
    file_handle.filename = const_cast<char*>(control_block->m_RequestStructure.filename.c_str());
		file_handle.free_filename = 0;
		file_handle.type = ZEND_HANDLE_FILENAME;
		file_handle.opened_path = NULL;
		init_request_info(control_block TSRMLS_CC);
    php_request_startup(TSRMLS_C);
    ret = php_execute_script( &file_handle TSRMLS_CC );
    php_request_shutdown(NULL);
  }zend_catch 
  {  
	}zend_end_try();
  
  return ret;
}

static void ***tsrm_ls = NULL;

#else //HAS_PHP_SAPI
#ifdef WIN32
#pragma message("*** PHP SAPI Disabled ***")
#endif
#endif //HAS_PHP_SAPI

static bool PHP5Loaded = false;

PHPResource::PHPResource(
      SBCPHPSapi & sapi,
      PHTTPAuthority & auth,
      const PURL & url,
      const PURL & resourceURL
) : PServiceHTTPString(resourceURL, "", "text/html; charset=UTF-8", auth), m_Sapi( sapi )
{
#if  HAS_PHP_SAPI
  tsrm_ls = tsrm_ls;  // kludge to silence gcc about this variable not being utilized in unix builds
#endif
  m_PHPURL = url;
}

PHPResource::~PHPResource()
{
}

BOOL PHPResource::OnGET(
  PHTTPServer & server,       ///< HTTP server that received the request
  const PURL & url,           ///< Universal Resource Locator for document.
  const PMIMEInfo & info,     ///< Extra MIME information in command.
  const PHTTPConnectionInfo & conInfo   ///< HTTP connection information
)
{
#if HAS_PHP_SAPI
  string = "";
  PString url_path = m_PHPURL.AsString( PURL::PathOnly );
  //PURL::FullURL;
  PString url_string = m_PHPURL.AsString();
  PString queryString = m_PHPURL.GetQuery();
  PString contentType = info.GetString( "Content-Type", "text/plain" );
  

  m_RequestStructure.filename = (const char *)url_path;
  m_RequestStructure.mime_info = info;
  m_RequestStructure.request_method  = "GET";
	m_RequestStructure.query_string    = (const char *)queryString;
	m_RequestStructure.path_translated = (const char *)url_path;
	m_RequestStructure.request_uri     = (const char *)url_string;
	m_RequestStructure.content_type    = (const char *)contentType;
	m_RequestStructure.content_length  = info.GetInteger( "Content-Length", 0 );
	m_RequestStructure.auth_user       = "";
	m_RequestStructure.auth_password   = "";
	m_RequestStructure.http_response_code = 200;
  oss_php5_handle_request( this );
#endif
  return PServiceHTTPString::OnGET( server, url, info, conInfo );
}

BOOL PHPResource::LoadHeaders(PHTTPRequest & request)
{
  request.code = (PHTTP::StatusCode)m_RequestStructure.http_response_code;
  PString mimes = m_RequestStructure.sapi_send_headers.c_str();
  if( !mimes.IsEmpty() )
  {
    PStringArray extra = mimes.Lines();
    for( PINDEX i = 0; i < extra.GetSize(); i++ )
      request.outMIME.AddMIME( extra[i] );
  }

  return TRUE;
}

BOOL PHPResource::OnPOST(PHTTPServer & server,
  const PURL & url,
  const PMIMEInfo & info,
  const PStringToString & data,
  const PHTTPConnectionInfo & connectInfo)
{
#if HAS_PHP_SAPI
  string = "";
  PString url_path = m_PHPURL.AsString( PURL::PathOnly );
  //PURL::FullURL;
  PString url_string = m_PHPURL.AsString();
  PString queryString = m_PHPURL.GetQuery();
  PString contentType = info.GetString( "Content-Type", "text/plain" );
  
  m_RequestStructure.has_read_post_data = false;
  m_RequestStructure.mime_info = info;
  m_RequestStructure.filename = (const char *)url_path;
  m_RequestStructure.request_method  = "POST";
	m_RequestStructure.query_string    = (const char *)queryString;
	m_RequestStructure.path_translated = (const char *)url_path;
	m_RequestStructure.request_uri     = (const char *)url_string;
	m_RequestStructure.content_type    = (const char *)contentType;
  m_RequestStructure.entity_body     = (const char *)connectInfo.GetEntityBody();
  m_RequestStructure.content_length  = connectInfo.GetEntityBodyLength();
	m_RequestStructure.auth_user       = "";
	m_RequestStructure.auth_password   = "";
	m_RequestStructure.http_response_code = 200;
  oss_php5_handle_request( this );
#endif

  return PHPResource::PServiceHTTPString::OnPOST( server, url, info, data, connectInfo );
}

BOOL PHPResource::Post(PHTTPRequest & /*request*/,
                      const PStringToString &,
                      PHTML & msg)
{
  msg=string;
  return TRUE;
}


SBCPHPSapi::SBCPHPSapi(
  const PHTTPSpace & urlSpace  ///< Name space to use for URLs received.
) : PHTTPServer( urlSpace )
{
}

BOOL SBCPHPSapi::OnGET(
  const PURL & url,                    ///< Universal Resource Locator for document.
  const PMIMEInfo & info,              ///< Extra MIME information in command.
  const PHTTPConnectionInfo & conInfo  ///< HTTP connection information
)
{ 

  m_PHPMutex.Wait();
  PURL currentURL =  url;
#if HAS_PHP_SAPI
  static int curent_page_index = 0;
  PFilePath php_path = url.GetPathStr();
  PFilePathString phpPage = php_path.GetFileName();
  PString ext = phpPage.Right(4);
  if( ext *= ".php" )
  {
    currentURL = "php-html-resource-" + PString( curent_page_index++ );

    if( urlSpace.FindResource(currentURL) == NULL )
    {
      PHTTPSimpleAuth authority( "PHP Resource", "", "" );
      GetURLSpace().AddResource( new PHPResource( *this, authority, url, currentURL), PHTTPSpace::ErrorOnExist );
    }
  }
#endif
  m_PHPMutex.Signal();
  BOOL retval = PHTTPServer::OnGET( currentURL, info, conInfo );
#if HAS_PHP_SAPI
  m_PHPMutex.Wait();
  GetURLSpace().DelResource( currentURL );
  m_PHPMutex.Signal();
#endif
  return retval;
}


BOOL SBCPHPSapi::OnPOST(
  const PURL & url,                   ///< Universal Resource Locator for document.
  const PMIMEInfo & info,             ///< Extra MIME information in command.
  const PStringToString & data,       ///< Variables provided in the POST data.
  const PHTTPConnectionInfo & conInfo ///< HTTP connection information
)
{
  m_PHPMutex.Wait();

  PURL currentURL = url;

#if HAS_PHP_SAPI
  static int curent_page_index = 0;
  PFilePath php_path = url.GetPathStr();
  PFilePathString phpPage = php_path.GetFileName();
  PString ext = phpPage.Right(4);
  if( ext *= ".php" )
  {
    currentURL = "php-html-post-resource-" + PString( curent_page_index++ );

    if( urlSpace.FindResource(currentURL) == NULL )
    {
      PHTTPSimpleAuth authority( "PHP Resource", "", "" );
      GetURLSpace().AddResource( new PHPResource( *this, authority, url, currentURL), PHTTPSpace::ErrorOnExist );
    }
  }
#endif
  m_PHPMutex.Signal();

  BOOL ret_val = PHTTPServer::OnPOST( currentURL, info, data, conInfo );

#if HAS_PHP_SAPI
  m_PHPMutex.Wait();
  GetURLSpace().DelResource( currentURL );
  m_PHPMutex.Signal();
#endif

  return ret_val;
}



int SBCPHPSapi::PHP5_startup( const std::string & /*inc_path*/ ) 
{
#if HAS_PHP_SAPI
	tsrm_startup(1, 1, 0, NULL);
	sapi_startup(&oss_sapi_module);
	if (oss_sapi_module.startup) {
		oss_sapi_module.startup(&oss_sapi_module);
	};
	
  PHP5Loaded= 1;
#endif  
	return PHP5Loaded;
};

int SBCPHPSapi::PHP5_shutdown() 
{
#if HAS_PHP_SAPI
	if (oss_sapi_module.shutdown) 
  {
		oss_sapi_module.shutdown(&oss_sapi_module);
	}
	sapi_shutdown();
	tsrm_shutdown();
  PHP5Loaded = false;
#endif
  return !PHP5Loaded;
};

bool PHPResource::PHP5_echo( const std::string & line_str )
{
  string += line_str.c_str();
  return true;
}

bool PHPResource::PHP_evaluate(
  const std::string & funcName,
  PHPVariantMap & in,
  PHPVariantMap & out 
)
{
  return m_Sapi.PHP_evaluate( funcName, in, out );
}

