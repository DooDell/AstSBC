/*
 *
 * SBCSwitchIVRInterface.cxx
 *
 * Open SIP Stack ( OSS )
 *
 * Copyright (c) opensipstack.org.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either expressed or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is OpenSIPStack.
 *
 * The Initial Developer of the Original Code is opensipstack.org.
 *
 * The author of this code is Joegen E. Baclor
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * The OpenSIPStack Library includes some GPL/LGPL code libraries that MAY be 
 * enabled at compile time using the --enable-gpllibs configure switch.  If
 * enabled, the content of this file is published under the terms of GNU 
 * General Public License Version 2.  For a detailed list of the available
 * GPL code, see $(opensipstack)/gnu/README file.
 *
 * $Log: SBCSwitchIVRInterface.cxx,v $
 * Revision 1.3  2009/06/03 11:57:16  joegenbaclor
 * Checking in MOH feature
 *
 *
 */

#include "SBCSwitchIVRInterface.h"
#include "SBCSwitchRTPBridge.h"
#include "SBCB2BUACall.h"

#define new PNEW
using namespace SWITCH;
using namespace UACORE;
using namespace B2BUA;
///////////////////////////////////////////////////////////

#include "codec/g711codec.h"

///////////////////////////////////////////////////////////
SBCSwitchIVRInterface::SBCSwitchIVRInterface()
{
  m_SBCSwitchMediaStream = NULL;
  m_SBCSwitchIVRSession = NULL;
  m_RTPSession = NULL;
  m_PeerRTPSession = NULL;
  m_RTPBridge = NULL;
  m_Encoder = NULL;
  m_Decoder = NULL;
}

SBCSwitchIVRInterface::~SBCSwitchIVRInterface()
{
  if( m_SBCSwitchMediaStream != NULL && m_SBCSwitchIVRSession != NULL )
  {
    m_SBCSwitchIVRSession->Close();
  }
  StopStream();
  delete m_SBCSwitchMediaStream;
  delete m_SBCSwitchIVRSession; 
  delete m_Encoder;
  delete m_Decoder;
}

BOOL SBCSwitchIVRInterface::OnCreateIVRStream(
  const OString & formatName,
  SBCB2BUACall * call
)
{
  if( m_SBCSwitchMediaStream != NULL || m_SBCSwitchIVRSession != NULL )
    return FALSE;

  OpalMediaFormat mediaFormat;
  OString fmt = formatName.ToUpper().Trim();

  if( fmt == "PCMU" )
  {
    mediaFormat = OpalPCM16;
    m_Encoder = new Opal_PCM_G711_uLaw();
    m_Decoder = new Opal_G711_uLaw_PCM();
  }else if( fmt == "PCMA" ) 
  {
    mediaFormat = OpalPCM16;
    m_Encoder = new Opal_PCM_G711_ALaw();
    m_Decoder = new Opal_G711_ALaw_PCM();
  }else 
    return FALSE;

  m_RTPSession = dynamic_cast<RTP_UDP*>(call->GetRTPSessionManager().GetSession( OpalMediaFormat::DefaultAudioSessionID ));
  /// Create the IVR
  m_SBCSwitchIVRSession = new SBCSwitchIVRSession();
  m_SBCSwitchMediaStream = new SBCSwitchMediaStream( mediaFormat, call->GetLegIndex(), TRUE, m_SBCSwitchIVRSession, call );
  
  m_SBCSwitchMediaStream->SetDataSize( m_Encoder->GetOptimalDataFrameSize( TRUE ) );
  m_Encoder->SetMaxOutputSize( m_SBCSwitchMediaStream->GetDataSize() );
  
  return m_SBCSwitchMediaStream->Open();
}

BOOL SBCSwitchIVRInterface::StartStream()
{
  return TRUE;
}
 
BOOL SBCSwitchIVRInterface::StopStream()
{
  return TRUE;
}

void SBCSwitchIVRInterface::ProcessStream()
{
  /// read one sample and exit
  
  RTP_UDP * rtpSession = m_PeerRTPSession == NULL ? m_RTPSession : m_PeerRTPSession;
  RTP_DataFrame inFrame;
  if( rtpSession == NULL )
    return;

  if( !rtpSession->ReadData( inFrame ) )
  {
    RTP_DataFrame frame( m_SBCSwitchMediaStream->GetDataSize() );
    if( m_SBCSwitchMediaStream->ReadPacket( frame ) )
    {
      RTP_DataFrameList output;
      m_Encoder->ConvertFrames( frame, output );
      for( PINDEX i = 0; i < output.GetSize(); i++ )
      {
        m_RTPSession->WriteData( output[i] );
      }
    }
  }
}

BOOL SBCSwitchIVRInterface::PlayFile( const PFilePath & file )
{
  if( m_SBCSwitchIVRSession == NULL || !m_SBCSwitchIVRSession->IsOpen() )
    return FALSE;

  PString filePath = "file:" + file;
  m_SBCSwitchIVRSession->PlayFile( "", (const char *)filePath, 1 );
  return TRUE;
}

void SBCSwitchIVRInterface::AcquireRTPBridge( 
  SBCSwitchRTPBridge * bridge,
  RTP_UDP * peerRTP
)
{
  m_PeerRTPSession = peerRTP;
  bridge->AttachIVRChannel( this );
}

void SBCSwitchIVRInterface::ReleaseRTPBridge( SBCSwitchRTPBridge * bridge )
{
  m_PeerRTPSession = NULL;
  bridge->DetachIVRChannel();
}



