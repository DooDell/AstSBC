/*
 *
 * SBCCALEATrunk.cxx
 *
 * Open SIP Stack ( OSS )
 *
 * Copyright (c) opensipstack.org.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either expressed or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is OpenSIPStack.
 *
 * The Initial Developer of the Original Code is opensipstack.org.
 *
 * The author of this code is Joegen E. Baclor
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * The OpenSIPStack Library includes some GPL/LGPL code libraries that MAY be 
 * enabled at compile time using the --enable-gpllibs configure switch.  If
 * enabled, the content of this file is published under the terms of GNU 
 * General Public License Version 2.  For a detailed list of the available
 * GPL code, see $(opensipstack)/gnu/README file.
 *
 * $Log: SBCCALEATrunk.cxx,v $
 * Revision 1.16  2009/05/27 12:40:34  joegenbaclor
 * Initial upload of switch related classes
 *
 * Revision 1.15  2009/03/26 06:32:26  joegenbaclor
 * Added NAT port forwarding support
 *
 * Revision 1.14  2009/03/13 02:52:14  joegenbaclor
 * fixing compile errors in gcc
 *
 * Revision 1.13  2009/03/13 02:26:18  joegenbaclor
 * In this revision, we moved listener configuration to its own
 * page allowing all listeners to be configured seperately.
 * Previous behavior only allowed the main listener to be configured.
 * We have also added a out of dialog handler in the backdoor trunk
 * to allow unsolcited messages like OPTIONS and NOTIFY to passthrough.
 * Both of these functionalities are still under testing.
 *
 * Revision 1.12  2008/12/22 06:51:46  joegenbaclor
 * Application Timers for Alerting and Connect is causing a deadlock on connection destruction.
 * To address this issue, we modified opensipstack to take care of the timers in the ICT Layer.
 *
 * Revision 1.11  2008/11/20 11:02:34  joegenbaclor
 * Depcrecated old SIPMessage URI accessors
 *
 * Revision 1.10  2008/09/09 10:53:22  joegenbaclor
 * transfered calea pcap directory to application config path
 *
 * Revision 1.9  2007/10/30 16:39:36  joegenbaclor
 * Modified default thread count for trunks
 *
 * Revision 1.8  2007/10/01 16:17:27  joegenbaclor
 * Added transport status page in http admin
 *
 * Revision 1.7  2007/09/18 09:20:33  joegenbaclor
 * -  Added SBC-Accounting header
 * -  if SBC-Min-Trunk header is not present, we use the Contact URI as the replacement destination
 *
 * Revision 1.6  2007/09/04 21:58:13  joegenbaclor
 * More work on SIP Trunks.
 *
 * Revision 1.5  2007/08/28 01:25:19  joegenbaclor
 * Completed recording SIP signals for CALEA in pcap format
 *
 * Revision 1.4  2007/08/25 12:17:32  joegenbaclor
 * commiting initial CALEA working alpha code
 *
 * Revision 1.3  2007/08/25 09:08:42  joegenbaclor
 * More work on CALEA trunk
 *
 * Revision 1.2  2007/08/24 01:14:42  joegenbaclor
 * scrapped previous code for upstream proxy handling
 *
 * Revision 1.1  2007/08/20 06:25:34  joegenbaclor
 * Added separate trunk for CALEA processing
 *
 * Revision 1.1  2007/08/16 13:33:37  joegenbaclor
 * More work on trunking
 *
 *
 */

#include "SBCCALEATrunk.h"
#include "OString.h"
#include "Version.h"
#include "SBCConfigParams.h"
#include "B2BUAConnection.h"
#include "B2BUAEndPoint.h"
#include "Encryption.h"
#include "SIPUDPTransport.h"
#include "PCAPFile.h"

using namespace SIPTransports;
using namespace Tools;

#define new PNEW

///////////////////////////////////////////////////////////

class SBCCALEAEndPoint : public B2BUAEndPoint
{
  PCLASSINFO( SBCCALEAEndPoint, B2BUAEndPoint );
public:
  SBCCALEAEndPoint(
    SBCCALEATrunk & ua
  );

  virtual ~SBCCALEAEndPoint();

  virtual B2BUAConnection * OnCreateB2BUA(
    const SIPMessage & request,
    const OString & sessionId,
    B2BUACall * session
  );

  PINLINE void SetPCAPDirectory( const PDirectory & dir ){ m_PCAPDirectory = dir; };
  PINLINE const PDirectory & GetPCAPDirectory()const{ return m_PCAPDirectory; };
protected:
  PDirectory m_PCAPDirectory;

};

///////////////////////////////////////////////////////////

class SBCCALEAConnection : public B2BUAConnection
{
  PCLASSINFO( SBCCALEAConnection, B2BUAConnection );
public:
  SBCCALEAConnection(
    SBCCALEAEndPoint & ep,
    const OString & sessionId
  );

  virtual ~SBCCALEAConnection();

  virtual void OnSendRequest(
    B2BUACall & call,
    SIPMessage & msg
  );

  virtual void OnReceivedRequest(
    B2BUACall & call,
    const SIPMessage & msg
  );


  PINLINE SBCCALEAEndPoint & GetCALEAEndPoint(){ return m_CALEAEndPoint; };
protected:
  SBCCALEAEndPoint & m_CALEAEndPoint;
  PCAPFile * m_PCAPFile;
  PIPSocket::Address m_PCAPLocalAddress;
  PIPSocket::Address m_PCAPRemoteAddress;
  WORD m_PCAPLocalPort;
  WORD m_PCAPRemotePort;
};

///////////////////////////////////////////////////////////
SBCCALEAEndPoint::SBCCALEAEndPoint(
    SBCCALEATrunk & ua
) : B2BUAEndPoint( ua, 1, 1024 * 2 )
{
}

SBCCALEAEndPoint::~SBCCALEAEndPoint()
{
}

B2BUAConnection * SBCCALEAEndPoint::OnCreateB2BUA(
    const SIPMessage & /*request*/,
    const OString & _sessionId,
    B2BUACall * /*session*/
)
{
  OString sessionId = _sessionId + "-connection";
  SBCCALEAConnection * connection = new SBCCALEAConnection( *this, sessionId );
  connection->SetMediaProxyIfPrivate( FALSE );
  return connection;
}
///////////////////////////////////////////////////////////

SBCCALEAConnection::SBCCALEAConnection(
  SBCCALEAEndPoint & ep,
  const OString & sessionId
) : B2BUAConnection( ep, sessionId ),
    m_CALEAEndPoint( ep )
{
  OStringStream fn;
  fn << m_CALEAEndPoint.GetPCAPDirectory() << "/" << sessionId << ".pcap";
  m_PCAPFile = new PCAPFile( fn.str().c_str() );

  m_PCAPLocalAddress = 0;
  m_PCAPLocalPort = 0;
  m_PCAPRemoteAddress = 0;
  m_PCAPRemotePort = 0;
}

SBCCALEAConnection::~SBCCALEAConnection()
{
  m_PCAPFile->Close();
  delete m_PCAPFile;
}

void SBCCALEAConnection::OnSendRequest(
  B2BUACall & call,
  SIPMessage & msg
)
{
  if( call.GetLegIndex() == 1 )
  {
    PIPSocket::Address dstAddress;
    WORD dstPort;

    PIPSocket::Address srcAddress;
    WORD srcPort;

    OString msgString = msg.AsString();
    PBYTEArray bytes;
    bytes.SetSize( msgString.GetSize() );
    memcpy( bytes.GetPointer(), msgString.c_str(), msgString.GetLength() );
    bytes[msgString.GetLength()] = '\0';

    if( msg.IsRequest() )
    {
      if( !m_PCAPLocalAddress.IsValid() )
      {
        SIPTransport::Resolve( msg, dstAddress, dstPort );

        m_PCAPLocalAddress = srcAddress = PIPSocket::Address( "127.0.0.1" );/*PIPSocket::Address( via.GetAddress().c_str() )*/;
        m_PCAPLocalPort = srcPort = msg.GetTopVia().GetPort();
        m_PCAPRemoteAddress = dstAddress;
        m_PCAPRemotePort = dstPort;
      }else
      {
        srcAddress = m_PCAPLocalAddress;
        srcPort = m_PCAPLocalPort;
        dstAddress = m_PCAPRemoteAddress;
        dstPort = m_PCAPRemotePort;
      }
    }else
    {
      srcAddress = m_PCAPLocalAddress;
      srcPort = m_PCAPLocalPort;
      dstAddress = m_PCAPRemoteAddress;
      dstPort = m_PCAPRemotePort;
    }

    m_PCAPFile->WritePacketUDP(
        PTime(),
        srcAddress,
        dstAddress,
        srcPort,
        dstPort,
        bytes );
  }
}

void SBCCALEAConnection::OnReceivedRequest(
  B2BUACall & call,
  const SIPMessage & msg
)
{
  if( call.GetLegIndex() == 1 )
  {
    PIPSocket::Address dstAddress;
    WORD dstPort;

    PIPSocket::Address srcAddress;
    WORD srcPort;

    OString msgString = msg.AsString();
    PBYTEArray bytes;
    bytes.SetSize( msgString.GetSize() );
    memcpy( bytes.GetPointer(), msgString.c_str(), msgString.GetLength() );
    bytes[msgString.GetLength()] = '\0';

    dstAddress = m_PCAPLocalAddress;
    dstPort = m_PCAPLocalPort;
    srcAddress = m_PCAPRemoteAddress;
    srcPort = m_PCAPRemotePort;

    m_PCAPFile->WritePacketUDP(
        PTime(),
        srcAddress,
        dstAddress,
        srcPort,
        dstPort,
        bytes );
  }
}

///////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////

class SBCCALEARoutingHandler : public B2BRoutingInterface
{
  PCLASSINFO( SBCCALEARoutingHandler, B2BRoutingInterface );
public:
  SBCCALEARoutingHandler(  
    SBCCALEATrunk & b2bua 
  );

  virtual ~SBCCALEARoutingHandler();

  virtual BOOL B2BRouteCall(
    B2BUAConnection & connection,
    SIPMessage & invite,
    BOOL ignoreRegistrations = FALSE
  );

protected:
  SBCCALEATrunk & m_SBCCALEATrunk;
};

////////////////////////////////////////////////////////////
SBCCALEARoutingHandler::SBCCALEARoutingHandler(  
  SBCCALEATrunk & b2bua 
) : B2BRoutingInterface( b2bua ),
    m_SBCCALEATrunk( b2bua )
{
}

SBCCALEARoutingHandler::~SBCCALEARoutingHandler()
{
}

BOOL SBCCALEARoutingHandler::B2BRouteCall(
  B2BUAConnection & connection,
  SIPMessage & invite,
  BOOL /*ignoreRegistrations*/
)
{
  const Via & via = invite.GetTopVia();

  OString callId = invite.GetCallId();

  OpenSBC * mainSBC = m_SBCCALEATrunk.GetTrunkProcess()->GetTrunkManager()->GetMainProcess()->GetSBC();
  BOOL fromLocalTrunk = mainSBC->GetB2BUAEndPoint()->GetTransportManager()->IsLocalAddressAndPort( via.GetURI() );
  PIPSocket::Address verifiedAddress;
  WORD verifiedPort = 0;

  if( fromLocalTrunk )
  {
    OSSAppConfig * config = mainSBC->GetAppConfig();
    connection.SetRewriteToURI( FALSE );
    SIPURI routeURI;
    invite.GetRequestURI( routeURI );
    
    
    if( !GetB2BUA().GetStack().GetTransportManager()->IsLocalAddressAndPort( routeURI ) )
    {
      if( SIPTransport::Resolve( routeURI, verifiedAddress, verifiedPort, SIPTransport::UDP, FALSE ) )
      {
        PIPSocket::Address lAddr;
        WORD lPort;
        mainSBC->GetB2BUAEndPoint()->GetTransportManager()->GetListenerAddress( 
          SIPTransport::UDP, 
          routeURI.GetAddress(), 
          lAddr, 
          lPort 
        );

         SIPURI mainSBCListener;
         mainSBCListener.SetUser( routeURI.GetUser() );
         mainSBCListener.SetHost( lAddr.AsSTLString() );
         mainSBCListener.SetPort( OString( lPort ) );

        if( !config->GetBoolean( configKeyCALEASection, configKeyUseExternalCALEATrunk, FALSE ) )
        {
           /// route it back to the main SBC Trunk
          connection.AddRoute( mainSBCListener );
          SIPHeader noRTP( "SBC-RTP-Proxy" );
          noRTP.SetHeaderBody( "off" );
          invite.AddCustomHeader( noRTP );

          SIPHeader noBilling( "SBC-Accounting" );
          noBilling.SetHeaderBody( "off" );
          invite.AddCustomHeader( noBilling );
        }else
        {
          OString cURI = config->GetString( configKeyCALEASection, configKeyExternalCALEATrunkURI, "" );
          if( !cURI.IsEmpty() )
          {
            SIPURI externalURI( cURI );
            /// see if we can resolve it
            verifiedAddress = 0;
            verifiedPort = 0;
            if( !SIPTransport::Resolve( externalURI, verifiedAddress, verifiedPort, SIPTransport::UDP, FALSE ) )
              return FALSE;
            externalURI.SetHost( verifiedAddress.AsSTLString() );
            /// route it to the external CALEA address
            connection.AddRoute( externalURI );
          }else
          {
            return FALSE;
          }
        }

          
        OStringStream forceRoute;
        forceRoute << "<" << routeURI << ">";
        SIPHeader fRoute( "SBC-Force-Route" );
        fRoute.SetHeaderBody( forceRoute.str() );
        invite.AddCustomHeader( fRoute );

        SIPHeader cFilter( "SBC-Calea-Filter" );
        cFilter.SetHeaderBody( "off" );
        invite.AddCustomHeader( cFilter );

        SIPHeader mTrunk( "SBC-Main-Trunk" );
        OStringStream mtRoute;
        mtRoute << "<" << mainSBCListener << ">";  
        mTrunk.SetHeaderBody( mtRoute.str() );
        invite.AddCustomHeader( mTrunk );

        return TRUE;
      }else
      {
        return FALSE;
      }
    }
  }else
  {

    /// this may have been relayed from a remote CALEA trunk
    /// check the invite if it has a Main-Trunk-URI header
    SIPURI mainTrunkURI;
    SIPHeader mainTrunkURIHeader( "SBC-Main-Trunk" );
    if( !invite.PopCustomHeader( "SBC-Main-Trunk", mainTrunkURIHeader ) )
      // get it from the contact URI
      mainTrunkURI = invite.GetContactTopURI();
    else
      mainTrunkURI = SIPURI( mainTrunkURIHeader.GetHeaderBody() );
    //see if we can reolve it
    verifiedAddress = 0;
    verifiedPort = 0;
    if( !SIPTransport::Resolve( mainTrunkURI, verifiedAddress, verifiedPort, SIPTransport::UDP, FALSE ) )
      return FALSE;

    connection.AddRoute( mainTrunkURI );
    return TRUE;

  }

  return FALSE;
}

////////////////////////////////////////////////////////////

SBCCALEATrunk::SBCCALEATrunk(
  SBCTrunkProcess * trunkProcess
  ) : SBCTrunk( trunkProcess )
{
  m_UserAgentName = "CALEA Trunk";
  m_HasInitConfig = FALSE;
  SBCCALEAEndPoint * ep = new SBCCALEAEndPoint( *this);
  trunkProcess->SetEndPoint( ep );
  SetEndPoint( ep );

  //PFilePath applicationPath = trunkProcess->GetTrunkManager()->GetMainProcess()->GetFile();
  PString caleaDIR = OSSApplication::GetApplicationDirectory() + "calea";
  PDirectory calea( caleaDIR );
  if( !calea.Exists() )
    calea.Create();

  PString pcapDIR = OSSApplication::GetApplicationDirectory() + "calea/pcap";
  PDirectory pcap( pcapDIR );
  if( !pcap.Exists() )
    pcap.Create();

  ep->SetPCAPDirectory( pcap );
}

SBCCALEATrunk::~SBCCALEATrunk()
{
}

B2BRoutingInterface * SBCCALEATrunk::OnCreateRoutingInterface()
{
  return new SBCCALEARoutingHandler( *this );
}

void SBCCALEATrunk::OnConfigChanged( 
  OSSAppConfig & config,
  const char * /*section*/  
)
{
  if( m_HasInitConfig )
    return;

  m_HasInitConfig = TRUE;

  int workerThreadCount = 1;
  

  //B2BUAConnection::SetSeizeTimeout( config.GetInteger( configKeySection, configKeySeizeTimeout, 0 ) );
  //B2BUAConnection::SetAlertingTimeout( config.GetInteger( configKeySection, configKeyAlertingTimeout, 0 ) );
  
  // Enable Feature SIP Session Timers
  GetB2BUAEndPoint()->EnableSessionTimer( FALSE );

  Encryption::Engine::m_Key = (const char *)config.GetString( configKeySection, configKeyEncryptionKey, Encryption::Engine::m_DefKey );
  OString encMode = config.GetString( configKeySection, configKeyEncryption, "XOR" );
  if( encMode *= "XOR" )
    Encryption::Engine::m_Type = Encryption::Engine::Type_XOR;
  else if( encMode *= "DiffShift" )
    Encryption::Engine::m_Type = Encryption::Engine::Type_DiffShift;

 
  m_AcceptAllCalls = TRUE;
  GetB2BUAEndPoint()->EnableLocalRefer( FALSE );

  PStringArray privacyDomains;
  for( PINDEX i = 0; i <  config.GetListSize( configKeyPrivacyTrustedDomainSection, configKeyPrivacyDomain ); i++ )
    privacyDomains.AppendString( config.GetListItem( configKeyPrivacyTrustedDomainSection, configKeyPrivacyDomain, i ) );
  AddPrivacyTrustedDomains( privacyDomains, TRUE );
  SetPrivacyDefaultRealm( config.GetString( configKeyPrivacyTrustedDomainSection, configKeyPrivacyDefaultRealm, "" ) );

  OpenSBC * mainSBC = GetTrunkProcess()->GetTrunkManager()->GetMainProcess()->GetSBC();
  SIPURI bindAddress((const char *)config.GetString( configKeySIPTransportSection, configKeyCALEAInterfaceAddress, "sip:*:5068" ));
  PIPSocket::Address iface = PIPSocket::Address( bindAddress.GetHost() );
  if( !iface.IsValid() )
    iface = mainSBC->GetTransportManager()->GetDefaultInterfaceAddress( FALSE );
  WORD port = (WORD)bindAddress.GetPort().AsUnsigned();
  GetDefaultProfile().GetTransportProfile().EnableUDP( iface, port  );

#if ENABLE_TCP_TRANSPORT
  GetDefaultProfile().GetTransportProfile().EnableTCP( iface, port  );
#endif

  Initialize( workerThreadCount );

  m_RoutingHandler->RefreshStaticRoutes();

  SIPUDPTransport * transport = dynamic_cast<SIPUDPTransport*>( GetB2BUAEndPoint()->GetTransportManager()->GetUDPTransport() );

  PIPSocket::Address laddr;
  WORD lport;
  transport->GetDefaultListenerAddress( laddr, lport );
  OStringStream listenerAddr;
  listenerAddr << "sip:" << laddr << ":" << port;
  this->GetMainTrunk()->SetCALEATrunkURI( listenerAddr.str().c_str() );
}

void SBCCALEATrunk::ProcessEvent(
    SIPStackEvent * event
)
{
  m_EndPoint->ProcessStackEvent( NULL, event );
}


