/*
 *
 * PHPScript.cxx
 * 
 * Open SIP Stack ( OSS )
 *
 * Copyright (c) opensipstack.org.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either expressed or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is OpenSIPStack.
 *
 * The Initial Developer of the Original Code is opensipstack.org.
 *
 * The author of this code is Joegen E. Baclor
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * The OpenSIPStack Library includes some GPL/LGPL code libraries that MAY be 
 * enabled at compile time using the --enable-gpllibs configure switch.  If
 * enabled, the content of this file is published under the terms of GNU 
 * General Public License Version 2.  For a detailed list of the available
 * GPL code, see $(opensipstack)/gnu/README file.
 *
 * $Log: PHPScript.cpp,v $
 * Revision 1.3  2008/03/08 13:25:13  joegenbaclor
 * Added session variable and cookie support in PHP
 *
 * Revision 1.2  2008/03/07 15:11:22  joegenbaclor
 * Added PHP SAPI Support in HTTP Server
 *
 * Revision 1.1  2008/03/07 04:20:50  joegenbaclor
 * Added PHP Classes
 *
 *
 */


#include <php/PHPScript.h>
#include <iostream>
#include <vector>
#include <string>
#include <map>

/* PHP Includes */
extern "C" 
{
  /* PHP Defines */
  #if WIN32
  #ifndef ZEND_WIN32
  #define ZEND_WIN32
  #endif
  #ifndef PHP_WIN32
  #define PHP_WIN32
  #endif
  #endif

  #ifndef ZTS
  #define ZTS 1
  #endif

  #ifndef ZEND_DEBUG
  #define ZEND_DEBUG 0
  #endif

  #include <php.h>
  #include <php_embed.h>
}

using namespace PHP;
static PHPScript * script_engine = NULL;

#define PHP_SUCCESS 0
#define PHP_ERROR 1

class php_exception: public std::exception
{
public:
  php_exception( const std::string & w )
  {
    m_What = w;
  }

  const char* what() const throw()
  {
    return m_What.c_str();
  }

  std::string m_What;
};

class PHPArray
  {
  public:
    PHPArray()
    {
      MAKE_STD_ZVAL(php_array);
      array_init(php_array);
      can_delete_ptr = true;
    }

    PHPArray(zval * _php_array)
    {
      php_array = _php_array;
      array_init(php_array);
      can_delete_ptr = false;
    }

    ~PHPArray()
    {
      if( can_delete_ptr )
        zval_ptr_dtor(&php_array);
    }

    void push_back( const char * str )
    {
      add_next_index_string(php_array, const_cast<char*>(str), 1);
    }

    void push_back( long val )
    {
      add_next_index_long(php_array, val);
    }

    void push_back( bool val )
    {
      add_next_index_bool(php_array, val);
    }

    void push_back( double val )
    {
      add_next_index_double(php_array, val);
    }

    void push_back_null()
    {
      add_next_index_null(php_array);
    }

    void set_at( unsigned long index, const char * str )
    {
      add_index_string(php_array, index, const_cast<char*>(str), 1);
    }

    void set_at( unsigned long index, long val )
    {
      add_index_long(php_array, index, val);
    }

    void set_at( unsigned long index, bool val )
    {
      add_index_bool(php_array, index, val);
    }

    void set_at( unsigned long index, double val )
    {
      add_index_double(php_array, index, val);
    }

    void set_at_null( unsigned long index )
    {
      add_index_null(php_array, index);
    }

    void set_at( const char * id, int str_len, const char * str )
    {
      add_assoc_string_ex(php_array, const_cast<char*>(id), str_len + 1, const_cast<char*>(str), 1);
    }

    void set_at( const char * id, int str_len, long val )
    {
      add_assoc_long_ex(php_array, const_cast<char*>(id), str_len + 1, val);
    }

    void set_at( const char * id, int str_len, bool val )
    {
      add_assoc_bool_ex(php_array, const_cast<char*>(id), str_len + 1, val);
    }

    void set_at( const char * id, int str_len, double val )
    {
      add_assoc_double_ex(php_array, const_cast<char*>(id), str_len + 1, val);
    }

    void set_at_null( const char * id, int str_len  )
    {
      add_assoc_null_ex(php_array, const_cast<char*>(id), str_len + 1);
    }

  private:
    bool can_delete_ptr;
    zval * php_array;
  };

static PHP_FUNCTION( cpp_session_start )
{
  script_engine->OnSessionGlobalStart();
}

static PHP_FUNCTION( cpp_session_destroy )
{
  script_engine->OnSessionGlobalDestroy();
}

static PHP_FUNCTION( cpp_set_cookie )
{
  zval ***args = NULL;
	int nargs = ZEND_NUM_ARGS();

	if(nargs == 2) 
  {
		args = (zval ***)safe_emalloc(sizeof(zval *), nargs, 0);
		zend_get_parameters_array_ex(nargs, args);
	}else
  {
    // there should at least be one argument
    RETURN_NULL();
  }

  std::string cookieName, cookieValue;

  zval cname = **args[0];
  zval_copy_ctor(&cname);
  convert_to_string(&cname);
  cookieName = Z_STRVAL_P((&cname));
  zval_dtor(&cname);

  zval cval = **args[1];
  zval_copy_ctor(&cval);
  convert_to_string(&cval);
  cookieValue = Z_STRVAL_P((&cval));
  zval_dtor(&cval);

  script_engine->OnCPPStoreCookie( cookieName, cookieValue );

  RETURN_NULL();
}

static PHP_FUNCTION(cpp_evaluate)
{
  zval ***args = NULL;
	int nargs = ZEND_NUM_ARGS();

	if (nargs) 
  {
		args = (zval ***)safe_emalloc(sizeof(zval *), nargs, 0);
		zend_get_parameters_array_ex(nargs, args);
	}else
  {
    // there should at least be one argument
    RETURN_NULL();
  }
  
  std::string funcName;
  PHPVariantMap in, out;

  zval temp = **args[0];
  zval_copy_ctor(&temp);
  convert_to_string(&temp);
  funcName = Z_STRVAL_P((&temp));
  zval_dtor(&temp);

  for( int i = 1; i < nargs; i++ )
  {   
    if( Z_TYPE_P(*args[i])==IS_ARRAY )
    {
      HashTable *arr_hash  = Z_ARRVAL_P(*args[i]);
      int array_count = zend_hash_num_elements(arr_hash);
      HashPosition pointer;
      zval **data;
      for(  zend_hash_internal_pointer_reset_ex(arr_hash, &pointer); 
            zend_hash_get_current_data_ex(arr_hash, (void**) &data, &pointer) == SUCCESS; 
            zend_hash_move_forward_ex(arr_hash, &pointer)) 
      {
          zval temp;
          char *key;
          uint key_len;
          ulong index;
          
          std::string first, second;

          if (zend_hash_get_current_key_ex(arr_hash, &key, (uint*)&key_len, &index, 0, &pointer) == HASH_KEY_IS_STRING) 
          {
            first = std::string(key, key_len);
          } else 
          {
            char array_index_buf[10];
            char index_buf[10];
            ::itoa( i, index_buf, 10 );
            ::itoa( index, array_index_buf, 10 );
            std::string h1 = std::string( index_buf );
            std::string h2 = std::string( array_index_buf );
            first = "[" + h1 + "," + h2 + "]"; 
          }

          temp = **data;
          zval_copy_ctor(&temp);
          //convert_to_string(&temp);
          //second = Z_STRVAL_P((&temp));

          switch( Z_TYPE_P(&temp) )
          {    
            case IS_LONG:
              second = (long)Z_LVAL_P(&temp);
              break;
            case IS_DOUBLE:
              second = (double)Z_DVAL_P(&temp);
              break;
            case IS_BOOL:
              second = (bool)Z_BVAL_P(&temp);
              break;
            case IS_STRING:
              second = Z_STRVAL_P(&temp);
              break;
            case IS_ARRAY: // none supported types
            case IS_NULL:
            case IS_OBJECT:
            case IS_RESOURCE:
            case IS_CONSTANT:
            case IS_CONSTANT_ARRAY:
              throw php_exception( "PHP Script Returned Unsupported Type" );
          }

          zval_dtor(&temp);
          in[first] = second;
      }

    }else if( Z_TYPE_P(*args[i])==IS_STRING )
    {
      zval arg_temp = **args[i];
      zval_copy_ctor(&arg_temp);
      std::string second;

      switch( Z_TYPE_P(&temp) )
      {    
        case IS_LONG:
          second = (long)Z_LVAL_P(&temp);
          break;
        case IS_DOUBLE:
          second = (double)Z_DVAL_P(&temp);
          break;
        case IS_BOOL:
          second = (bool)Z_BVAL_P(&temp);
          break;
        case IS_STRING:
          second = Z_STRVAL_P(&temp);
          break;
        case IS_ARRAY: // none supported types
        case IS_NULL:
        case IS_OBJECT:
        case IS_RESOURCE:
        case IS_CONSTANT:
        case IS_CONSTANT_ARRAY:
          throw php_exception( "PHP Script Returned Unsupported Type" );
      }

      zval_dtor(&arg_temp);
      
      char buf[5];
      ::itoa( i, buf, 10 );
      std::string first( buf );

      in[first] = second;
    }
  }

	if (args) 
		efree(args);

  if( !script_engine->OnCPPEvaluate( funcName, in, out ) )
    RETURN_NULL();

  PHPArray param_arg( return_value ); 
  for( PHPVariantMap::iterator iter = out.begin(); iter != out.end(); iter++ )
  {
    //ret_val.set_at( iter->first.c_str(), (int)iter->first.length(), iter->second );

    if ( iter->second.is_type<int>() )
    {
      param_arg.set_at( iter->first.c_str(), (int)iter->first.length(), (long)iter->second );
    }
    else if ( iter->second.is_type<double>() )
    {
      param_arg.set_at( iter->first.c_str(), (int)iter->first.length(), (double)iter->second );
    }else if ( iter->second.is_type<long>() )
    {
      param_arg.set_at( iter->first.c_str(), (int)iter->first.length(), (long)iter->second );
    }
    else if ( iter->second.is_type<std::string>() )
    {
      std::string str_value = (std::string)iter->second;
      param_arg.set_at( iter->first.c_str(), (int)iter->first.length(), str_value.c_str() );
    }else if( iter->second.is_type<bool>() )
    {
      param_arg.set_at( iter->first.c_str(), (int)iter->first.length(), (bool)iter->second );//MAKE_STD_ZVAL(zvalue);
    }else
    {
      throw php_exception( "PHP Function Parameter Unknown Type" );
    }
  }

}


static int PHPEcho(const char *str, unsigned int len, void ***)
{
  std::string buf( str, len );
  script_engine->OnPHPEcho( buf );
  return PHP_SUCCESS;
}

zend_bool PHPSessionAutoGlobal(char *name, uint name_len TSRMLS_DC)
{
  zval *session_val;
  int i;

  MAKE_STD_ZVAL(session_val);
  array_init(session_val);

  for(i = 0; i < 10000; i++) 
  {
      add_next_index_long(session_val, i);
  }
  ZEND_SET_SYMBOL(&EG(symbol_table), "_SESSION",
                                  session_val);
  return 0;
}

static function_entry cpp_functions[] = {
    PHP_FE(cpp_evaluate, NULL)
    PHP_FE(cpp_set_cookie, NULL)
    PHP_FE(cpp_session_start, NULL)
    PHP_FE(cpp_session_destroy, NULL)
    {NULL, NULL, NULL}
};

PHPScript::PHPScript( int argc, char **argv, const std::string & inc_path )
{
  if( script_engine != NULL )
    throw php_exception( "You can only instantiate the scripting engine once" );

  php_embed_module.ub_write = PHPEcho;
  php_embed_init( argc, argv PTSRMLS_CC );

  std::string ini_entry = "max_execution_time";
  std::string ini_entry_value = "0";
  zend_alter_ini_entry(
    const_cast<char*>(ini_entry.c_str()), 
    ((int)ini_entry.length())+1, 
    const_cast<char*>(ini_entry_value.c_str()), ((int)ini_entry_value.length())+1,
    PHP_INI_USER, PHP_INI_STAGE_ACTIVATE);

  ini_entry = "variables_order";
  ini_entry_value = "S";
  zend_alter_ini_entry(
    const_cast<char*>(ini_entry.c_str()), 
    ((int)ini_entry.length())+1, 
    const_cast<char*>(ini_entry_value.c_str()), ((int)ini_entry_value.length())+1,
    PHP_INI_USER, PHP_INI_STAGE_ACTIVATE);

  zend_alter_ini_entry("include_path", strlen("include_path") + 1,
                 const_cast<char*>(inc_path.c_str()), ((int)inc_path.length())+1, 
                 PHP_INI_SYSTEM, PHP_INI_STAGE_ACTIVATE);


  zend_register_functions(NULL, cpp_functions, NULL, MODULE_PERSISTENT TSRMLS_CC);

  //REGISTER SESSION AUTO GLOBAL

  // Note: Notice here that the second parameter, referring to the length of the variable name, 
  // uses sizeof()-1 to exclude the terminating NULL. This is an about-face from most of the 
  // internal calls you've seen so far, so be careful not to get bit by it when declaring your own variables.
  zend_register_auto_global("_SESSION", sizeof("_SESSION") - 1
                        ,PHPSessionAutoGlobal
                        TSRMLS_CC);

  PHPSessionAutoGlobal("_SESSION", sizeof("_SESSION") - 1 TSRMLS_CC);


  script_engine = this;
}

PHPScript::~PHPScript()
{
  php_embed_shutdown(TSRMLS_C);
  script_engine = NULL;
}

void PHPScript::OnPHPEcho( const std::string & str )
{
  std::cout << str;
}

int PHPScript::LoadScript( const std::string & file )
{
  zval ret_value;
  int exit_status = 0;

  std::string evalString = "include(\"" + file + "\")" ;

  try
  {
  zend_first_try {
		PG(during_request_startup) = 0;
		zend_eval_string(const_cast<char*>(evalString.c_str()), &ret_value, "EvaluateString" TSRMLS_CC);
    exit_status= Z_LVAL(ret_value);
	}
	zend_catch {
    std::cout << "Unknown error while calling zend_eval_string" << std::endl;
		exit_status = EG(exit_status);
	}
	zend_end_try();
  }catch(...)
  {
    std::cout << "Unknown error while calling zend_eval_string" << std::endl;
    exit_status = EG(exit_status);
  }

  return exit_status;
}

int PHPScript::ExecuteScript( const std::string & file )
{
  zend_file_handle script;


  /* Set up a File Handle structure */
  script.type = ZEND_HANDLE_FP;
  script.filename = const_cast<char*>(file.c_str());
  script.opened_path = NULL;
  script.free_filename = 0;
  if (!(script.handle.fp = fopen(script.filename, "rb")))
      return -1;

  return php_execute_script(&script TSRMLS_CC);
}


struct ZendString
{
  ZendString()
  {
    zval_str = NULL;
  }

  ~ZendString()
  {
    if( zval_str != NULL )
      zval_ptr_dtor(&zval_str);
  }

  ZendString (const char *str)
  {
    zval_str = NULL;
    operator=(str);
  }

  ZendString & operator=(const char *str)
  {
    if( zval_str != NULL )
      zval_ptr_dtor(&zval_str);

    MAKE_STD_ZVAL(zval_str);
    ZVAL_STRING(zval_str, const_cast<char*>(str), (int)1);
    return *this;
  }

  zval * zval_str;
};


bool PHPScript::PHPEvaluate( 
  const std::string & funcName,
  PHPVariantMap & in,
  PHPVariantMap & out
)
{
  zval *retval = NULL;
  MAKE_STD_ZVAL(retval);

  ZendString func( funcName.c_str() );

  if( in.size() > 256 )
    throw php_exception( "PHP Function Parameter > 256 in size" );

  zval * params[1] = {NULL};
  
  int i = 0;
  MAKE_STD_ZVAL(params[0]);
  PHPArray param_arg( params[0] );

  for( PHPVariantMap::iterator iter = in.begin(); iter != in.end(); iter++ )
  {
    
    if ( iter->second.is_type<int>() )
    {
      param_arg.set_at( iter->first.c_str(), (int)iter->first.length(), (long)iter->second );
    }
    else if ( iter->second.is_type<double>() )
    {
      param_arg.set_at( iter->first.c_str(), (int)iter->first.length(), (double)iter->second );
    }else if ( iter->second.is_type<long>() )
    {
      param_arg.set_at( iter->first.c_str(), (int)iter->first.length(), (long)iter->second );
    }
    else if ( iter->second.is_type<std::string>() )
    {
      std::string str_value = (std::string)iter->second;
      param_arg.set_at( iter->first.c_str(), (int)iter->first.length(), str_value.c_str() );
    }else if( iter->second.is_type<bool>() )
    {
      param_arg.set_at( iter->first.c_str(), (int)iter->first.length(), (bool)iter->second );//MAKE_STD_ZVAL(zvalue);
    }else
    {
      throw php_exception( "PHP Function Parameter Unknown Type" );
    }
  }

  if( call_user_function( EG( function_table ), NULL, func.zval_str, retval, 1, params TSRMLS_CC ) != SUCCESS )
  {
    zval_ptr_dtor(&params[i]);
    if(retval)
       zval_ptr_dtor(&retval);
    return false;
  }

  if( Z_TYPE_P(retval)==IS_ARRAY )
  {
    HashTable *arr_hash  = Z_ARRVAL_P(retval);
    int array_count = zend_hash_num_elements(arr_hash);
    HashPosition pointer;
    zval **data;

    for(  zend_hash_internal_pointer_reset_ex(arr_hash, &pointer); 
          zend_hash_get_current_data_ex(arr_hash, (void**) &data, &pointer) == SUCCESS; 
          zend_hash_move_forward_ex(arr_hash, &pointer)) 
    {
      zval temp;
      char *key;
      uint key_len;
      ulong index;
      
      std::string first, second;

      if (zend_hash_get_current_key_ex(arr_hash, &key, (uint*)&key_len, &index, 0, &pointer) == HASH_KEY_IS_STRING) 
      {
        first = std::string(key, key_len);
      } else 
      {
        char buf[20];
        ::itoa( index, buf, 10 );
        first = std::string( buf );
      }

      temp = **data;
      zval_copy_ctor(&temp);

      switch( Z_TYPE_P(&temp) )
      {    
        case IS_LONG:
          second = (long)Z_LVAL_P(&temp);
          break;
        case IS_DOUBLE:
          second = (double)Z_DVAL_P(&temp);
          break;
        case IS_BOOL:
          second = (bool)Z_BVAL_P(&temp);
          break;
        case IS_STRING:
          second = Z_STRVAL_P(&temp);
          break;
        case IS_ARRAY: // none supported types
        case IS_NULL:
        case IS_OBJECT:
        case IS_RESOURCE:
        case IS_CONSTANT:
        case IS_CONSTANT_ARRAY:
          throw php_exception( "PHP Script Returned Unsupported Type" );
      }
      
      zval_dtor(&temp);
      out[first] = second;
    }
  }else
  {
    zval temp = *retval;
    zval_copy_ctor(&temp);
    PHPVariant second;

    long nullRet = 0;
    switch( Z_TYPE_P(&temp) )
    {    
      case IS_LONG:
        second = (long)Z_LVAL_P(&temp);
        break;
      case IS_DOUBLE:
        second = (double)Z_DVAL_P(&temp);
        break;
      case IS_BOOL:
        second = (bool)Z_BVAL_P(&temp);
        break;
      case IS_STRING:
        second = Z_STRVAL_P(&temp);
        break;
      case IS_NULL:
        second = (long)nullRet;
        break;
      case IS_ARRAY: // none supported types
      case IS_OBJECT:
      case IS_RESOURCE:
      case IS_CONSTANT:
      case IS_CONSTANT_ARRAY:
        throw php_exception( "PHP Script Returned Unsupported Type" );
    }
    zval_dtor(&temp);
    out["0"] = second;
  }

  if(retval)
    zval_ptr_dtor(&retval);

  return true;
}


bool PHPScript::OnSessionGlobal(
  const std::string & sessionId,
  const std::string & varName,
  PHPVariantMap & out
)
{
  return false;
}

void PHPScript::OnSessionGlobalStart()
{
}

void PHPScript::OnSessionGlobalDestroy()
{
}






