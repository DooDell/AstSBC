/*
 *
 * SBCSIPTrunkConnection.cxx
 *
 * Open SIP Stack ( OSS )
 *
 * Copyright (c) opensipstack.org.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either expressed or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is OpenSIPStack.
 *
 * The Initial Developer of the Original Code is opensipstack.org.
 *
 * The author of this code is Joegen E. Baclor
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * The OpenSIPStack Library includes some GPL/LGPL code libraries that MAY be 
 * enabled at compile time using the --enable-gpllibs configure switch.  If
 * enabled, the content of this file is published under the terms of GNU 
 * General Public License Version 2.  For a detailed list of the available
 * GPL code, see $(opensipstack)/gnu/README file.
 *
 * $Log: SBCSIPTrunkConnection.cxx,v $
 * Revision 1.12  2008/12/22 06:51:46  joegenbaclor
 * Application Timers for Alerting and Connect is causing a deadlock on connection destruction.
 * To address this issue, we modified opensipstack to take care of the timers in the ICT Layer.
 *
 * Revision 1.11  2008/12/18 03:52:03  joegenbaclor
 * Introduced new failover rule.
 *
 * Revision 1.10  2008/11/20 11:02:35  joegenbaclor
 * Depcrecated old SIPMessage URI accessors
 *
 * Revision 1.9  2008/08/02 15:34:40  joegenbaclor
 * More HTTP Session work
 *
 * Revision 1.8  2008/07/25 08:51:15  joegenbaclor
 * Completing WS-SOHO support for solegy
 *
 * Revision 1.7  2008/04/16 00:44:21  joegenbaclor
 * Using OnPostCreateB2BUA callback to set keep-alive and max-session-lifetime
 *
 * Revision 1.6  2008/01/27 05:44:58  joegenbaclor
 * Corrected typos in last commit
 *
 * Revision 1.5  2008/01/27 05:33:22  joegenbaclor
 * Added WWW Authentication handler for INVITE received by SIP Trunks.
 *
 * Revision 1.4  2007/12/21 09:48:07  joegenbaclor
 * Added ability to preserve the transaction via the incoming SIP message.  This pointer may be provided to SendRequest so that responses can avoid another search of the transaction from the transaction db.
 *
 * Revision 1.3  2007/10/17 03:17:39  joegenbaclor
 * More work on sip trunks
 *
 * Revision 1.2  2007/10/10 16:59:57  joegenbaclor
 * Logging improvement
 *
 * Revision 1.1  2007/10/02 16:42:56  joegenbaclor
 * Marking initial release of SIP Trunking
 *
 *
 */

#include "SBCSIPTrunkConnection.h"

#define new PNEW

SBCSIPTrunkConnection::SBCSIPTrunkConnection(
  B2BUAEndPoint & ep,
  const OString & sessionId,
  SBCSIPTrunkRoutingHandler * handler,
  SBCSIPTrunkReg * trunkReg
) : B2BUAConnection( ep, sessionId )
{
  m_RoutingHandler = handler;
  m_TrunkReg = trunkReg;
  m_IsEgress = FALSE;
}

SBCSIPTrunkConnection::~SBCSIPTrunkConnection()
{
}

BOOL SBCSIPTrunkConnection::OnIncomingCall(
  B2BUACall & call,
  SIPMessage & invite
)
{

  if( m_RoutingHandler->IsEgress( invite ) )
  {
    ///remove authorizations headers if there are any
    invite.RemoveWWWAuthenticate();
    invite.RemoveProxyAuthenticate();
    ///change the from URI domain
    From from = invite.GetFrom();
    SIPURI toURI = invite.GetToURI();
    SIPURI fromURI = invite.GetFromURI();
    fromURI.SetHost( toURI.GetHost() );
    
    if( !m_EgressUser.IsEmpty() )
      fromURI.SetUser( m_EgressUser );

    from.SetURI( fromURI );
    invite.SetFrom( from );
  }


  B2BUserAgent & b2bua = 
    (B2BUserAgent &)GetSessionManager().GetUserAgent();

  return b2bua.OnIncomingCall( *this, call, invite );
}

BOOL SBCSIPTrunkConnection::OnTrunkAuthentication(
  B2BUACall & call,
  const SIPMessage & challenge
)
{
  GCVERIFYREF( "SBCSIPTrunkConnection::OnTrunkAuthentication", FALSE );

  if( !IsEgress() )
    return FALSE;

  if( m_EgressAuthUser.IsEmpty() )
  {
    LOG( LogWarning(), "*** Proxy Authentication User is EMPTY!!! ***" );
    LOG( LogWarning(), "*** Unable to authenticate Call!!! ***" );
  }

  if( m_EgressPassword.IsEmpty() )
  {
    LOG( LogWarning(), "Proxy authentication password is Empty" );
  }

  if( challenge.HasProxyAuthenticate() )
    return OnTrunkProxyAuthentication( call, challenge );
  else if( challenge.HasWWWAuthenticate() )
    return OnTrunkWWWAuthentication( call, challenge );
  
  return FALSE;
}

BOOL SBCSIPTrunkConnection::OnTrunkProxyAuthentication(
  B2BUACall & call,
  const SIPMessage & challenge
)
{
  ProxyAuthenticate proxyAuth;
  challenge.GetProxyAuthenticate( proxyAuth );

  /// clear the internal headers from the previous transaction
  //currentUACInvite.ClearInternalHeaders();

  SIPMessage currentUACInvite = call.GetCurrentUACInvite();
  /// increment cseq
  CSeq cseq;
  currentUACInvite.GetCSeq( cseq );
  currentUACInvite.SetCSeq( ++cseq );
  call.SetLocalSequence( cseq.GetSequence() );
  
  StartLine startLine;
  currentUACInvite.GetStartLine( startLine );
  startLine.GetRequestLine()->GetRequestURI().AsString();
  OString uriText = startLine.GetRequestLine()->GetRequestURI().AsString( FALSE );

  OString realm;
  proxyAuth.GetParameter( "realm", realm );
  ParserTools::UnQuote( realm );
  OString nonce;
  proxyAuth.GetParameter( "nonce", nonce );
  ParserTools::UnQuote( nonce );

  MD5::A1Hash a1( m_EgressAuthUser,realm, m_EgressPassword );
  MD5::A2Hash a2( startLine.GetRequestLine()->GetMethod(), uriText );
  OString hResponse = MD5::MD5Authorization::Construct( a1.AsString(), nonce, a2.AsString() );

  ProxyAuthorization authorization;
  authorization.SetLeadString( "Digest" );
  authorization.AddParameter( "username", ParserTools::Quote( m_EgressAuthUser ) );
  authorization.AddParameter( "realm", ParserTools::Quote( realm ) );
  authorization.AddParameter( "nonce", ParserTools::Quote( nonce ) );
  authorization.AddParameter( "uri", ParserTools::Quote( uriText ) );
  authorization.AddParameter( "response", ParserTools::Quote( hResponse ) );
  authorization.AddParameter( "algorithm", "MD5" );

  currentUACInvite.SetProxyAuthorization( authorization );

  Via via = currentUACInvite.GetTopVia();
  via.AddParameter( "branch", ParserTools::GenBranchParameter(), TRUE );
  currentUACInvite.SetViaAt( 0, via );

  /// check if we are configured to use an outbound proxy
  if(  !m_SessionProfile.GetProxyProfile().GetServerAddress().IsEmpty() )
  {
    /// put the proxy as the static route
    SIPURI sendAddress( m_SessionProfile.GetProxyProfile().GetServerAddress() );
    currentUACInvite.SetSendAddress( sendAddress );
  }

  call.SetCurrentUACInvite( currentUACInvite );
  
  return call.SendRequest( currentUACInvite );
}

BOOL SBCSIPTrunkConnection::OnTrunkWWWAuthentication(
  B2BUACall & call,
  const SIPMessage & challenge
)
{
  WWWAuthenticate proxyAuth;
  challenge.GetWWWAuthenticate( proxyAuth );

  /// clear the internal headers from the previous transaction
  //currentUACInvite.ClearInternalHeaders();

  SIPMessage currentUACInvite = call.GetCurrentUACInvite();
  /// increment cseq
  CSeq cseq;
  currentUACInvite.GetCSeq( cseq );
  currentUACInvite.SetCSeq( ++cseq );
  call.SetLocalSequence( cseq.GetSequence() );
  
  StartLine startLine;
  currentUACInvite.GetStartLine( startLine );
  startLine.GetRequestLine()->GetRequestURI().AsString();
  OString uriText = startLine.GetRequestLine()->GetRequestURI().AsString( FALSE );

  OString realm;
  proxyAuth.GetParameter( "realm", realm );
  ParserTools::UnQuote( realm );
  OString nonce;
  proxyAuth.GetParameter( "nonce", nonce );
  ParserTools::UnQuote( nonce );

  MD5::A1Hash a1( m_EgressAuthUser,realm, m_EgressPassword );
  MD5::A2Hash a2( startLine.GetRequestLine()->GetMethod(), uriText );
  OString hResponse = MD5::MD5Authorization::Construct( a1.AsString(), nonce, a2.AsString() );

  Authorization authorization;
  authorization.SetLeadString( "Digest" );
  authorization.AddParameter( "username", ParserTools::Quote( m_EgressAuthUser ) );
  authorization.AddParameter( "realm", ParserTools::Quote( realm ) );
  authorization.AddParameter( "nonce", ParserTools::Quote( nonce ) );
  authorization.AddParameter( "uri", ParserTools::Quote( uriText ) );
  authorization.AddParameter( "response", ParserTools::Quote( hResponse ) );
  authorization.AddParameter( "algorithm", "MD5" );

  currentUACInvite.SetAuthorization( authorization );

  Via via = currentUACInvite.GetTopVia();
  via.AddParameter( "branch", ParserTools::GenBranchParameter(), TRUE );
  currentUACInvite.SetViaAt( 0, via );

  /// check if we are configured to use an outbound proxy
  if(  !m_SessionProfile.GetProxyProfile().GetServerAddress().IsEmpty() )
  {
    /// put the proxy as the static route
    SIPURI sendAddress( m_SessionProfile.GetProxyProfile().GetServerAddress() );
    currentUACInvite.SetSendAddress( sendAddress );
  }

  call.SetCurrentUACInvite( currentUACInvite );
  
  return call.SendRequest( currentUACInvite );
}

void SBCSIPTrunkConnection::OnHandlePreConnectState( 
  B2BUACall & call,
  const SIPMessage & message
)
{
  SIPMessage msg = message;

  B2BUserAgent& b2bUA = (B2BUserAgent&)GetSessionManager().GetUserAgent();

  if( call.GetLegIndex() == 1 )
  {
    if( msg.GetCSeqMethod() *= "INVITE" )
    {
      if( msg.Is1xx() )
      {
        if( msg.GetStatusCode() == 100 )
        {
          m_SessionState = Trying;
          return;
        }else
        {
          m_SessionState = Proceeding;
          // ok now we are ringing
          // stop connecting timer and start
          // alerting timer
          //StopAlertingTimer();
          ///LOG( LogInfo(), "Connection: Alerting / SDP = " << ( msg.HasSDP() ? "TRUE" : "FALSE" ) );
          b2bUA.OnAlerting( *this, call, msg );
          OnIncomingSDPAnswer( call, msg );
        }
      }else if( msg.Is2xx() )
      {
        m_SessionState = Connected;
        // ok we receive 2xx value
        // stop alerting timer
        //StopAlertingTimer();

        // we should also stop connection timer
        // due to it is possible that it
        // will directly send 200 without
        // sending 183 - alerting
        //StopSeizeTimer(); 
        b2bUA.OnConnected( *this, call, msg );
        OnIncomingSDPAnswer( call, msg );

        // check if we would post a warning message
        if( !m_200OkWarning.GetHeaderBody().IsEmpty() )
        {
          // for now we would overrider warning messages
          // with our warning message
          msg.SetWarning( m_200OkWarning );
        }


        // no need to send session keep-alive for trunks
        // the b2bua should handle the keep-alive
        //if( m_SendSessionKeepAlive )
        //{
        //  GetLeg1Call()->StartSessionKeepAlive( 120000 );
        //  GetLeg2Call()->StartSessionKeepAlive( 120000 );
        //}

      }else if( !msg.IsRequest() ) // 3xx - 6xx
      {
        int statusCode = msg.GetStatusCode();
        // check if we should fail over
        if( !msg.Is3xx() && 
             statusCode != 401 &&
             statusCode != 407 && 
            !m_HasReceivedSDP )
        {
          if( m_Routes.GetSize() > 1 && (statusCode == SIPMessage::Code408_RequestTimeout || statusCode >= 500) )
          {
            // destroy first leg 2 connection
            if( m_Leg2Call )
            {
              DetachCall( m_Leg2Call->GetCallId(), TRUE );
              m_Leg2Call->Destroy();
              m_Leg2Call = NULL;
            }

            m_Routes.RemoveAt( 0 );

            LOG( LogInfo(), "Connection: Rejected / Code = " << msg.GetStatusCode() );

            // Change to FailOver method
            LOG( LogInfo(), "Connection: Failing over to other routes: Error " 
              << msg.GetStatusCode() );
            b2bUA.OnRejected( *this, call, msg );

            OnSetupOutbound( m_Leg1Call->GetRequest() );
            return;
          }
        } 

        // if message status is not 3xx then 
        // we should notify ua for rejection
        if( !msg.Is3xx() )
        {
          if(  statusCode != 401 && statusCode != 407 )
          {
            LOG( LogInfo(), "Connection: Rejected / Code = " << msg.GetStatusCode() );
            m_SessionState = Disconnected;
            b2bUA.OnRejected( *this, call, msg );
          }else
          {
            OnTrunkAuthentication( call, msg );
            return;
          }
        }else
        {
          /// just return as if nothing happend, call is now about to be redirected
          
          return;
        }
      }

      GetLeg1Call()->AnswerB2BCall( call, msg );
    }
  }else if( call.GetLegIndex() == 0 )
  {
    if( msg.IsCancel() )
    {
      SIPMessage ok;
      msg.CreateResponse( ok, SIPMessage::Code200_Ok );
      call.SendRequest( ok, msg.GetTransaction() );
      SIPMessage reqCancelled;
      call.GetRequest().CreateResponse( reqCancelled, SIPMessage::Code487_RequestCancelled );
      call.SendRequest( reqCancelled, call.GetRequest().GetTransaction() );
      
      B2BUACall * leg2Call = GetLeg2Call();
      if( leg2Call )
        leg2Call->SendCancel();

      m_SessionState = Disconnected;
      LOG( LogInfo(), "*** CALL ABANDONED *** " << GetSessionId() );
      b2bUA.OnCallAbandoned( *this, call, msg );
    }     
  }else
  {
    PAssertAlways( PLogicError );
  }

  if( m_SessionState == Disconnected )
  {
    // if we receive disconnect then
    // stop all timer
    //StopSeizeTimer();
    //StopAlertingTimer();
    DestroyConnection( msg );    
  } 
}

void SBCSIPTrunkConnection::OnHandleStateTransferring( 
  B2BUACall & call,
  const SIPMessage & msg
)
{
  B2BUAConnection::OnHandleStateTransferring( call, msg );
}

void SBCSIPTrunkConnection::OnHandleStateAuthenticationPending( 
  B2BUACall & call,
  const SIPMessage & msg
)
{
  B2BUAConnection::OnHandleStateAuthenticationPending( call, msg );
}

void SBCSIPTrunkConnection::OnHandleStateConnected( 
  B2BUACall & call,
  const SIPMessage & msg
)
{
  B2BUAConnection::OnHandleStateConnected( call, msg );
}

void SBCSIPTrunkConnection::OnHandleStateDisconnected( 
  B2BUACall & call,
  const SIPMessage & msg
)
{
  B2BUAConnection::OnHandleStateDisconnected( call, msg );
}

void SBCSIPTrunkConnection::OnHandleStateTerminated( 
  B2BUACall & call,
  const SIPMessage & msg
)
{
  B2BUAConnection::OnHandleStateTerminated( call, msg );
}


