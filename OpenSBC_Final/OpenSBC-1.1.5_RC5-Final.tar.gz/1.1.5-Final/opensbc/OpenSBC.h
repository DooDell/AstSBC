/*
 *
 * OpenSBC.h
 * 
 * Open SIP Stack ( OSS )
 *
 * Copyright (c) opensipstack.org.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either expressed or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is OpenSIPStack.
 *
 * The Initial Developer of the Original Code is opensipstack.org.
 *
 * The author of this code is Joegen E. Baclor
 *
 * Contributor(s): ______________________________________.
 *
 * $Log: OpenSBC.h,v $
 * Revision 1.71  2009/05/27 12:40:34  joegenbaclor
 * Initial upload of switch related classes
 *
 * Revision 1.70  2009/05/05 11:37:58  joegenbaclor
 * updated deprecated functions used by xbase
 * updated MSVC 2005 Project files to include XBase classes
 *
 * Revision 1.69  2009/03/26 06:32:26  joegenbaclor
 * Added NAT port forwarding support
 *
 * Revision 1.68  2009/02/23 14:26:18  joegenbaclor
 * Added solegy fraud detection class
 *
 * Revision 1.67  2009/02/10 08:16:09  joegenbaclor
 * Fixed HTTP Config crash
 *
 * Revision 1.66  2009/02/06 09:50:38  joegenbaclor
 * Added email alert notification support
 *
 * Revision 1.65  2009/01/25 07:24:23  joegenbaclor
 * Implemented new deadlock detection using 100 trying consecutive occurence
 *
 * Revision 1.64  2009/01/23 11:14:13  joegenbaclor
 * Aded OnInboundPacket callback
 *
 * Revision 1.63  2009/01/21 10:01:56  joegenbaclor
 * Marking bug fix for solegy START race condition
 *
 * Revision 1.62  2008/12/22 06:51:46  joegenbaclor
 * Application Timers for Alerting and Connect is causing a deadlock on connection destruction.
 * To address this issue, we modified opensipstack to take care of the timers in the ICT Layer.
 *
 * Revision 1.61  2008/11/12 08:54:15  joegenbaclor
 * Bug:  Delay registrar evaluation for a solegy controlled domain
 *
 * Revision 1.60  2008/11/11 02:54:47  joegenbaclor
 * Feature:  Introducing RTTS aggregation of groomer and osbc
 * Bug:  Disconnect calls if ParseRouting has an empty result set
 *
 * Revision 1.59  2008/09/25 05:45:19  joegenbaclor
 * Put solegy stuffs in separate namespace
 *
 * Revision 1.58  2008/09/12 09:49:44  joegenbaclor
 * - Upper registration bug fixes.
 * - Bring back support for upper reg routing
 * - Bring back support for upper-reg domain rewrite
 *
 * Revision 1.57  2008/09/01 14:44:29  joegenbaclor
 * Commiting interim code for new registrar with SLA support
 *
 * Revision 1.56  2008/08/27 03:02:14  joegenbaclor
 * Adding new registrar code
 *
 * Revision 1.55  2008/08/19 16:16:03  joegenbaclor
 * We can now call tail.exe from the applicaton menu in debug mode (Windows only)
 *
 * Revision 1.54  2008/08/19 14:16:03  joegenbaclor
 * Finalizing new log/config directory structure
 *
 * Revision 1.53  2008/07/26 16:29:23  joegenbaclor
 * implemented http client for call-accounting module
 *
 * Revision 1.52  2008/07/01 12:27:00  joegenbaclor
 * Added Solegy debit module
 *
 * Revision 1.51  2008/07/01 05:09:14  joegenbaclor
 * Implemented HTML Dump-Memory page
 *
 * Revision 1.50  2008/06/30 01:59:10  joegenbaclor
 * Implemented garbage collector status page
 *
 * Revision 1.49  2008/05/27 14:15:03  joegenbaclor
 * Implemented maximum concurrent connection counter
 *
 * Revision 1.48  2008/05/26 12:05:51  joegenbaclor
 * Added VLD and support for console only build
 *
 * Revision 1.47  2008/05/25 02:38:36  joegenbaclor
 * Added shutdown handler for SIGUSR1 and SIGUSR2
 *
 * Revision 1.46  2008/05/11 23:40:56  joegenbaclor
 * Use separate config header for win32 builds
 *
 * Revision 1.45  2008/04/16 00:44:21  joegenbaclor
 * Using OnPostCreateB2BUA callback to set keep-alive and max-session-lifetime
 *
 * Revision 1.44  2008/03/14 05:53:31  joegenbaclor
 * Fixed visual studio 2005 compile errors
 *
 * Revision 1.43  2008/03/11 15:00:40  joegenbaclor
 * PHP Build fixes
 *
 * Revision 1.42  2008/03/11 02:10:03  joegenbaclor
 * Revised PHP Sapi implementation and removed python from configure script check
 *
 * Revision 1.41  2008/03/07 15:11:22  joegenbaclor
 * Added PHP SAPI Support in HTTP Server
 *
 * Revision 1.40  2008/03/04 17:50:48  joegenbaclor
 * Added PySNMP support
 *
 * Revision 1.39  2008/02/13 07:31:15  rcolobong
 * 1. Update revision number and release date
 * 2. Readd enable disable of backdoor, trunk and calea port in the configuration.
 *
 * Revision 1.38  2007/10/15 10:37:49  joegenbaclor
 * Minor bug fixes
 *
 * Revision 1.37  2007/10/01 16:17:27  joegenbaclor
 * Added transport status page in http admin
 *
 * Revision 1.36  2007/09/26 14:27:20  joegenbaclor
 * SBCRoutingHandler now redirects Trunk calls to the trunk listener address
 *
 * Revision 1.35  2007/09/23 14:50:45  joegenbaclor
 * Added new config params to flag resolution of To and R-RUIs in B2BUA and Ralay routes
 *
 * Revision 1.34  2007/09/20 10:32:59  joegenbaclor
 * Comleted SIP Trunk registration status page
 *
 * Revision 1.33  2007/09/04 21:58:13  joegenbaclor
 * More work on SIP Trunks.
 *
 * Revision 1.32  2007/08/25 09:08:42  joegenbaclor
 * More work on CALEA trunk
 *
 * Revision 1.31  2007/08/24 01:14:42  joegenbaclor
 * scrapped previous code for upstream proxy handling
 *
 * Revision 1.30  2007/08/20 06:24:45  joegenbaclor
 * commiting alpha code for new backdoor using trunks
 *
 * Revision 1.29  2007/08/16 13:25:50  joegenbaclor
 * More work on trunking
 *
 * Revision 1.28  2007/08/12 01:57:49  joegenbaclor
 * More work on trunking
 *
 * Revision 1.27  2007/08/08 07:36:08  joegenbaclor
 * Added SBCTrunk classes
 * Removed singleton factory for OSSAppConfig
 *
 * Revision 1.26  2007/07/15 12:27:26  joegenbaclor
 * Added capability to route to registered endpoints using static routes
 * Removed unused config parameters
 *
 * Revision 1.25  2007/07/15 07:51:20  joegenbaclor
 * implemented resource counter page
 *
 * Revision 1.24  2007/07/14 07:53:56  joegenbaclor
 * Migrated code to use new STL based string class
 *
 * Revision 1.23  2007/07/06 14:18:25  rcolobong
 * Add Upstream Proxy Route feature
 *
 * Revision 1.22  2007/06/13 09:22:01  joegenbaclor
 * Added IVR handler
 *
 * Revision 1.21  2007/05/18 01:23:55  joegenbaclor
 * 1.  Added separate useragent to handle B2BUpperReg backdoor
 * 2.  Modified routing for B2BUpperReg
 * 3.  Corrected bug in ParserTools::GetCompactHeader()
 *
 * Revision 1.20  2007/05/07 06:13:22  rcolobong
 * 1. Add support for disabling and enabling Local Refer
 * 2. Add support for defining static RTP media address
 * 3. Remove support for Force B2B Routes
 *
 * Revision 1.19  2007/03/07 23:20:26  joegenbaclor
 * Added media server UA
 *
 * Revision 1.18  2007/02/16 11:09:20  joegenbaclor
 * More work on privacy
 *
 * Revision 1.17  2007/02/15 09:36:29  joegenbaclor
 * Added Privacy Section
 *
 * Revision 1.16  2007/02/14 11:22:09  joegenbaclor
 * Added Trusted Domain section
 *
 * Revision 1.15  2007/01/17 10:33:43  joegenbaclor
 * Redesigned syslog
 *
 * Revision 1.14  2007/01/17 00:05:59  joegenbaclor
 * Added SysLog
 *
 * Revision 1.13  2007/01/12 10:50:05  joegenbaclor
 * minor proxy bug fixes
 * more launcher code
 *
 * Revision 1.12  2007/01/12 01:02:50  joegenbaclor
 * launcher related code
 *
 * Revision 1.11  2007/01/10 23:58:30  joegenbaclor
 * launcher specific code
 *
 * Revision 1.10  2007/01/08 11:15:18  joegenbaclor
 * Added registration status page
 *
 * Revision 1.9  2007/01/08 07:13:23  joegenbaclor
 * Added ability to run SBC in pure proxy or pure b2b modes
 *
 * Revision 1.8  2006/12/22 07:40:27  joegenbaclor
 * More on command line argument parsing.
 *
 * Revision 1.7  2006/11/22 11:37:09  rcolobong
 * 1. Added new support for Force B2BUA in HTTP configuration
 * 2. Added log level in Application level and SIP/RTP Level
 * 3. Update OnAcceptRegistration signature
 *
 * Revision 1.6  2006/10/11 04:59:50  rcolobong
 * Add http configuration "Accept all registration". If this true then it will accept all registration even if it is not included on the "Local domain accounts"
 *
 * Revision 1.5  2006/09/01 12:51:03  rcolobong
 * Use ActiveSessionCounter to update session count through OSSApplication
 *
 * Revision 1.4  2006/08/30 09:07:31  rcolobong
 * Update setting connection timer and alerting timer
 *
 * Revision 1.3  2006/08/29 07:43:58  rcolobong
 * 1. Rename file to a better filename
 * 2. Change SBCRTBESesionManager class to RTBESessionManager
 *
 * Revision 1.2  2006/08/16 10:34:32  rcolobong
 * 1. Syslog server is now configurable
 * 2. Alerting timer and Connection Timer is now configurable
 *
 * Revision 1.1  2006/08/14 10:04:59  rcolobong
 * Convert B2BUA to SBC
 * Support MP logging
 *
 * Revision 1.5  2006/07/11 13:59:34  joegenbaclor
 * Completed Proxy functionalities for B2BUA
 *
 * Revision 1.4  2006/07/10 06:29:37  joegenbaclor
 * Completed crude Registration support for B2BUA
 *
 * Revision 1.3  2006/07/03 15:29:47  joegenbaclor
 * Started merging OpenB2BUA into OpenSBC
 *
 * Revision 1.2  2006/06/20 09:58:11  joegenbaclor
 * *** empty log message ***
 *
 * Revision 1.1  2006/06/14 08:43:38  joegenbaclor
 * Initial upload of OpenB2BUA applcation and related classes
 *
 *
 */

#ifndef OPENSBC_H
#define OPENSBC_H

#include <ptlib.h>

#ifndef WIN32
#include <sbcbuildopts.h>
#else
#include <sbcbuildopts-win32.h>
#endif

#include "OSSApplication.h"
#include "SBCConfigParams.h"
#include "B2BUA.h"
#include "MediaServer.h"
#include "SBCPHPSapi.h"
#include "Solegy.h"
#include "HTTPSessionManager.h"
#include "Registrar.h"
#include "SBCConnectionScript.h"
#include "SBCXBaseManager.h"

using namespace B2BUA;

class OpenSBCDaemon;
class SBCRoutingHandler;
class SBCCallHandler;
class SBCAuthHandler;
class SBCIVRHandler;
class SBCTrunk;
class SBCTrunkProcess;
class SBCTrunkManager;
class SBCMediaHandler;
class SBCAuxiliaryUA;

#if HAS_PYTHON_SAPI
class SBCScriptHandler;
#endif

class OpenSBC : public B2BUserAgent
{
  PCLASSINFO( OpenSBC, B2BUserAgent );
public:

  OpenSBC( 
    OpenSBCDaemon * application,
    UAMode mode,
    BOOL noReg = TRUE,
    BOOL isMainProcess = FALSE
  );

  virtual ~OpenSBC();

  BOOL SendMailAlert( 
    const PString & _subject, 
    const PString & _body 
  );

  virtual void OnStart( 
    OSSAppConfig & config 
  );


  virtual void OnStop();

  virtual void OnConfigChanged( 
    OSSAppConfig & config,
    const char * section = NULL
  );

  void OnINITConfig( 
    OSSAppConfig & config
  );

  void OnGenParamsConfigChanged( 
    OSSAppConfig & config
  );

  virtual void OnSignalShutDown();

  virtual void OnTransactionCreated(
    const SIPMessage & request,
    SIPTransaction *& transaction
  );

  virtual B2BCallInterface * OnCreateCallInterface();

  virtual B2BAuthInterface * OnCreateAuthInterface();

  virtual B2BMediaInterface * OnCreateMediaInterface();

  virtual B2BRoutingInterface * OnCreateRoutingInterface();

  virtual B2BIVRInterface * OnCreateIVRInterface();

  virtual BOOL OnCreateExternalCallController( 
      B2BUAConnection & connection,
      SIPURI & route,
      const SIPMessage * invite = NULL
  );

  virtual RegisterSession::AcceptRegistrationResponse OnAcceptRegistration( 
    RegisterSession & session,
	  const SIPMessage & request
  );

  virtual BOOL OnPostCreateB2BUA(
    B2BUAEndPoint * endPoint,
    B2BUAConnection * connection,
    B2BUACall * inboundCall
  );

  virtual BOOL OnIncomingCall(
    B2BUAConnection & connection,
    B2BUACall & call,
    SIPMessage & invite
  );

  BOOL FindLocalDomainAccount(
    const SIPURI & uri,
    SIPURI & accountURI
  )const;

  BOOL AddLocalDomainAccounts(
    const PStringArray & accounts,
    BOOL dumpExisting
  );

  BOOL AddTrustedDomains(
    const PStringArray & accounts,
    BOOL dumpExisting
  );

  BOOL IsTrustedDomain( const SIPURI & uri )const;

  BOOL AddPrivacyTrustedDomains(
    const PStringArray & accounts,
    BOOL dumpExisting
  );

  BOOL IsPrivacyTrustedDomain( 
    const SIPURI & uri,
    SIPURI & domainEntry
  )const;

  virtual OSSAppConfig * GetAppConfig()const;

  virtual BOOL OnInboundPacket( 
    SIPTransportManager & transport, 
    SIPMessage & thePacket 
  );

  virtual BOOL OnOutboundPacket( 
    SIPTransportManager & me, 
    SIPMessage & thePacket 
  );
  
  PINLINE const PString & GetPrivacyDefaultRealm()const{ return m_PrivacyDefaultRealm; };
  PINLINE void SetPrivacyDefaultRealm( const PString & realm ){ m_PrivacyDefaultRealm = realm; };
  PINLINE BOOL WillAcceptAllRegistration()const{ return m_AcceptAllRegistration; };
  PINLINE BOOL WillAcceptAllCalls()const{ return m_AcceptAllCalls; };
  PINLINE OpenSBCDaemon * GetApplication(){ return m_Application; };
  PINLINE SBCAuthHandler * GetSBCAuthHandler(){ return m_SBCAuthHandler; };
  PINLINE SBCCallHandler * GetSBCCallHandler(){ return m_SBCCallHandler; };
  PINLINE SBCRoutingHandler * GetSBCRoutingHandler(){ return m_SBCRoutingHandler; };
  PINLINE SBCMediaHandler * GetSBCMediaHandler(){ return m_SBCMediaHandler; };
  PINLINE const OString & GetCALEATrunkURI()const{ return m_CALEATrunkURI; };
  PINLINE void SetCALEATrunkURI( const OString & uri ){ m_CALEATrunkURI = uri; }; 
  PINLINE const OString & GetSIPTrunkURI()const{ return m_SIPTrunkURI; };
  PINLINE void SetSIPTrunkURI( const OString & uri ){ m_SIPTrunkURI = uri; }; 
  PINLINE REGISTRAR::Registrar * GetLocalRegistrar()const{ return m_LocalRegistrar; };
  PINLINE SOLEGY::SolegySessionManager * GetSolegyManager(){ return m_SolegySessionManager; };
  PINLINE BOOL IsMainTrunk()const{ return m_IsMainTrunk; };
  PINLINE SBCAuxiliaryUA * GetAuxiliaryEndPoint()const{ return m_AuxiliaryEndPoint; };
#ifdef HAS_XBASE
  PINLINE SBCXBaseManager * GetXBaseManager()const{ return m_XBaseManager; };
#endif
protected:
  OpenSBCDaemon * m_Application;
  
  BOOL m_IsMainTrunk;
  int m_MaxConcurrentSession;
  BOOL m_AcceptAllRegistration;
  BOOL m_AcceptAllCalls;
  SOLEGY::SolegySessionManager * m_SolegySessionManager;
  HTTPSessionManager m_HTTPSessionManager;
  SBCAuthHandler * m_SBCAuthHandler;
  SBCCallHandler * m_SBCCallHandler;
  SBCRoutingHandler * m_SBCRoutingHandler;
  SBCMediaHandler * m_SBCMediaHandler;
  SBCIVRHandler * m_SBCIVRHandler;
  REGISTRAR::Registrar * m_LocalRegistrar;
  SBCAuxiliaryUA * m_AuxiliaryEndPoint;


#if HAS_PYTHON_SAPI
  SBCScriptHandler * m_SBCScriptHandler;
#endif

  PMutex m_LocalDomainAccountsMutex;
  PDICTIONARY( AccountList, PCaselessString, SIPURI );
  AccountList m_LocalDomainAccounts;

  PMutex m_TrustedDomainsMutex;
  PSortedStringList m_TrustedDomains;

  PMutex m_PrivacyTrustedDomainsMutex;
  PSortedStringList m_PrivacyTrustedDomains;
  PString m_PrivacyDefaultRealm;
  OString m_CALEATrunkURI;
  OString m_SIPTrunkURI;
  BOOL m_IsInitialConfigChanged;

#ifdef HAS_XBASE
  SBCXBaseManager * m_XBaseManager;
#endif
  
};

//////////////////////////////////////////////////////////////////

#include "OpenSBCDaemon.h"








#endif




