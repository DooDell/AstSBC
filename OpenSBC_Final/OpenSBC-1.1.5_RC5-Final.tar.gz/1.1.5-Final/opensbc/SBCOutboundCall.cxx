/*
 *
 * SBCOutboundCall.cxx
 *
 * Open SIP Stack ( OSS )
 *
 * Copyright (c) opensipstack.org.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either expressed or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is OpenSIPStack.
 *
 * The Initial Developer of the Original Code is opensipstack.org.
 *
 * The author of this code is Joegen E. Baclor
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * The OpenSIPStack Library includes some GPL/LGPL code libraries that MAY be 
 * enabled at compile time using the --enable-gpllibs configure switch.  If
 * enabled, the content of this file is published under the terms of GNU 
 * General Public License Version 2.  For a detailed list of the available
 * GPL code, see $(opensipstack)/gnu/README file.
 *
 * $Log: SBCOutboundCall.cxx,v $
 * Revision 1.41  2009/06/01 09:30:02  joegenbaclor
 * bug in last commit for siptrunks
 *
 * Revision 1.40  2009/06/01 03:16:55  joegenbaclor
 * Added outbound call class for sip trunks
 *
 * Revision 1.39  2009/05/28 14:02:49  joegenbaclor
 * damn typo again!
 *
 * Revision 1.38  2009/05/28 13:08:00  joegenbaclor
 * typo
 *
 * Revision 1.37  2009/05/28 13:04:51  joegenbaclor
 * Added from-host param in outbound rewrite
 *
 * Revision 1.36  2009/05/27 12:40:34  joegenbaclor
 * Initial upload of switch related classes
 *
 * Revision 1.35  2009/05/20 12:49:41  joegenbaclor
 * dalayed rewriting of request uri after all the proprietary params have been processed
 *
 * Revision 1.34  2009/05/20 09:11:05  joegenbaclor
 * Adding SBCB2BUACall base class
 *
 * Revision 1.33  2009/05/20 08:58:59  joegenbaclor
 * added from user rewrite
 *
 * Revision 1.32  2009/05/20 08:42:33  joegenbaclor
 * *** empty log message ***
 *
 * Revision 1.31  2009/05/07 12:46:08  joegenbaclor
 * Insert Display Name in outbound INVITE if not present
 *
 * Revision 1.30  2009/04/30 08:20:06  joegenbaclor
 * Disbaled TransactionBypass for outbound call
 *
 * Revision 1.29  2009/04/28 01:40:58  joegenbaclor
 * Added SIPSession as a paramater to FindTransactionAndAddEvent() so that SIPTransaction can instantiate a reference to the owning session
 *
 * Revision 1.28  2009/04/27 02:06:32  joegenbaclor
 * Set initial target address in onsetupoutbound
 *
 * Revision 1.27  2009/04/25 05:22:20  joegenbaclor
 * Change FindOutboundProxy parameter to accept uri instead of the entire sip message
 *
 * Revision 1.26  2009/03/26 07:49:42  joegenbaclor
 * fixed ip helper bug
 *
 * Revision 1.25  2009/03/26 06:32:26  joegenbaclor
 * Added NAT port forwarding support
 *
 * Revision 1.24  2009/03/17 03:57:50  joegenbaclor
 * Call ICT Callbacks instead of sending the event straight to the connection object
 *
 * Revision 1.23  2009/03/17 03:03:06  joegenbaclor
 * Send PRACK when required in transaction by ICT callback
 *
 * Revision 1.22  2009/03/17 02:24:42  joegenbaclor
 * introduced bypassing of ICT responses for fater response time
 *
 * Revision 1.21  2009/03/16 06:15:04  joegenbaclor
 * In this revision, we temporarily removed the pike mechanism to test the scalability of the
 *  FSM changes in OpenSIPStack.  We have also added a bypass handler for BYE for faster reaction
 *  time.  SIPP test at 100 CPS suceeded with zero retranmission on a windows box running
 *  running on Intel Dual Core 3 Ghz CPU with 2 GB Ram.
 *
 * Revision 1.20  2009/02/18 12:55:11  joegenbaclor
 * Late media support
 *
 * Revision 1.19  2009/02/16 03:44:07  joegenbaclor
 * Allowed setting of from host.  Deprecated Full mode
 *
 * Revision 1.18  2009/02/10 08:16:09  joegenbaclor
 * Fixed HTTP Config crash
 *
 * Revision 1.17  2009/01/24 15:21:13  joegenbaclor
 * Solegy logging improvements
 *
 * Revision 1.16  2009/01/23 12:27:20  joegenbaclor
 * Always rewrite the to URI for solegy calls
 *
 * Revision 1.14  2009/01/13 14:32:45  joegenbaclor
 * Fixing Solegy session mem leaks
 *
 * Revision 1.13  2009/01/03 12:14:24  joegenbaclor
 * Reimplemented DestroyConenction to enqueue a session event instead to avoid further race conditons and dead locks.
 * We also implemented B2BUAConnection::IsSafeReference() to further guaranty the integrity of connection pointers.
 *
 * Revision 1.12  2008/12/16 12:53:12  joegenbaclor
 * Undo last commit.  Introduced double locking in DestroyConneciton() instead
 *
 * Revision 1.11  2008/12/16 12:37:12  joegenbaclor
 * Modified SBCConnection::EnforceDisconnectedState() to not call DestroyConnection()
 * directl for this may result to a deadlock of two threads are trying to destroy
 * the connection at the same time
 *
 * Revision 1.10  2008/12/12 08:57:20  joegenbaclor
 * Bug fixes in encryption and solegy soho calls
 *
 * Revision 1.9  2008/12/01 03:52:14  joegenbaclor
 * Upper reg bug fixes
 *
 * Revision 1.8  2008/11/27 03:25:34  joegenbaclor
 * Made sure we do not use the IP address of the NAT bining in request URIwhen sending
 *  INVITE to NATted UA
 *
 * Revision 1.7  2008/11/25 16:56:17  joegenbaclor
 * Removed more remnants of rewrite request uri
 *
 * Revision 1.6  2008/11/20 11:02:35  joegenbaclor
 * Depcrecated old SIPMessage URI accessors
 *
 * Revision 1.5  2008/11/12 13:41:33  joegenbaclor
 * Bug:  We do not rewrite request-uri when using ob proxy routing
 *
 * Revision 1.4  2008/11/12 12:41:33  joegenbaclor
 * Bug: Use loose route for OB Proxy
 *
 * Revision 1.3  2008/11/03 02:35:09  joegenbaclor
 * Introducing new a la B2BUA-Routes Outbound-Proxy routing and deprecated old global
 *  Outbound-Proxy parameter
 *
 * Revision 1.2  2008/10/29 06:24:20  joegenbaclor
 * Addded SBCWArningBeepStreamer class
 * Bug fixes in rtts session destruction
 *
 * Revision 1.1  2008/10/27 09:44:04  joegenbaclor
 * Subclassing B2BUA objects to give OpenSBC a more fine grained control
 *
 *
 */

#include "SBCB2BUAEndPoint.h"
#include "SBCConnection.h"
#include "SBCOutboundCall.h"
#include "SDPLazyParser.h"
#include "OpenSBC.h"

using namespace B2BUA;

#define new PNEW

SBCOutboundCall::SBCOutboundCall(
  B2BUAEndPoint & manager,
  const OString & sessionId,
  const ProfileUA & profile
) : SBCB2BUACall( manager, sessionId, profile )
{
  m_WarnTimeLeftState = WarnIdle;
}

SBCOutboundCall::~SBCOutboundCall()
{
}

void SBCOutboundCall::StartWarnTimeLeftTimer( int interval )
{
  m_WarnTimeLeftTimer.Stop();
  m_WarnTimeLeftTimer = PTimer( interval );
  m_WarnTimeLeftTimer.SetNotifier( PCREATE_NOTIFIER( OnWarnTimeLeftExpire ) );
  m_WarnTimeLeftTimer.Resume();  
}

void SBCOutboundCall::OnWarnTimeLeftExpire( PTimer &, INT )
{
  GCVERIFYREF_VOID( "SBCOutboundCall::OnWarnTimeLeftExpire" );
  PWaitAndSignal lock( m_EventMutex );

  SIPMessage invite;
  CloneRequestWithinDialog( GetCurrentUACInvite(), invite );

  SDPLazyParser sdp = GetCurrentUACInvite().GetBody();
  if( sdp.IsEmpty() )
    return;

  SIPURI mediaAddress;
  sdp.IncrementVersion();
  sdp.GetMediaAddress( SDPLazyParser::Audio, mediaAddress, 0 );
  sdp.SetMediaAddress( SDPLazyParser::Audio, 0, "0.0.0.0", 0 );
  sdp.SetGlobalAddress( "0.0.0.0" );
  sdp.SetMediaDirection( SDPLazyParser::SendOnly, SDPLazyParser::Audio, 0 );
  invite.SetBody( sdp );

  m_WarnTimeLeftState = WarnHoldUAS;
  SendRequest( invite );
}


void SBCOutboundCall::OnSessionEvent(
  SIPSessionEvent & sessionEvent
)
{
  int event = sessionEvent.GetEvent();
  const SIPMessage & eventMsg = sessionEvent.GetMessage();

  /// make sure we never get deleted while we are doing something
  GCVERIFYREF_VOID( "SBCOutboundCall::OnSessionEvent" );
  /// Handle one event at a time
  PWaitAndSignal lock( m_EventMutex );

  if( m_WarnTimeLeftState == WarnIdle || event > ICT_Recv6xx )
  {
    B2BUACall::OnSessionEvent( sessionEvent );
    return;
  }
  
  switch( m_WarnTimeLeftState )
  {
    case WarnHoldUAS:
      HandleWarnHoldUAS( event, eventMsg );
      break;
    case WarnTransferUAC:
      HandleWarnTransferUAC( event, eventMsg );
      break;
    case WarnReconnectUAC:
      HandleWarnReconnectUAC( event, eventMsg );
      break;
    default:
      B2BUACall::OnSessionEvent( sessionEvent );
  }  
}

void SBCOutboundCall::HandleWarnHoldUAS(
  int event,
  const SIPMessage & eventMsg
)
{
  GCVERIFYREF_VOID( "SBCOutboundCall::HandleWarnHoldUAS" );

  if( event == ICT_Recv1xx )
    return;
  else if( event > ICT_Recv2xx )
  {
    LOG( LogWarning(), "Unable to put UAS on hold for WarnTimeLeft()" );
    m_WarnTimeLeftState = WarnIdle;
  }

  if( event == ICT_Recv2xx )
  {
    SendAck( eventMsg );
    m_WarnTimeLeftState = WarnTransferUAC;

    if( m_Connection != NULL && m_Connection->IsSafeReference() )
      dynamic_cast<SBCConnection*>(m_Connection)->WarnTransferUAC();
  }
}

void SBCOutboundCall::HandleWarnTransferUAC(
  int event,
  const SIPMessage & eventMsg
)
{
  if( event == ICT_Recv2xx )
  {
    SendAck( eventMsg );
  }
}

void SBCOutboundCall::HandleWarnReconnectUAC(
  int /*event*/,
  const SIPMessage & /*eventMsg*/
)
{
}

void SBCOutboundCall::OnSetupOutbound(
  const SIPMessage & inboundInvite,
  B2BUAConnection & connection
)
{
  GCVERIFYREF_VOID( "B2BUACall::OnSetupOutbound" );

  B2BRoutingInterface::B2BRouteList routes;
  routes = connection.GetRoutes();
  SBCB2BUAEndPoint & b2buaEp = dynamic_cast<SBCB2BUAEndPoint &>(GetSessionManager());
  //B2BUserAgent & b2bua = dynamic_cast<B2BUserAgent&>(b2buaEp.GetUserAgent());

  if( connection.GetCallController() == NULL && routes.GetSize() == 0 )
  {
    connection.EnqueueSessionEvent( new SIPSessionEvent( connection, B2BUAConnection::ErrorNoRoute ) );
    return;
  }else if( routes.GetSize() == 0 )
  {
    LOG( LogError(), "SETUP OUTBOUND without ROUTE!!!" );
    return;
  }

  PIPSocket::Address targetAddress;
  WORD targetPort = 0;
  SIPURI uri( routes[0] );

  
  
  if( !SIPTransport::Resolve( uri, targetAddress, targetPort ) )
  {
    LOG_IF_DEBUG( LogWarning(), uri << " does not resolve to an IP Address" );
    connection.EnqueueSessionEvent( new SIPSessionEvent( connection, B2BUAConnection::ErrorRouteResolution ) );
    return;
  }

  LOG( LogDetail(), "Resolving " << uri << " -> " << targetAddress );

  //m_SessionProfile.SetRemoteURI( uri.AsString() );
  SIPMessage invite = inboundInvite;

  /// get rid of the authorization headers for locally authenticated invites
  if( connection.GetSessionState() == B2BUAConnection::LocalAuthenticationPending )
  {
    invite.RemoveProxyAuthenticate();
  }

  /// IncomingConnection Allowed this call to process
  /// check for presence of SDP

  if( SIPTransport::IsPrivateNetwork( targetAddress ) )
  {
    connection.SetMediaProxyIfPrivate( FALSE );
  }
  
  BOOL hasSDP = invite.HasSDP();
  OString sdpOffer;

  if( hasSDP )
  {
    OString sdp;
    invite.GetBody( sdp );
    sdpOffer = OString( sdp );

    if( connection.IsSafeReference() )
    {
      if( !connection.GetLeg1Call()->OnIncomingSDPOffer( invite ) )
      {
        LOG_IF_DEBUG( LogError(), "OnIncomingSDPOffer FAILED.  Rejecting incoming INVITE." );
        connection.EnqueueSessionEvent( new SIPSessionEvent( connection, B2BUAConnection::ErrorUnsupportedCodec ) );
        return;
      }
    }
  }
  
  invite.RemoveAllRoutes();
  invite.ClearInternalHeaders();
  invite.SetEncryption( FALSE );

  /// set the from Domain
  if( !connection.GetFromDomain().IsEmpty() )
  {
    From from = invite.GetFrom();
    SIPURI fromDomain( connection.GetFromDomain() );
    if( !fromDomain.GetHost().IsEmpty() )
    {
      SIPURI fromURI = from.GetURI();
      fromURI.SetHost( fromDomain.GetHost() );
      fromURI.SetPort( fromDomain.GetPort() );
      from.SetURI( fromURI );
      invite.SetFrom( from );
    }
  }
 
  
  //check the from if it has a tag
  OString fromTag = invite.GetFromTag();
  if( fromTag.IsEmpty() )
  {
    LOG( LogWarning(), "Creating adhoc From tag for a UA that did not generate it" );
    fromTag = ParserTools::GenTagParameter();
    invite.SetFromTag( fromTag );
  }

  OString transport;
  if( !uri.GetParameter( "transport", transport ) )
    transport = "udp";

  
  Via via;
  GetSessionManager().ConstructVia( targetAddress, via, SIPTransport::UDP, connection.GetInterfacePort() );
  via.SetBranch( ParserTools::GenBranchParameter() );
  via.AddParameter( "rport", "" );
  invite.RemoveAllVias();
  invite.AppendVia( via );

  /// Set the inteface address to be used for future requests
  /// based it from the via host
  m_InterfaceAddress = via.GetAddress();
  m_TranslatedInterfaceAddress = via.GetTranslatedAddress();
  m_InterfacePort = via.GetPort();

  
  /// Set the call Id
  CallId callId;
  callId.SetHeaderBody( GetSessionId() );
  invite.SetCallId( callId );

  /// Set the contact
  SIPURI contactURI;
  contactURI.SetHost( m_TranslatedInterfaceAddress );
  if( via.GetURI().GetPort() != "5060" ) 
    contactURI.SetPort( via.GetPort() );

  // Set the outbound invite's contact's user
  BOOL hasUser = FALSE;
  Contact c;
  if ( inboundInvite.GetContactAt( c, 0 ) )
  {
    // Try to get the user from the inbound contact...
    ContactURI cURI;
    if ( c.GetURI( cURI ) )
    {

      if ( !cURI.GetURI().GetUser().IsEmpty() )
      {
        contactURI.SetUser( cURI.GetURI().GetUser() );
        hasUser = TRUE;
      }
    }
  }

  if ( !hasUser )
  {
    // Wasn't able to get the user from the inbound contact. Use
    // the one in From instead.
    From fr = inboundInvite.GetFrom();
    {
      if ( !fr.GetURI().GetUser().IsEmpty() )
      {
        contactURI.SetUser( fr.GetURI().GetUser() );
        hasUser = TRUE;
      }
    }
  }

  ContactURI contact( contactURI, m_SessionProfile.GetDisplayName() );
  invite.RemoveAllContact();
  invite.AppendContact( contact );

  /// check if the route is to use an XOR Hash
  OString paramEnc = uri.RemoveParameter( "encrypted" );
  if( paramEnc.ToLower() == "true" )
  {
    invite.SetEncryption( TRUE );
    EnableEncryption();
  }


  /// check if from user is forced
  OString paramFromUser = uri.RemoveParameter( "from-user" );
  OString paramFromHost = uri.RemoveParameter( "from-host" );
  if( !paramFromUser.IsEmpty() || !paramFromHost.IsEmpty() )
  {
    From newFrom = invite.GetFrom();
    SIPURI newFromURI = newFrom.GetURI();
    if( !paramFromUser.IsEmpty()  )
      newFromURI.SetUser( paramFromUser );
    if( !paramFromHost.IsEmpty() )
      newFromURI.SetHost( paramFromHost );
    newFrom.SetURI( newFromURI );
    invite.SetFrom( newFrom );
  }

  /// set the display name if its empty
  if( invite.GetFromDisplayName().IsEmpty() )
  {
    OStringStream dName;
    dName << "\"" << invite.GetFromURI().GetUser() << "\"";
    invite.SetFromDisplayName( dName.str() );
  }

  /// check if we need to force privacy
  OString paramPrivacy = uri.RemoveParameter( "force-privacy" ).ToLower();
  if( paramPrivacy == "id" || paramPrivacy == "true"  )
  {
    LOG( LogInfo(), "Enforcing Privacy for outbound" );

    PAssertedIdentity identity;
    ContactURI puri( invite.GetFromURI() );
    identity.AddURI( puri );
    invite.AppendPAssertedIdentity( identity );
    
    From from( "From: sip:anonymous@anonymous.invalid" );
    if( !invite.GetFromTag().IsEmpty() )
      from.AddParameter( "tag", invite.GetFromTag() );
    invite.SetFrom( from );

    Privacy privacy( "Privacy: id" );
    invite.SetPrivacy( privacy );
  }else if( paramPrivacy == "none" )
  {
    LOG( LogInfo(), "Enforcing Privacy for outbound" );

    PAssertedIdentity identity;
    ContactURI puri( invite.GetFromURI() );
    identity.AddURI( puri );

    invite.AppendPAssertedIdentity( identity );
    
    Privacy privacy( "Privacy: none" );
    invite.SetPrivacy( privacy );
  }else if( paramPrivacy == "no-support" )
  {
    /// destination does not have support for privacy
    if( invite.HasPrivacy() )
    {
      From from = invite.GetFrom();

      if( from.GetURI().GetUser() *= "anonymous" )
      {
        if( invite.GetPPreferredIdentitySize() > 0 )
        {
          PPreferredIdentity identity = invite.GetPPreferredIdentityAt( 0 );
          ContactURI curi;
          if( identity.GetURI( curi, 0 ) )
          {
            from.SetURI( curi.GetURI() );
            invite.SetFrom( from );
          }
        }else if( invite.GetPAssertedIdentitySize() > 0 )
        {
          PAssertedIdentity identity = invite.GetPAssertedIdentityAt( 0 );
          ContactURI curi;
          if( identity.GetURI( curi, 0 ) )
          {
            from.SetURI( curi.GetURI() );
            invite.SetFrom( from );
          }
        }
      }
    }
  }

  invite.RemoveAllRecordRoutes();

  /// Check if we need to relay to the sip trunk
  OString useSIPTrunk = uri.RemoveParameter( "sip-trunk" );
  if( useSIPTrunk *= "true" )
  {
    OpenSBC & sbc = dynamic_cast<OpenSBC&>(b2buaEp.GetUserAgent());
    SIPURI newURI( sbc.GetSIPTrunkURI() );
    invite.SetSendAddress( newURI );
    invite.SetRequestURI( uri );
  }else
  {
    /// Check for outbound route-set
    RouteURI obProxy;
    if( !connection.GetOutboundRouteSet().IsEmpty() )
    {
      invite.SetRequestURI( uri );
      OStringArray routeSetTokens;
      connection.GetOutboundRouteSet().Tokenise( routeSetTokens, "," );
      int routeSetCount = routeSetTokens.GetSize();

      for( int i = routeSetCount - 1; i >= 0; i-- )
      {
        RouteURI ruri( routeSetTokens[i].Trim() );
        invite.AppendRoute( ruri );
      }
      connection.SetOutboundRouteSet(""); /// strike it out so failover attempts will not re-use it
    }else if( b2buaEp.FindOutboundProxy( uri, obProxy ) )
    {
      invite.SetRequestURI( uri );
      obProxy.SetLooseRouter(TRUE);
      invite.AppendRoute( obProxy );
    }else
    {
      if(  connection.GetCallController() == NULL   )
      {
        /// create the request line
        OString sendAddr = uri.RemoveParameter( "send-addr" );
        if( !sendAddr.IsEmpty() )
        {
          sendAddr = "sip:" + sendAddr;
          SIPURI newTarget( sendAddr );
          invite.SetSendAddress( newTarget );
        }

        invite.SetRequestURI( uri );
      }
    }

    /// set the to uri;
    if( connection.GetCallController() == NULL && connection.WillRewriteToURI() )
    {
      To to = invite.GetTo();
      to.SetURI( uri );
      invite.SetTo( to );
    }
  }
  
  
  SIPTransport::Resolve( invite, m_InitialTargetAddress, m_InitialTargetPort );
  
  if( invite.HasSDP() )
    OnRequireSDPOffer( invite );


  SetRequest( invite );

  connection.OnOutgoingCall( *this, invite );
  m_CurrentUACInvite = invite;
  m_CurrentUASInvite.SetTransaction( NULL );
  SendRequest( invite );
}






