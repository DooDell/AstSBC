
#ifndef SBCCONFIGPARAMS_H
#define SBCCONFIGPARAMS_H

#define XML_CONFIG_ID "103"

/** SIP-TRANSPORTS **/
static const char configKeySIPTransportSection[] = "SIP-Transports";
static const char configKeyMainInterfaceAddress[] = "Main-Interface-Address";
static const char configKeyBackdoorInterfaceAddress[] = "Backdoor-Interface-Address";
static const char configKeyAuxiliaryInterfaceAddress[] = "Auxiliary-Interface-Address";
static const char configKeyTrunkInterfaceAddress[] = "Trunk-Interface-Address";
static const char configKeyMediaServerInterfaceAddress[] = "Media-Server-Interface-Address";
static const char configKeyCALEAInterfaceAddress[] = "CALEA-Interface-Address";
static const char configKeyInterfaceRouteList[] = "Interface-Route-List";

/** GENERAL-PARAMETERS **/
static const char configKeySection[] = "OpenSBC-General-Parameters";
static const char configKeyUserAgentName[] = "User-Agent-Name";
static const char configKeyEnableTrunkPort[] = "Enable-Trunk-Port";
static const char configKeyEnableCaleaPort[] = "Enable-Calea-Port";
static const char configKeyTransactionThreadCount[] = "Transaction-Thread-Count";
static const char configKeySessionThreadCount[] = "Session-Thread-Count";
static const char configKeyAppLogLevel[] = "SIP-Log-Level";
static const char configKeyCoreLogLevel[] = "PTRACE-Log-Level";
static const char configKeySysLogServer[] = "Syslog Server";
static const char configKeyRTPMinPort[] = "RTP-Min-Port";
static const char configKeyRTPMaxPort[] = "RTP-Max-Port";
static const char configKeyEnableLocalRefer[] = "Enable-Local-Refer";
static const char configKeyDisableReferOptimization[] = "Disable-Refer-Optimization";
static const char configKeyMaxForwards[] = "Max-Forwards";
static const char configKeySeizeTimeout[] = "Seize-Timeout";
static const char configKeyAlertingTimeout[] = "Alerting-Timeout";
static const char configKeyAppLogFilePrefix[] = "Log-File-Prefix";
static const char configKeySIPTimerH[] = "SIP-Timer-H";
static const char configKeySIPTimerB[] = "SIP-Timer-B";
static const char configKeySessionKeepAlive[] = "Session-Keep-Alive";
static const char configKeySessionMaxLifeSpan[] = "Session-Max-Life-Span";
static const char configKeyMaxConcurrentSession[] = "Max-Concurrent-Session";
static const char configKeyMaxCallRatePerSecond[] = "Max-Call-Rate-Per-Second";
static const char configKeySendResponsesUsingNewSocket[] = "Send-Responses-Using-New-Socket";
static const char configKeyNATKeepAliveInterval[] = "NAT-Keep-Alive-Interval";
static const char configKeySendOptionsNATKeepAlive[] = "Send-OPTIONS-NAT-Keep-Alive";

static const char configKeyRTPProxySection[] = "RTP-Proxy";
static const char configKeyProxyPrivateContact[] = "Proxy-On-Private-Contact";
static const char configKeyProxyViaReceived[] = "Proxy-On-via-received-vs-signaling-address";
static const char configKeyProxyViaSendAddress[] = "Proxy-On-Private-Via";
static const char configKeyProxyViaRPort[] = "Proxy-On-Different-RPORT";
static const char configKeyProxyAllMedia[] = "Proxy-All-Media";

static const char configKeyEncryption[] = "Encryption-Mode";
static const char configKeyEncryptionKey[] = "Encryption-Key";

static const char configKeySBCMode[] = "SBC-Application-Mode";

static const char configKeyAccountSection[] = "Local-Domain-Accounts";
static const char configKeyAcceptAllRegistration[] = "Accept-All-Registration";
static const char configKeyAccount[] = "Account-List";

static const char configKeyTrustedDomainSection[] = "Trusted-Domains";
static const char configKeyAcceptAllCalls[] = "Accept-All-Calls";
static const char configKeyTrustedDomainList[] = "Trusted-Domain-List";

static const char configKeyHostAccessListSection[] = "Host-Access-List";
static const char configKeyTrustAllHosts[] = "Trust-All-Hosts";
static const char configKeyTrustedHosts[] = "Trusted-Host-List";
static const char configKeyBanSelectedHosts[] = "Enable-Selective-Banning";
static const char configKeyBannedHosts[] = "Banned-Host-List";

static const char configKeyPrivacyTrustedDomainSection[] = "Privacy-RFC-3325";
static const char configKeyPrivacyDefaultRealm[] = "Default-Realm";
static const char configKeyPrivacyDomain[] = "Trusted-Domain-List";



//static const char configMediaServerSection[] = "Media Server";
static const char configKeyVXMLScript[] = "VXML Script";

static const char configKeyB2BUASection[] = "B2BUA-Routes";
static const char configKeyB2BUARewriteRequestURI[] = "Rewrite-Request-URI";
static const char configKeyB2BUAAppendInfoDigit[] = "Prepend-ISUP-OLI";
static const char configKeyB2BUAInsertRouteHeader[] = "Insert-Route-Header";
static const char configKeyB2BUAResolveToURI[] = "Route-By-To-URI";
static const char configKeyB2BUARewriteFromDomain[] = "Rewrite-From-Domain";
static const char configKeyB2BUAResolveRequestURI[] = "Route-By-Request-URI";
static const char configKeyB2BUARouteUserExternalXML[] = "Use-External-XML";
static const char configKeyB2BUARouteUserExternalXMLPath[] = "External-XML-File";

static const char configKeyDNSMapSection[] = "Internal-DNS-Mapping";
static const char configKeyB2BUARouteList[] = "Route-List";
static const char configKeyB2BUACatchAllRoute[] = "Catch-All-Route";
static const char configKeyInternalDNSMap[] = "Internal-DNS-Map";
static const char configKeyB2BUARewriteToURI[] = "Rewrite-TO-URI";
static const char configKeyUpperRegRewriteFromDomain[] = "Rewrite-FROM-Domain";
static const char configKeyUpperRegRewriteToDomain[] = "Rewrite-TO-Domain";
static const char configKeyB2BICMPValidation[] = "Drop-Routes-On-Ping-Timeout";
static const char configKeyRelayICMPValidation[] = "Drop-Routes-On-Ping-Timeout";

static const char configKeyUpperRegistrarSection[] = "Upper-Registration";
static const char configKeyEnableStatefulReg[] = "Enable-Stateful-Reg";
static const char configKeyAllRegAsUpperReg[] = "All-Reg-As-Upper-Reg";


static const char configMediaServerSection[] = "Media-Server";
static const char configKeyEnableMediaServer[] = "Enable-Media-Server";
static const char configKeyAutoAttendantNumber[] = "Media-Server-Number";
static const char configKeyAutoAttendantCodecs[] = "Codec-List";
static const char configKeyEnableAnnouncementService[] = "Enable-Announcement-Service";
static const char configKeyAnnouncementErrorMap[] = "Announcement-Error-Map";
static const char configKeyAnnouncement4xxErrorMap[] = "4xx-Error-Map";
static const char configKeyAnnouncement5xxErrorMap[] = "5xx-Error-Map";
static const char configKeyAnnouncement6xxErrorMap[] = "6xx-Error-Map";


static const char configKeyRelayRouteSection[] = "Proxy-Relay-Routes";
static const char configKeyProxyResolveToURI[] = "Proxy-Resolve-To-URI";

static const char configKeyCALEASection[] = "CALEA-Calls";
static const char configKeyUseExternalCALEATrunk[] = "Use-External-CALEA-Trunk";
static const char configKeyExternalCALEATrunkURI[] = "External-CALEA-Trunk-URI";
static const char configKeyCALEAFilter[] = "CALEA-Filter";

static const char configKeySIPTrunkSection[] = "SIP-Trunk-Config";
static const char configKeySIPTrunkConfig[] = "SIP-Trunk-Config";

static const char configKeyB2BUATestMessageSection[] = "B2BUA-Test-Message";
static const char configKeyB2BUATestMessage[] = "B2BUA-Test-Message";

static const char configKeyOutboundProxiesSection[] = "Outbound-Proxies";
static const char configKeyOutboundProxies[] = "Outbound-Proxies";
#endif

