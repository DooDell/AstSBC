/*
 *
 * Open Session Border Controller (OpenSBC)
 *
 * CHANGE HISTORY
 *
 * Version: MPL 1.1/GPL 2.0/LGPL 2.1
 *
 * Jun 15, 2009 : Joegen :  Marking Event rewind on deadlock opensipstack changes
 *
 * Jun 02, 2009 : Joegen :  Added new Switch classes for future switch like features
 *                          in opensbc.  Watch out for the new features to come!
 *
 * May 14, 2009 : Joegen :  In this revision, we added Disable-Refer-Optimization in general params
 *                          to allow REFER hijacking to be configurable.
 *
 * May 01, 2009 : Joegen :  We modified SendB2BConnect() and SendB2BProgress() to rewrite the contact address when the dialog 
 *                           is already in final state.  This is in reaction to a bug report in OSS Forum that OpenSBC sends
 *                           the contact address of the remote peer when sending reponses to re-INVITEs.  
 *
 * Mar. 31, 2009 : joegen  : SOLEGY: Introduced thread-pool based solegy transport
 *
 * Mar. 22, 2009 : joegen  : Added NAT port forwarding support via static interface table "external" parameter
 *
 * Mar. 22, 2009 : joegen  : In this revision, we introduced the capability of having the http admin preconfigure 
 *                           a static interface table for routing packets.
 *
 * Mar. 16, 2009 : joegen  : In this revision, we temoparily removed the pike mechanism to test the scalability of the 
 *                           FSM changes in OpenSIPStack.  We have also added a bypass handler for BYE for faster reaction
 *                           time.  SIPP test at 100 CPS suceeded with zero retranmission on a windows box running
 *                           on Intel Dual Core 3 Ghz CPU with 2 GB Ram. 
 *
 * Mar. 13, 2009 : joegen :  In this revision, we moved listener configuration to its own
 *                           page allowing all listeners to be configured seperately.
 *                           Previous behavior only allowed the main listener to be configured.
 *                           We have also added a out of dialog handler in the backdoor trunk
 *                           to allow unsolcited messages like OPTIONS and NOTIFY to passthrough.
 *                           Both of these functionalities are still under testing.
 *
 * Mar. 06, 2009 : joegen :  There are a lot of reports from the community that there are cases where NAT binding
 *                           is lost even if OpenSBC is sending CDLF/CRLF every 15 seconds.  Because of this
 *                           I decided to simply made it configurable to be able to use OPTIONS to force a two way
 *                           comminication between OSBC and the UA behinds NAT.
 *
 * Feb. 27, 2009 : joegen :  We accidentally introduced a bug in the transport where none NATted sip requests are responded to using the rport
 *                           causing the responses to get lost if the sender is using a different port other then the via to send the request.  
 *
 * Feb. 18, 2009 : joegen :  In this patch we added support for INVITE without SDP (Late Media) and SDP in ACK.  
 *                           Sort of offer/answer in reverse.
 *
 * Feb. 13, 2009 : Joegen :  Because of an issue discovered with asterisk which sends CANCEL to the port where it first received 
 *                           the provisional response, we are making the use of a new socket for sending responses configurable.
 *
 * Feb. 02, 2009 : Joegen :  In this revision, we put code inside the previously unimplemented HandleLeg2PreConnect_3xx method
 *                           in SBCConnection.  Recent change in OpenSIPStack allowed the 3xx handler to not call the default call session 
 *                           handler giving more flexibility to how the specific use case would want to do redirects
 *
 * Jan. 29, 2009 : Joegen :  Introduced yielding the transport when a certain queue size threshold is reached.
 *
 * Jan. 28, 2009 : Joegen :  We have also introduced pike limits for REGISTER, NOTIFY and OPTIONS in this build.
 *
 * Jan. 20, 2009 : Joegen :  In this revision, we have introduced a new deadlock mechanism based on whether OpenSBC is still responding to
 *                           INVITEs with none 100 Trying provisional or final response.  Since it is highly unlikely that 30 consecutive 
 *                           INVITEs will be left unanswered, we chose that value as the magic number.
 *
 * Jan. 20, 2009 : Joegen :  We reimplemented call rate checking.  Call rate is now checked be OpenSBC in the application layer.  Previous
 *                           implementation check call rate in the transport layer of the library.  We now effectively made call rate checking
 *                           implementation specific.
 *
 * Jan. 20, 2009 : Joegen :  SOLEGY:  We modified SolegySessionManager::EnqueueEvent to check if the current packet is read from the same
 *                           active socket for the session.  If it came from a different socket other thatn the current socket, it will
 *                           be silently dropped.  This will prevent the race condition brought about by START failover wherein a response
 *                           from the previous START attempt maybe interpreted as a response for the new failover ATTEMPT.  This would have been 
 *                           ok if Solegy RTTS allows START packet to have incrementing SEQ parameter since it can be dropped as stale.
 *
 * Jan. 12, 2009 : Joegen :  We modified two things in this commit.  The first is to handle CANCEL requests arriving before an in INVITE is sent out
 *                           to the upstream termination. Previous implementation did not handle this case properly which results to the call still
 *                           being attempted even after it was aborted by the caller.  The second bug fix is we introduced m_LocallyAuthenticated
 *                           in the B2BUAConnection layer so that the SBC can determine cases where both the SBC and the upstream termination both
 *                           challenged the INVITE resulting to a double authentication.  Although RFC 3261 allows this, we yet have to see UAs that
 *                           can handle authentication from two realms.  In most cases this call would end up in bad state so its better to just destroy 
 *                           the connection when this happens.
 *
 * Jan. 09, 2009 : Joegen :  SOLEGY: In this build we introduced state cookies for Solegy Calls.  The state cookie would allow OpenSBC to disconnect
 *                           calls (both BYE and CALLSTOP) after a restart or a crash happen by reconstructing dialog and RTTS state using the
 *                           cookie data.  The cookie is created on CALLSTART and will be deleted on CALLSTOP.  When a crash happens, calls may stay 
 *                           connected making it impossible to bill reliably.  Disconnecting calls on restart would minimize the possibility of runaway calls.
 *
 * Jan. 03, 2009 : Joegen :  Reimplemented DestroyConenction to enqueue a session event instead to avoid further race conditons and dead locks.
 *                           We also implemented B2BUAConnection::IsSafeReference() to further guaranty the integrity of connection pointers.
 *
 * Dec. 22, 2008 : Joegen :  Application Timers for Alerting and Connect is causing a deadlock on connection destruction. 
 *                           To address this issue, we modified opensipstack to take care of the timers in the ICT Layer.
 *
 * Dec. 18, 2008 : Joegen :  SOLEGY: Changed default failover procudure to only failover for calls resulting to a timeout 
 *                           or to a status code > 5xx.  Solegy calls use SolegySession::IsFailoverCandidate() 
 *                           method as an added feature to allow excemptions to be configurable
 *
 * Dec. 17, 2008 : Joegen :  Introduced a new handler for cancelled calls in SBCConnection. As opposed to
 *                           the old behavior of blindly sending CANCEL to the UAS while abruptly destroying the 
 *                           call, the new handler would wait for final response from the UAS before the call
 *                           is queued for deletion.  Hopefully this would eradicate the chances of race conditions 
 *                           that may happen when multiple methods are interrupted by a call to cancel.
 *
 * Dec. 12, 2008 : Joegen :  Used BOOL to determine if a SIP Message is to be encrypted or not.
 *                           Previous implementation is using SIP Message internal headers which is slower.
 *                           We must now explicitly call SIPMessage::SetEncryption() in places where SIPMessage::
 *                           ClearInternalHeaders() was enough to reset the SIP Message application specific states.
 *
 *
 */


#ifndef SBC_VERSION_H
#define SBC_VERSION_H



/* WARNING: You MUST NOT add any comments to the #defines which follow
   or add extra commented out #defines as this will confuse the parser
   which extracts the version numbers
 */

#define SBC_MAJOR_VERSION 1
#define SBC_MINOR_VERSION 1
#define SBC_BUILD_NUMBER 5
#define SBC_REVISION_NUMBER 108
#define SBC_BUILD_TYPE    ReleaseCode

#endif  // SBC_VERSION_H


// End of File ///////////////////////////////////////////////////////////////
