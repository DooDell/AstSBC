/*
 *
 * RouteRecord.cxx
 *
 * Open SIP Stack ( OSS )
 *
 * Copyright (c) opensipstack.org.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either expressed or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is OpenSIPStack.
 *
 * The Initial Developer of the Original Code is opensipstack.org.
 *
 * The author of this code is Joegen E. Baclor
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * The OpenSIPStack Library includes some GPL/LGPL code libraries that MAY be 
 * enabled at compile time using the --enable-gpllibs configure switch.  If
 * enabled, the content of this file is published under the terms of GNU 
 * General Public License Version 2.  For a detailed list of the available
 * GPL code, see $(opensipstack)/gnu/README file.
 *
 *
 * $Log: RouteRecord.cxx,v $
 * Revision 1.20  2009/05/27 13:52:17  joegenbaclor
 * Fixed unix build errors and warnings
 *
 * Revision 1.19  2009/03/22 23:42:48  joegenbaclor
 * Added configurable interface table support
 *
 * Revision 1.18  2009/02/10 08:16:09  joegenbaclor
 * Fixed HTTP Config crash
 *
 * Revision 1.17  2009/01/21 10:01:56  joegenbaclor
 * Marking bug fix for solegy START race condition
 *
 * Revision 1.16  2008/10/01 13:50:59  joegenbaclor
 * Added "@" in safechars
 *
 * Revision 1.15  2008/09/16 01:22:11  joegenbaclor
 * Added ability to include "*" in dialstrings.  This was previously disallowed because
 *  it conflicts with route wild card matching.   To include "*" in the wildcard string,
 *  the route should insert the "*" in it's hex escaped form "%2A"
 * Example: ( [sip:%2A1800*]  sip:foo.org )
 *  will match the URI sip:*18005558355@foo.org
 *
 * Revision 1.14  2008/08/29 06:21:21  joegenbaclor
 * Added paralllel forking support
 *
 * Revision 1.13  2008/07/01 12:27:00  joegenbaclor
 * Added Solegy debit module
 *
 * Revision 1.12  2008/04/10 06:45:55  joegenbaclor
 * Forced use of SetValue() instead of operator=() for PAtomicIntegers
 *
 * Revision 1.11  2008/02/28 13:36:15  rcolobong
 * Added feature to rewrite the FROM domain to a specific domain in the B2BUA routes
 *
 * Revision 1.10  2008/02/07 13:17:51  rcolobong
 * Fix bug for parsing target route in GetTargetURI
 *
 * Revision 1.9  2007/07/14 07:53:56  joegenbaclor
 * Migrated code to use new STL based string class
 *
 * Revision 1.8  2007/07/07 15:21:17  joegenbaclor
 * Added iproute2 support for linux
 *
 * Revision 1.7  2007/07/06 14:16:36  rcolobong
 * 1. Route by primary codec
 * 2. Support Upstream proxy routing
 *
 * Revision 1.6  2007/05/29 17:43:04  joegenbaclor
 * Initial work on auto attendant
 *
 * Revision 1.5  2007/04/03 06:06:48  rcolobong
 * 1. Add new method GetAllTargetURIList
 * 2. Update handling of MaxSession in SIPURI parameter
 *
 * Revision 1.4  2007/01/22 10:00:58  joegenbaclor
 * Fixed ProxyRouteRequest
 *
 * Revision 1.3  2007/01/02 01:54:59  joegenbaclor
 * Corrected parser bug for Route Records
 *
 * Revision 1.2  2006/11/22 11:33:25  rcolobong
 * 1. Change method FindRoute to HasScheme
 * 2. Fix problem where it "Rounds Robin" in HasScheme method
 *
 * Revision 1.1  2006/08/14 10:04:59  rcolobong
 * Convert B2BUA to SBC
 * Support MP logging
 *
 * Revision 1.2  2006/07/11 13:59:34  joegenbaclor
 * Completed Proxy functionalities for B2BUA
 *
 * Revision 1.1  2006/06/20 09:58:11  joegenbaclor
 * *** empty log message ***
 *
 * Revision 1.2  2006/05/19 06:30:37  joegenbaclor
 * 1.  Fixed bug in SIPHeaderB where tag may not be parsed properly if no < > enclosure is present
 * 2.  Various enhancements to OpenSBC and proxy session
 *
 * Revision 1.1  2006/05/17 04:04:48  joegenbaclor
 * Initial upload of OpenSBC files
 *
 *
 */



//Routing:

/// routes calls prefixed by 1212 for example.domain.com to sip:xxx.xxx.xxx.xxx
///<1212*@example.domain.com> sip:xxx.xxx.xxx.xxx

/// routes all calls to example.domain.com to the two destinations using a round robin scheme
///<*@example.domain.com> sip:xxx.xxx.xxx.xxx:5060, sip:xxx.xxx.xxx.xxx:5060

/// relay everything
///<*> *

///Upper Registration:

/// routes REGISTERS for example.domain.com to sip:xxx.xxx.xxx.xxx
///<*@example.domain.com> sip:xxx.xxx.xxx.xxx

/// routes all REGISTERS to example.domain.com to the two destinations using a round robin scheme
/// will hijack contacts if upper-registrar is true
/// will challenge REGISTER if authenticate is true

///<*@example.domain.com;upper-registrar=true;authenticate=false> sip:xxx.xxx.xxx.xxx:5060, sip:xxx.xxx.xxx.xxx:5060

/// relay everything
///<*> *


#include "RouteRecord.h"
#include "ParserTools.h"
#include "Router.h"

using namespace SIPParser;

#define new PNEW

static OString EscapeWildCardSymbols( 
  const OString & str 
)
{
  PString xlat = str;

  const char * safeChars = "abcdefghijklmnopqrstuvwxyz"
                      "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
                      "@0123456789$-_.!'(),+#:;";

  PINDEX pos = (PINDEX)-1;

  while ((pos += (int)(1+strspn(&xlat[pos+1], safeChars))) < xlat.GetLength())
    xlat.Splice(psprintf("%%%02X", (BYTE)xlat[pos]), pos, 1);

  return (const char *)xlat;
}

RouteRecord::RouteRecord( Router * router )
{
  m_CurrentTargetIndex.SetValue(0);
  m_MaxSession.SetValue( P_MAX_INDEX );
  m_CurrentSession.SetValue( 0 );
  m_Router = router;
  m_IsParallelFork = FALSE;
}

RouteRecord::RouteRecord( 
  const OString & routeRec,
  Router * router
)
{
  m_CurrentTargetIndex.SetValue(0);
  m_MaxSession.SetValue( P_MAX_INDEX );
  m_CurrentSession.SetValue(0);
  m_Router = router;
  operator=( routeRec );
}

RouteRecord::RouteRecord( 
  const RouteRecord & routeRec
)
{
  m_Router = routeRec.m_Router;
  m_CurrentTargetIndex.SetValue(0);
  m_MaxSession.SetValue( P_MAX_INDEX );
  m_CurrentSession.SetValue(0);
  operator=( routeRec );
}

RouteRecord & RouteRecord::operator=(
  const OString & routeRec
)
{
  Parse( routeRec );
  return *this;
}

RouteRecord & RouteRecord::operator=(
  const RouteRecord & routeRec
)
{
  m_RouteURI = routeRec.m_RouteURI;

  for( int i = 0; i < routeRec.m_Targets.GetSize(); i++ )
    m_Targets.AppendString( routeRec.m_Targets[i] );

  m_CurrentTargetIndex.SetValue( (long)routeRec.m_CurrentTargetIndex );
  m_MaxSession.SetValue( routeRec.m_MaxSession );
  m_CurrentSession.SetValue( (long)routeRec.m_CurrentSession );
  return *this;
}


BOOL RouteRecord::Parse( 
  const OString & routeRec
)
{
  PINDEX less, greater;

  less = routeRec.Find( "[" );
  if( less == P_MAX_INDEX )
    return FALSE;

  greater = routeRec.Find( "]" );
  if( greater == P_MAX_INDEX )
    return FALSE;

  if( greater <= less )
    return FALSE;

  OString buff = routeRec.Mid( less+1 , greater-less-1 );
  m_RouteURI = buff;

  SIPURI routeURI = buff;

  UpdateMaxSession( routeURI );
  UpdatePrimaryCodec( routeURI );
  UpdateRewriteFromDomain( routeURI );
  UpdateIsParallelFork( routeURI );

  const MimeParam::SortedCollection & paramCollection = routeURI.GetParameters();

  OStringStream _params;

  for( PINDEX i = 0; i < paramCollection.GetSize(); i++ )
  {
    _params << paramCollection.GetDataAt( i );

    if( i < paramCollection.GetSize() -1 )
      _params << "; ";
  }

  OString params( _params );

  OString target = routeRec.Mid( greater + 1 );

  if( target.IsEmpty() )
    return FALSE;

  OStringArray targets = target.Tokenise( ',' );

  if( targets.GetSize() == 0 )
    m_Targets.AppendString( target.Trim() );
  else
  {
    for( PINDEX i = 0; i < targets.GetSize(); i++ )
    {
      OString currentTarget = targets[i].Trim();
      if( currentTarget *= "ivr" )
        currentTarget = m_Router->GetIVRRoute().AsString();

      if( !params.IsEmpty() )
      {
        PStringStream targetString;
        targetString << currentTarget << "; " << params;
        m_Targets.AppendString( (const char *)targetString );
      }else
      {
        m_Targets.AppendString( currentTarget );
      }
    }
  }

  m_TargetsSubIndex = PIntArray( m_Targets.GetSize() );
  for( PINDEX j = 0; j < m_Targets.GetSize(); j++ )
    m_TargetsSubIndex[j] = 0;

  return TRUE;
}

/*
BOOL RouteRecord::ReferenceRoute(
  B2BUAConnection & connection
)
{
  if( m_MaxSession > m_CurrentSession )
  {
    connection.AddInternalPObject( new RouteHandler( *this ) );
    return TRUE;
  }

  return FALSE;
}*/


BOOL RouteRecord::SetRouteURI(
  const OString & uri
)
{
  m_RouteURI = uri;
  return TRUE;
}

const OString & RouteRecord::GetRouteURI()const
{
  return m_RouteURI;
}

BOOL RouteRecord::GetTargetURI( 
  SIPURI & target
)
{
  if( m_Targets.GetSize() == 1 )
    return GetTargetURI( target, 0 );

  PTRACE( 1, "Performing routeRobin" << m_CurrentTargetIndex );

  if(  GetTargetURI( target, m_CurrentTargetIndex ) )
  {
    if( ++m_CurrentTargetIndex >= m_Targets.GetSize() )
      m_CurrentTargetIndex.SetValue(0);

    return TRUE;
  }

  return FALSE;
}

OStringArray RouteRecord::GetTargetURIList()const
{
  OStringArray list;
  for( PINDEX i = 0; i < m_Targets.GetSize(); i++ )
  {
    SIPURI target;
    if( const_cast<RouteRecord *>(this)->GetTargetURI( target, i ) )
      list.AppendString( target.AsString() );
  }

  return list;
}

OStringArray RouteRecord::GetAllTargetURIList() const
{
  OStringArray list;
  for( PINDEX index = 0; index < m_Targets.GetSize(); ++index )
  {
    OStringArray targets = m_Targets[index].Tokenise( '|' );
    if( targets.GetSize() > 1 )
    {
      for( PINDEX i = 0; i < targets.GetSize(); ++i )
        list.AppendString( targets[i].Trim() );
    } else
    {
      list.AppendString( m_Targets[index].Trim() );
    }
  }

  return list;
}

BOOL RouteRecord::GetTargetURI( 
  SIPURI & target,
  PINDEX index
)
{
  PINDEX subIndex = m_TargetsSubIndex[index];

  if( index >= m_Targets.GetSize() )
    return FALSE;

  OStringArray targets = m_Targets[index].Tokenise( '|' ); 
 
  if( subIndex >= targets.GetSize() )
    subIndex = 0;

  if( targets.GetSize() > 1 )
  {
    target = targets[subIndex].Trim();
    if( ++subIndex >= targets.GetSize() )
      subIndex = 0;
  }else
  {
    target = m_Targets[index].Trim();
  }
  
  m_TargetsSubIndex[index] = subIndex;

  return TRUE;
}

BOOL RouteRecord::AppendTargetURI(
  const SIPURI & target
)
{
  m_Targets.AppendString( target.AsString() );
  return TRUE;
}

BOOL RouteRecord::RemoveTargetURI(
  PINDEX index
)
{
  m_Targets.RemoveAt( index );
  return TRUE;
}

BOOL RouteRecord::HasScheme(
  const OString& scheme
)
{
  SIPURI uri;
  for( PINDEX index = 0; index < m_Targets.GetSize(); ++index )
  {
    uri = m_Targets[index];
    if( uri.GetScheme() *= scheme )
      return TRUE;
  }

  return FALSE;
}

PINDEX RouteRecord::GetTargetURICount()const
{
  return m_Targets.GetSize();
}

void RouteRecord::PrintOn( ostream & strm )const
{
  strm << "<" << m_RouteURI << "> ";
  for( PINDEX i = 0; i < m_Targets.GetSize(); i++ )
  {
    strm << m_Targets[i];

    if( i < m_Targets.GetSize() - 1 )
      strm << ", ";
  }
}


BOOL RouteRecord::operator*=(
  const SIPURI & uri
)
{
  OString buff = uri.AsString();
  return operator*=( buff );
}

BOOL RouteRecord::operator*=(
  const OString & _uri
)
{
  OString wild = m_RouteURI;
  OString uri = EscapeWildCardSymbols( _uri );

  OStringArray tokens = m_RouteURI.Tokenise( ';' );
  if( tokens.GetSize() > 0 )
    wild = tokens[0];

  BOOL match = ParserTools::WildCardCompare( wild.c_str(), uri.c_str() );

  if( match )
  {

    PTRACE( 5, "*** MATCH *** " << uri << " --> " << *this );
  }else
    PTRACE( 5, "*** NO MATCH *** " << uri << " --> " << wild );

  return match;
}

void RouteRecord::UpdateMaxSession( SIPURI & uri )
{
  OString maxSession = uri.RemoveParameter( "max-session" );
  if( !maxSession.IsEmpty() )
    m_MaxSession.SetValue( maxSession.AsUnsigned() );
  else
    m_MaxSession.SetValue( P_MAX_INDEX );
}

void RouteRecord::UpdatePrimaryCodec( SIPURI & uri )
{
  OString primaryCodec;
  if( uri.GetParameter( "codec", primaryCodec ) )
  {
    uri.RemoveParameter( "codec" );
    m_PrimaryCodec = primaryCodec; 
  } else
  {
    m_PrimaryCodec = OString::Empty();
  }
}

void RouteRecord::UpdateRewriteFromDomain( SIPURI & uri )
{
  OString fromURI;
  if( uri.GetParameter( "from", fromURI ) )
  {
    uri.RemoveParameter( "from" );
    m_RewriteFromDomain = fromURI; 
  } else
  {
    m_RewriteFromDomain = OString::Empty();
  }
}

void RouteRecord::UpdateIsParallelFork( SIPURI & uri )
{
  OString fork;
  if( uri.GetParameter( "fork", fork ) )
  {
    uri.RemoveParameter( "fork" );
    if( fork[0] == 't' || fork[0] == 'T' )
      m_IsParallelFork = TRUE; 
  } else
  {
    m_IsParallelFork = FALSE;
  }
}

///////////////////////////////////////////////////////////
// RouteHandler public Member
/*
RouteRecord::RouteHandler::RouteHandler( 
  RouteRecord & routeRecord
) 
{
  m_RouteRecord = new RouteRecord( routeRecord );
}

RouteRecord::RouteHandler::~RouteHandler()
{
  delete m_RouteRecord;
}
*/

