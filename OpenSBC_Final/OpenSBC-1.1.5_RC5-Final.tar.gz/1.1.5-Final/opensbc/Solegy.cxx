/*
 *
 * Solegy.cxx
 *
 * Open SIP Stack ( OSS )
 *
 * Copyright (c) opensipstack.org.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either expressed or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is OpenSIPStack.
 *
 * The Initial Developer of the Original Code is opensipstack.org.
 *
 * The author of this code is Joegen E. Baclor
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * The OpenSIPStack Library includes some GPL/LGPL code libraries that MAY be 
 * enabled at compile time using the --enable-gpllibs configure switch.  If
 * enabled, the content of this file is published under the terms of GNU 
 * General Public License Version 2.  For a detailed list of the available
 * GPL code, see $(opensipstack)/gnu/README file.
 *
 * $Log: Solegy.cxx,v $
 * Revision 1.87  2009/06/18 08:13:11  joegenbaclor
 * corrected some type in last ommit
 *
 * Revision 1.86  2009/06/18 08:10:49  joegenbaclor
 * implementing event queue reqind for rtts
 *
 * Revision 1.85  2009/06/08 06:30:45  joegenbaclor
 * Added route caching capability to solegy rtts client
 *
 * Revision 1.84  2009/05/05 11:37:58  joegenbaclor
 * updated deprecated functions used by xbase
 * updated MSVC 2005 Project files to include XBase classes
 *
 * Revision 1.83  2009/04/16 05:02:15  joegenbaclor
 * *** empty log message ***
 *
 * Revision 1.82  2009/04/15 12:27:31  joegenbaclor
 * *** empty log message ***
 *
 * Revision 1.81  2009/04/14 08:56:32  joegenbaclor
 * *** empty log message ***
 *
 * Revision 1.80  2009/04/14 02:00:10  joegenbaclor
 * Reverting Thread-based transport
 *
 * Revision 1.70  2009/03/14 11:19:02  joegenbaclor
 * added authenticator support in solegy auth
 *
 * Revision 1.69  2009/03/13 02:26:19  joegenbaclor
 * In this revision, we moved listener configuration to its own
 * page allowing all listeners to be configured seperately.
 * Previous behavior only allowed the main listener to be configured.
 * We have also added a out of dialog handler in the backdoor trunk
 * to allow unsolcited messages like OPTIONS and NOTIFY to passthrough.
 * Both of these functionalities are still under testing.
 *
 * Revision 1.68  2009/03/05 09:25:35  joegenbaclor
 * delayed locking of the session list mutex until Start() is queued for a solegy session.
 *
 * Revision 1.67  2009/02/23 14:26:18  joegenbaclor
 * Added solegy fraud detection class
 *
 * Revision 1.66  2009/02/20 05:15:31  joegenbaclor
 * added logs for rtts mutex deadlock
 *
 * Revision 1.65  2009/02/14 06:49:38  joegenbaclor
 * Maximized use of time mutex for rtts session list mutual access
 *
 * Revision 1.64  2009/02/13 04:49:32  joegenbaclor
 * reinstated mutex for session list in ProcessEvent
 *
 * Revision 1.63  2009/02/12 15:39:58  joegenbaclor
 * Null check for session in EnqueueEvent
 *
 * Revision 1.62  2009/02/12 05:50:31  joegenbaclor
 * block further events if state is terminated
 *
 * Revision 1.61  2009/02/12 02:36:04  joegenbaclor
 * More call rate sanity check
 *
 * Revision 1.60  2009/02/09 04:14:15  joegenbaclor
 * corrected typos
 *
 * Revision 1.59  2009/02/06 09:50:38  joegenbaclor
 * Added email alert notification support
 *
 * Revision 1.58  2009/02/03 05:58:06  joegenbaclor
 * Added ability to not send PING for aggregated RTTS sessions
 *
 * Revision 1.57  2009/02/03 05:12:10  joegenbaclor
 * Minor tweaks
 *
 * Revision 1.56  2009/01/29 13:15:14  joegenbaclor
 * Implemented new queue for commands comming from b2bua connection towrds the solegy client
 *
 * Revision 1.55  2009/01/28 06:12:47  joegenbaclor
 * Using one thread for RTTS event que and we no longer need m_PacketQueue locks allover
 *
 * Revision 1.54  2009/01/27 09:01:02  joegenbaclor
 * Encountered deadlock in STOP
 *
 * Revision 1.53  2009/01/26 02:51:08  joegenbaclor
 * local-id not set becaise invite is null when creating WSDB session without billing
 *  vector header
 *
 * Revision 1.52  2009/01/26 02:16:21  joegenbaclor
 * Ok found why RTTS Client gets deleted unexpectedly.  We are using m_CurrentRTTSIndex which is getting reset when we introduced fwest load rtbe routing
 *
 * Revision 1.51  2009/01/26 01:13:28  joegenbaclor
 * Added temporary TRACE lines
 *
 * Revision 1.50  2009/01/25 07:24:23  joegenbaclor
 * Implemented new deadlock detection using 100 trying consecutive occurence
 *
 * Revision 1.49  2009/01/25 04:46:05  joegenbaclor
 * Introduced capability to use only the RTTS server with the lowest load
 *
 * Revision 1.48  2009/01/25 03:02:21  joegenbaclor
 * Used events for retransmission timers to avoid locking up pwlib timer thread during
 *  heavy load
 *
 * Revision 1.47  2009/01/24 06:55:51  joegenbaclor
 * Bug fix for EnqueEvent
 *
 * Revision 1.45  2009/01/20 03:38:35  joegenbaclor
 * We modified SolegySessionManager::EnqueueEvent to check if the current packet is read from the same  active socket for the session.  If it came from a different socket other thatn the current socket, it will be silently dropped.  This will prevent the race condition brought about by START failover wherein a response  from the previous START attempt maybe interpreted as a response for the new failover ATTEMPT.  This would have been ok if Solegy RTTS allows START packet to have incrementing SEQ parameter since it can be dropped as stale.
 *
 * Revision 1.44  2009/01/16 03:46:32  joegenbaclor
 * Marking DumpCDRRecon and SolegySocket::Close bugfix
 *
 * Revision 1.43  2009/01/15 03:16:57  joegenbaclor
 * added close function for solegy sockets to allow other modules to explicitly delete the udp socket when used outside of the manager
 *
 * Revision 1.42  2009/01/14 15:50:10  joegenbaclor
 * Deleting the content of the solegy session event queue seems to make opensbc crash.  instead we just make sure that no more events are enqueued when state is termianted
 *
 * Revision 1.41  2009/01/14 02:10:04  joegenbaclor
 * some shutdown enhancements
 *
 * Revision 1.40  2009/01/12 04:50:01  joegenbaclor
 * We modified two things in this commit.  The first is to handle CANCEL requests arriving before an in INVITE is sent out to the upstream termination. Previous implementation did not handle this case properly which results to the call still being attempted even after it was aborted by the caller.  The second bug fix is we introduced m_LocallyAuthenticated in the B2BUAConnection layer so that the SBC can determine cases where both the SBC and the upstream termination both challenged the INVITE resulting to a double authentication.  Although RFC 3261 allows this, we yet have to see UAs that can handle authentication from two realms.  In most cases this call would end up in bad state so its better to just destroy the connection when this happens.
 *
 * Revision 1.39  2009/01/09 12:57:39  joegenbaclor
 * Minor GCC spcific tweaks
 *
 * Revision 1.38  2009/01/09 12:32:16  joegenbaclor
 * In this build we introduced state cookies for Solegy Calls.  The state cookie would allow OpenSBC to disconnect  calls (both BYE and CALLSTOP) after a restart or a crash happen by reconstructing dialog and RTTS state using the cookie data.  The cookie is created on CALLSTART and will be deleted on CALLSTOP.  When a crash happens, calls may stay  connected making it impossible to bill reliably.  Disconnecting calls on restart would minimize the possibility of runaway calls.
 *
 * Revision 1.37  2009/01/08 12:14:32  joegenbaclor
 * Added state cookie support to allow calls to be disconnected upon restart of osbc
 *
 * Revision 1.36  2008/12/31 05:04:50  joegenbaclor
 * Introduced mutex for Solegy socket read-write operations
 *
 * Revision 1.35  2008/11/20 11:02:35  joegenbaclor
 * Depcrecated old SIPMessage URI accessors
 *
 * Revision 1.34  2008/11/18 02:56:47  joegenbaclor
 * Commenting out unused variable in DumpCDRRecon
 *
 * Revision 1.33  2008/11/12 08:54:15  joegenbaclor
 * Bug:  Delay registrar evaluation for a solegy controlled domain
 *
 * Revision 1.32  2008/11/12 04:23:46  joegenbaclor
 * Feature: Added registration list to be checked for registered calls
 *
 * Revision 1.31  2008/11/11 02:54:47  joegenbaclor
 * Feature:  Introducing RTTS aggregation of groomer and osbc
 * Bug:  Disconnect calls if ParseRouting has an empty result set
 *
 * Revision 1.30  2008/11/07 08:46:42  joegenbaclor
 * Used EventQueue for Recon post instead
 *
 * Revision 1.29  2008/11/07 04:48:47  joegenbaclor
 * Bug:  m_ExitFlag for recon not initialilzed in construcotr
 *
 * Revision 1.28  2008/11/04 02:19:50  joegenbaclor
 * reinserting recon postdata back to queue if postdata fails
 *
 * Revision 1.27  2008/11/04 02:06:08  joegenbaclor
 * Use separate thread for Recon Informer
 *
 * Revision 1.26  2008/10/27 09:44:04  joegenbaclor
 * Subclassing B2BUA objects to give OpenSBC a more fine grained control
 *
 * Revision 1.25  2008/10/23 08:08:43  joegenbaclor
 * Corrected bug in RTTS lookup when route is enabled.  We increment current index twice!
 *
 * Revision 1.24  2008/10/22 05:06:25  joegenbaclor
 * Added MPL License Header
 *
 *
 */

#include "Solegy.h"
#include "SBCRoutingHandler.h"
#include "SolegyDebit.h"
#include "SolegyWSDB.h"
#include "SolegyCachedWSDB.h"
#include "SolegyWSPT.h"
#include "OpenSBC.h"
#include "SolegyFraudDetect.h"
#include "SolegyPromptManager.h"
#include "SBCInboundCall.h"

#define new PNEW

using namespace SOLEGY;

///////////////////////////////////////////////////////////////////////////////


SolegySessionManager::SolegySessionManager()
{
  /// REGISTER new schemes
  SIPURI::RegisterScheme( "rtts" );
  SIPURI::RegisterScheme( "wsdb" );
  SIPURI::RegisterScheme( "msdb" );
  SIPURI::RegisterScheme( "cnam" );
  SIPURI::RegisterScheme( "wspt" );
  m_EventProcessor = new EQ::EventQueue( PCREATE_NOTIFIER( OnProcessEvent ), 1 /** NOTE: RTBE Client is not thread safe so just use one thread*/ );
  m_ConnectionEventProcessor = new EQ::EventQueue( PCREATE_NOTIFIER( OnProcessConnectionEvent ), 1  );
  m_STUNClient = NULL;
  m_PortBase = 7800;
  m_PortMax =  8000;
  m_ExitRead = FALSE;
  m_IsReading = FALSE;
  m_IsStartUp = TRUE;
  m_CurrentRTTSIndex = 0;
  m_ReconInformerCurrentIndex = 0;
  m_CATLog = NULL;
  m_UseFewestLoadServer = TRUE;

  /// create directories if non existent
  PFilePath catDIR = OSSApplication::GetApplicationDirectory() + "CAT";
  if( !PDirectory::Exists( catDIR ) )
    PDirectory::Create( catDIR );

  m_CATDIR = catDIR + "/rtbe";
  if( !PDirectory::Exists( m_CATDIR ) )
    PDirectory::Create( m_CATDIR );

  PFilePath stateDIR = OSSApplication::GetApplicationDirectory() + "STATE";
  if( !PDirectory::Exists( stateDIR ) )
    PDirectory::Create( stateDIR );

  m_RTTSStateDIR = stateDIR + "/rtbe";
  if( !PDirectory::Exists( m_RTTSStateDIR ) )
    PDirectory::Create( m_RTTSStateDIR );

  m_RTTSRouteCacheDIR = m_RTTSStateDIR + "/route-cache";
  if( !PDirectory::Exists( m_RTTSRouteCacheDIR ) )
    PDirectory::Create( m_RTTSRouteCacheDIR );

  m_ReconQueue = new EventQueue( PCREATE_NOTIFIER( OnCDRReconPostEvent ), 1, 1024000 );
  m_FraudDetector = new SolegyFraudDetect( this );
}

SolegySessionManager::~SolegySessionManager()
{
  m_ExitSync.Signal();
  m_ReadExitSync.Wait( 5000 );
  delete m_CATLog;
  delete m_ReconQueue;
  delete m_ConnectionEventProcessor;
  delete m_EventProcessor;
  delete m_FraudDetector;
}

void SolegySessionManager::OnCDRReconPostEvent( EventQueue &, INT value )
{
  ReconPostData * postData = reinterpret_cast<ReconPostData*>( value );
  if( postData != NULL )
  {
    PMIMEInfo replyMIME;
    if( m_ReconInformer.PostData( postData->url, postData->sendMIME, "", replyMIME ) )
      delete postData;
    else
    {
      PTRACE( 1, "*** REINSERTING RECON POST DATA *** Recon Server at " 
                  << postData->url << " Failed to process last POST" );
      if( !m_ReconQueue->EnqueueEvent( postData ) )
        delete postData;
    }
  }
}

BOOL SolegySessionManager::Initialize( OpenSBC * sbc )
{
  PWaitAndSignal lock( m_RTTSMutex );
  m_SBC = sbc;
  OSSAppConfig * config = sbc->GetAppConfig();
  
  m_SolegyHomeDir = config->GetString( "Solegy", "Solegy-Home-Dir", "solegy" );
  m_CDRReconDir = m_SolegyHomeDir + "/recon";
  if( m_SolegyHomeDir.Exists() )
  {
    m_SolegyHomeDir.Create();
    if( m_CDRReconDir.Exists() )
      m_CDRReconDir.Create();
  }

  
  m_PortBase = (WORD)config->GetInteger( "Solegy", "RTTS-Client-Base-Port", 18000 ); 
  m_PortMax = (WORD)config->GetInteger( "Solegy", "RTTS-Client-Max-Port", 20000 );
  PString rttsStunServer = config->GetString( "Solegy", "RTTS-STUN-Server", "stun.voxgratia.org" );
  PString rttsClientAddress = config->GetString( "Solegy", "RTTS-Client-Address", "0.0.0.0" );
  
  if( rttsClientAddress == "0.0.0.0" )
  {
    PIPSocket::Address defIface = SIPTransportManager::GetDefaultInterfaceAddress();
    rttsClientAddress = defIface.AsString();
  }else
  {
    ///now check if the current interface is still valid
    PIPSocket::InterfaceTable ifaceTable;
    PIPSocket::GetInterfaceTable( ifaceTable );
    BOOL isIfaceValid = FALSE;
    for( PINDEX i = 0; i < ifaceTable.GetSize(); i++ )
    {
      PIPSocket::InterfaceEntry * entry = (PIPSocket::InterfaceEntry *)ifaceTable.GetAt(i);
      if( entry != NULL && entry->GetAddress().IsValid() )
      {
        PString iface = entry->GetAddress().AsString();
        if( rttsClientAddress *= iface )
        {
          isIfaceValid = TRUE;
          break;
        }
      }
    }

    if( !isIfaceValid )
    {
      PIPSocket::Address defIface = SIPTransportManager::GetDefaultInterfaceAddress();
      rttsClientAddress = defIface.AsString();
    }
  }

  int count = m_RTTSClientList.GetSize();

  for( PINDEX i = 0; i < count; i++ )
     m_RTTSClientList.GetDataAt(i).Disable();

  config->SetString( "Solegy", "RTTS-Client-Address", rttsClientAddress  );
  m_RTTSClientAddress = rttsClientAddress;

  int rttsCount = config->GetListSize( "Solegy", "RTTS-Host-List" );
  for( PINDEX i = 0; i < rttsCount; i++ )
    AddRTTSInstance((const char *)config->GetListItem( "Solegy", "RTTS-Host-List", i ));

  {
    PWaitAndSignal lock( m_ReconfInformerResourceMutex );
    int reconCount = config->GetListSize( "Solegy", "CDR-Recon-List" );
    for( PINDEX i = 0; i < reconCount; i++ )
      m_ReconfInformerResource.Append( new PURL( (const char *)config->GetListItem( "Solegy", "CDR-Recon-List", i ) ) );
  }

  {
    //LB-Host-List
    PWaitAndSignal lock( m_LBHostListMutex );
    m_LBHostList.RemoveAll();
    int lbCount = config->GetListSize( "Solegy", "LB-Host-List" );
    for( PINDEX i = 0; i < lbCount; i++ )
      m_LBHostList.Append( new SIPURI( (const char *)config->GetListItem( "Solegy", "LB-Host-List", i ) ) );
  }

  {
    //Registrar-Domain-List
    PWaitAndSignal lock( m_RegistrarDomainListMutex );
    m_RegistrarDomainList.RemoveAll();
    int count = config->GetListSize( "Solegy", "Registrar-Domain-List" );
    for( PINDEX i = 0; i < count; i++ )
    {
      SIPURI domain( (const char *)config->GetListItem( "Solegy", "Registrar-Domain-List", i ) );
      if( !domain.GetHost().IsEmpty() )
        m_RegistrarDomainList.AppendString( domain.GetHost().c_str() );
    }
  }
  

  if( !m_IsReading )
  {
    PThread::Create( 
      PCREATE_NOTIFIER( 
      ProcessRead ), 
      0, 
      PThread::AutoDeleteThread,
      PThread::NormalPriority,
      "RTTS Read Thread"  );
  }

  count = m_RTTSClientList.GetSize();
  for( PINDEX i = 0; i < count ; i++ )
     m_RTTSClientList.GetDataAt(i).ValidateServer();
 
  OpenCATLog();

  /// RTTS-Error-Prompts
  OStringArray errorPrompts;
  int promptCount = config->GetListSize( "Solegy", "RTTS-Error-Prompts" );
  for( PINDEX x = 0; x <  promptCount; x++ )
    errorPrompts.AppendString( config->GetListItem( "Solegy", "RTTS-Error-Prompts", x ) );

  if( errorPrompts.GetSize() > 0 )
    m_CustomErrorPrompts.Parse( errorPrompts );

  if( m_IsStartUp )
  {
    m_IsStartUp = FALSE;
    ValidateRTTSState();
  }

  return TRUE;
}

void SolegySessionManager::ValidateRTTSState()
{
  PDirectory dir = m_RTTSStateDIR;
  if( dir.Open() )
  {  
    WORD portBase = m_PortBase;
    WORD portMax = m_PortMax;

    do
    {
      PFilePath fp = m_RTTSStateDIR + "/" + dir.GetEntryName();
      PTextFile stateFile( fp );
      if( stateFile.IsOpen() )
      {
        PString bye1, bye2;
        for(;;)
        {
          PString line;
          if( !stateFile.ReadLine( line ) )
            goto DELFILE;

          if( line == "-*-*-" )
            break;

          bye1 += line + "\r\n";
        }

        SIPMessage msg1( (const char *)bye1 );
        msg1.SetNICTNullTransaction( TRUE );
        m_SBC->GetB2BUAEndPoint()->SendRequest( msg1 );

        for(;;)
        {
          PString line;
          if( !stateFile.ReadLine( line ) )
            goto DELFILE;

          if( line == "-*-*-" )
            break;

          bye2 += line + "\r\n";
        }

        SIPMessage msg2( (const char *)bye2 );
        msg2.SetNICTNullTransaction( TRUE );
        m_SBC->GetB2BUAEndPoint()->SendRequest( msg2 );

        OStringStream stop;
        for(;;)
        {
          PString line;
          if( !stateFile.ReadLine( line ) )
            goto DELFILE;

          if( line == "-*-*-" )
            break;

          stop << line << endl;
        }

        //<< "CALL-START-TIME=" << now.GetTimeInSeconds() << endl
        //<< "RTTS-SERVER-ADDR=" << m_Socket->GetRTTSSeverAddress() << endl 
        //<< "RTTS-SERVER-PORT=" << m_Socket->GetRTTSServerPort() << endl;
        OString rttsServerAddr, rttsServerPort, callStartTime;
        if( SolegyParser::ParseHeader( "RTTS-SERVER-ADDR", rttsServerAddr, stop.str() ) &&
            SolegyParser::ParseHeader( "RTTS-SERVER-PORT", rttsServerPort, stop.str() ) &&
            SolegyParser::ParseHeader( "CALL-START-TIME", callStartTime, stop.str() ) )
        {
          PIPSocket::Address server( rttsServerAddr.c_str() );
          WORD port = (WORD)rttsServerPort.AsUnsigned();
          int cst = callStartTime.AsInteger();
          PTime now;
          stop << "DURATION=" << now.GetTimeInSeconds() - cst << endl;
          SolegySocket sock( this, server, port );
          

          if( sock.Open( m_RTTSClientAddress, portBase, portMax ) )
          {
            sock.GetSocket()->SetReadTimeout( 500 );
            PIPSocket::Address localAddress;
            WORD localPort;
            sock.GetSocket()->GetLocalAddress( localAddress, localPort );
            portBase = localPort + 1;
            for( int i = 0; i < 5; i++ )
            {
             
              PTRACE( 1, ">>> RTTS: CALLSTOP DST: " << server << ":" << port << ":UDP SRC: " 
                << localAddress << ":" << localPort << " enc=0 bytes=" << (unsigned int)stop.str().length() );

              //PTRACE( 3, stop.str() );

              std::string packet = stop.str();
              sock.Write( packet );

              char buf[2048];
      
              if( !sock.GetSocket()->Read( buf, 2048 ) )
                continue;
      
              PString response;

              int len = sock.GetSocket()->GetLastReadCount();
              if( len <= 10 || len >= 2048 ) /// definitely not an RTBE PACKET
                continue;

              buf[len] = '\0';
              response = (const char *)&buf[0];

              PStringArray lines = response.Lines();
              if( lines.GetSize() > 0 )
              {
                  PTRACE( 1, "<<< RTTS: " << lines[0] << " DST: " << localAddress << ":" << localPort << ":UDP SRC: " 
                    << server << ":" << port << " enc=0 bytes=" << response.GetLength() );
                  //PTRACE( 3, response );
              }
              break;
            }
            sock.Close( TRUE );
          }
        }

        stateFile.Close();
      }
DELFILE:
      PFile::Remove( fp );
    }while( dir.Next() );
  }
  dir.Close();
}

BOOL SolegySessionManager::IsRoutableDomain( const SIPMessage & invite )const
{
  PWaitAndSignal lock( m_RegistrarDomainListMutex ); 
  if( m_RegistrarDomainList.GetStringsIndex( invite.GetRequestURI().GetHost().c_str() ) != P_MAX_INDEX )
    return TRUE;
  return FALSE;
}

BOOL SolegySessionManager::ValidateRegisteredRoute(
  SIPMessage & invite 
)
{
  PWaitAndSignal lock( m_RegistrarDomainListMutex );
  if( m_RegistrarDomainList.GetStringsIndex( invite.GetRequestURI().GetHost().c_str() ) != P_MAX_INDEX )
  {
    Contact contact;
    if( m_SBC->GetLocalRegistrar()->FindRegistrationBinding( invite, contact ) )
    {
      invite.SetRequestURI( contact.GetTopURI() );
      return TRUE;
    }
  }

  return FALSE;
}


BOOL SolegySessionManager::IsLBHost( const SIPURI & uri )const
{
  PWaitAndSignal lock( m_LBHostListMutex );
  int count = m_LBHostList.GetSize();
  for( int i = 0; i < count; i++ )
  {
    if( m_LBHostList[i].GetHost() == uri.GetHost() )
    {
      OString rport = uri.GetPort();
      if( rport.IsEmpty() || rport == "0" )
        rport = "5060";

      OString lport =  m_LBHostList[i].GetPort();
      if( lport.IsEmpty() || lport == "0" )
        lport = "5060";

      return lport == rport;
    }
  }
  return FALSE;
}

void SolegySessionManager::DumpCDRRecon( SolegySession * session )
{
  PWaitAndSignal lock( m_ReconfInformerResourceMutex );
  int count = m_ReconfInformerResource.GetSize();
  if( count == 0 )
  {
    OStringStream log;
    log << "WARNING:  There are no CDR RECON URL configured for this instance";
    session->DumpLog( log.str().c_str() );
    return;
  }

  m_ReconInformer.SetReadTimeout( 5000 );
  ReconPostData * postData = new ReconPostData();
  postData->url = m_ReconfInformerResource[ m_ReconInformerCurrentIndex % count ];
  m_ReconInformerCurrentIndex++;

  if(postData->url.GetUserName() != "") 
  {
      PStringStream authToken;
      authToken << postData->url.GetUserName() << ":" << postData->url.GetPassword();
      postData->sendMIME.SetAt( "Authorization", PBase64::Encode(authToken) );
  }

  postData->sendMIME.SetAt( PHTTP::ContentTypeTag, "application/x-www-form-urlencoded" );
  if( !session->OnPrepareCDRReconInfo( postData->sendMIME ) )
  {
    delete postData;
    return;
  }

  postData->sendMIME.SetAt( "Server", postData->url.GetHostName() );
  
  OStringStream log;
  log << ">>> CDR RECON: " << postData->sendMIME;
  session->DumpLog( log.str().c_str() );
  if( !m_ReconQueue->EnqueueEvent( postData ) )
    delete postData;

}

BOOL SolegySessionManager::SendMailAlert( const PString & _subject, const PString & _body, const PString & mailingList )
{
  PWaitAndSignal configLock( PHTTPConfig::m_HTTPConfigMutex );
  OSSAppConfig * config = m_SBC->GetAppConfig();
  PString smtpUser = config->GetString( "", "SMTP User", "" );
  PString smtpPassword = PHTTPPasswordField::Decrypt(config->GetString( "", "SMTP Password", "" ));
  PString smtpReturnAddress = config->GetString( "", "SMTP Return Address", "noreply@localhost" );
  PString smtpServer = config->GetString( "", "SMTP Server", "localhost" );
  PString subject = "[OpenSBC-Alert] " + _subject;
 
  int listCount = config->GetListSize( "Solegy", mailingList );
  if( listCount == 0 )
    return FALSE;
  
  PString toList;
  for( PINDEX i = 0; i < listCount; i++ )
  {
    toList += config->GetListItem( "Solegy", mailingList, i );
    if( i + 1 < listCount )
      toList += ',';
  }

  const PTime today;
  PString appVersion = m_SBC->GetApplication()->GetVersion();
  const PFilePath &appPath = OSSApplication::GetInstance()->GetFile();
 
  PStringStream body;
  body << "Date: " << today << endl;
  body << "Server: " << m_RTTSClientAddress << endl;
  body << "Application: " << appPath << endl;
  body << "PID: " << m_SBC->GetApplication()->GetProcessID() << endl;
  body << "Version: " << appVersion << endl << endl;
  
  body << "Alert Detail: " << endl;
  body << _body << endl;
  body << endl << endl << "Your Humble Servant," << endl << "OSBC";

  PRFC822Channel envelope( PRFC822Channel::Sending );
  envelope.SetFromAddress( smtpReturnAddress );
  envelope.SetToAddress( toList );
  envelope.SetSubject( subject );
  return envelope.SendWithSMTP( smtpUser, smtpPassword, smtpServer, body );
}


BOOL SolegySessionManager::AddRTTSInstance(
  const OString & address,
  BOOL enablePingTimer
)
{
  OStringArray tokens;
  address.Tokenise( tokens, ":" );
  PIPSocket::Address rttsAddress;
  WORD rttsPort = 0;
  if( tokens.GetSize() == 1 )
    rttsAddress = PIPSocket::Address( tokens[0].c_str() );
  else if( tokens.GetSize() == 2 )
  {
    rttsAddress = PIPSocket::Address( tokens[0].c_str() );
    rttsPort = (WORD)tokens[1].AsUnsigned();
  }else
    return FALSE;
  
  return AddRTTSInstance( rttsAddress, rttsPort, enablePingTimer );
}

BOOL SolegySessionManager::AddRTTSInstance(
  const PIPSocket::Address & address,
  WORD port,
  BOOL enablePingTimer
)
{  
  PWaitAndSignal lock( m_RTTSMutex );
  PStringStream id;
  id << address.AsString() << ":" << port;

  if( m_RTTSClientList.Contains( id ) )
  {
    m_RTTSClientList.GetAt( id )->Enable();
    return TRUE;
  }

  SolegySocket * socket = new SolegySocket( this, address, port, 60000, enablePingTimer );

  if( !socket->Open( m_RTTSClientAddress, m_PortBase, m_PortMax, m_STUNClient ) )
  {
    delete socket;
    return FALSE;
  }

  PTRACE( 1, "RTTS: Added RTTS Server " << id );
  m_RTTSClientList.SetAt( id, socket );
  m_RTTSServerList.AppendString( (const char *)id );
  
  return TRUE;
}

SolegySocket * SolegySessionManager::GetSpecificTransport(
  const SIPURI & transport, BOOL addIfMissing, BOOL enablePingTimer
)
{
  PWaitAndSignal lock( m_RTTSMutex );
  int count = m_RTTSServerList.GetSize();
  if( count == 0 )
  {
    if( addIfMissing )
    {
      PIPSocket::Address ip; 
      WORD port = 7823;
      if( transport.GetIPAndPort( ip, port ) )
        AddRTTSInstance( ip, port, enablePingTimer );
      else
        return NULL;
    }else
    {
      return NULL;
    }
  }


  PIPSocket::Address addr = transport.GetAddress();
  WORD port = (WORD)transport.GetPort().AsUnsigned();
  count = m_RTTSServerList.GetSize();
  for( int i = 0; i < count; i++ )
  {
    SolegySocket * socket = NULL;
    OString & currentRTTS = m_RTTSServerList[ i ];
    socket = m_RTTSClientList.GetAt( currentRTTS.c_str() );
    if( socket->GetRTTSSeverAddress() == addr && socket->GetRTTSServerPort() == port )
      return socket;
  }

  ///oops not here
  if( addIfMissing )
  {
    PIPSocket::Address ip; 
    WORD port = 7823;
    if( transport.GetIPAndPort( ip, port ) )
      AddRTTSInstance( ip, port, enablePingTimer );
    else
      return NULL;

    //try it again
    count = m_RTTSServerList.GetSize();
    for( int i = 0; i < count; i++ )
    {
      SolegySocket * socket = NULL;
      OString & currentRTTS = m_RTTSServerList[ i ];
      socket = m_RTTSClientList.GetAt( currentRTTS.c_str() );
      if( socket->GetRTTSSeverAddress() == addr && socket->GetRTTSServerPort() == port )
        return socket;
    }
  }

  return NULL;
}

SolegySocket * SolegySessionManager::GetNextAvailableTransport()
{
  PWaitAndSignal lock( m_RTTSMutex );
  int count = m_RTTSServerList.GetSize();
  if( count == 0 )
    return NULL;

  for( int i = 0; i < count; i++ )
  {
    SolegySocket * socket = NULL;
    OString & currentRTTS = m_RTTSServerList[ m_CurrentRTTSIndex % count ];
    
    m_CurrentRTTSIndex++;
    socket = m_RTTSClientList.GetAt( currentRTTS.c_str() );
    if( socket != NULL && socket->IsEnabled() && socket->IsReliableTransport() )
    {
      return socket;
    }else
    {
      PTRACE( 1, "RTTS: Skipping DISABLED or UNRELIABLE RTTS Server " << currentRTTS );
      continue;
    }
  }

  return NULL;
}

SolegySocket * SolegySessionManager::GetTransportWithFewestLoad()
{
  PWaitAndSignal lock( m_RTTSMutex );
  int count = m_RTTSClientList.GetSize();
  int fewest = P_MAX_INDEX;
  if( count == 0 )
    return NULL;
  PString clientKey;
  int i = 0;
  BOOL foundServer = FALSE;
  for( i = 0; i < count; i++ )
  {
    SolegySocket & socket = m_RTTSClientList.GetDataAt(i);
    if( socket.GetServerSessionLoad() < fewest && socket.IsEnabled() && socket.IsReliableTransport() )
    {
      foundServer = TRUE;
      fewest = socket.GetServerSessionLoad();
      clientKey = m_RTTSClientList.GetKeyAt(i);
      if( fewest == 0 )
        break;
    }
  }
  if( !foundServer )
    return NULL;

  m_CurrentRTTSIndex = i;
  return m_RTTSClientList.GetAt( clientKey );
}


BOOL SolegySessionManager::SetSTUNServer( const OString & stunServer )
{
  if( m_STUNClient != NULL )
    delete  m_STUNClient;

  m_STUNClient = new PSTUNClient( stunServer.c_str() );
  return TRUE;
}

BOOL SolegySessionManager::CreateMediaServerSession( B2BUAConnection & connection )
{
  SolegySocket * socket = NULL;

  if( !m_UseFewestLoadServer )
    socket = GetNextAvailableTransport();
  else
    socket = GetTransportWithFewestLoad();

  if( socket == NULL )
    return FALSE;

  OString localSessionId = connection.GetLeg1Call()->GetCallId();
  SolegyDebit * session = new SolegyDebit( this, socket, &connection, localSessionId.c_str() );
  connection.AttachCallController( session ); 
  return TRUE;
}

BOOL SolegySessionManager::CreateWSDBSession( B2BUAConnection & connection, const SIPURI &routeParam, const SIPMessage * invite )
{
  XBillingVector * billingVector = NULL;
  OString callId = connection.GetLeg1Call()->GetCallId();
  if( invite != NULL )
  {
    billingVector = invite->GetXBillingVector();
  }

  SolegySocket * socket = NULL;
  if( billingVector == NULL )
  {
    if( !m_UseFewestLoadServer )
      socket = GetNextAvailableTransport();
    else
      socket = GetTransportWithFewestLoad();

    if( socket == NULL )
    {
      LOG( connection.LogError(), "RTTS: Unable to acquire reliable transport!!!" );
      return FALSE;
    }
  }else
  {
    socket = GetSpecificTransport( billingVector->GetURI(), TRUE, FALSE );
    if( socket == NULL )
    {
      LOG( connection.LogError(), "RTTS: Unable to acquire client transport to " << billingVector->GetURI() );
      return FALSE;
    }
  }

  if( connection.GetSessionState() == B2BUAConnection::Disconnected || dynamic_cast<SBCConnection&>(connection).m_IsAbandoned)
  {
    LOG( connection.LogError(), "RTTS: Not creating a session for a disconnected call" );
    return FALSE;
  }

  SolegySession * session = NULL;
  OString routeCache = routeParam.GetParameter( "route-cache" );
  if( routeCache.ToLower() *= "true" )
    session = new SolegyCachedWSDB( this, socket, &connection, callId.c_str() );
  else
    session = new SolegyWSDB( this, socket, &connection, callId.c_str(), FALSE, FALSE );

  connection.AttachCallController( session );
  return TRUE;
}

BOOL SolegySessionManager::CreateCNAMSession( B2BUAConnection & connection )
{
  SolegySocket * socket = NULL;
  if( !m_UseFewestLoadServer )
    socket = GetNextAvailableTransport();
  else
    socket = GetTransportWithFewestLoad();

  if( socket == NULL )
    return FALSE;

  OString localSessionId = connection.GetLeg1Call()->GetCallId();
  SolegyWSPT * session = new SolegyWSPT( this, socket, &connection, localSessionId.c_str(), FALSE, TRUE );
  connection.AttachCallController( session );

  return TRUE;
}


void SolegySessionManager::ProcessRead( PThread & /*thrd*/, INT /*data*/ )
{
  while( !m_ExitSync.Wait(1) )
  {
    PSocket::SelectList read;
    int slSize = 0;
    if( m_RTTSClientList.GetSize() == 0 )
      PThread::Sleep( 500 );

    {
      PWaitAndSignal lock( m_RTTSMutex );

      slSize = m_RTTSClientList.GetSize();
      m_IsReading = TRUE;
      
      for( PINDEX i = 0; i < slSize; i++ )
      {
        if( m_RTTSClientList.GetDataAt(i).IsEnabled() )
        {
          PUDPSocket * sock = m_RTTSClientList.GetDataAt(i).GetSocket();
          if( sock != NULL  )
            read.Append( sock );
        }
      }
    }

    PChannel::Errors error = PSocket::Select( read );

    if( m_ExitRead )
      return;

    if ( error != PChannel::NoError || read.GetSize() == 0 )
      continue;
    
    PIPSocket::Address rtts;
    WORD rttsPort = 0;
    PString packet;
    {
      PWaitAndSignal lock( m_RTTSMutex );
      PUDPSocket & socket = (PUDPSocket &)read[0];
      slSize = m_RTTSClientList.GetSize();
      //packet = socket.ReadString( 2048 );
      char buf[2048];
      
      {
        PWaitAndSignal lock( SolegySocket::m_ReadWriteMutex );
        socket.ReadFrom( buf, 2048, rtts, rttsPort );
      }

      int len = socket.GetLastReadCount();
      if( len <= 10 || len >= 2048 ) /// definitely not an RTBE PACKET
        continue;

      buf[len] = '\0';
      packet = (const char *)&buf[0];
      if( packet.GetLength() == m_CurrentRTBEPacket.GetLength() && packet == m_CurrentRTBEPacket )
        continue;  /// retransmission, discard
      else
        m_CurrentRTBEPacket = packet;
      
      if( buf[0] == 'P' && 
          buf[1] == 'I' &&
          buf[2] == 'N' &&
          buf[3] == 'G' &&
          buf[4] == 'A' &&
          buf[5] == 'C' &&
          buf[6] == 'K' )
      {
        for( PINDEX i = 0; i < slSize; i++ )
        {
          if( m_RTTSClientList.GetDataAt(i).GetSocket() == &socket )
            m_RTTSClientList.GetDataAt(i).OnPINGACK( (const char *)packet );
        }

        continue;
      }
    }
    EnqueueEvent( rtts, rttsPort, packet );
  }
  m_ReadExitSync.Signal();
  m_IsReading = FALSE;
}

class EnqueueEventRewind_1 : public PThread
{
public:
  EnqueueEventRewind_1(
    SolegySessionManager * manager,
    const PIPSocket::Address & rttsServer,
    WORD rttsPort,
    const PString & packet,
    int retryCount ) : PThread( 1024 * 2 )
  {
    m_Manager = manager;
    m_RTTSServer = rttsServer;
    m_RTTSPort = rttsPort;
    m_Packet = packet;
    m_RetryCount = retryCount;
    Resume();
  }

  void Main()
  {
    m_Manager->EnqueueEvent( m_RTTSServer, m_RTTSPort, m_Packet, m_RetryCount );
  }

  SolegySessionManager * m_Manager;
  PIPSocket::Address m_RTTSServer;
  WORD m_RTTSPort;
  PString m_Packet;
  int m_RetryCount;
};

void SolegySessionManager::EnqueueEvent( 
  const PIPSocket::Address & rttsServer,
  WORD rttsPort,
  const PString & packet,
  int retryCount
)
{ 
  OString id;
  SolegyParser::ParseHeader( "LOCALID", id, (const char *)packet );
   
  if( !id.IsEmpty() )
  {
    SIPSession::GCRef ref = this->m_SBC->GetB2BUAEndPoint()->FindGCRefByCallId( id );
    if( ref.GetObject() == NULL )
    {
      SolegySession * session = NULL;

      if( !m_RTTSSessionListMutex.Wait( 100 ) )
      {
        if( retryCount < 5 )
        {
          new EnqueueEventRewind_1( this, rttsServer, rttsPort, packet, retryCount + 1 );
        }else
        {
          LOG( LogError(), "!!! UNABLE TO ACQUIRE RTTS SESSION LIST MUTEX !!! SolegySessionManager::EnqueueEvent( const PIPSocket::Address &,WORD, const PString & )" );
          _exit(-1);
        }
        return;
      }

      session = m_RTTSSessionList.GetAt( id );
      
      if( session == NULL )
      {
        m_RTTSSessionListMutex.Signal();
        return;
      }

      if( session->GetState() == SolegySession::TERMINATED && packet != "TERMINATE" )
      {
        m_RTTSSessionListMutex.Signal();
        return;
      }
        
      if( session->GetSocket()->GetRTTSSeverAddress() == rttsServer && 
          session->GetSocket()->GetRTTSServerPort() == rttsPort )
      {
        session->EnqueuePacket( packet );
        m_EventProcessor->EnqueueEvent( new PString( id.c_str() ) );
        m_RTTSSessionListMutex.Signal();
        return;
      }
      
      m_RTTSSessionListMutex.Signal();

      
    }else
    {
      SBCInboundCall * call = dynamic_cast<SBCInboundCall*>(ref.GetObject());
      if( call != NULL )
      {
        SBCConnection * conn = dynamic_cast<SBCConnection*>(call->GetB2BUAConnection());
        if( conn != NULL  )
        {
          SIPSessionEvent * evt = new SIPSessionEvent( *conn, SBCConnection::Event_OnReceivedAccountingPacket );
          evt->SetApplicationData( (INT)new OString( (const char *)packet ) );
          conn->EnqueueSessionEvent( evt );
          return;
        }
      }
    }
  }
}

class EnqueueEventRewind_2 : public PThread
{
public:
  EnqueueEventRewind_2(
    SolegySessionManager * manager,
    const PString & packet,
    int retryCount ) : PThread( 1024 * 2 )
  {
    m_Manager = manager;
    m_Packet = packet;
    m_RetryCount = retryCount;
    Resume();
  }

  void Main()
  {
    m_Manager->EnqueueEvent( m_Packet, m_RetryCount );
  }

  SolegySessionManager * m_Manager;
  PString m_Packet;
  int m_RetryCount;
};

void SolegySessionManager::EnqueueEvent( 
  const PString & packet,
  int retryCount )
{
  OString id;
  SolegyParser::ParseHeader( "LOCALID", id, (const char *)packet );
   
  if( !id.IsEmpty() )
  {
    SolegySession * session = NULL;
    {
      if( !m_RTTSSessionListMutex.Wait( 100 ) )
      {
        if( retryCount < 5 )
        {
          new EnqueueEventRewind_2( this, packet, retryCount + 1 );
        }else
        {
          LOG( LogError(), "!!! UNABLE TO ACQUIRE RTTS SESSION LIST MUTEX !!! SolegySessionManager::EnqueueEvent( const PString & )" );
          _exit(-1);
        }
        return;
      }

      session = m_RTTSSessionList.GetAt( id );
      if(  session == NULL || (session != NULL && session->GetState() == SolegySession::TERMINATED && packet != "TERMINATE") )
      {
        m_RTTSSessionListMutex.Signal();
        return;
      }
    }

    session->EnqueuePacket( packet );
    m_EventProcessor->EnqueueEvent( new PString( id.c_str() ) );
    m_RTTSSessionListMutex.Signal();
  }
}

void SolegySessionManager::EnqueueEvent( 
  const PString & packet,
  SolegySession * session
)
{
  if( session->GetState() == SolegySession::TERMINATED && packet != "TERMINATE" )
      return;

  session->EnqueuePacket( packet );
  PString * id = new PString( session->GetLocalSessionId().c_str() );
  m_EventProcessor->EnqueueEvent( id );
}

void SolegySessionManager::EnqueueConnectionEvent( 
  SolegySessionManager::ConnectionEvent * _event
)
{
  m_ConnectionEventProcessor->EnqueueEvent( _event );
}

class OnProcessConnectionEventRewind : public PThread
{
public:
  OnProcessConnectionEventRewind(
    SolegySessionManager * manager,
    EQ::EventQueue & eq,
    SolegySessionManager::ConnectionEvent * evt ) : PThread( 1024 * 2 ), m_EventQueue(eq)
  {
    m_Manager = manager;
    m_Event = evt;
    Resume();
  }

  void Main()
  {
    m_Manager->OnProcessConnectionEvent( m_EventQueue, (INT)m_Event );
  }

  SolegySessionManager * m_Manager;
  SolegySessionManager::ConnectionEvent * m_Event;
  EQ::EventQueue & m_EventQueue;
};


void SolegySessionManager::OnProcessConnectionEvent( EQ::EventQueue & eq, INT _event )
{
  ConnectionEvent * evt = reinterpret_cast<ConnectionEvent *>(_event);
  if( evt != NULL )
  {
    switch( evt->m_Type )
    {
    case ConnectionEvent::START:
    {
      if( !m_RTTSSessionListMutex.Wait(100) )
      {
        if( evt->m_RetryCount < 5 )
        {
          evt->m_RetryCount++;
          new OnProcessConnectionEventRewind( this, eq, evt );
        }else
        {
          LOG( LogError(), "!!! UNABLE TO ACQUIRE RTTS SESSION LIST MUTEX !!! SolegySessionManager::OnProcessConnectionEvent()" );
          _exit(-1);
        }
        return;
      }
      m_RTTSSessionList.SetAt( evt->m_Session->GetLocalSessionId().c_str(), evt->m_Session );
      m_RTTSSessionListMutex.Signal();
      evt->m_Session->InternalStart( evt->m_SIPMessage );
      break;
    }
    case ConnectionEvent::STOP:
      evt->m_Session->InternalStop( evt->m_SIPMessage );
      break;
    case ConnectionEvent::CALLSTART:
      evt->m_Session->InternalOnCallStart();
      break;
    case ConnectionEvent::CALLSTOP:
      evt->m_Session->InternalOnCallStop();
      break;
    case ConnectionEvent::DUMPCAT:
      evt->m_Session->InternalOnDumpCallAuditTrail();
      break;
    case ConnectionEvent::TRANSFERREJECT:
      evt->m_Session->InternalOnTransferReject( evt->m_SIPMessage );
      break;
    }
  }
  delete evt;
}

class OnProcessEventRewind : public PThread
{
public:
  OnProcessEventRewind(
    SolegySessionManager * manager,
    EQ::EventQueue & eq,
    PString * _event ) : PThread( 1024 * 2 ), m_EventQueue(eq)
  {
    m_Manager = manager;
    m_Event = _event;
    Resume();
  }

  void Main()
  {
    m_Manager->OnProcessEvent( m_EventQueue, (INT)m_Event );
  }

  SolegySessionManager * m_Manager;
  PString * m_Event;
  EQ::EventQueue & m_EventQueue;
};

void SolegySessionManager::OnProcessEvent( EQ::EventQueue & eq, INT _event )
{
  PString * id = reinterpret_cast<PString *>( _event );
  if( id == NULL )
    return;

  int retryCount = 0;
  if( id->Left(2) == "^~" )
  {
    PString retryStr((*id)[2]); 
    retryCount = retryStr.AsInteger();
    *id = id->Mid( 3 );
  }

  SolegySession * session = NULL;

  if( !m_RTTSSessionListMutex.Wait( 100 ) )
  {
    if( retryCount < 5 )
    {
      PStringStream newId;
      newId << "^~" << retryCount + 1 << *id;
      *id = newId;
      new OnProcessEventRewind( this, eq, id );
    }else
    {
      LOG( LogError(), "!!! UNABLE TO ACQUIRE RTTS SESSION LIST MUTEX !!! SolegySessionManager::OnProcessEvent()" );
      _exit( -1 );
    }
    return;
  }

  session = m_RTTSSessionList.GetAt( *id );

  if( session != NULL )
  {
    if( session->GetState() == SolegySession::TERMINATED )
    {
      LOG( session->GetB2BUAConnection()->LogInfo(), "*** SOLEGY SESSION TERMINATED ***" );
      for(;;)
      {
        PString * packet = session->DequeuePacket();
        if( packet != NULL )
        {
          LOG( session->GetB2BUAConnection()->LogInfo(), "*** CONSUMING QUEUED PACKET *** " << *packet );
          delete packet;
        }else
        {
          break;
        }
      }

      m_RTTSSessionList.RemoveAt( session->GetLocalSessionId().c_str() );
    }else
    {
      session->ProcessEvent();
    }
  }

  m_RTTSSessionListMutex.Signal();
  delete id;
}

BOOL SolegySessionManager::DumpCATLog( const char * log )
{
  PWaitAndSignal lock( m_CATMutex );
  PTime now;
  if( now.GetDay() !=  m_CATDate.GetDay() )
  {
    m_CATDate = now;
    OpenCATLog();
  }

  return m_CATLog->WriteLine( log );
}

BOOL SolegySessionManager::OpenCATLog()
{ 
  PWaitAndSignal lock( m_CATMutex );
  
  OStringStream m;
  m << m_CATDIR + "/CAT" << m_CATDate.GetYear() << m_CATDate.GetMonth() << m_CATDate.GetDay();

  PFilePath fp( m.str() ); 
  
  delete m_CATLog;
  m_CATLog = new PTextFile( fp, PFile::ReadWrite );
  m_CATLog->SetPosition(0, PFile::End);

  return TRUE;
}

BOOL SolegySessionManager::AnnounceRTBEError(
  const OString & errorPacket,
  SolegySession * session,
  const OString & eventId,
  const OString & promptDir,
  const OString & language
)
{
  /*
  1001	Invalid host  	//The originating host's name is not registered under any Group.  
  1002	Brand Service undefined 	//There is no Brand Service defined for the given host
  1003	Group inactive 	//Group is inactive; 
  1004	Brand inactive 	//Brand is inactive. 
  1005	Insufficient balance 	//The Group's credit limit + balance is less than zero. The Group has consumed beyond its allowed limit. 
  1006	Insufficient balance 	//The Brand's credit limit + balance is less than zero. The Brand has consumed beyond its allowed limit. 
  1007	Pin nonexistent 	//Invalid Account 
  1008	PIN not roaming 	//Account is not allowed to roam 
  1009	Insufficient balance 	//The Account's credit limit + balance is less than zero. The Account has consumed beyond its allowed limit. 
  1010	Expired PIN 	//Account has already expired 
  1011	<status> PIN 	//Account is . Status may be inactive
  1012	EventListener initiated failure on Auth: 	//The specified EventListener met an exception 
  1013	Carrier is not in cache anymore 	//Carrier is not in cache anymore 
  1014	Error encountered on SIGNIN 	//Timeout on SIGNIN 
  1015	Incorrect PinDNIS dialing rules 	//Incorrect PinDNIS dialing rules 
  1016	Timeout 	//Last Activity exceeds 60 secs 
  1017	Call Cancelled after Call Auth 	//call is STOPPED by the RtbeClient after the Auth process 
  1018	RTTS is in the process of shutting down 	//RTTS server is in the process of shutting down 
  1022	System Encountered a Fatal Exception 	//Problem database connection 
  1023	Database Problem	RTBE Database Exception. //Possible socket connection problem.
  1032	Carrier's Group ID and Brand Service's Group ID are not equal 	//A Brand Service based on the Carrier's Originating Host is defined in another Group 
  1111	General Proxy Error 	//General Proxy Error 
  2001	Cannot complete call  	//Invalid command/protocol sequence  
  2002	PIN not entered 	//Account is not specified 
  2006	EventListener initiated failure on Signin: [Actual error message found in logs] 	//The specified EventListener met an exception 
  2007	Pin nonexistent 	//Invalid Account 
  2008	PIN not roaming Account 	//Account is not allowed to roam 
  2009	Insufficient balance 	/The Account's credit limit + balance is less than zero. The Account has consumed beyond its allowed limit. 
  2010	Expired PIN 	//Account has already expired 
  2011	<status> PIN 	//Account is . Status may be inactive
  2012	Expired PIN. Usage Expiration 	//Account usage expiration date has been reached. 
  2013	pin status was changed to DELETED while still in use 	//Administrator chaned the pin to DELETED
  2014	Error encountered on SETUP 	//Timeout on SETUP 
  2015	Username nonexistent 	//No record of this username was found 
  2016	Digest Not Equal 	//Digest does not match 
  2017	No accounts for username 	//No accounts is registered to the username 
  2018	pin status was changed to EXPIRED while still in use 	//Administrator chaned the pin to EXPIRED
  2019	No USERID for Subsciption Account 	//Subscription account is not registered to a RTBE User 
  2020	Call Cancelled after Call Signin 	//call is STOPPED by the RtbeClient after the Signin process 
  2021	pin status was changed to INACTIVE while still in use 	//Administrator chaned the pin to inactive
  2022	No updated Exchange Rate found for the defined Brand Service Currency	//Currency is either expired or non-existent
  2023	No udpated Exchange Rate found for the defined Account Currency	//Currency is either expired or non-existent
  2025	Brandservice mapped to account is not existing 	//The Brand Service assigned to the Account is non-exsitent or does not belong to the Brand owning the Account 
  3001	Invalid Command Sequence  	//Invalid command/protocol sequence  
  3002	Incorrect inbound dialing rules 	//Erroneous inbound dialing rule 
  3003	Exchange code blacklisted 	//The exchange code is blacklisted 
  3004	No baserates for PRODUCTCODE 	//No baserate for the product 
  3005	No route 	//No route for the corresponding brandproduct 
  3008	Recursion exceeds SAFECOUNTER 	//Cyclical routing 
  3009	Insufficient Balance 	//Cannot start the call due to insufficient balance 
  3010	No route 	//No route (no carrier route nor group route) for the corresponding groupproduct. 
  3011	No route 	//No route in the terminating group for the corresponding groupproduct. 
  3012	EventListener initiated failure on Setup: 	//The specified EventListener met an exception 
  3013	Invalid date range 	//Invalid date range for routing 
  3014	Error encountered on CALLSTART 	//Timeout on CALLSTART 
  3015	No routes for group to group 	//No route in the terminating group for the corresponding groupproduct. 
  3016	ChargeType Operation NULL 	//No charge type operation was defined. 
  3017	Illegal chargetype operation. 	//Charge type operation is invalid. 
  3018	Terminating Brand reached credit limit. 	//Consumption of brand balance 
  3019	Number not Supported 	//No brand product for dialstring 
  3020	ANI or DNIS length is below minimum 	//ANI or DNIS length is less than the specified minimum length in the originating host's inbound dialing rule 
  3021	Invalid Billingblock or Minimum Chargeable Duration 	//invalid billingblock or minimum chargeable duration field in product 
  3022	Number not supported in terminating group 	//No brand product for terminating group 
  3023	No baserates for GROUPPRODUCTCODE 	//No baserate for group product code 
  3024	No baserates for BRANDPRODUCTCODE 	//No baserate for brand product code 
  3025	Call Cancelled after Call Setup 	//call is STOPPED by the RtbeClient after the Setup process 
  3026	ANI Billing error. 	//ANI is either null or blank Trying to use ANI billing but RTTS was not able to received any ANI from proxy/rtbedebit 
  3027	Insufficient balance for simultaneous use of account 	//Insufficient pin account balance while there are other calls using the pin account 
  3028	No group product for inter-group call 	//No group product defined for a inter-group call 
  3029	No Carrier Code Rate The Carrier Code has no rate 	//Please define a rate for the carrier code 
  3030	DNIS length exceeds maximum 	//DNIS length exceeds maximum length specified in the dialing rule 
  3031	ANI length is below minimum 	//ANI length is less than the specified minimum length in the dialing rule 
  3032	ANI length exceeds maximum 	//ANI length exceeds maximum length specified in the dialing rule 
  3033	ANI code blacklisted 	//ANI is blacklisted by Administrator 
  3034	Query of brandproduct in routes timed out 	//Database is busy. SQL query timed out 
  3035	Query of source blacklist timed out 	//Database is busy. SQL query timed out 
  3036	Query of destination blacklist timed out 	//Database is busy. SQL query timed out 
  3037	Query of routes timedout 	Database is busy. //SQL query timed out 
  3100	No valid agents 	//No valid agents for given DIALSTRING and Brand's domain 
  3101	No contact URL 	//No contact URL under agent's presence 
  3102	No Identity Agent 	//Agent has no identity 
  3103	No Identity 	//No identity found for given identity ID 
  3104	Identity disabled 	//Identity is disabled 
  3105	No Availability 	//Identity has no availability 
  3106	Not available. 	//Identity is not available for reason specified 
  3107	Identity2 is not equal to zero 	Availability's identity 2 is not equal to zero 
  3108	No Identity Presence 	//No identity's presence for the given identity ID 
  3109	No Agent for FORWARD TO PRESENCE 	//No agent found for status FORWARD TO PRESENCE 
  3110	Agent for FORWARD TO PRESENCE is disabled 	//Agent for FORWARD TO PRESENCE is disabled 
  3111	Agent is Status FORWARD TO PRESENCE again 	//Status of agent of FORWARD TO PRESENCE is FORWARD TO PRESENCE again 
  3112	No agent name 	//No agent name defined in agent's information 
  3113	No contact URL for Agent in FORWARD TO PRESENCE 	//No contact URL under agent's presence 
  3114	Disabled agent 	//Agent is disabled 
  3115	PAM Contact URL has invalid format 	//PAM Contact URL has invalid format 
  4001	Cannot complete call  	//Invalid command/protocol sequence  
  4002	Warning: Account Depleted. Insufficient Balance 	//Account balance is insufficient 
  4003	ASimultaneous Access Reached Maximum 	//Access to the account is greater than the allowed simultaneous access. 
  4004	EventListener initiated failure on Callstart: [Actual error message found in logs] 	//The specified EventListener met an exception 
  4005	Maximum Transaction Quantity Reached 	//Wholesale call exceeded the maximum transaction quantity 
  4006	Maximum Allowed Duration Reached 	//Debit call exceeded the TIMELEFT. 
  4007	MTQ of service reached 	//Debit Call exceeded the maximum transaction quantity of either the groupservice or brandservice
  4008	Call Cancelled after Call Start 	//call is STOPPED by the RtbeClient after the CALLSTART process 
  4014	Error encountered on CALLSTOP 	//Timeout on CALLSTOP 
  5001	Cannot complete call  	//Invalid command/protocol sequence  
  5002	Insufficient balance 	//Insufficient balance + credit limit 
  5003	Proxy timed out or restarted 	//Proxy timed out or restarted (serial changed). 
  5004	RTTS shutdown 	//Abnormal Shutdown of RTTS 
  5005	EventListener initiated failure on Callstop: [Actual error message found in logs] 	//The specified EventListener met an exception 
  6000	Cannot complete call  	//Rtbe program error  
  6001	Proxy was restarted or has changed serial 	//Proxy has changed serial or was restarted 
  6002	Unable to create stash directory for incomplete cdrs 	//CDRS dir was set as read only 
  6003	Brand Product Code is empty. 	//no brand product code 
  6004	Warning: RTTS Shutdown 	//Abnormal Shutdown of RTTS 
  6005	Warning: Forced RTTS Shutdown 	//Forced Shutdown of RTTS 
  6006	Invalid Packet Format 	//Quotes or Double Quotes was found in the Packet Data 
  6007	Cdr was not uploaded to the database 	  

  8000	Unseized Call	
  8001	Connect Timeout	
  8002	Trunk Busy	
  8003	Channel Busy	
  8004	Unsupported Media	
  8005	Not Found	
  8006	No Media	
  8007	Media Timeout	
  8008	Not Available	
  8009	Remote Busy	
  8010	Remote Bad Number	
  8011	No Answer	
  8012	Time Exceeded	//The call's Maximum Transaction Quantity (MTQ) has been reached 1. Check if the account still has sufficient balance. 2. If your business goals warrant it, you may increase Brand Service MTQ or Group Service MTQ."
  8013	Declined	
  8014	Invalid	
  8015	Not In Service	
  8016	SIT	
  8017	No Dial Tone	
  8018	Auth Failed	
  8019	Auth Rejected	
  8020	Error	
  8021	ErrorFailed	
  8022	Cancelled 	//Call cancelled by terminating gateway 
  8023	Unauthorized User 	//Originating username has no corresponding account entry 
  8024	abandonned 	//call abandoned by originating gateway or caller 
  8026	ErrorAuthInvalid 	//Wrong username/password in SIP AUTH 
  8028	Service Unavailable	//The server is temporarily unable to process the request due to a temporary overloading or maintenance of the server
  8080	Warning: Proxy Ping timeout 	//Proxy ping timeout. Rtts finalize the session and estimated the duration. 
  8081	Unable to terminate to any of the routes 	//failed to terminate to all terminating hosts 
  8082	Failed to terminate to terminating Group 	//failed to terminate to the terminating group specified in the switch log 
  8100	Warning: Proxy serial changed 	//proxy was restarted 
  8101	Abandoned 	//Call abandoned by originating gateway or caller 
  8888	Operation Timeout or ICMP Port Unreachable 	//Rtbe Server is unreachable. 
  */

  BOOL found = FALSE;
  OString error;
  SIPURI target;
  if( SolegyParser::ParseHeader( "ERROR", error, errorPacket ) )
  {
    OStringArray tokens = error.Tokenise( " " );
    if( tokens.GetSize() > 1 )
    {
      SIPURI wildcard( "file:" + tokens[0] );
      if( m_CustomErrorPrompts.FindRoute( wildcard, target ) )
        found = TRUE;
    }
  }
  
  if( found )
  {
    OStringStream path;
    path << promptDir << "/" << language << "/" << target.GetHost();
    PFilePath voiceFilePath = path.str().c_str();
    SolegyPromptManager ivr( session );
    ivr.IVRAnnounce( eventId, static_cast<const char *>(voiceFilePath), 500, 1000 );
  }else
  {
    OStringStream path;
    path << promptDir << "/" << language << "/" << "cant_complete.wav";
    PFilePath voiceFilePath = path.str().c_str();
    SolegyPromptManager ivr( session );
    ivr.IVRAnnounce( eventId, static_cast<const char *>(voiceFilePath), 500, 1000 );
  }
 
  return TRUE;
}




