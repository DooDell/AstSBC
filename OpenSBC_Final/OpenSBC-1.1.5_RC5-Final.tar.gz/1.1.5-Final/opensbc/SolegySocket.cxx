/*
 *
 * SolegySocket.cxx
 *
 * Open SIP Stack ( OSS )
 *
 * Copyright (c) opensipstack.org.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either expressed or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is OpenSIPStack.
 *
 * The Initial Developer of the Original Code is opensipstack.org.
 *
 * The author of this code is Joegen E. Baclor
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * The OpenSIPStack Library includes some GPL/LGPL code libraries that MAY be 
 * enabled at compile time using the --enable-gpllibs configure switch.  If
 * enabled, the content of this file is published under the terms of GNU 
 * General Public License Version 2.  For a detailed list of the available
 * GPL code, see $(opensipstack)/gnu/README file.
 *
 * $Log: SolegySocket.cxx,v $
 * Revision 1.19  2009/04/14 02:00:10  joegenbaclor
 * Reverting Thread-based transport
 *
 * Revision 1.16  2009/03/13 02:26:19  joegenbaclor
 * In this revision, we moved listener configuration to its own
 * page allowing all listeners to be configured seperately.
 * Previous behavior only allowed the main listener to be configured.
 * We have also added a out of dialog handler in the backdoor trunk
 * to allow unsolcited messages like OPTIONS and NOTIFY to passthrough.
 * Both of these functionalities are still under testing.
 *
 * Revision 1.15  2009/02/09 01:30:02  joegenbaclor
 * minor tweaks
 *
 * Revision 1.14  2009/02/06 09:50:38  joegenbaclor
 * Added email alert notification support
 *
 * Revision 1.13  2009/02/03 05:58:06  joegenbaclor
 * Added ability to not send PING for aggregated RTTS sessions
 *
 * Revision 1.12  2009/01/25 04:46:05  joegenbaclor
 * Introduced capability to use only the RTTS server with the lowest load
 *
 * Revision 1.11  2009/01/16 03:46:33  joegenbaclor
 * Marking DumpCDRRecon and SolegySocket::Close bugfix
 *
 * Revision 1.10  2009/01/15 03:16:57  joegenbaclor
 * added close function for solegy sockets to allow other modules to explicitly delete the udp socket when used outside of the manager
 *
 * Revision 1.9  2008/12/31 05:04:50  joegenbaclor
 * Introduced mutex for Solegy socket read-write operations
 *
 * Revision 1.8  2008/10/22 05:06:25  joegenbaclor
 * Added MPL License Header
 *
 *
 */

#include "SolegySocket.h"
#include "SolegyParser.h"
#include "Solegy.h"
using namespace SOLEGY;

#define new PNEW
#define RTTS_UDP_BUFFER_SIZE 65536
#define RTTS_DEFAULT_PORT 7823
PMutex SolegySocket::m_ReadWriteMutex;

SolegySocket::SolegySocket(
  SolegySessionManager * manager,
  const PIPSocket::Address & serverAddress,
  WORD serverPort,
  const PTimeInterval & expire,
  BOOL enablePingTimer
)
{
  m_Manager = manager;
  m_IsReliableTransport = TRUE; /// lets be optimistic that RTTS is alive
  m_PingExpireInterval = expire;
  m_PingRetryInterval = 500;
  m_Pinging = FALSE;
  m_PINGSequence = 0;
  m_ServerSessionLoad = 0;
  m_Socket = NULL;
  m_Enabled = TRUE;
  m_RTTSServerAddress = serverAddress;
  m_RTTSServerPort = serverPort == 0 ? RTTS_DEFAULT_PORT : serverPort;

  if( enablePingTimer )
  {
    m_PingTimer = PTimer( expire );
    m_PingTimer.SetNotifier( PCREATE_NOTIFIER( OnPingTimer ) ); 
  }
}

static void SetRTTSMinBufferSize(PUDPSocket & sock, int buftype)
{
  int sz = 0;
  if (sock.GetOption(buftype, sz)) {
    if (sz >= RTTS_UDP_BUFFER_SIZE)
      return;
  }

  if (!sock.SetOption(buftype, RTTS_UDP_BUFFER_SIZE)) {
    PTRACE(1, "RTTS: SetOption(" << buftype << ") failed: " << sock.GetErrorText());
  }
}

BOOL SolegySocket::Open(
  const PIPSocket::Address & iface,
  WORD portBase, 
  WORD portMax,
  PSTUNClient * stun
)
{
  PIPSocket::Address localAddress = iface;
  WORD localDataPort    = (WORD)(portBase&0xfffe);

  delete m_Socket;
  m_Socket = NULL;

  if( stun != NULL )
  {
    if( stun->CreateSocket( m_Socket ) )
      m_Socket->GetLocalAddress( localAddress, localDataPort );
    else 
    {
      PTRACE(1, "RTTS: STUN could not create RTTS socket.");
      return FALSE;
    }
  }

  if( m_Socket == NULL )
  {
    m_Socket = new PUDPSocket();
    while (!m_Socket->Listen(localAddress, 1, localDataPort))
    {
      m_Socket->Close();
      if ((localDataPort > portMax) || (localDataPort > 0xfffd))
      {
        delete m_Socket;
        m_Socket = NULL;
        return FALSE; // If it ever gets to here the OS has some SERIOUS problems!
      }
      localDataPort++;
    }
  }

  SetRTTSMinBufferSize(*m_Socket, SO_RCVBUF);
  SetRTTSMinBufferSize(*m_Socket, SO_SNDBUF);

  
  return TRUE;
}

BOOL SolegySocket::Close( BOOL autoDeleteSocket )
{
  if( m_Socket == NULL )
    return FALSE;

  m_Socket->Close();
  if( autoDeleteSocket )
  {
    delete m_Socket;
    m_Socket = NULL;
  }
  return TRUE;
}

void SolegySocket::ValidateServer()
{
  m_Pinging = FALSE;
  OnPingTimer( m_PingTimer, 0 );
}

BOOL SolegySocket::Write(
  std::string & packet
)
{
  PWaitAndSignal lock( SolegySocket::m_ReadWriteMutex );
  if( m_Socket == NULL )
    return FALSE;
  m_Socket->WriteTo( packet.c_str(), (int)packet.length(), m_RTTSServerAddress, m_RTTSServerPort );
  return TRUE;
}

void SolegySocket::OnPingTimer( PTimer & /*timer*/, INT )
{
  PWaitAndSignal lock( m_PingMutex );

  if( m_Pinging )
  {
    if( m_PingRetryInterval > 5000 )
    {
      m_PingRetryInterval = 500;
      m_Pinging = FALSE;
      OnPingTimeout();
      return;
    }

    Write( m_CurrentPingRequest );
    m_Pinging = TRUE;
    m_PingRetryInterval =  m_PingRetryInterval * 2;
    m_PingTimer.SetInterval( m_PingRetryInterval );
    m_PingTimer.Resume();   
    return;
  }

  OStringStream strm;
  strm << "PING" << endl;
  strm << "SERIAL=" << PProcess::Current().GetProcessID() << endl;
  strm << "EXPIRES=" << m_PingExpireInterval.GetSeconds() << endl;
  strm << "SEQ=" << m_PINGSequence++ << endl;
  m_CurrentPingRequest = strm.str();
  
  PTRACE( 3, "RTTS: !!!VALIDATING!!! RTTS Server " << m_RTTSServerAddress );

  Write( m_CurrentPingRequest );

  m_Pinging = TRUE;
  m_PingTimer.SetInterval( m_PingRetryInterval );
  m_PingTimer.Resume();
}

void SolegySocket::OnPINGACK( const char * ack )
{
  PTRACE( 3, "RTTS: !!!VALIDATED!!! RTTS Server " << m_RTTSServerAddress );
  PWaitAndSignal lock( m_PingMutex );
  m_PingTimer.Stop();
  m_Pinging = FALSE;
  m_IsReliableTransport = TRUE;

  OString sn;
  if( SolegyParser::ParseHeader( "SERIAL", sn, ack ) )
  {
    if( m_ServerSN.IsEmpty() )
    {
      m_ServerSN = sn;
    }else
    {
      if( m_ServerSN != sn )
      {
        m_ServerSN = sn;
        OnServerSNChanged();
      }
    }
  }


  /// reset the PING Timer
  m_PingTimer.SetInterval( m_PingExpireInterval.GetMilliSeconds() );
  m_PingTimer.Resume();
}

void SolegySocket::OnServerSNChanged()
{
  PTRACE( 1, "RTTS: !!!SERIAL CHANGED!!! RTTS Server " << m_RTTSServerAddress );
}

void SolegySocket::OnPingTimeout()
{
  PTRACE( 1, "RTTS: !!!KEEP ALIVE TIMEOUT!!! RTTS Server " << m_RTTSServerAddress );
  m_IsReliableTransport = FALSE;
  m_PingTimer.SetInterval( 60000 ); // retry after 1 minute
  m_PingTimer.Resume();
}

BOOL SolegySocket::MarkLastFatalTimeout( const OString & sessionId, const OString & method )
{
  PWaitAndSignal lock( m_TimeoutReportMutex );
  PTime now;
  OStringStream rec;
  rec << now << " " << method << " SID: " << sessionId << " LOAD: " << GetServerSessionLoad();
  m_TimeoutReportList.AppendString( rec.str() );
  
  
  if( m_TimeoutReportList.GetSize() > 20 && PTimer::Tick().GetMinutes() - m_LastFatalTimeout.GetMinutes() > 60 )
  {
    m_LastFatalTimeout = PTimer::Tick();
    PString subject = "RTTS " + GetRTTSSeverAddress().AsString() + " 8888 Alert";
    PStringStream body;
    for( int i = 0; i < m_TimeoutReportList.GetSize(); i++ )
    {
      body << i+1 << ". " << m_TimeoutReportList[i] << endl;
    }
    m_Manager->SendMailAlert( subject, body, "SMTP-Alert-Mailing-List" );
    m_TimeoutReportList.RemoveAll();
  }
  return TRUE;
}

