/*
 *
 * SBCSwitchConnection.cxx
 *
 * Open SIP Stack ( OSS )
 *
 * Copyright (c) opensipstack.org.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either expressed or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is OpenSIPStack.
 *
 * The Initial Developer of the Original Code is opensipstack.org.
 *
 * The author of this code is Joegen E. Baclor
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * The OpenSIPStack Library includes some GPL/LGPL code libraries that MAY be 
 * enabled at compile time using the --enable-gpllibs configure switch.  If
 * enabled, the content of this file is published under the terms of GNU 
 * General Public License Version 2.  For a detailed list of the available
 * GPL code, see $(opensipstack)/gnu/README file.
 *
 * $Log: SBCSwitchConnection.cxx,v $
 * Revision 1.4  2009/06/09 07:11:49  joegenbaclor
 * added ivr leg class
 *
 * Revision 1.3  2009/06/03 11:57:16  joegenbaclor
 * Checking in MOH feature
 *
 * Revision 1.2  2009/05/29 09:31:32  joegenbaclor
 * Added Switch IVR Classes
 *
 * Revision 1.1  2009/05/27 12:40:34  joegenbaclor
 * Initial upload of switch related classes
 *
 *
 */

#include "SBCSwitchConnection.h"
#include "SBCSwitchLeg1.h"
#include "SBCSwitchLeg2.h"
#include "SBCSwitchIVRLeg.h"


#define new PNEW
using namespace SWITCH;
using namespace B2BUA;

SBCSwitchConnection::SBCSwitchConnection(
  B2BUAEndPoint & ep,
  const OString & sessionId
) : SBCConnection( ep, sessionId )
{
  m_SwitchMedia = NULL;
  SetMediaProxyIfPrivate( FALSE );  ///Let's always start with media proxy enabled
}

SBCSwitchConnection::~SBCSwitchConnection()
{
}

void SBCSwitchConnection::OnSessionEvent(
  SIPSessionEvent & sessionEvent
)
{
  if( sessionEvent.GetEvent() < SBCConnection::NumCallControlEvent )
  {
    SBCConnection::OnSessionEvent( sessionEvent );
    return;
  }

  switch( sessionEvent.GetEvent() )
  {
  case SBCSwitchConnection::Event_IVRAnswer:
    {
      SBCSwitchIVRLeg * ivr = dynamic_cast<SBCSwitchIVRLeg*>(GetLeg2Call());
      if( ivr != NULL )
        ivr->OnIVRAnswerCall();
    break;
    }
  default:
    break;
  }
}

void SBCSwitchConnection::AddRoute( 
  const SIPURI & route, 
  const SIPMessage * invite 
)
{
  if( route.GetScheme() != "ivr" )
  {
    SBCConnection::AddRoute( route, invite );
    return;
  }
  PWaitAndSignal lock( m_RoutesMutex );   
  m_Routes.Append( new SIPURI( route ) ); 
}

void SBCSwitchConnection::OnSetupOutbound( 
  const SIPMessage & inboundInvite 
)
{
  if( m_SessionState == Disconnected )
    return;

  B2BUserAgent & b2bua = 
    (B2BUserAgent &)GetSessionManager().GetUserAgent();

  SIPMessage outboundInvite = inboundInvite;
  outboundInvite.ClearInternalHeaders();
  outboundInvite.SetEncryption( FALSE );
  

  OString callId = outboundInvite.GetCallId() + "-" + B2BUAConnection::GenerateCallIdExtension();
    
  B2BUACall * call = NULL; 
  {
    ProfileUA defaultProfile = b2bua.GetDefaultProfile();
    defaultProfile.SetUserData( this );
    call = (B2BUACall*)this->GetSessionManager().CreateClientSession( defaultProfile, callId );
  }

  if( call == NULL )
  {
    Destroy();
    return;
  }

  call->SetLogContextId( callId );

  SIPSession::GCRef autoRef = GCCREATEREF( call, "SBCSwitchConnection::OnSetupOutbound", "B2BUACall Leg 2" );
  GCAssertNull( autoRef );

  if( GetSessionState() == B2BUAConnection::Transferring )
  {
    LOG_CONTEXT( LogInfo(), inboundInvite.GetCallId(), "*** CALL TRANSFER ***" );
    B2BUACall * callToTransfer = GetCallTransferIndex() == 0 ?
      GetLeg1Call() : GetLeg2Call();

    callToTransfer->SetReferrerCall();

    call->SetLegIndex( GetCallTransferIndex() );
    call->SetTransferedCall( callToTransfer );
    call->SetReferredCall();
    AttachCall( callId, call, GetCallTransferIndex() );
  }else
  {
    AttachCall( callId, call );
  }

  call->OnSetupOutbound( outboundInvite, *this );
}

void SBCSwitchConnection::OnConnected(
  B2BUACall & call,
  SIPMessage & msg 
)
{
  SBCConnection::OnConnected( call, msg );

  ///create the class 5 features and start detecting DTMF
  OnCreateCallFeatures( this );
  
  SBCSwitchLeg1 * leg1 = dynamic_cast<SBCSwitchLeg1*>(GetLeg1Call());
  if( leg1 != NULL )
    leg1->OnDTMFStartFCodeDetect();

  SBCSwitchLeg2 * leg2 = dynamic_cast<SBCSwitchLeg2*>(GetLeg2Call());
  if( leg2 != NULL )
    leg2->OnDTMFStartFCodeDetect(); 
}

void SBCSwitchConnection::OnDisconnected(
  B2BUACall & call,
  const SIPMessage & msg 
)
{
  if( m_SwitchMedia != NULL )
  {
    m_SwitchMedia->BridgeDestroy();
    m_SwitchMedia->SendBye();
    m_SwitchMedia->Destroy();
    m_SwitchMedia = NULL;
  }
}

void SBCSwitchConnection::OnDestroySession()
{
  SBCConnection::OnDestroySession();
}

BOOL SBCSwitchConnection::OnIncomingSDPOffer(
  B2BUACall & call,
  const SIPMessage & message
)
{
  return m_SwitchMedia->OnSwitchIncomingSDPOffer( this, dynamic_cast<SBCB2BUACall*>(&call), message );
}

BOOL SBCSwitchConnection::OnIncomingSDPAnswer(
  B2BUACall & call,
  const SIPMessage & message
)
{
  return m_SwitchMedia->OnSwitchIncomingSDPAnswer( this, dynamic_cast<SBCB2BUACall*>(&call), message );
}

BOOL SBCSwitchConnection::OnRequireSDPOffer(
  B2BUACall & call,
  SIPMessage & offer
)
{
  return m_SwitchMedia->OnSwitchRequireSDPOffer( this, dynamic_cast<SBCB2BUACall*>(&call), offer );
}

BOOL SBCSwitchConnection::OnRequireSDPAnswer(
  B2BUACall & call,
  const SIPMessage & /*offer*/,
  SIPMessage & answer
)
{
  return m_SwitchMedia->OnSwitchRequireSDPAnswer( this, dynamic_cast<SBCB2BUACall*>(&call), answer );
}

PIPSocket::Address SBCSwitchConnection::GetSDPAddress( const PIPSocket::Address & iface )const
{
  SIPTransportManager * transportManager = GetTransportManager();

  if( transportManager->GetUDPTransport() == NULL )
    return iface;

  PIPSocket::Address sdpAddress; WORD dummyPort;
  if( !transportManager->GetListenerAddress( SIPTransport::UDP, iface, sdpAddress, dummyPort ) )
    return iface;
 
  return sdpAddress;
}

void SBCSwitchConnection::OnReceivedFCodeEvent(
  SBCB2BUACall & call,
  const OString & fCode
)
{
  LOG( LogInfo(), "--- Received FCode(" << fCode << ") from LEG " << call.GetLegIndex() );
  
  SBCB2BUACall * ownerCall = dynamic_cast<SBCB2BUACall *>(&call);
  SBCSwitchCallFeature * feature = OnGetCallFeature( ownerCall,  fCode );
  if( feature == NULL )
  {
    LOG( LogWarning(), "--- No feature available to handle FCode(" << fCode << ") from LEG " << call.GetLegIndex() );
  }else
    (*feature).Execute( ownerCall );
}










