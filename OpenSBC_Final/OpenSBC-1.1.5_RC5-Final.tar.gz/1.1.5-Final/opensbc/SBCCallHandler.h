/*
 *
 * SBCCallHandler.h
 * 
  * Open SIP Stack ( OSS )
 *
 * Copyright (c) opensipstack.org.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either expressed or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is OpenSIPStack.
 *
 * The Initial Developer of the Original Code is opensipstack.org.
 *
 * The author of this code is Joegen E. Baclor
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * The OpenSIPStack Library includes some GPL/LGPL code libraries that MAY be 
 * enabled at compile time using the --enable-gpllibs configure switch.  If
 * enabled, the content of this file is published under the terms of GNU 
 * General Public License Version 2.  For a detailed list of the available
 * GPL code, see $(opensipstack)/gnu/README file.
 *
 * $Log: SBCCallHandler.h,v $
 * Revision 1.8  2009/01/12 04:50:01  joegenbaclor
 * We modified two things in this commit.  The first is to handle CANCEL requests arriving before an in INVITE is sent out to the upstream termination. Previous implementation did not handle this case properly which results to the call still being attempted even after it was aborted by the caller.  The second bug fix is we introduced m_LocallyAuthenticated in the B2BUAConnection layer so that the SBC can determine cases where both the SBC and the upstream termination both challenged the INVITE resulting to a double authentication.  Although RFC 3261 allows this, we yet have to see UAs that can handle authentication from two realms.  In most cases this call would end up in bad state so its better to just destroy the connection when this happens.
 *
 * Revision 1.7  2008/08/20 12:56:39  joegenbaclor
 * Removed sending of individual events for IVR User Input
 * Some enhancements related to call audit trail
 *
 * Revision 1.6  2007/11/20 07:06:50  joegenbaclor
 * Added support for Request-URI routing
 *
 * Revision 1.5  2007/11/18 16:53:51  joegenbaclor
 * Added support for merged requests ending up in the same connection
 *
 * Revision 1.4  2007/07/07 15:21:17  joegenbaclor
 * Added iproute2 support for linux
 *
 * Revision 1.3  2007/02/09 03:50:30  joegenbaclor
 * 1. Added MaxForwards handling for B2B calls
 * 2. #defined SIP_DEFAULT_MAX_FORWARDS constant
 *
 * Revision 1.2  2007/02/08 13:38:17  joegenbaclor
 * Changed signature of B2BCallInterface::OnIncomingCall to allow for intial rejection
 *  of call before routing is performed.
 *
 * Revision 1.1  2006/08/14 10:04:59  rcolobong
 * Convert B2BUA to SBC
 * Support MP logging
 *
 * Revision 1.2  2006/06/29 05:09:12  joegenbaclor
 * Changed OnOutgoingCall invite parameter from const to none const to give a
 * chance for applications to modify the outbound invite before being sent to the transport
 *
 * Revision 1.1  2006/06/20 09:58:11  joegenbaclor
 * *** empty log message ***
 *
 *
 */

#ifndef B2BCALLHANDLER_H
#define B2BCALLHANDLER_H

#include "OpenSBC.h"

class SBCCallHandler : public B2BCallInterface
{
  PCLASSINFO( SBCCallHandler, B2BCallInterface );

public:
  SBCCallHandler( 
    OpenSBC & ua 
  );

  ~SBCCallHandler();

  virtual CallSession::AnswerCallDeniedResponse OnIncomingCall(
    B2BUAConnection & connection,
    B2BUACall & call,
    SIPMessage & invite
  );

  virtual void OnOutgoingCall(
    B2BUAConnection & connection,
    B2BUACall & call,
    SIPMessage & invite
  );


  virtual void OnCallReinvite(
    B2BUAConnection & connection,
    B2BUACall & call,
    const SIPMessage & invite
  );

  virtual void OnProceeding(
    B2BUAConnection & connection,
    B2BUACall & outboundCall,
    const SIPMessage & proceeding
  );


  virtual void OnAlerting(
    B2BUAConnection & connection,
    B2BUACall & outboundCall,
    const SIPMessage & alerting
  );

  virtual void OnProgress(
    B2BUAConnection & connection,
    B2BUACall & outboundCall,
    const SIPMessage & progress
  );

  virtual void OnRejected(
    B2BUAConnection & connection,
    B2BUACall & outboundCall,
    const SIPMessage & reject
  );

  virtual void OnConnected(
    B2BUAConnection & connection,
    B2BUACall & outboundCall,
    const SIPMessage & connect
  );

  virtual void OnDisconnected(
    B2BUAConnection & connection,
    B2BUACall & outboundCall,
    const SIPMessage & bye
  );

  virtual void OnInSessionMessage(
    B2BUAConnection & connection,
    B2BUACall & remoteCall,
    const SIPMessage & request
  );

  virtual BOOL OnReceivedBackDoorMergedInvite(
    B2BUserAgent & userAgent,
    B2BUAConnection & connection,
    B2BUACall & call,
    const SIPMessage & invite
  );

  virtual BOOL OnReceivedMergedInvite(
    B2BUserAgent & userAgent,
    B2BUAConnection & connection,
    B2BUACall & call,
    const SIPMessage & invite
  );

  virtual BOOL OnReceivedMergedCancel(
    B2BUserAgent & userAgent,
    B2BUAConnection & connection,
    B2BUACall & call,
    const SIPMessage & cancel
  );


  virtual BOOL OnReceivedResponseToMergedInvite(
    B2BUserAgent & userAgent,
    B2BUAConnection & connection,
    B2BUACall & call,
    const SIPMessage & response
  );

  virtual BOOL OnReceivedACKToMergedResponse(
    B2BUserAgent & userAgent,
    B2BUAConnection & connection,
    B2BUACall & call,
    const SIPMessage & ack
  );

  virtual BOOL OnReceivedMergedMidDialogMessage(
    B2BUserAgent & userAgent,
    B2BUAConnection & connection,
    B2BUACall & call,
    const SIPMessage & msg
  );

  BOOL DumpCATLog( B2BUAConnection & conn, BOOL rejected );
  BOOL OpenCATLog();

  PINLINE OpenSBC & GetSBC(){ return (OpenSBC &)m_B2BUA; };

protected:
  PTextFile * m_CATLog;
  PTime m_CATDate;
  PMutex m_CATMutex;
};

#endif

