#include "SBCXBaseManager.h"
#include "OSSApplication.h"
#ifdef HAS_XBASE


#ifdef WIN32
#pragma message("*** XBASE Routing Enabled ***")
#endif


#define new PNEW

using namespace Tools;

SBCXBaseManager::SBCXBaseManager()
{
  SIPURI::RegisterScheme( "xbase" );
  m_DBDirectory = OSSApplication::GetApplicationDirectory() + "/xbase";
  if( !PDirectory::Exists( m_DBDirectory ) )
    PDirectory::Create( m_DBDirectory );
  m_LATATable = new LATATable( this );
  m_LATACarrierTable = new LATACarrierTable( this );
  m_NpaNxxTable = new NpaNxxTable( this );
}

SBCXBaseManager::~SBCXBaseManager()
{
  m_LATATable->CloseDataBase();
  m_LATACarrierTable->CloseDataBase();
  m_NpaNxxTable->CloseDataBase();

  delete m_LATATable;
  delete m_LATACarrierTable;
  delete m_NpaNxxTable;

  XBase::DeinitEngine();
}

BOOL SBCXBaseManager::CreateTables()
{
  int rc = m_LATATable->CreateDatabase( FALSE );
  if(  rc != XBase::XBASE_NO_ERROR && rc != XBase::XBASE_FILE_EXISTS )
  {
    PTRACE( 1, "Error Creating LATA Table - " << XBase::GetErrorMessage( rc ) );
    return FALSE;
  }

  rc = m_LATATable->OpenDatabase();
  if(  rc != XBase::XBASE_NO_ERROR )
  {
    PTRACE( 1, "Error Opening LATA Table - " << XBase::GetErrorMessage( rc ) );
    return FALSE;
  }

  m_LATATable->Initialize();

  rc = m_LATACarrierTable->CreateDatabase( FALSE );
  if(  rc != XBase::XBASE_NO_ERROR && rc != XBase::XBASE_FILE_EXISTS )
  {
    PTRACE( 1, "Error Creating LATA Carrier Table - " << XBase::GetErrorMessage( rc ) );
    return FALSE;
  }

  rc = m_LATACarrierTable->OpenDatabase();
  if(  rc != XBase::XBASE_NO_ERROR )
  {
    PTRACE( 1, "Error Opening LATA Carrier Table - " << XBase::GetErrorMessage( rc ) );
    return FALSE;
  }

  m_LATACarrierTable->Initialize();

  rc = m_NpaNxxTable->CreateDatabase( FALSE );
  if(  rc != XBase::XBASE_NO_ERROR && rc != XBase::XBASE_FILE_EXISTS)
  {
    PTRACE( 1, "Error Creating NPA-NXX Carrier Table - " << XBase::GetErrorMessage( rc ) );
    return FALSE;
  }

  rc = m_NpaNxxTable->OpenDatabase();
  if(  rc != XBase::XBASE_NO_ERROR )
  {
    PTRACE( 1, "Error Opening NPA-NXX Carrier Table - " << XBase::GetErrorMessage( rc ) );
    return FALSE;
  }

  m_NpaNxxTable->Initialize();

  return TRUE;
}


//////LATA//////
LATATable::LATATable( SBCXBaseManager * manager )
{
  m_Manager = manager;

  PFilePath dbPath = m_Manager->GetDBDirectory() + "/lata.dbf";
  SetDBPath( dbPath );
  AddField( "LATA", XBaseSchema::FLD_CHAR,     3    );
  AddField( "C_CODE",  XBaseSchema::FLD_CHAR,  3    );
  AddField( "NPA",  XBaseSchema::FLD_CHAR,     3    );
  AddField( "NXX",  XBaseSchema::FLD_CHAR,     3    );
  AddField( "DESC", XBaseSchema::FLD_CHAR,     100    );
  AddIndex( "lata_npa_nxx", "C_CODE-NPA-NXX", TRUE );
}

BOOL LATATable::Initialize()
{
  XBase * xBase = GetDB();
  if( xBase == NULL )
    return FALSE;
  m_LATA = xBase->FieldGetContext( "LATA" );
  m_C_CODE = xBase->FieldGetContext( "C_CODE" );
  m_NPA = xBase->FieldGetContext( "NPA" );
  m_NXX = xBase->FieldGetContext( "NXX" );
  m_DESC = xBase->FieldGetContext( "DESC" );
  return TRUE;
}

//////LATA-CARRIER//////
LATACarrierTable::LATACarrierTable( SBCXBaseManager * manager )
{
  m_Manager = manager;
  PFilePath dbPath = m_Manager->GetDBDirectory() + "/lata_carrier.dbf";
  SetDBPath( dbPath );
  AddField( "LATA", XBaseSchema::FLD_CHAR,     3    );
  AddField( "ROUTE_1",  XBaseSchema::FLD_CHAR,  100    );
  AddField( "ROUTE_2",  XBaseSchema::FLD_CHAR,  100    );
  AddField( "ROUTE_3",  XBaseSchema::FLD_CHAR,  100    );
  AddField( "ROUTE_4",  XBaseSchema::FLD_CHAR,  100    );
  AddField( "ROUTE_5",  XBaseSchema::FLD_CHAR,  100    );
  AddField( "DESC", XBaseSchema::FLD_CHAR,     100    );
  AddIndex( "lata_carrier", "LATA", TRUE );
}

BOOL LATACarrierTable::Initialize()
{
  XBase * xBase = GetDB();
  if( xBase == NULL )
    return FALSE;

  m_LATA = xBase->FieldGetContext( "LATA" );
  m_ROUTE_1 = xBase->FieldGetContext( "ROUTE_1" );
  m_ROUTE_2 = xBase->FieldGetContext( "ROUTE_2" );
  m_ROUTE_3 = xBase->FieldGetContext( "ROUTE_3" );
  m_ROUTE_4 = xBase->FieldGetContext( "ROUTE_4" );
  m_ROUTE_5 = xBase->FieldGetContext( "ROUTE_5" );
  m_DESC = xBase->FieldGetContext( "DESC" );

  return TRUE;
}

//////LATA//////
NpaNxxTable::NpaNxxTable( SBCXBaseManager * manager )
{
  m_Manager = manager;
  PFilePath dbPath = m_Manager->GetDBDirectory() + "/npanxx.dbf";
  SetDBPath( dbPath );
  AddField( "C_CODE",  XBaseSchema::FLD_CHAR,  3    );
  AddField( "NPA",  XBaseSchema::FLD_CHAR,     3    );
  AddField( "NXX",  XBaseSchema::FLD_CHAR,     3    );
  AddField( "DESC", XBaseSchema::FLD_CHAR,     100    );
  AddField( "ROUTE_1",  XBaseSchema::FLD_CHAR,  100    );
  AddField( "ROUTE_2",  XBaseSchema::FLD_CHAR,  100    );
  AddField( "ROUTE_3",  XBaseSchema::FLD_CHAR,  100    );
  AddField( "ROUTE_4",  XBaseSchema::FLD_CHAR,  100    );
  AddField( "ROUTE_5",  XBaseSchema::FLD_CHAR,  100    );
  AddIndex( "npa_nxx", "C_CODE-NPA-NXX", TRUE );
}

BOOL NpaNxxTable::Initialize()
{
  XBase * xBase = GetDB();
  if( xBase == NULL )
    return FALSE;

  m_C_CODE = xBase->FieldGetContext( "C_CODE" );
  m_NPA = xBase->FieldGetContext( "NPA" );
  m_NXX = xBase->FieldGetContext( "NXX" );
  m_DESC = xBase->FieldGetContext( "DESC" );
  m_ROUTE_1 = xBase->FieldGetContext( "ROUTE_1" );
  m_ROUTE_2 = xBase->FieldGetContext( "ROUTE_2" );
  m_ROUTE_3 = xBase->FieldGetContext( "ROUTE_3" );
  m_ROUTE_4 = xBase->FieldGetContext( "ROUTE_4" );
  m_ROUTE_5 = xBase->FieldGetContext( "ROUTE_5" );

  return TRUE;
}

///////////////////////////

/////////CDR TABLE//////////
CDRTable::CDRTable( SBCXBaseManager * manager )
{
  m_Manager = manager;
  PFilePath dbPath = m_Manager->GetDBDirectory() + "/cdr.dbf";
  SetDBPath( dbPath );

  /// Time fields
  AddField( "DATE",  XBaseSchema::FLD_DATE, 8 );
  AddField( "TIME",  XBaseSchema::FLD_INTEGER, 5 );
  AddField( "TIME_200",  XBaseSchema::FLD_INTEGER, 5 );
  AddField( "TIME_BYE",  XBaseSchema::FLD_INTEGER, 5 );

  /// Originating fields
  AddField( "O_CID", XBaseSchema::FLD_CHAR, 100 );   /// The Call-ID
  AddField( "O_RURI", XBaseSchema::FLD_CHAR, 100 );
  AddField( "O_CONTACT", XBaseSchema::FLD_CHAR, 100 );
  AddField( "O_FROM", XBaseSchema::FLD_CHAR, 100 );
  AddField( "O_TO", XBaseSchema::FLD_CHAR, 100 );
  AddField( "O_IDENT", XBaseSchema::FLD_CHAR, 100 ); /// P-Asserted-Identity
  AddField( "O_VIA", XBaseSchema::FLD_CHAR, 100 );   /// Bottom Via
  AddField( "O_TOPVIA", XBaseSchema::FLD_CHAR, 100 ); /// Top Via
  AddField( "O_NEXTVIA", XBaseSchema::FLD_CHAR, 100 ); /// Second Via from Top
  AddField( "O_INGRESS", XBaseSchema::FLD_BOOLEAN, 1 ); /// Ingress proxy URI
  AddField( "O_SRCIP", XBaseSchema::FLD_CHAR, 30 );  /// Source IP of the packet
  AddField( "O_SRCPORT", XBaseSchema::FLD_INTEGER, 5 );  /// Source port of the packet

  /// Terminating Carrier fields
  AddField( "T_CID", XBaseSchema::FLD_CHAR, 100 );
  AddField( "T_RURI", XBaseSchema::FLD_CHAR, 100 );
  AddField( "T_CONTACT", XBaseSchema::FLD_CHAR, 100 );
  AddField( "T_FROM", XBaseSchema::FLD_CHAR, 100 );
  AddField( "T_TO", XBaseSchema::FLD_CHAR, 100 );
  AddField( "T_EGRESS", XBaseSchema::FLD_BOOLEAN, 1 );  /// Egress Proxy URI
  AddField( "T_SRCIP", XBaseSchema::FLD_CHAR, 30 );
  AddField( "T_SRCPORT", XBaseSchema::FLD_INTEGER, 5 );
  AddField( "T_ROUTE_ERR", XBaseSchema::FLD_CHAR, 100 );
  AddField( "T_ROUTE_IDX", XBaseSchema::FLD_INTEGER, 2 );
}

BOOL CDRTable::Initialize()
{
  return FALSE;
}
////////////////////////////

BOOL SBCXBaseManager::FindLATACarrier(
  const OString & dialString,
  OStringArray & routes
)
{
  int len = dialString.GetLength();
  if( len < 11 ) // tooshort
    return FALSE;

  OString key = dialString.Left( len - 4 );

  XBase * rec = m_LATATable->GetDB();
  XBaseIndex * ndx = m_LATATable->GetIndex( "lata_npa_nxx" );

  if( rec == NULL || ndx == NULL )
    return FALSE;

  if( ndx->FindStringKey( key.c_str() ) != XBase::XBASE_FOUND )
  {
    if( key.GetLength() > 3 )
    {
      OString nkey = key.Left( key.GetLength() - 3 );
      nkey = nkey + "000";
      if( ndx->FindStringKey( nkey.c_str() ) != XBase::XBASE_FOUND )
        return FALSE;
    }else
    {
      return FALSE;
    }
  }

  OString lata = rec->FieldGetString( m_LATATable->m_LATA );
  if( lata.IsEmpty() )
    return FALSE;

  rec = m_LATACarrierTable->GetDB();
  ndx = m_LATACarrierTable->GetIndex( "lata_carrier" );

  if( rec == NULL || ndx == NULL )
    return FALSE;

  /// ok we got a LATA
  if( ndx->FindStringKey( lata.c_str() ) != XBase::XBASE_FOUND )
    return FALSE;

  OString route_1 = rec->FieldGetString( m_LATACarrierTable->m_ROUTE_1 ).Trim();
  OString route_2 = rec->FieldGetString( m_LATACarrierTable->m_ROUTE_2 ).Trim();
  OString route_3 = rec->FieldGetString( m_LATACarrierTable->m_ROUTE_3 ).Trim();
  OString route_4 = rec->FieldGetString( m_LATACarrierTable->m_ROUTE_4 ).Trim();
  OString route_5 = rec->FieldGetString( m_LATACarrierTable->m_ROUTE_5 ).Trim();

  if( !route_1.IsEmpty() )
    routes.AppendString( route_1 );

  if( !route_2.IsEmpty() )
    routes.AppendString( route_2 );

  if( !route_3.IsEmpty() )
    routes.AppendString( route_3 );
  
  if( !route_4.IsEmpty() )
    routes.AppendString( route_4 );

  if( !route_5.IsEmpty() )
    routes.AppendString( route_5 );

  return TRUE;
}

BOOL SBCXBaseManager::FindNPANXX(
  const OString & dialString,
  OStringArray & routes
)
{
  int len = dialString.GetLength();
  if( len < 11 ) // tooshort
    return FALSE;

  OString key = dialString.Left( len - 4 );

  XBase * rec = m_NpaNxxTable->GetDB();
  XBaseIndex * ndx = m_NpaNxxTable->GetIndex( "npa_nxx" );

  if( rec == NULL || ndx == NULL )
    return FALSE;

  

  if( ndx->FindStringKey( key.c_str() ) != XBase::XBASE_FOUND )
  {
    if( key.GetLength() > 3 )
    {
      OString nkey = key.Left( key.GetLength() - 3 );
      nkey = nkey + "000";
      if( ndx->FindStringKey( nkey.c_str() ) != XBase::XBASE_FOUND )
        return FALSE;
    }else
    {
      return FALSE;
    }
  }
  OString route_1 = rec->FieldGetString( m_NpaNxxTable->m_ROUTE_1 ).Trim();
  OString route_2 = rec->FieldGetString( m_NpaNxxTable->m_ROUTE_2 ).Trim();
  OString route_3 = rec->FieldGetString( m_NpaNxxTable->m_ROUTE_3 ).Trim();
  OString route_4 = rec->FieldGetString( m_NpaNxxTable->m_ROUTE_4 ).Trim();
  OString route_5 = rec->FieldGetString( m_NpaNxxTable->m_ROUTE_5 ).Trim();

  if( !route_1.IsEmpty() )
    routes.AppendString( route_1 );

  if( !route_2.IsEmpty() )
    routes.AppendString( route_2 );

  if( !route_3.IsEmpty() )
    routes.AppendString( route_3 );
  
  if( !route_4.IsEmpty() )
    routes.AppendString( route_4 );

  if( !route_5.IsEmpty() )
    routes.AppendString( route_5 );

  return TRUE;
}


#endif //HAS_XBASE


