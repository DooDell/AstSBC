/*
 *
 * OpenSBC.cxx
 *
 * Open SIP Stack ( OSS )
 *
 * Copyright (c) opensipstack.org.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either expressed or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is OpenSIPStack.
 *
 * The Initial Developer of the Original Code is opensipstack.org.
 *
 * The author of this code is Joegen E. Baclor
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * The OpenSIPStack Library includes some GPL/LGPL code libraries that MAY be 
 * enabled at compile time using the --enable-gpllibs configure switch.  If
 * enabled, the content of this file is published under the terms of GNU 
 * General Public License Version 2.  For a detailed list of the available
 * GPL code, see $(opensipstack)/gnu/README file.
 *
 * $Log: OpenSBC.cxx,v $
 * Revision 1.181  2009/06/27 01:29:39  joegenbaclor
 * Fixing compile errors for visual studio 2008 express
 *
 * Revision 1.180  2009/06/08 06:30:45  joegenbaclor
 * Added route caching capability to solegy rtts client
 *
 * Revision 1.179  2009/05/27 12:40:34  joegenbaclor
 * Initial upload of switch related classes
 *
 * Revision 1.178  2009/05/14 02:03:05  joegenbaclor
 * In this revision, we added Disable-Refer-Optimization in general params
 * to allow REFER hijacking to be configurable.
 *
 * Revision 1.177  2009/05/07 12:46:08  joegenbaclor
 * Insert Display Name in outbound INVITE if not present
 *
 * Revision 1.176  2009/05/05 11:37:58  joegenbaclor
 * updated deprecated functions used by xbase
 * updated MSVC 2005 Project files to include XBase classes
 *
 * Revision 1.175  2009/03/26 06:32:26  joegenbaclor
 * Added NAT port forwarding support
 *
 * Revision 1.174  2009/03/22 23:42:47  joegenbaclor
 * Added configurable interface table support
 *
 * Revision 1.173  2009/03/21 11:16:11  joegenbaclor
 * Intorduced new transport class for solegy session
 *
 * Revision 1.172  2009/03/17 02:24:41  joegenbaclor
 * introduced bypassing of ICT responses for fater response time
 *
 * Revision 1.171  2009/03/16 06:15:04  joegenbaclor
 * In this revision, we temporarily removed the pike mechanism to test the scalability of the
 *  FSM changes in OpenSIPStack.  We have also added a bypass handler for BYE for faster reaction
 *  time.  SIPP test at 100 CPS suceeded with zero retranmission on a windows box running
 *  running on Intel Dual Core 3 Ghz CPU with 2 GB Ram.
 *
 * Revision 1.170  2009/03/13 02:54:40  joegenbaclor
 * fixing compile errors in gcc
 *
 * Revision 1.169  2009/03/13 02:52:14  joegenbaclor
 * fixing compile errors in gcc
 *
 * Revision 1.168  2009/03/13 02:26:18  joegenbaclor
 * In this revision, we moved listener configuration to its own
 * page allowing all listeners to be configured seperately.
 * Previous behavior only allowed the main listener to be configured.
 * We have also added a out of dialog handler in the backdoor trunk
 * to allow unsolcited messages like OPTIONS and NOTIFY to passthrough.
 * Both of these functionalities are still under testing.
 *
 * Revision 1.167  2009/03/06 03:17:18  joegenbaclor
 * configurable OPTIONS based NAT keep alive support
 *
 * Revision 1.166  2009/02/23 14:26:18  joegenbaclor
 * Added solegy fraud detection class
 *
 * Revision 1.165  2009/02/13 10:58:44  joegenbaclor
 * Because of an issue discovered with asterisk which sends CANCEL to the port where it first received the provisional response, we are making the use of a new socket for sending responses configurable.
 *
 * Revision 1.164  2009/02/10 13:03:44  joegenbaclor
 * Fixing screwed up listener config due to last patch
 *
 * Revision 1.163  2009/02/10 08:16:09  joegenbaclor
 * Fixed HTTP Config crash
 *
 * Revision 1.162  2009/02/06 09:50:38  joegenbaclor
 * Added email alert notification support
 *
 * Revision 1.161  2009/02/03 05:12:10  joegenbaclor
 * Minor tweaks
 *
 * Revision 1.160  2009/01/25 07:24:23  joegenbaclor
 * Implemented new deadlock detection using 100 trying consecutive occurence
 *
 * Revision 1.159  2009/01/24 07:44:30  joegenbaclor
 * Change timer B and H Lowest possible value from 8 seconds to 3 seconds
 *
 * Revision 1.158  2009/01/24 03:39:27  joegenbaclor
 * removed rate limit checking from transport layer.
 *
 * Revision 1.157  2009/01/23 11:14:13  joegenbaclor
 * Aded OnInboundPacket callback
 *
 * Revision 1.156  2009/01/21 10:01:56  joegenbaclor
 * Marking bug fix for solegy START race condition
 *
 * Revision 1.155  2009/01/09 12:32:16  joegenbaclor
 * In this build we introduced state cookies for Solegy Calls.  The state cookie would allow OpenSBC to disconnect  calls (both BYE and CALLSTOP) after a restart or a crash happen by reconstructing dialog and RTTS state using the cookie data.  The cookie is created on CALLSTART and will be deleted on CALLSTOP.  When a crash happens, calls may stay  connected making it impossible to bill reliably.  Disconnecting calls on restart would minimize the possibility of runaway calls.
 *
 * Revision 1.154  2008/12/22 06:51:46  joegenbaclor
 * Application Timers for Alerting and Connect is causing a deadlock on connection destruction.
 * To address this issue, we modified opensipstack to take care of the timers in the ICT Layer.
 *
 * Revision 1.153  2008/12/08 02:38:30  joegenbaclor
 * Implemented Rate Limits for INVITE, REGISTER and SUSBCRIBE requests.
 *
 * Revision 1.152  2008/11/11 02:54:47  joegenbaclor
 * Feature:  Introducing RTTS aggregation of groomer and osbc
 * Bug:  Disconnect calls if ParseRouting has an empty result set
 *
 * Revision 1.151  2008/11/03 02:35:09  joegenbaclor
 * Introducing new a la B2BUA-Routes Outbound-Proxy routing and deprecated old global
 *  Outbound-Proxy parameter
 *
 * Revision 1.150  2008/11/02 02:34:27  joegenbaclor
 * Added autodelte parameter to SetBypass handler to allow applications to override the
 *  m_AutoDelete property of the handler in cases where the bypass handler might be shared
 *  by multiple transactions.
 *
 * Revision 1.149  2008/10/27 09:44:04  joegenbaclor
 * Subclassing B2BUA objects to give OpenSBC a more fine grained control
 *
 * Revision 1.148  2008/10/22 05:21:31  joegenbaclor
 * Changing default value of m_AcceptAllCalls to TRUE
 *
 * Revision 1.147  2008/10/08 07:10:12  joegenbaclor
 * Added Subscribe and Notify handlers
 *
 * Revision 1.146  2008/10/02 00:34:39  joegenbaclor
 * Added Options Bypass handler
 *
 * Revision 1.145  2008/09/26 07:25:58  joegenbaclor
 * Made SIP Timer B configurable.
 * Some work on RTTS error prompts
 *
 * Revision 1.144  2008/09/23 02:59:08  joegenbaclor
 * Fixied crashed scenario when StartVXML() fails
 *
 * Revision 1.143  2008/09/12 09:49:44  joegenbaclor
 * - Upper registration bug fixes.
 * - Bring back support for upper reg routing
 * - Bring back support for upper-reg domain rewrite
 *
 * Revision 1.142  2008/09/12 04:06:42  joegenbaclor
 * Fixed core dumps during shutdown
 *
 * Revision 1.141  2008/09/01 14:44:29  joegenbaclor
 * Commiting interim code for new registrar with SLA support
 *
 * Revision 1.140  2008/08/27 03:47:18  joegenbaclor
 * included -f option in arg.Parse()
 *
 * Revision 1.139  2008/08/27 03:02:14  joegenbaclor
 * Adding new registrar code
 *
 * Revision 1.138  2008/08/19 16:16:03  joegenbaclor
 * We can now call tail.exe from the applicaton menu in debug mode (Windows only)
 *
 * Revision 1.137  2008/08/19 14:16:03  joegenbaclor
 * Finalizing new log/config directory structure
 *
 * Revision 1.136  2008/08/19 09:33:59  joegenbaclor
 * Transfered default log DIR to $(HOME)/opensipstack/OpenSBC.  This is to make sure
 *  that the application always has write access to the directory
 *
 * Revision 1.135  2008/08/19 05:26:25  joegenbaclor
 * Added ability to set RTP Proxy Port Range Via HTTP Admin.
 * More work on Solegy stuffs.
 *
 * Revision 1.134  2008/08/04 02:45:43  joegenbaclor
 * introduced cnam only solegy handler
 *
 * Revision 1.133  2008/08/01 16:28:09  joegenbaclor
 * Commiting work on IVR HTTP Handler
 *
 * Revision 1.132  2008/07/29 06:11:21  joegenbaclor
 * Fixed Bug in Balance Parser where the ones value of the whole number is not played
 *  by the media server
 *
 * Fixed Bug in Route Parser where the port of the inbound INVITE propagates to the outbound
 *  INVITE if the RTTS did not specify a port
 *
 * Revision 1.131  2008/07/27 15:27:01  joegenbaclor
 * more work on HTTP classes
 *
 * Revision 1.130  2008/07/26 16:29:23  joegenbaclor
 * implemented http client for call-accounting module
 *
 * Revision 1.129  2008/07/24 12:05:48  joegenbaclor
 * Added Solegy Wholesale/SOHO support
 *
 * Revision 1.128  2008/07/23 07:13:00  joegenbaclor
 * Changed yield time in shutdown sequence from 5 seconds to 1
 *
 * Revision 1.127  2008/07/17 11:58:49  joegenbaclor
 * Implemented route failover for debit calls
 *
 * Revision 1.126  2008/07/03 01:04:00  joegenbaclor
 * Implemented Solegy Transport
 *
 * Revision 1.125  2008/07/02 03:38:38  joegenbaclor
 * More work on solegy debit
 *
 * Revision 1.124  2008/07/01 12:27:00  joegenbaclor
 * Added Solegy debit module
 *
 * Revision 1.123  2008/07/01 05:09:14  joegenbaclor
 * Implemented HTML Dump-Memory page
 *
 * Revision 1.122  2008/06/30 05:42:53  joegenbaclor
 * Implemented HTML call status page
 *
 * Revision 1.121  2008/06/30 01:59:10  joegenbaclor
 * Implemented garbage collector status page
 *
 * Revision 1.120  2008/06/16 08:10:39  joegenbaclor
 * Added default 4xx,5xx,6xx announcement error maps
 *
 * Revision 1.119  2008/06/16 05:49:13  joegenbaclor
 * Completing Announcement-Error-Map support
 *
 * Revision 1.118  2008/06/13 13:05:34  joegenbaclor
 * implemented announcement service
 *
 * Revision 1.117  2008/06/11 23:53:25  joegenbaclor
 * Fixed compile errors in solaris
 *
 * Revision 1.116  2008/06/11 04:46:40  joegenbaclor
 * Added Catch-All-Route functionality.  See http://www.assembla.com/spaces/opensbc/tickets/23
 *
 * Revision 1.115  2008/06/02 08:42:29  joegenbaclor
 * Merging-in Solegy required patches
 *
 * Revision 1.114  2008/05/27 14:15:02  joegenbaclor
 * Implemented maximum concurrent connection counter
 *
 * Revision 1.113  2008/05/27 03:16:05  joegenbaclor
 * More work on leak free process termination.
 *
 * Revision 1.112  2008/05/26 12:05:51  joegenbaclor
 * Added VLD and support for console only build
 *
 * Revision 1.111  2008/05/25 02:38:36  joegenbaclor
 * Added shutdown handler for SIGUSR1 and SIGUSR2
 *
 * Revision 1.110  2008/05/07 11:05:00  joegenbaclor
 * Added support for NULL Server Transactions.
 *
 * Revision 1.109  2008/04/28 09:37:23  joegenbaclor
 * Added empty string check for User-Agent-Name
 *
 * Revision 1.108  2008/04/28 09:31:56  joegenbaclor
 * HTTP admin aesthetics.
 * Allowed User-Agent header to be configurable
 * Incremented release version
 *
 * Revision 1.107  2008/04/16 09:38:25  joegenbaclor
 * Bug fix for session-keep-alive
 *
 * Revision 1.106  2008/04/16 00:44:21  joegenbaclor
 * Using OnPostCreateB2BUA callback to set keep-alive and max-session-lifetime
 *
 * Revision 1.105  2008/04/14 09:02:55  joegenbaclor
 * Added new config params for session-keep-alive and max-life-span
 *
 * Revision 1.104  2008/04/10 06:45:55  joegenbaclor
 * Forced use of SetValue() instead of operator=() for PAtomicIntegers
 *
 * Revision 1.103  2008/03/27 03:31:02  joegenbaclor
 * Added more fine grained NAT detection parameters as suggested by Mike Wengrov
 *
 * Revision 1.102  2008/03/17 11:34:51  rcolobong
 * Update refresh rate in Resource Counter page
 *
 * Revision 1.101  2008/03/14 05:53:31  joegenbaclor
 * Fixed visual studio 2005 compile errors
 *
 * Revision 1.100  2008/03/11 09:16:09  joegenbaclor
 * Fixed linux compilation errors due to python and php enhancements
 *
 * Revision 1.99  2008/03/11 02:10:02  joegenbaclor
 * Revised PHP Sapi implementation and removed python from configure script check
 *
 * Revision 1.98  2008/03/07 15:11:22  joegenbaclor
 * Added PHP SAPI Support in HTTP Server
 *
 * Revision 1.97  2008/03/06 09:35:01  rcolobong
 * 1. Expose new info in ResourceCounters in HTTP Config Page
 * 2. Fixed bug regarding crashes when PythonScript is reinitialized in OnConfigChanged
 *
 * Revision 1.96  2008/03/04 17:50:48  joegenbaclor
 * Added PySNMP support
 *
 * Revision 1.95  2008/02/21 10:16:10  rcolobong
 * Add configuration to update supported media for IVR
 *
 * Revision 1.94  2008/02/19 07:23:33  rcolobong
 * 1. Add modifiers for SIP Timer H
 * 2. Add configuration for SIP Timer H
 *
 * Revision 1.93  2008/02/13 07:31:15  rcolobong
 * 1. Update revision number and release date
 * 2. Readd enable disable of backdoor, trunk and calea port in the configuration.
 *
 * Revision 1.92  2008/01/10 11:22:38  rcolobong
 * Fix bug in B2BUpperReg only mode when backdoor port is disable
 *
 * Revision 1.91  2008/01/08 08:42:14  rcolobong
 * 1. Add configuration to enable/disable backdoor, calea, and sip trunk port
 * 2. More work on handling spiral or merged invite
 *
 * Revision 1.90  2007/12/21 09:48:07  joegenbaclor
 * Added ability to preserve the transaction via the incoming SIP message.  This pointer may be provided to SendRequest so that responses can avoid another search of the transaction from the transaction db.
 *
 * Revision 1.89  2007/12/05 14:21:49  joegenbaclor
 * Modified backdoor behavior so that it does not rewrite refer-to uri
 *
 * Revision 1.88  2007/12/04 16:03:14  joegenbaclor
 * Added Access List Verification
 *
 * Revision 1.87  2007/11/12 04:34:07  joegenbaclor
 * Added ability to configure default max-forwards
 *
 * Revision 1.86  2007/10/30 16:39:36  joegenbaclor
 * Modified default thread count for trunks
 *
 * Revision 1.85  2007/10/28 17:23:08  joegenbaclor
 * Added PThread to resource counters
 *
 * Revision 1.84  2007/10/15 10:37:49  joegenbaclor
 * Minor bug fixes
 *
 * Revision 1.83  2007/10/10 01:00:18  joegenbaclor
 * Added check for Allow header when local refer is enabled
 *
 * Revision 1.82  2007/10/05 07:14:01  joegenbaclor
 * Introduced new method OnInitialConfigChanged to SIP Trunk to be called on startup
 *
 * Revision 1.81  2007/10/02 06:25:18  joegenbaclor
 * Changed default MS port to 5068
 *
 * Revision 1.80  2007/10/02 06:10:15  joegenbaclor
 * Allowed application layer to set the listener port of the media server
 *
 * Revision 1.79  2007/10/01 16:17:27  joegenbaclor
 * Added transport status page in http admin
 *
 * Revision 1.78  2007/09/26 14:27:20  joegenbaclor
 * SBCRoutingHandler now redirects Trunk calls to the trunk listener address
 *
 * Revision 1.77  2007/09/23 14:50:44  joegenbaclor
 * Added new config params to flag resolution of To and R-RUIs in B2BUA and Ralay routes
 *
 * Revision 1.76  2007/09/20 10:32:59  joegenbaclor
 * Comleted SIP Trunk registration status page
 *
 * Revision 1.75  2007/09/19 18:22:48  joegenbaclor
 * Added registration recovery via text files if SQLite is not available
 *
 * Revision 1.74  2007/09/04 23:32:46  joegenbaclor
 * Using a messagebox to display config version error in windows
 *
 * Revision 1.73  2007/09/04 21:58:13  joegenbaclor
 * More work on SIP Trunks.
 *
 * Revision 1.72  2007/08/24 01:14:41  joegenbaclor
 * scrapped previous code for upstream proxy handling
 *
 * Revision 1.71  2007/08/20 06:24:45  joegenbaclor
 * commiting alpha code for new backdoor using trunks
 *
 * Revision 1.70  2007/08/16 13:25:50  joegenbaclor
 * More work on trunking
 *
 * Revision 1.69  2007/08/14 10:58:54  joegenbaclor
 * included SIP timers in resource counter
 *
 * Revision 1.68  2007/08/12 01:57:49  joegenbaclor
 * More work on trunking
 *
 * Revision 1.67  2007/08/08 07:36:08  joegenbaclor
 * Added SBCTrunk classes
 * Removed singleton factory for OSSAppConfig
 *
 * Revision 1.66  2007/08/02 02:18:57  joegenbaclor
 * Added OpenSBC-Setup project
 *
 * Revision 1.65  2007/07/31 04:32:43  joegenbaclor
 * updated Exhibit  A of MPL
 *
 * Revision 1.64  2007/07/30 06:47:29  joegenbaclor
 * removed unused variable uproute
 *
 * Revision 1.63  2007/07/29 06:29:55  joegenbaclor
 * updated visual studio 2003 project files
 *
 * Revision 1.62  2007/07/25 12:20:31  joegenbaclor
 * changed conf file version to 1.1.4-2
 *
 * Revision 1.61  2007/07/20 03:33:14  joegenbaclor
 * Config aesthetics
 *
 * Revision 1.60  2007/07/17 02:01:22  joegenbaclor
 * modified config template
 *
 * Revision 1.59  2007/07/17 01:31:48  joegenbaclor
 * Added Config version checking
 *
 * Revision 1.58  2007/07/15 12:27:25  joegenbaclor
 * Added capability to route to registered endpoints using static routes
 * Removed unused config parameters
 *
 * Revision 1.57  2007/07/15 07:51:20  joegenbaclor
 * implemented resource counter page
 *
 * Revision 1.56  2007/07/14 07:53:56  joegenbaclor
 * Migrated code to use new STL based string class
 *
 * Revision 1.55  2007/07/06 14:18:25  rcolobong
 * Add Upstream Proxy Route feature
 *
 * Revision 1.54  2007/06/17 02:49:18  joegenbaclor
 * Introduced Global lock to PHTTPConfig
 *
 * Revision 1.53  2007/06/16 13:06:19  joegenbaclor
 * change regdb to use CachePointers instead fo a direct pointer access to cache objects
 *
 * Revision 1.52  2007/06/13 09:22:01  joegenbaclor
 * Added IVR handler
 *
 * Revision 1.51  2007/06/06 16:20:31  joegenbaclor
 * Commiting Media Server Related Changes
 *
 * Revision 1.50  2007/05/18 01:23:44  joegenbaclor
 * 1.  Added separate useragent to handle B2BUpperReg backdoor
 * 2.  Modified routing for B2BUpperReg
 * 3.  Corrected bug in ParserTools::GetCompactHeader()
 *
 * Revision 1.49  2007/05/07 06:13:22  rcolobong
 * 1. Add support for disabling and enabling Local Refer
 * 2. Add support for defining static RTP media address
 * 3. Remove support for Force B2B Routes
 *
 * Revision 1.48  2007/05/06 15:53:16  joegenbaclor
 * Incremented minor version
 *
 * Revision 1.47  2007/05/04 10:07:18  joegenbaclor
 * more on delayed deletion mechanism
 *
 * Revision 1.46  2007/04/11 09:11:38  joegenbaclor
 * Corrected type from last commit
 *
 * Revision 1.45  2007/04/10 06:31:46  joegenbaclor
 * Added new Encryption Mode
 *
 * Revision 1.44  2007/03/08 10:27:09  joegenbaclor
 * Tidy up OpalManager Destruction
 * Enabled Recording in vxml
 *
 * Revision 1.43  2007/03/08 06:43:20  joegenbaclor
 * This commit marks first successful call to the Media Server
 *
 * Revision 1.42  2007/03/07 23:20:13  joegenbaclor
 * Added media server UA
 *
 * Revision 1.41  2007/02/22 14:41:13  joegenbaclor
 * Completed multi listener support
 *
 * Revision 1.40  2007/02/22 08:23:51  joegenbaclor
 * Added multi listener support
 *
 * Revision 1.39  2007/02/21 01:00:02  joegenbaclor
 * Fixed compile error in CentOS.  Thanks Harold Bray
 *
 * Revision 1.38  2007/02/16 11:09:19  joegenbaclor
 * More work on privacy
 *
 * Revision 1.37  2007/02/15 09:36:29  joegenbaclor
 * Added Privacy Section
 *
 * Revision 1.36  2007/02/15 02:51:44  joegenbaclor
 * Completed trusted domain and proxy authentication support
 *
 * Revision 1.35  2007/02/14 11:22:08  joegenbaclor
 * Added Trusted Domain section
 *
 * Revision 1.34  2007/02/08 18:12:21  joegenbaclor
 * Appropriately rename connection timeout to SeizeTimeout
 *
 * Revision 1.33  2007/01/29 08:37:02  joegenbaclor
 * Added TCP Listener activation code
 *
 * Revision 1.32  2007/01/23 11:10:59  joegenbaclor
 * Last minute changes for new tarball release
 *
 * Revision 1.31  2007/01/22 10:00:58  joegenbaclor
 * Fixed ProxyRouteRequest
 *
 * Revision 1.30  2007/01/18 08:39:27  joegenbaclor
 * Added VC7.10 project files for launcher
 *
 * Revision 1.29  2007/01/18 06:06:41  joegenbaclor
 * Incremented Build Number for latest development release
 *
 * Revision 1.28  2007/01/17 10:33:43  joegenbaclor
 * Redesigned syslog
 *
 * Revision 1.27  2007/01/17 00:04:31  joegenbaclor
 * Added SysLog
 *
 * Revision 1.26  2007/01/15 10:06:57  joegenbaclor
 * More on XML-RPC Registration Queries
 *
 * Revision 1.25  2007/01/15 09:24:47  joegenbaclor
 * Added capability to find Registraton via XML-RPC
 *
 * Revision 1.24  2007/01/14 13:15:09  joegenbaclor
 * Fixed bug were mode is not initialized properly for configuration file
 *
 * Revision 1.23  2007/01/12 10:50:04  joegenbaclor
 * minor proxy bug fixes
 * more launcher code
 *
 * Revision 1.22  2007/01/12 01:02:44  joegenbaclor
 * launcher related code
 *
 * Revision 1.21  2007/01/11 10:00:26  joegenbaclor
 * more launcher code
 *
 * Revision 1.20  2007/01/11 02:34:58  rcolobong
 * Add new http config for enable/disable proxying media
 *
 * Revision 1.19  2007/01/10 23:58:23  joegenbaclor
 * launcher specific code
 *
 * Revision 1.18  2007/01/10 05:00:39  joegenbaclor
 * Added B2BUpperReg mode.
 *
 * Revision 1.17  2007/01/09 02:29:44  joegenbaclor
 * Fixed Unregister Post code
 *
 * Revision 1.16  2007/01/08 11:15:18  joegenbaclor
 * Added registration status page
 *
 * Revision 1.15  2007/01/08 07:13:23  joegenbaclor
 * Added ability to run SBC in pure proxy or pure b2b modes
 *
 * Revision 1.14  2007/01/02 01:54:48  joegenbaclor
 * Corrected parser bug for Route Records
 *
 * Revision 1.13  2006/12/22 12:05:42  joegenbaclor
 * We need to include all params in arg.parse in daemon constructor or unix implementation would break.  It seems Parse of PargList can only be called one.  Second call the Parse wont update the params.
 *
 * Revision 1.12  2006/12/22 07:40:27  joegenbaclor
 * More on command line argument parsing.
 *
 * Revision 1.11  2006/12/21 08:56:59  joegenbaclor
 * Added pid in b2bua log file name
 * Fixed bug in proxy relay where startline URI is not rewritten if a static route is
 *  not found
 *
 * Revision 1.10  2006/11/25 02:59:13  joegenbaclor
 * Added project files to opensbc.  Old scheme of producing the VC 8.0 workspace using configure is still available
 *
 * Revision 1.9  2006/11/24 10:59:55  rcolobong
 * Remove support for RTBE Classes
 *
 * Revision 1.8  2006/11/22 11:37:09  rcolobong
 * 1. Added new support for Force B2BUA in HTTP configuration
 * 2. Added log level in Application level and SIP/RTP Level
 * 3. Update OnAcceptRegistration signature
 *
 * Revision 1.7  2006/10/11 04:59:50  rcolobong
 * Add http configuration "Accept all registration". If this true then it will accept all registration even if it is not included on the "Local domain accounts"
 *
 * Revision 1.6  2006/09/04 14:39:07  joegenbaclor
 * Corrected bug where logger prefix defaults to b2bua--
 *
 * Revision 1.5  2006/09/01 12:51:03  rcolobong
 * Use ActiveSessionCounter to update session count through OSSApplication
 *
 * Revision 1.4  2006/08/30 09:07:31  rcolobong
 * Update setting connection timer and alerting timer
 *
 * Revision 1.3  2006/08/29 07:43:58  rcolobong
 * 1. Rename file to a better filename
 * 2. Change SBCRTBESesionManager class to RTBESessionManager
 *
 * Revision 1.2  2006/08/16 10:34:32  rcolobong
 * 1. Syslog server is now configurable
 * 2. Alerting timer and Connection Timer is now configurable
 *
 * Revision 1.1  2006/08/14 10:04:59  rcolobong
 * Convert B2BUA to SBC
 * Support MP logging
 *
 * Revision 1.10  2006/08/04 07:30:52  joegenbaclor
 * #ifdefed RTBE headers
 *
 * Revision 1.9  2006/08/04 05:44:18  rcolobong
 * Instantiate B2BRTBEUA instead of openB2BUA if HAS_RTBECLIENT is defined
 *
 * Revision 1.8  2006/07/26 09:19:41  joegenbaclor
 * Added System Log support
 *
 * Revision 1.7  2006/07/17 11:36:44  joegenbaclor
 * 1.  More routing enhancements to B2BUA
 *
 * Revision 1.6  2006/07/11 13:59:34  joegenbaclor
 * Completed Proxy functionalities for B2BUA
 *
 * Revision 1.5  2006/07/10 06:29:37  joegenbaclor
 * Completed crude Registration support for B2BUA
 *
 * Revision 1.4  2006/07/03 15:29:47  joegenbaclor
 * Started merging OpenB2BUA into OpenSBC
 *
 * Revision 1.3  2006/06/29 00:50:25  joegenbaclor
 * Corrected some typos that makes unix compilation barf
 *
 * Revision 1.2  2006/06/20 09:58:11  joegenbaclor
 * *** empty log message ***
 *
 *
 */

#include "OpenSBC.h"
#include "SBCRoutingHandler.h"
#include "SBCCallHandler.h"
#include "SBCAuthHandler.h"
#include "SBCIVRHandler.h"
#include "SBCMediaHandler.h"

#include "SBCOptionsHandler.h"
#include "SBCNotifyHandler.h"
#include "SBCSubscribeHandler.h"
#include "SBCByeHandler.h"

#include "SBCB2BUAEndPoint.h"
/// Status pages
#include "SBCGarbageCollectorPage.h"
#include "SBCCallStatusPage.h"
#include "SBCMemoryDumpPage.h"


#if HAS_PYTHON_SAPI
#include "SBCScriptHandler.h"
#endif

#include "SBCTrunk.h"
#include "Version.h"
#include "Encryption.h"
#include "ResourceCounter.h"
#include "Solegy.h"

#include "SBCBackDoorTrunk.h"
#include "SBCCALEATrunk.h"

#include "SBCSIPTrunk.h"
#include "SBCSIPTrunkRegSession.h"
#include "SBCB2BUAEndPoint.h"
#include "SBCAuxiliaryEndPoint.h"
#include "InviteClientTransaction.h"

#ifdef HAS_FREESWITCH
#include "FSLoader.h"
#endif

#define new PNEW



OpenSBC::OpenSBC( 
  OpenSBCDaemon * application,
  UAMode mode,
  BOOL noReg,
  BOOL isMainTrunk
  ) : B2BUserAgent( "OpenSBC Main Trunk", mode )
{
  m_Application = application;
  m_MaxConcurrentSession = 100;
  m_SBCAuthHandler = NULL;
  m_SBCCallHandler = NULL;
  m_SBCRoutingHandler = NULL;
  m_SBCIVRHandler = NULL;
  m_SBCMediaHandler = NULL;
  m_AcceptAllCalls = TRUE;
  m_AcceptAllRegistration = FALSE;
  m_IsMainTrunk = isMainTrunk;
  m_IsInitialConfigChanged = TRUE;
  m_AuxiliaryEndPoint = NULL;
  #if HAS_PYTHON_SAPI
  m_SBCScriptHandler = NULL;
  #endif

  if( !noReg )
    m_LocalRegistrar = new REGISTRAR::Registrar( *this );
  else
    m_LocalRegistrar = NULL;

  if( m_IsMainTrunk )
  {
    m_SolegySessionManager = new SOLEGY::SolegySessionManager();
    #ifdef HAS_XBASE
    XBase::InitEngine();
    m_XBaseManager = new SBCXBaseManager;
    #endif
    m_SBCRoutingHandler = new SBCRoutingHandler( *this );
    m_SBCRoutingHandler->RefreshInterfaceTable();

  }else
  {
    m_SolegySessionManager = NULL;
    m_SBCRoutingHandler = NULL;
    #ifdef HAS_XBASE
    m_XBaseManager = NULL;
    #endif
  }

  
}

OpenSBC::~OpenSBC()
{
  #if HAS_PYTHON_SAPI
  if( m_SBCScriptHandler != NULL )
    delete m_SBCScriptHandler;
  #endif
  delete m_LocalRegistrar;
  delete m_SolegySessionManager;
  delete m_AuxiliaryEndPoint;
  #ifdef HAS_XBASE
  delete m_XBaseManager;
  #endif
  SIPTransport::Deinitialize();
}

OSSAppConfig * OpenSBC::GetAppConfig()const
{
  return m_Application->GetAppConfig();
}

void OpenSBC::OnStart( 
  OSSAppConfig & 
)
{
}

void OpenSBC::OnStop()
{
}

void OpenSBC::OnINITConfig( 
  OSSAppConfig & config
)
{
  int workerThreadCount = 1;//config.GetInteger( configKeySection, configKeyTransactionThreadCount, 1 );
  unsigned maxForward = config.GetInteger( configKeySection, configKeyMaxForwards, SIP_DEFAULT_MAX_FORWARDS );
  SIP::SIPStack::SetDefaultMaxForwards( maxForward );
  SIPURI bindAddress;
  OStringArray moreBindAddress;
  if( !m_Application->HasExtendedArgs() )
  {
    PINDEX listSize = config.GetListSize( configKeySIPTransportSection, configKeyMainInterfaceAddress );
    if( listSize == 0 )
      bindAddress  = "sip:*:5060";
    else
    {
      bindAddress = SIPURI((const char *)config.GetListItem( configKeySIPTransportSection, configKeyMainInterfaceAddress, 0 ));
      if( bindAddress.GetHost().IsEmpty() )
        bindAddress = "sip:*:5060" ;

      /// check if there are more interfaces configured
      if( listSize > 1 )
      {
        for( PINDEX i = 1; i < listSize; i++ )
        {
          OString moreIface = config.GetListItem( configKeySIPTransportSection, configKeyMainInterfaceAddress, i );
          if( !moreIface.IsEmpty() )
            moreBindAddress.AppendString( moreIface );
        }
      }
    }
  }else
  {
    bindAddress = m_Application->GetExtendedArgs().AsString( FALSE );
  }

  SIPTransaction::m_WillSendResponseWithNewSocket = config.GetBoolean( configKeySection, configKeySendResponsesUsingNewSocket, TRUE );
  m_MaxConcurrentSession = config.GetInteger( configKeySection, configKeyMaxConcurrentSession, 100 );
  int rateLimit = config.GetInteger( configKeySection, configKeyMaxCallRatePerSecond, 10 );
  ((B2BUA::SBCB2BUAEndPoint*)GetB2BUAEndPoint())->SetCallRateLimit( rateLimit );

  
  InviteClientTransaction::m_ICTAlertingTimeout = config.GetInteger( configKeySection, configKeyAlertingTimeout, 30000 );
  InviteClientTransaction::m_ICTConnectTimeout = config.GetInteger( configKeySection, configKeySeizeTimeout, 60000 );

  // Indicate if we will accept all registrations
  m_AcceptAllRegistration = config.GetBoolean( configKeyAccountSection, configKeyAcceptAllRegistration, 0 );
  GetRegistrar()->SetAcceptAllRegistrations( m_AcceptAllRegistration );
  GetLocalRegistrar()->SetAcceptAllRegistrations( m_AcceptAllRegistration );
  GetLocalRegistrar()->SetUseOptionsNATKeepAlive( config.GetBoolean( configKeySection, configKeySendOptionsNATKeepAlive, FALSE ) );
  GetLocalRegistrar()->SetNATKeepAliveInterval( config.GetInteger( configKeySection, configKeyNATKeepAliveInterval, 15 ) );
  GetLocalRegistrar()->OnParseUpperRegRoutes();



  // Enable Feature SIP Session Timers
  GetB2BUAEndPoint()->EnableSessionTimer( FALSE );

  BOOL mediaProxy = config.GetBoolean( configKeyRTPProxySection, configKeyProxyAllMedia, FALSE );
  GetB2BUAEndPoint()->SetMediaProxyIfPrivate( !mediaProxy );

  Encryption::Engine::m_Key = (const char *)config.GetString( configKeySection, configKeyEncryptionKey, Encryption::Engine::m_DefKey );
  OString encMode = config.GetString( configKeySection, configKeyEncryption, "XOR" );
  if( encMode *= "XOR" )
    Encryption::Engine::m_Type = Encryption::Engine::Type_XOR;
  else if( encMode *= "DiffShift" )
    Encryption::Engine::m_Type = Encryption::Engine::Type_DiffShift;

  /// create the domain account database
  PStringArray accounts;
  for( PINDEX i = 0; i <  config.GetListSize( configKeyAccountSection, configKeyAccount ); i++ )
    accounts.AppendString( config.GetListItem( configKeyAccountSection, configKeyAccount, i ) );
  AddLocalDomainAccounts( accounts, TRUE );

  m_AcceptAllCalls = config.GetBoolean( configKeyTrustedDomainSection, configKeyAcceptAllCalls, 1 );
  /// create the domain account database
  PStringArray domains;
  for( PINDEX i = 0; i <  config.GetListSize( configKeyTrustedDomainSection, configKeyTrustedDomainList ); i++ )
    domains.AppendString( config.GetListItem( configKeyTrustedDomainSection, configKeyTrustedDomainList, i ) );
  AddTrustedDomains( domains, TRUE );

  /// check whether we should enable local Refer
  BOOL localRefer = config.GetBoolean( configKeySection, 
    configKeyEnableLocalRefer, 0 );
  GetB2BUAEndPoint()->EnableLocalRefer( localRefer );

  /// session keep alive parameters
  GetB2BUAEndPoint()->SetSessionKeepAliveInterval( config.GetInteger( configKeySection, configKeySessionKeepAlive, 1800 ) );
  GetB2BUAEndPoint()->SetMaxSessionLifeSpan( config.GetInteger( configKeySection, configKeySessionMaxLifeSpan, 10800 ) );

  /// if catch all routing is set
  OString catchAllRoute = (const char *)config.GetString( configKeyB2BUASection, configKeyB2BUACatchAllRoute, "" );
  if( !catchAllRoute.IsEmpty() )
  {
    SIPURI catchAllRouteURI = catchAllRoute;
    GetB2BUAEndPoint()->SetCatchAllRoute( catchAllRouteURI );
    GetB2BUAEndPoint()->UseCatchAllRoute();
  }else
  {
    GetB2BUAEndPoint()->UseCatchAllRoute( FALSE );
  }

  dynamic_cast<SBCB2BUAEndPoint*>(GetB2BUAEndPoint())->LoadOutboundProxies( config );

  PStringArray privacyDomains;
  for( PINDEX i = 0; i <  config.GetListSize( configKeyPrivacyTrustedDomainSection, configKeyPrivacyDomain ); i++ )
    privacyDomains.AppendString( config.GetListItem( configKeyPrivacyTrustedDomainSection, configKeyPrivacyDomain, i ) );
  AddPrivacyTrustedDomains( privacyDomains, TRUE );
  SetPrivacyDefaultRealm( config.GetString( configKeyPrivacyTrustedDomainSection, configKeyPrivacyDefaultRealm, "" ) );

  PIPSocket::Address iface = PIPSocket::Address( bindAddress.GetHost() );
  if( !iface.IsValid() )
    iface = 0;

  WORD port = 5060;
  if( bindAddress.GetPort() != "0" )
    port = (WORD)bindAddress.GetPort().AsUnsigned();

  OString sipTimerH = (const char *)config.GetString( configKeySection, configKeySIPTimerH, "Default" );
  if( sipTimerH == "Default" )
    GetStack().SetDefaultTimer_H( SIP_TIMER_H );
  else if( sipTimerH == "Lowest" )
    GetStack().SetDefaultTimer_H( 3000 );
  else if( sipTimerH == "Highest" )
    GetStack().SetDefaultTimer_H( SIP_TIMER_H );
  else if( sipTimerH == "Low" )
    GetStack().SetDefaultTimer_H( (SIP_TIMER_H) / 4 );

  OString sipTimerB = (const char *)config.GetString( configKeySection, configKeySIPTimerB, "Default" );
   
  if( sipTimerB == "Default" )
    GetStack().SetDefaultTimer_B( SIP_TIMER_B );
  else if( sipTimerB == "Lowest" )
    GetStack().SetDefaultTimer_B( 3000 );
  else if( sipTimerB == "Highest" )
    GetStack().SetDefaultTimer_B( SIP_TIMER_B );
  else if( sipTimerB == "Low" )
    GetStack().SetDefaultTimer_B( (SIP_TIMER_B) / 4 );

  if( m_IsInitialConfigChanged )
  {
    GetDefaultProfile().GetTransportProfile().EnableUDP( iface, port  );

    if( iface.IsValid() && moreBindAddress.GetSize() > 0 )
      GetDefaultProfile().GetTransportProfile().SetUDPAdditionalListenerAddress( moreBindAddress );

    #if ENABLE_TCP_TRANSPORT
      GetDefaultProfile().GetTransportProfile().EnableTCP( iface, port  );
    #endif
  }

  Initialize( workerThreadCount );

  ((SBCRoutingHandler*)m_RoutingHandler)->RefreshStaticRoutes();
  ((SBCRoutingHandler*)m_RoutingHandler)->RefreshInterfaceTable();
  ((SBCRoutingHandler*)m_RoutingHandler)->RefreshDNSMap();
  ((SBCRoutingHandler*)m_RoutingHandler)->RefreshCALEAMap();
  ((SBCAuthHandler*)m_AuthHandler)->RefreshAccessList();

  if( m_IsInitialConfigChanged )
  {
    int rtpMinPort = config.GetInteger( configKeySection, 
      configKeyRTPMinPort, 30000 );

    int rtpMaxPort = config.GetInteger( configKeySection, 
      configKeyRTPMaxPort, 35000 );

    if( rtpMinPort >= rtpMaxPort )
    {
      rtpMinPort = 30000;
      rtpMaxPort = 35000;
    }

    m_SBCMediaHandler->SetRTPPortRange( rtpMinPort, rtpMaxPort );
  }

  m_SBCMediaHandler->SetProxyAllMedia( config.GetBoolean( configKeyRTPProxySection, configKeyProxyAllMedia, FALSE ) );
  m_SBCMediaHandler->SetProxyPrivateContact( config.GetBoolean( configKeyRTPProxySection, configKeyProxyPrivateContact, TRUE ));
  m_SBCMediaHandler->SetProxyViaReceived( config.GetBoolean( configKeyRTPProxySection, configKeyProxyViaReceived, TRUE ));
  m_SBCMediaHandler->SetProxyViaSendAddress( config.GetBoolean( configKeyRTPProxySection, configKeyProxyViaSendAddress, TRUE ));
  m_SBCMediaHandler->SetProxyViaRPort( config.GetBoolean( configKeyRTPProxySection, configKeyProxyViaRPort, TRUE ));

  
  if( m_IsInitialConfigChanged )
  {
      BOOL enableMediaServer = config.GetBoolean( configKeySection, 
        configKeyEnableMediaServer, TRUE );

      if( enableMediaServer )
      {
        MediaServer * mediaServer = GetMediaServer();
        if( mediaServer )
        {
          OString defaultVXML = "<?xml version=\"1.0\"?>"
                        "<vxml version=\"1.0\">"
                          "<form id=\"root\">"
                            "<audio src=\"welcome.wav\">"
                              "Welcome to the auto attendant main menu."
                            "</audio>"
                          "</form>"
                        "</vxml>";

          //OString vxmlScript = config.GetString( configMediaServerSection, configKeyVXMLScript, defaultVXML );
           
          mediaServer->GetMediaServerEndPoint()->SetDefaultVXML( defaultVXML );

          ((SBCIVRHandler*)m_IVRHandler)->RefreshSupportedCodecs();
          ((SBCIVRHandler*)m_IVRHandler)->RefreshAnnouncementMap();
        }

        m_AuxiliaryEndPoint = new SBCAuxiliaryUA( this );
        m_AuxiliaryEndPoint->InitEndPoint();
      }

    #if HAS_PYTHON_SAPI
      if( m_SBCScriptHandler == NULL )
        m_SBCScriptHandler = new SBCScriptHandler( *this );
      m_SBCScriptHandler->Intialize();
    #endif

    #ifdef HAS_XBASE
    m_XBaseManager->CreateTables();
    #endif
  }


  /// Initialize the Solegy RTTS sub system
  m_SolegySessionManager->Initialize( this );
  m_HTTPSessionManager.Initialize( this );

  m_IsInitialConfigChanged = FALSE;
}

void OpenSBC::OnGenParamsConfigChanged( 
  OSSAppConfig & config
)
{
  int logLevel = config.GetInteger( configKeySection, configKeyAppLogLevel, 3 );
  Logger::SetDefaultLevel( logLevel );
  PTRACE( 1, "Setting SIP Log Level to " << logLevel );
  
  int ptraceLevel = config.GetInteger( configKeySection, configKeyCoreLogLevel, 1 );
  GetApplication()->SetPTraceLevel( ptraceLevel );
  PTRACE( 1, "Setting PTRACE Log Level to " << ptraceLevel );

  /// check whether we should enable local Refer
  BOOL localRefer = config.GetBoolean( configKeySection, 
    configKeyEnableLocalRefer, 0 );
  GetB2BUAEndPoint()->EnableLocalRefer( localRefer );

  /// check if we should rewrite refer relay
  if( !localRefer )
  {
    BOOL rewriteRefer = !config.GetBoolean( configKeySection, 
      configKeyDisableReferOptimization, 0 );
    m_EndPoint->SetWillRewriteREFER( rewriteRefer );
  }

  /// session keep alive parameters
  GetB2BUAEndPoint()->SetSessionKeepAliveInterval( config.GetInteger( configKeySection, configKeySessionKeepAlive, 1800 ) );
  GetB2BUAEndPoint()->SetMaxSessionLifeSpan( config.GetInteger( configKeySection, configKeySessionMaxLifeSpan, 10800 ) );

  m_MaxConcurrentSession = config.GetInteger( configKeySection, configKeyMaxConcurrentSession, 100 );
  int rateLimit = config.GetInteger( configKeySection, configKeyMaxCallRatePerSecond, 10 );
  ((B2BUA::SBCB2BUAEndPoint*)GetB2BUAEndPoint())->SetCallRateLimit( rateLimit );

  SIPTransaction::m_WillSendResponseWithNewSocket = config.GetBoolean( configKeySection, configKeySendResponsesUsingNewSocket, TRUE );

  OString sipTimerH = (const char *)config.GetString( configKeySection, configKeySIPTimerH, "Default" );
  if( sipTimerH == "Default" )
    GetStack().SetDefaultTimer_H( SIP_TIMER_H );
  else if( sipTimerH == "Lowest" )
    GetStack().SetDefaultTimer_H( 3000 );
  else if( sipTimerH == "Highest" )
    GetStack().SetDefaultTimer_H( SIP_TIMER_H );
  else if( sipTimerH == "Low" )
    GetStack().SetDefaultTimer_H( (SIP_TIMER_H) / 4 );

  OString sipTimerB = (const char *)config.GetString( configKeySection, configKeySIPTimerB, "Default" );
   
  if( sipTimerB == "Default" )
    GetStack().SetDefaultTimer_B( SIP_TIMER_B );
  else if( sipTimerB == "Lowest" )
    GetStack().SetDefaultTimer_B( 3000 );
  else if( sipTimerB == "Highest" )
    GetStack().SetDefaultTimer_B( SIP_TIMER_B );
  else if( sipTimerB == "Low" )
    GetStack().SetDefaultTimer_B( (SIP_TIMER_B) / 4 );
}

void OpenSBC::OnConfigChanged( 
  OSSAppConfig & config,
  const char * section  
)
{
  PWaitAndSignal b2bConfigLock( ((B2BUA::SBCB2BUAEndPoint*)GetB2BUAEndPoint())->GetConfigMutex() );
  PWaitAndSignal configLock( PHTTPConfig::m_HTTPConfigMutex );

  if( section != NULL && ::strcmp( section, "INIT" ) == 0 )
  {
    OnINITConfig( config );
    SendMailAlert( "Application Startup", "Application started" );
    return;
  }else if( section != NULL && ::strcmp( section, configKeyB2BUATestMessageSection ) == 0 )
  {
    OString testRequest = (const char *)config.GetString( configKeyB2BUATestMessageSection, configKeyB2BUATestMessage, "" );
    if( !testRequest.IsEmpty() )
    {
      SIPMessage sipRequest( testRequest );
      if( sipRequest.IsValid() )
        GetStack().CreateNullServerTransaction( sipRequest );
    }
    return;
  }else if( section != NULL && ::strcmp( section, configKeyB2BUASection ) == 0 )
  {
    ((SBCRoutingHandler*)m_RoutingHandler)->RefreshStaticRoutes();
    return;
  }else if( section != NULL && ::strcmp( section, configKeySIPTransportSection ) == 0 )
  {
    ((SBCRoutingHandler*)m_RoutingHandler)->RefreshInterfaceTable();
    return;
  }else if( section != NULL && ::strcmp( section, configKeySection ) == 0 )
  {
    OnGenParamsConfigChanged( config );
  }else if( section != NULL && ::strcmp( section, configKeyAccountSection ) == 0 )
  {
    m_AcceptAllRegistration = config.GetBoolean( configKeyAccountSection, configKeyAcceptAllRegistration, 0 );
    GetRegistrar()->SetAcceptAllRegistrations( m_AcceptAllRegistration );
    GetLocalRegistrar()->SetAcceptAllRegistrations( m_AcceptAllRegistration );
    /// create the domain account database
    PStringArray accounts;
    for( PINDEX i = 0; i <  config.GetListSize( configKeyAccountSection, configKeyAccount ); i++ )
      accounts.AppendString( config.GetListItem( configKeyAccountSection, configKeyAccount, i ) );
    AddLocalDomainAccounts( accounts, TRUE );
  }else if( section != NULL && ::strcmp( section, configKeyTrustedDomainSection ) == 0 )
  {
    m_AcceptAllCalls = config.GetBoolean( configKeyTrustedDomainSection, configKeyAcceptAllCalls, 1 );

    /// create the domain account database
    PStringArray domains;
    for( PINDEX i = 0; i <  config.GetListSize( configKeyTrustedDomainSection, configKeyTrustedDomainList ); i++ )
      domains.AppendString( config.GetListItem( configKeyTrustedDomainSection, configKeyTrustedDomainList, i ) );
    AddTrustedDomains( domains, TRUE );
  }else if( section != NULL && ::strcmp( section, configKeyHostAccessListSection ) == 0 )
  {
    ((SBCAuthHandler*)m_AuthHandler)->RefreshAccessList();
  }else if( section != NULL && ::strcmp( section, configKeyPrivacyTrustedDomainSection ) == 0 )
  {
    PStringArray privacyDomains;
    for( PINDEX i = 0; i <  config.GetListSize( configKeyPrivacyTrustedDomainSection, configKeyPrivacyDomain ); i++ )
      privacyDomains.AppendString( config.GetListItem( configKeyPrivacyTrustedDomainSection, configKeyPrivacyDomain, i ) );
    AddPrivacyTrustedDomains( privacyDomains, TRUE );
    SetPrivacyDefaultRealm( config.GetString( configKeyPrivacyTrustedDomainSection, configKeyPrivacyDefaultRealm, "" ) );
  }else if( section != NULL && ::strcmp( section, configKeyOutboundProxiesSection ) == 0 )
  {
    dynamic_cast<SBCB2BUAEndPoint*>(GetB2BUAEndPoint())->LoadOutboundProxies( config );
  }else if( section != NULL && ::strcmp( section, configKeyDNSMapSection ) == 0 )
  {
    ((SBCRoutingHandler*)m_RoutingHandler)->RefreshDNSMap();
  }else if( section != NULL && ::strcmp( section, configKeyCALEASection ) == 0 )
  {
    ((SBCRoutingHandler*)m_RoutingHandler)->RefreshCALEAMap();
  }else if( section != NULL && ::strcmp( section, "Solegy" ) == 0 )
  {
    m_SolegySessionManager->Initialize( this );
  }
}

void OpenSBC::OnSignalShutDown()
{
  PSystemLog s(PSystemLog::StdError);
  s << "*** OpenSBC SHUTDOWN *** Busying out transactions ..." << endl;
  BusyOutTransactions( "OpenSBC Is Shutting Down" );
  s << "*** OpenSBC SHUTDOWN *** Closing transport." << endl;
  CloseTransport();
  s << "*** OpenSBC SHUTDOWN *** Destroying Transactions. " << endl;
  TerminateTransactions();
  Terminate();
  s << "*** OpenSBC SHUTDOWN *** Sequence complete ..." << endl;
}

BOOL OpenSBC::IsTrustedDomain( const SIPURI & uri )const
{
  PWaitAndSignal lock( m_TrustedDomainsMutex );
  OString key( uri.GetHost() );
  PINDEX index = m_TrustedDomains.GetStringsIndex(key);
  return index != P_MAX_INDEX;
}

BOOL OpenSBC::AddTrustedDomains(
  const PStringArray & domains,
  BOOL dumpExisting
)
{
  PWaitAndSignal lock( m_TrustedDomainsMutex );
  
  if( dumpExisting )
    m_TrustedDomains.RemoveAll();

  for( PINDEX i = 0; i < domains.GetSize(); i++ )
  {
    SIPURI domain( (const char *)domains[i] );
    OString key = domain.GetHost();
    m_TrustedDomains.AppendString( key );
  }

  return TRUE;
}


BOOL OpenSBC::IsPrivacyTrustedDomain( 
  const SIPURI & uri,
  SIPURI & domainEntry
)const
{
  PWaitAndSignal lock( m_PrivacyTrustedDomainsMutex );
  OString key( uri.GetHost() );
  PINDEX index = m_PrivacyTrustedDomains.GetStringsIndex(key);
  if( index != P_MAX_INDEX )
  {
    OString * str = dynamic_cast<OString*>(m_PrivacyTrustedDomains.GetAt(index));
    if( str != NULL )
      domainEntry = *str;

    return TRUE;
  }

  return FALSE;
}

BOOL OpenSBC::AddPrivacyTrustedDomains(
  const PStringArray & domains,
  BOOL dumpExisting
)
{
  PWaitAndSignal lock( m_PrivacyTrustedDomainsMutex );
  
  if( dumpExisting )
    m_PrivacyTrustedDomains.RemoveAll();

  for( PINDEX i = 0; i < domains.GetSize(); i++ )
  {
    SIPURI domain( (const char *)domains[i] );
    OString key = domain.GetHost();
    m_PrivacyTrustedDomains.AppendString( key );
  }

  return TRUE;
}

BOOL OpenSBC::FindLocalDomainAccount(
  const SIPURI & uri,
  SIPURI & accountURI
)const
{
  PWaitAndSignal lock( m_LocalDomainAccountsMutex );

  PStringStream key;
    key << uri.GetUser() << ":" << uri.GetHost();

  SIPURI * account = m_LocalDomainAccounts.GetAt( key );

  if( account == NULL )
    return FALSE;

  accountURI = *account;

  return TRUE;
}

BOOL OpenSBC::AddLocalDomainAccounts(
  const PStringArray & accounts,
  BOOL dumpExisting
)
{
  PWaitAndSignal lock( m_LocalDomainAccountsMutex );
  
  if( dumpExisting )
    m_LocalDomainAccounts.RemoveAll();

  for( PINDEX i = 0; i < accounts.GetSize(); i++ )
  {
    SIPURI accountURI( (const char *)accounts[i] );
    PStringStream key;
    key << accountURI.GetUser() << ":" << accountURI.GetHost();
    m_LocalDomainAccounts.SetAt( key, new SIPURI( accountURI ) );
  }

  return TRUE;
}

void OpenSBC::OnTransactionCreated(
    const SIPMessage & request,
    SIPTransaction *& transaction
)
{
  if( transaction->GetType() == SIPTransaction::NIST )
  {
    OString method = request.GetMethod().ToUpper();
    if( method *= "REGISTER" )
    {
      transaction->SetBypassHandler( m_LocalRegistrar, m_LocalRegistrar->m_AutoDeleteBypass );
    }else if( method *= "OPTIONS" )
    {
      if( request.GetToTag().IsEmpty() )
      {
        transaction->SetBypassHandler( new SBCOptionsHandler( *this ), TRUE );
      }
    }else if( method *= "NOTIFY" )
    {
      if( request.GetToTag().IsEmpty() )
      {
        /// unsolicited NOTIFY
        transaction->SetBypassHandler( new SBCNotifyHandler( *this ), TRUE );
      }
    }else if( method *= "SUBSCRIBE" )
    {
        transaction->SetBypassHandler( new SBCSubscribeHandler( *this ), TRUE );
    }else if( method *= "BYE" )
    {
      transaction->SetBypassHandler( new SBCByeHandler( *this ), TRUE );
    }
  }
}

B2BCallInterface * OpenSBC::OnCreateCallInterface()
{
  if( m_SBCCallHandler == NULL )
    m_SBCCallHandler = new SBCCallHandler( *this );
  return m_SBCCallHandler;
}

B2BAuthInterface * OpenSBC::OnCreateAuthInterface()
{
  if( m_SBCAuthHandler == NULL  )
    m_SBCAuthHandler = new SBCAuthHandler( *this );
  return m_SBCAuthHandler;
}

B2BRoutingInterface * OpenSBC::OnCreateRoutingInterface()
{
  return m_SBCRoutingHandler;
}

B2BMediaInterface * OpenSBC::OnCreateMediaInterface()
{
 if( m_SBCMediaHandler == NULL )
    m_SBCMediaHandler = new SBCMediaHandler( *this );

  return m_SBCMediaHandler;
}

B2BIVRInterface * OpenSBC::OnCreateIVRInterface()
{
  if( m_SBCIVRHandler == NULL )
    m_SBCIVRHandler = new SBCIVRHandler( *this );

  return m_SBCIVRHandler;
}



RegisterSession::AcceptRegistrationResponse OpenSBC::OnAcceptRegistration( 
  RegisterSession &,
  const SIPMessage &
)
{
  if( m_AcceptAllRegistration )
    return RegisterSession::AcceptByOk;

  return RegisterSession::AcceptByChallenge;
}

BOOL OpenSBC::OnPostCreateB2BUA(
  B2BUAEndPoint * endPoint,
  B2BUAConnection * connection,
  B2BUACall * inboundCall
)
{
  if( endPoint->ConnectionCount > m_MaxConcurrentSession )
  {
    LOG( connection->LogError(), "Connection Count (" << endPoint->ConnectionCount << ") is > " << m_MaxConcurrentSession << " Maximum Concurrent connections" );
    inboundCall->SetCallAnswerResponseWarning( "Maximum Concurrent Connections Reached" );
    return FALSE;
  }

  connection->SetMediaProxyIfPrivate( endPoint->IsMediaProxyIfPrivate() );

  if( endPoint->GetMaxSessionLifeSpan() > 0 )
  {    
    connection->StartMaxSessionLifeSpanTimer( endPoint->GetMaxSessionLifeSpan() * 1000 );
  }

  if( endPoint->GetSessionKeepAliveInterval() > 0 )
  {
    connection->SetWillSendKeepAlive();
    connection->SetKeepAliveInterval( endPoint->GetSessionKeepAliveInterval() );
  }

  return TRUE;
}

BOOL OpenSBC::OnIncomingCall(
  B2BUAConnection & connection,
  B2BUACall & call,
  SIPMessage & invite
)
{
  if( B2BUserAgent::OnIncomingCall( connection, call, invite ) )
  {
    if( connection.GetRoutes().IsEmpty() )
      return FALSE;

    SIPURI uri = connection.GetRoutes()[0];
    
    OString action;
    if( uri.GetParameter( "action", action ) )
    {
      if( action *= "redirect" )
      {
        SIPMessage msg;
        invite.CreateResponse( msg, SIPMessage::Code302_MovedTemporarily );
        ContactURI curi;
        curi.SetURI( uri.GetBasicURI() );
        msg.AppendContact( curi );
        call.SendRequest( msg, invite.GetTransaction() );

        connection.DestroyConnection( msg );
        return FALSE;
      }
    }

    return TRUE;
  }

  return FALSE;
}

BOOL OpenSBC::OnCreateExternalCallController( 
    B2BUAConnection & connection,
    SIPURI & route,
    const SIPMessage * invite
)
{
  if( m_SolegySessionManager == NULL )
    return FALSE;

  if( route.GetScheme() *= "msdb" )
  {
    if( GetMediaServer() != NULL )
    {
      SIPURI ms( GetMediaServer()->GetListenerAddress(), GetMediaServer()->GetListenerPort() );
      ms.SetUser( route.GetUser() );
      route = ms;
      return m_SolegySessionManager->CreateMediaServerSession( connection );
    }
  }else if( route.GetScheme() *= "wsdb" )
  {
    return m_SolegySessionManager->CreateWSDBSession(connection, route, invite);
  }else if( route.GetScheme() *= "cnam" )
  {
    return m_SolegySessionManager->CreateCNAMSession(connection);
  }else if( route.GetScheme() *= "http" )
  {
    return m_HTTPSessionManager.CreateHTTPSession( connection, route );
  }

  return FALSE;
}

BOOL OpenSBC::OnInboundPacket( 
  SIPTransportManager & transport, 
  SIPMessage & thePacket 
)
{
  if( !m_IsMainTrunk )
    return TRUE;

  return dynamic_cast<SBCB2BUAEndPoint*>(GetB2BUAEndPoint())->OnInboundPacket( transport, thePacket );
}

BOOL OpenSBC::OnOutboundPacket( 
  SIPTransportManager & transport, 
  SIPMessage & thePacket 
)
{
  if( !m_IsMainTrunk )
    return TRUE;

  return dynamic_cast<SBCB2BUAEndPoint*>(GetB2BUAEndPoint())->OnOutboundPacket( transport, thePacket );
}


BOOL OpenSBC::SendMailAlert( const PString & _subject, const PString & _body )
{
  PWaitAndSignal configLock( PHTTPConfig::m_HTTPConfigMutex );
  OSSAppConfig * config = GetAppConfig();
  PString smtpUser = config->GetString( "", "SMTP User", "" );
  PString smtpPassword = PHTTPPasswordField::Decrypt(config->GetString( "", "SMTP Password", "" ));
  PString smtpReturnAddress = config->GetString( "", "SMTP Return Address", "noreply@localhost" );
  PString smtpServer = config->GetString( "", "SMTP Server", "localhost" );
  PString adminEmail = config->GetString( "", "SMTP Admin Address", "" );
  PString subject = "[OpenSBC-Alert] " + _subject;
 
  if( adminEmail.IsEmpty() )
    return FALSE;
 
  const PTime today;
  PString appVersion = GetApplication()->GetVersion();
  const PFilePath &appPath = OSSApplication::GetInstance()->GetFile();
 
  PStringStream body;
  body << "Date: " << today << endl;
  body << "Server: " << GetTransportManager()->GetDefaultInterfaceAddress() << endl;
  body << "Application: " << appPath << endl;
  body << "PID: " << GetApplication()->GetProcessID() << endl;
  body << "Version: " << appVersion << endl << endl;
  
  body << "Alert Detail: " << endl;
  body << _body << endl;
  body << endl << endl << "Your Humble Servant," << endl << "OSBC";

  PRFC822Channel envelope( PRFC822Channel::Sending );
  envelope.SetFromAddress( smtpReturnAddress );
  envelope.SetToAddress( adminEmail );
  envelope.SetSubject( subject );
  return envelope.SendWithSMTP( smtpUser, smtpPassword, smtpServer, body );
}


      






