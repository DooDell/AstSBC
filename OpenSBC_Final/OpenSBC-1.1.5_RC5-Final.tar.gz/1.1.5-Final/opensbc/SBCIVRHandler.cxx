/*
 *
 * SBCIVRHandler.cxx
 * 
  * Open SIP Stack ( OSS )
 *
 * Copyright (c) opensipstack.org.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either expressed or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is OpenSIPStack.
 *
 * The Initial Developer of the Original Code is opensipstack.org.
 *
 * The author of this code is Joegen E. Baclor
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * The OpenSIPStack Library includes some GPL/LGPL code libraries that MAY be 
 * enabled at compile time using the --enable-gpllibs configure switch.  If
 * enabled, the content of this file is published under the terms of GNU 
 * General Public License Version 2.  For a detailed list of the available
 * GPL code, see $(opensipstack)/gnu/README file.
 *
 * $Log: SBCIVRHandler.cxx,v $
 * Revision 1.16  2009/01/14 07:47:28  joegenbaclor
 * Changed default welcome prompt from welcome.wav to hello.wav
 *
 * Revision 1.15  2008/12/31 05:04:50  joegenbaclor
 * Introduced mutex for Solegy socket read-write operations
 *
 * Revision 1.14  2008/09/30 11:05:10  joegenbaclor
 * changed default prompt location
 *
 * Revision 1.13  2008/09/04 01:13:16  joegenbaclor
 * Finalized routing via registrar for SLA support
 * Used SetInternalHeader connection method instead of the unsafe AddInternalHeader
 *
 * Revision 1.12  2008/08/20 12:56:39  joegenbaclor
 * Removed sending of individual events for IVR User Input
 * Some enhancements related to call audit trail
 *
 * Revision 1.11  2008/06/30 01:59:10  joegenbaclor
 * Implemented garbage collector status page
 *
 * Revision 1.10  2008/06/16 08:10:39  joegenbaclor
 * Added default 4xx,5xx,6xx announcement error maps
 *
 * Revision 1.9  2008/06/16 05:49:13  joegenbaclor
 * Completing Announcement-Error-Map support
 *
 * Revision 1.8  2008/06/15 03:38:38  joegenbaclor
 * Some improvements in announcement handling
 *
 * Revision 1.7  2008/06/13 13:05:34  joegenbaclor
 * implemented announcement service
 *
 * Revision 1.6  2008/02/21 10:16:10  rcolobong
 * Add configuration to update supported media for IVR
 *
 * Revision 1.5  2007/07/07 15:21:17  joegenbaclor
 * Added iproute2 support for linux
 *
 * Revision 1.4  2007/06/15 09:12:07  joegenbaclor
 * Added IVR Transfer reject event
 *
 * Revision 1.3  2007/06/14 17:26:52  joegenbaclor
 * Changed grammar so that prompts may be interrupted anytime bu dtmf input
 *
 * Revision 1.2  2007/06/14 02:24:12  joegenbaclor
 * Forgot to check the password after FindLocalDomainAccount
 *
 * Revision 1.1  2007/06/13 09:22:01  joegenbaclor
 * Added IVR handler
 *
 *
 */

#include "SBCIVRHandler.h"
#include "SBCRoutingHandler.h"
#include "OpenSBC.h"
#include "B2BUAConnection.h"
#include "SBCConfigParams.h"

#include <codec/speexcodec.h>
#include <codec/ilbccodec.h>

#define new PNEW

SBCIVRHandler::AnnouncementMap::AnnouncementMap( const OString & token )
{
  operator=(token);
}

SBCIVRHandler::AnnouncementMap::AnnouncementMap( const SBCIVRHandler::AnnouncementMap & token )
{
  operator=(token);
}

SBCIVRHandler::AnnouncementMap::AnnouncementMap( const OString & scheme, int code, const OString & path )
{
  m_Scheme = scheme;
  m_Code = code;
  m_Path = path;
  m_Key = scheme + OString(":") + OString( code );
}

SBCIVRHandler::AnnouncementMap & SBCIVRHandler::AnnouncementMap::operator=( const SBCIVRHandler::AnnouncementMap & token )
{
  m_Scheme = token.m_Scheme;
  m_Code = token.m_Code;
  m_Path = token.m_Path;
  m_Key = token.m_Scheme + OString(":") + OString( token.m_Code );
  return *this;
}

SBCIVRHandler::AnnouncementMap & SBCIVRHandler::AnnouncementMap::operator=( const OString & token )
{
  ///[SCHEME];[STATUS-CODE];[FILE-LOCATION]
  OStringArray tokens;
  token.Tokenise( tokens, ";", FALSE );
  if( tokens.GetSize() < 3 )
    return *this;

  m_Scheme = tokens[0].Trim().ToLower();
  m_Code = tokens[1].AsInteger();
  m_Path = tokens[2].Trim();
  m_Key = m_Scheme + OString(":") + OString( m_Code );
  return *this;
}

BOOL SBCIVRHandler::AnnouncementMap::Exists()const
{
	return PFile::Exists( m_Path.c_str() );
}

////////////////////////////////


SBCIVRHandler::SBCIVRHandler( 
  OpenSBC & ua 
  ) : B2BIVRInterface( ua )
{
}

SBCIVRHandler::~SBCIVRHandler()
{
}

void SBCIVRHandler::RefreshSupportedCodecs()
{
  OSSAppConfig * config = dynamic_cast<OpenSBC&>(GetB2BUA()).GetAppConfig();

  /// lock the config to make sure noone can change data via http admin until we are done
  if( config == NULL )
    return;

  PWaitAndSignal configLock( PHTTPConfig::m_HTTPConfigMutex );
  
  MediaServer * mediaServer = GetB2BUA().GetMediaServer();
  if( mediaServer )
  {
    PStringArray codecs;
    for( PINDEX i = 0; i <  config->GetListSize( configMediaServerSection, configKeyAutoAttendantCodecs ); i++ )
      codecs.AppendString( config->GetListItem( configMediaServerSection, configKeyAutoAttendantCodecs, i ) );

    //// if media formats is empty then
    //// add all supported codecs
    if( codecs.IsEmpty() )
    {
      OpalMediaFormatList mediaFormatList; 
      mediaFormatList += OpalPCM16;
      mediaFormatList += OpalG729_RAW;

      mediaFormatList = OpalTranscoder::GetPossibleFormats( mediaFormatList );
      for( PINDEX index = 0; index < mediaFormatList.GetSize(); ++index )
      {
        codecs.AppendString( mediaFormatList[index] );
      }
    }

    mediaServer->SetSupportedMediaFormat( codecs );
    PStringArray formatMask = mediaServer->GetMediaFormatMask();
    for( PINDEX index = 0; index < formatMask.GetSize(); ++index )
    {
      LOG( LogInfo(), "Media Format Mask == " << formatMask[index] );
    }
    mediaServer->ApplyMediaInfo();
  }
 
}

void SBCIVRHandler::RefreshAnnouncementMap()
{
  OSSAppConfig * config = dynamic_cast<OpenSBC&>(GetB2BUA()).GetAppConfig();

  if( config == NULL )
    return;

  PWaitAndSignal configLock( PHTTPConfig::m_HTTPConfigMutex );
  PWaitAndSignal lock( m_AnnouncementMapMutex );
  
  m_AnnouncementMap.RemoveAll();
  PINDEX mapSize = config->GetListSize( configMediaServerSection, configKeyAnnouncementErrorMap );
  for( PINDEX i = 0; i <  mapSize; i++ )
  {
    //errorMap.AppendString(  );
    OString token = (const char *)config->GetListItem( configMediaServerSection, configKeyAnnouncementErrorMap, i );
    if( !token.IsEmpty() )
    {
      AnnouncementMap * entry = new AnnouncementMap( token );
      if( entry->Exists() )
        m_AnnouncementMap.SetAt( entry->m_Key.c_str(), entry );
      else
      {
        PTRACE( 1, "Error Prompt " << entry->m_Path << "does not exists" );
        delete entry;
      }
    }
  }

  m_4xxErrorMap = (const char *)config->GetString( configMediaServerSection, configKeyAnnouncement4xxErrorMap, "prompts/english/error/call_failed.wav" );
  m_5xxErrorMap = (const char *)config->GetString( configMediaServerSection, configKeyAnnouncement5xxErrorMap, "prompts/english/error/call_failed.wav" );
  m_6xxErrorMap = (const char *)config->GetString( configMediaServerSection, configKeyAnnouncement5xxErrorMap, "prompts/english/error/call_failed.wav" );

  if( !PFile::Exists( m_4xxErrorMap.c_str() ) )
  {
    PTRACE( 1, "Error Prompt " << m_4xxErrorMap << " does not exists" );
    m_4xxErrorMap = "";
  }

  if( !PFile::Exists( m_5xxErrorMap.c_str() ) )
  {
    PTRACE( 1, "Error Prompt " << m_5xxErrorMap << " does not exists" );
    m_5xxErrorMap = "";
  }

  if( !PFile::Exists( m_6xxErrorMap.c_str() ) )
  {
    PTRACE( 1, "Error Prompt " << m_6xxErrorMap << " does not exists" );
    m_6xxErrorMap = "";
  }
}


void SBCIVRHandler::IVROnCreateConnection(
  B2BUAConnection & connection,
  MediaServerSession & session
)
{
  SIPURI requestURI;
  if( connection.GetLeg2Call()->GetCurrentUACInvite().GetRequestURI( requestURI ) )
  {
    if( requestURI.GetUser() == "annc" )
    {
      
      PSafePtr<OpalConnection> _conn = session.GetCall().GetConnection(1);
      if (_conn != NULL) 
        if (!PIsDescendant(&(*_conn), OpalIVRConnection))
          _conn = session.GetCall().GetConnection(0);

      if( _conn == NULL )
        return;

      dynamic_cast<OpalIVRConnection*>(_conn->GetSelf())->SetAutoConnect( FALSE );
      connection.SetIsAnnouncing( TRUE );
      connection.GetLeg1Call()->SetCallAnswerResponse( CallSession::DisconnectWithTemporarilyUnavailable );

      Reason reason;
      if( connection.GetLeg2Call()->GetCurrentUACInvite().GetReason( reason ) )
      {
        OStringArray tokens = reason.GetHeaderBody().Tokenise( ";", FALSE );
        if( tokens.GetSize() >= 2 )
        {
          OString proto = tokens[0].Trim();
          OString cause = tokens[1].Trim();
          PINDEX idx = cause.Find( "=", 5 );
          if( idx != P_MAX_INDEX )
          {
            OString code = cause.Mid( idx + 1 );
            int status_code = code.AsInteger();
            connection.GetLeg1Call()->SetCallAnswerResponse((CallSession::AnswerCallDeniedResponse)status_code);
          }
        }
      }
    }
  }
}

void SBCIVRHandler::OnIVREvent(
  B2BUAConnection * conn,
  const B2BIVREvent * evt
)
{
  
  OpenSBC & sbc = dynamic_cast<OpenSBC&>(GetB2BUA());

  if( evt == NULL || conn == NULL  )
    return;


  B2BIVREvent::Type type = evt->GetType();

  if( conn->IsAnnouncing() )
  {
    SIPURI requestURI;
    conn->GetLeg2Call()->GetCurrentUACInvite().GetRequestURI( requestURI );
    OnHandleAnnouncementEvent( type, conn, requestURI );
    return;
  }

  switch( type )
  {
    case B2BIVREvent::Event_IVROnOpenChannel:
      {
        conn->IVRPlayFile( "greeting", "prompts/basic/hello.wav" );
        conn->IVRPlayFile( "enter-pin", "prompts/basic/enter_pin.wav" );
        conn->IVRSetDTMFGrammar( "pin-collect", 4, '#' );
      }
      break;
    case B2BIVREvent::Event_IVROnEndPlaying:
      {
        const OnEndPlaying * eventObject = static_cast<const OnEndPlaying *>(evt);
        PTRACE( 1, "Finished playing " << eventObject->m_Identifier );
        /*if( eventObject->m_Identifier == "enter-pin" )
          conn->IVRSetDTMFGrammar( "pin-collect", 4, '#' );
        else if( eventObject->m_Identifier == "enter-number" )
          conn->IVRSetDTMFGrammar( "number-collect", 20, '#' );
        else */if( eventObject->m_Identifier == "call-transfer" )
        {
          SIPHeader h("number-collect");
          if( conn->PopInternalHeader( "number-collect", h ) )
            conn->IVRTransferCall( h.GetHeaderBody(), FALSE );
        }
      }

      break;
    //case B2BIVREvent::Event_IVROnUserInput:
    //  break;
    case B2BIVREvent::Event_IVROnEndCollection:
      {
        const OnEndCollection * eventObject = static_cast<const OnEndCollection *>(evt);
        PTRACE( 1, "Collected: " << eventObject->m_GrammarId << " : " << eventObject->m_GrammarBuffer );
        
        if( eventObject->m_GrammarId == "pin-collect" )
        {
          SIPURI userURI = conn->GetLeg1Call()->GetRemoteURI();
          SIPURI account;
          if( sbc.FindLocalDomainAccount( userURI, account ) )
          {
            if( account.GetPassword() == eventObject->m_GrammarBuffer )
            {
              conn->IVRPlayFile( "enter-number", "prompts/basic/enter_number.wav" );
              conn->IVRSetDTMFGrammar( "number-collect", 20, '#' );
            }else
            {
              conn->IVRPlayFile( "invalid-pin", "prompts/basic/invalid_pin.wav" );
              conn->IVRPlayFile( "enter-pin", "prompts/basic/enter_pin.wav" );
              conn->IVRSetDTMFGrammar( "pin-collect", 4, '#' );
            }
          }else
          {
            conn->IVRPlayFile( "invalid-pin", "prompts/basic/invalid_pin.wav" );
            conn->IVRPlayFile( "enter-pin", "prompts/basic/enter_pin.wav" );
            conn->IVRSetDTMFGrammar( "pin-collect", 4, '#' );
          }
        }else if( eventObject->m_GrammarId == "number-collect" )
        {
          SIPURI userURI = conn->GetLeg2Call()->GetRemoteURI();
          userURI.SetUser( eventObject->m_GrammarBuffer );
          if( sbc.GetSBCRoutingHandler()->GetStaticRoutes().HasRoute( userURI ) )
          {
            conn->IVRPlayFile( "call-transfer", "prompts/basic/call_transfer.wav" );
            conn->SetInternalHeader( "number-collect", eventObject->m_GrammarBuffer );
          }else
          {
            conn->IVRPlayFile( "invalid-number", "prompts/basic/invalid_number.wav" );
            conn->IVRPlayFile( "enter-number", "prompts/basic/enter_number.wav" );
            conn->IVRSetDTMFGrammar( "number-collect", 20, '#' );
            /// error message here
          }
        }
      }
      break;
    case B2BIVREvent::Event_IVROnTransferReject:
      break;
    default:
      break;
  }
}

void SBCIVRHandler::OnHandleAnnouncementEvent(
  B2BIVREvent::Type type,
  B2BUAConnection * conn,
  const SIPURI & requestURI
)
{
  if( conn == NULL )
    return;

  if( type == B2BIVREvent::Event_IVROnOpenChannel )
  {
    /// check if there is a play parameter;
    OString voiceFile;
    if( requestURI.GetParameter( "play", voiceFile ) )
    {
      conn->IVRPlayFile( "Error Announcement", voiceFile );
      return;
    }else if( FindAnnouncementErrorMap( conn->GetLeg2Call()->GetCurrentUACInvite(), voiceFile ) )
    {
      conn->IVRPlayFile( "Error Announcement", voiceFile );
      return;
    }else
    {
      conn->DestroyConnection();
    }
  }else if( type == B2BIVREvent::Event_IVROnEndPlaying )
  { 
    /// disconnect call after 1 second to be sure we don't clip audio at the end
    conn->StartAutoDestructTimer( 1000 );
  }
}

BOOL SBCIVRHandler::FindAnnouncementErrorMap(
  const SIPMessage & invite,
  OString & file
)
{

  Reason reason;
  if( !invite.GetReason( reason ) )
    return FALSE;

  OStringArray tokens;
  reason.GetHeaderBody().Tokenise( tokens, ";" );

  if( tokens.GetSize() < 3 )
    return FALSE;

  OString scheme = tokens[0].ToLower().Trim();
  OString code = tokens[1].Trim();
  PINDEX offSet = code.Find( "=", 5 );
  if( offSet == P_MAX_INDEX )
    return FALSE;

  code = code.Mid( offSet + 1 );
  
  OString key = scheme + OString(":") + code;

  if( !FindAnnouncementErrorMap( key, file ) )
  {
    ///check if defaults are set
    if( scheme == "sip" )
    {
      int statusCode = code.AsInteger();
      if( statusCode >= 400 && statusCode < 500 )
      {
        if( !m_4xxErrorMap.IsEmpty() )
        {
          file = m_4xxErrorMap;
          return TRUE;
        }
      }else if( statusCode >= 500 && statusCode < 600 )
      {
        if( !m_5xxErrorMap.IsEmpty() )
        {
          file = m_5xxErrorMap;
          return TRUE;
        }
      }else if( statusCode >= 600 && statusCode < 700 )
      {
        if( !m_6xxErrorMap.IsEmpty() )
        {
          file = m_6xxErrorMap;
          return TRUE;
        }
      }
    }
    return FALSE;
  }

  return TRUE;
}

BOOL SBCIVRHandler::FindAnnouncementErrorMap(
  const OString & key,
  OString & file
)
{
  PWaitAndSignal lock( m_AnnouncementMapMutex );
  AnnouncementMap * map = m_AnnouncementMap.GetAt( key.c_str() );
  if( map != NULL )
    file = map->m_Path;
  
  return map != NULL;
}


