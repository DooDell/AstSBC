/*
 *
 * SBCTrunk.cxx
 * 
  * Open SIP Stack ( OSS )
 *
 * Copyright (c) opensipstack.org.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either expressed or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is OpenSIPStack.
 *
 * The Initial Developer of the Original Code is opensipstack.org.
 *
 * The author of this code is Joegen E. Baclor
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * The OpenSIPStack Library includes some GPL/LGPL code libraries that MAY be 
 * enabled at compile time using the --enable-gpllibs configure switch.  If
 * enabled, the content of this file is published under the terms of GNU 
 * General Public License Version 2.  For a detailed list of the available
 * GPL code, see $(opensipstack)/gnu/README file.
 *
 * $Log: SBCTrunk.cxx,v $
 * Revision 1.25  2009/03/26 06:32:26  joegenbaclor
 * Added NAT port forwarding support
 *
 * Revision 1.24  2009/03/13 02:26:19  joegenbaclor
 * In this revision, we moved listener configuration to its own
 * page allowing all listeners to be configured seperately.
 * Previous behavior only allowed the main listener to be configured.
 * We have also added a out of dialog handler in the backdoor trunk
 * to allow unsolcited messages like OPTIONS and NOTIFY to passthrough.
 * Both of these functionalities are still under testing.
 *
 * Revision 1.23  2009/03/03 08:05:44  joegenbaclor
 * *** empty log message ***
 *
 * Revision 1.22  2009/01/14 02:10:04  joegenbaclor
 * some shutdown enhancements
 *
 * Revision 1.21  2008/12/22 06:51:46  joegenbaclor
 * Application Timers for Alerting and Connect is causing a deadlock on connection destruction.
 * To address this issue, we modified opensipstack to take care of the timers in the ICT Layer.
 *
 * Revision 1.20  2008/10/22 05:21:31  joegenbaclor
 * Changing default value of m_AcceptAllCalls to TRUE
 *
 * Revision 1.19  2008/08/19 14:16:03  joegenbaclor
 * Finalizing new log/config directory structure
 *
 * Revision 1.18  2008/08/19 09:33:59  joegenbaclor
 * Transfered default log DIR to $(HOME)/opensipstack/OpenSBC.  This is to make sure
 *  that the application always has write access to the directory
 *
 * Revision 1.17  2008/06/13 13:05:34  joegenbaclor
 * implemented announcement service
 *
 * Revision 1.16  2008/06/02 08:42:29  joegenbaclor
 * Merging-in Solegy required patches
 *
 * Revision 1.15  2008/05/27 03:16:05  joegenbaclor
 * More work on leak free process termination.
 *
 * Revision 1.14  2008/04/28 09:31:56  joegenbaclor
 * HTTP admin aesthetics.
 * Allowed User-Agent header to be configurable
 * Incremented release version
 *
 * Revision 1.13  2007/10/30 16:39:36  joegenbaclor
 * Modified default thread count for trunks
 *
 * Revision 1.12  2007/10/10 16:59:57  joegenbaclor
 * Logging improvement
 *
 * Revision 1.11  2007/10/10 01:00:18  joegenbaclor
 * Added check for Allow header when local refer is enabled
 *
 * Revision 1.10  2007/10/05 07:14:01  joegenbaclor
 * Introduced new method OnInitialConfigChanged to SIP Trunk to be called on startup
 *
 * Revision 1.9  2007/10/02 16:42:56  joegenbaclor
 * Marking initial release of SIP Trunking
 *
 * Revision 1.8  2007/09/04 21:58:13  joegenbaclor
 * More work on SIP Trunks.
 *
 * Revision 1.7  2007/08/28 01:25:19  joegenbaclor
 * Completed recording SIP signals for CALEA in pcap format
 *
 * Revision 1.6  2007/08/22 06:12:39  joegenbaclor
 * Compile aesthetics
 *
 * Revision 1.5  2007/08/20 06:41:59  joegenbaclor
 * Upgraded version to 1.1.5
 *
 * Revision 1.4  2007/08/20 06:24:45  joegenbaclor
 * commiting alpha code for new backdoor using trunks
 *
 * Revision 1.3  2007/08/16 13:25:50  joegenbaclor
 * More work on trunking
 *
 * Revision 1.2  2007/08/12 01:57:49  joegenbaclor
 * More work on trunking
 *
 * Revision 1.1  2007/08/08 07:36:08  joegenbaclor
 * Added SBCTrunk classes
 * Removed singleton factory for OSSAppConfig
 *
 *
 */

#include "SBCTrunk.h"
#include "OString.h"
#include "Version.h"
#include "SBCConfigParams.h"
#include "B2BUAConnection.h"
#include "Encryption.h"

using namespace B2BUA;
using namespace Tools;
using namespace Encryption;

#define new PNEW

SBCTrunkProcess::SBCTrunkProcess(
  SBCTrunkManager * manager,
  WORD sipPort,
  const char * trunkName,
  OSSAppConfig * config
) : OSSApplication( "OpenSBC", TRUE )
{
  m_Trunk = NULL;
  m_EndPoint = NULL;
  m_TrunkHTTPPort = 0;
  m_TrunkSIPPort = sipPort;
  m_TrunkName = trunkName;
  m_TrunkManager = manager;
  m_AppConfig = config;
  m_HasExternalConfig =  m_AppConfig != NULL ? TRUE : FALSE;
  m_CanDeleteAppConfig = !m_HasExternalConfig;
  

  SetProductName( m_TrunkName );
  SetMajorVersion( SBC_MAJOR_VERSION );
  SetMinorVersion( SBC_MINOR_VERSION );
  SetBuildNumber( SBC_BUILD_NUMBER );
}

SBCTrunkProcess::SBCTrunkProcess(
  SBCTrunkManager * manager,
  WORD httpPort,
  WORD sipPort,
  const char * trunkName,
  const char * configTemplate
  ) : OSSApplication( "OpenSBC", TRUE )
{
  m_Trunk = NULL;
  m_EndPoint = NULL;
  m_TrunkHTTPPort = httpPort;
  m_TrunkSIPPort = sipPort;
  m_TrunkName = trunkName;
  m_TrunkConfigTemplate = configTemplate;
  m_TrunkManager = manager;
  m_AppConfig = NULL;

  SetProductName( m_TrunkName );
  SetMajorVersion( SBC_MAJOR_VERSION );
  SetMinorVersion( SBC_MINOR_VERSION );
  SetBuildNumber( SBC_BUILD_NUMBER );
}

SBCTrunkProcess::~SBCTrunkProcess()
{
}

PString SBCTrunkProcess::GetConfigurationFilePath()const
{
  return m_TrunkConfigTemplate;
}

BOOL SBCTrunkProcess::OnTrunkStart()
{

  PTRACE( 1, GetName() << " Trunk is starting" );

  if( !m_HasExternalConfig )
  {
    httpNameSpace.AddResource(new PHTTPDirectory("data", "data"));
    httpNameSpace.AddResource(new PServiceHTTPDirectory("html", "html"));

    if( m_AppConfig == NULL )
      m_AppConfig = OnCreateAppConfig();


    if(  !m_FirstRun && !m_AppConfig->Initialize( GetConfigurationFilePath() ) )
    {
      PTRACE( 1, "Unable to Initialize HTTP Server" );
      return FALSE;
    }

    if( m_FirstRun  )
    {
      if( !StartHTTPService() )
        return FALSE;
      else
        PTRACE(1, "Opened master socket for HTTP: " << m_AppConfig->GetHTTPPort() );
    }
  }else
  {
    /// attach a notifier to the external config 
    /// so that we get notified when something changes
    this->AddExternalConfig( *m_AppConfig );
  }
  
  m_FirstRun= FALSE;

  m_Trunk = m_TrunkManager->OnCreateTrunk( this );

  return TRUE;
}

void SBCTrunkProcess::OnTrunkStop()
{
  //if( m_AppConfig != NULL && !m_HasExternalConfig )
  //{
  //  delete m_AppConfig;
  //  m_AppConfig = NULL;
  //}

  if( m_EndPoint != NULL )
    delete m_EndPoint;

  if( m_Trunk != NULL )
  {
    m_Trunk->OnSignalShutDown();
    delete m_Trunk;
  }
}

OSSAppConfig * SBCTrunkProcess::OnCreateAppConfig()
{
  return new SBCTrunkConfig(  this, m_TrunkHTTPPort );
}

void SBCTrunkProcess::OnStart( 
  OSSAppConfig & /*config*/ 
)
{
  PAssertAlways( PUnimplementedFunction );
}

#if defined(_MSC_VER)
#pragma warning(push)
#pragma warning(disable:4311)
#endif

void SBCTrunkProcess::OnConfigChanged( 
  OSSAppConfig & config,
  const char * section  
)
{
  PThread::Create( 
      PCREATE_NOTIFIER( 
      OnConfigChanged ), 
      (INT)(OSSAppConfig*)&config, 
      PThread::AutoDeleteThread,
      PThread::NormalPriority,
      section  );
}

void SBCTrunkProcess::OnExternalConfigChanged( 
  OSSAppConfig & config,
  const char * section  
)
{
  PThread::Create( 
      PCREATE_NOTIFIER( 
      OnExternalConfigChanged ), 
      (INT)(OSSAppConfig*)&config, 
      PThread::AutoDeleteThread,
      PThread::NormalPriority,
      section  );
}

void SBCTrunkProcess::OnConfigChanged(
  PThread &,
  INT
)
{
}

void SBCTrunkProcess::OnExternalConfigChanged(
  PThread & thrd,
  INT
)
{
  PWaitAndSignal configLock( PHTTPConfig::m_HTTPConfigMutex );
  const char * section = static_cast<const char *>(thrd.GetThreadName());
  PTRACE( 4, "SBCTrunkProcess::OnExternalConfigChanged() - " << section );
  if( m_Trunk != NULL )
  {
    m_Trunk->OnConfigChanged( *m_AppConfig, section );
  }
}


void SBCTrunkProcess::OnHandleCommandArgs(
  PINDEX /*i*/,
  const PString & /*arg*/
)
{
  PAssertAlways( PUnimplementedFunction );
}

/////////////////////////////////////////////////////////////////////////////////////

SBCTrunkConfig::SBCTrunkConfig( 
  OSSApplication * app, 
  WORD httpPort 
) : OSSAppConfig( app, HTTPDefaultProvider, httpPort )
{
}
  
BOOL SBCTrunkConfig::Initialize( 
  const PFilePath & path 
)
{
  PWaitAndSignal lock( m_InitializeMutex );

  if( m_Type == XMLRPCClientProvider ) /// No need to initialize anything
  {
    m_FirstRun = FALSE;
    return TRUE;
  }

  PXML xml;
  BOOL hasConfig = xml.LoadFile( path );

  PStringStream configTitle;
  
  
  if( !hasConfig )
  {
#if 0
    configTitle << m_Application->GetName() << " HTTP Admin";
#endif
    PSYSTEMLOG(Fatal, "Unable to find " << path << ".  " << "Please install this file in the same directory as your applcation" );
    return FALSE;
  }else
  {
    PXMLElement * appName = xml.GetElement( "Application" );
   // PXMLElement * httpPort = xml.GetElement( "HTTPPort" );
    PXMLElement * versionId = xml.GetElement( "Version" );
    
    if( appName == NULL )
      configTitle << m_Application->GetName() << " HTTP Admin";
    else
      configTitle << appName->GetData() << " HTTP Admin";

    if( versionId != NULL )
      m_VersionId = versionId->GetData();
  }
  
  
  m_Config = PConfig( configTitle );

  // Get the HTTP basic authentication info
  PString adminUserName = m_Config.GetString( "HTTP User" );
  PString adminPassword = PHTTPPasswordField::Decrypt( m_Config.GetString( "HTTP Password" ) );
  PHTTPSimpleAuth authority( m_Application->GetName(), adminUserName, adminPassword );

  // Create the parameters URL page, and start adding fields to it
  PConfigPage * mainConfig = new PConfigPage( 
    *(m_Application), 
    configTitle, 
    configTitle, 
    authority );
  
  ConfigPages extraConfig;
  extraConfig.DisallowDeleteObjects();


  if( hasConfig )
  {
    IntializeConfigPages( xml, extraConfig, authority );
  }


#if P_SSL
  // SSL certificate file.
  PString certificateFile = "cert.pem";
  if (!m_Application->SetServerCertificate(certificateFile, TRUE)) {
    PSYSTEMLOG(Fatal, "BMAC\tCould not load certificate \"" << certificateFile << '"');
    return FALSE;
  }
#endif

  adminUserName = m_Config.GetString( "HTTP User" );
  adminPassword = PHTTPPasswordField::Decrypt(m_Config.GetString( "HTTP Password" ));

  // HTTP authentication username/password
  mainConfig->Add(new PHTTPStringField( "HTTP User", 25, adminUserName));
  mainConfig->Add(new PHTTPPasswordField( "HTTP Password", 25, adminPassword));

  CreateConfig( xml, extraConfig );

  /// Build the links
  PServiceHTML htmllink( configTitle );
  htmllink << PHTML::Paragraph()
      << PHTML::HotLink("Home Page") << "Reload page" << PHTML::HotLink()
      << "&nbsp;&nbsp;&nbsp;&nbsp;"
      << PHTML::HotLink("/") << "Home page" << PHTML::HotLink();

  mainConfig->BuildHTML( htmllink );

  PINDEX i = 0;

  for( i = 0; i < extraConfig.GetSize(); i++ )
  {
    PConfigPage * extra = (PConfigPage *)extraConfig.GetAt( i );
    PServiceHTML link( extra->GetConfigSection() );
    link << PHTML::Paragraph()
      << PHTML::HotLink(extra->GetConfigSection()) << "Reload page" << PHTML::HotLink()
      << "&nbsp;&nbsp;&nbsp;&nbsp;"
      << PHTML::HotLink("/") << "Home page" << PHTML::HotLink();

    extra->BuildHTML( link );

   
  }

  m_Application->GetHTTPNameSpace().AddResource( mainConfig, PHTTPSpace::Overwrite );
 

  for( i = 0; i < extraConfig.GetSize(); i++ )
  {
    PConfigPage * extra = (PConfigPage *)extraConfig.GetAt( i );
    m_Application->GetHTTPNameSpace().AddResource( extra, PHTTPSpace::Overwrite );
  }

  m_Application->OnAdditionalHTTPResource( authority );

    

  PHTML html;
  html << PHTML::Title(configTitle)
        << PHTML::Body()
        << m_Application->GetPageGraphic();

  html  << PHTML::Paragraph() << "<center>"
        << PHTML::HotLink(configTitle) << configTitle << PHTML::HotLink()
        << PHTML::Paragraph();

 
  for( i = 0; i < extraConfig.GetSize(); i++ )
  {
    PConfigPage * extra = (PConfigPage *)extraConfig.GetAt( i );
    PString linkTitle = extra->GetConfigSection();

    html  << PHTML::Paragraph() << "<center>"
          << PHTML::HotLink(linkTitle) << linkTitle << PHTML::HotLink()
          << PHTML::Paragraph();
  }

  m_Application->OnAdditionalHTTPLinks( html );

  html  << PHTML::HRule()
        << m_Application->GetCopyrightText()
        << PHTML::Body();

  m_Application->GetHTTPNameSpace().AddResource(new PServiceHTTPString("welcome.html", html), PHTTPSpace::Overwrite);


  m_FirstRun = FALSE;

  return TRUE;
}

/////////////////////////////////////////////////////////////////////////////////////

SBCTrunk::SBCTrunk(
  SBCTrunkProcess * trunkProcess,
  B2BUserAgent::UAMode mode
) : OpenSBC( trunkProcess->GetTrunkManager()->GetMainProcess(), mode )
{
  m_TrunkProcess = trunkProcess;
}

SBCTrunk::~SBCTrunk()
{
}

OpenSBC * SBCTrunk::GetMainTrunk()const
{  
  return m_TrunkProcess->GetTrunkManager()->GetMainProcess()->GetSBC(); 
}

OSSAppConfig * SBCTrunk::GetAppConfig()const
{
  return m_TrunkProcess->GetAppConfig();
}

B2BCallInterface * SBCTrunk::OnCreateCallInterface()
{
  return new B2BCallInterface( *this );
}

B2BAuthInterface * SBCTrunk::OnCreateAuthInterface()
{
  return new B2BAuthInterface( *this );
}

B2BMediaInterface * SBCTrunk::OnCreateMediaInterface()
{
  return new B2BMediaInterface( *this );
}

B2BRoutingInterface * SBCTrunk::OnCreateRoutingInterface()
{
  return new B2BRoutingInterface( *this );
}

B2BIVRInterface * SBCTrunk::OnCreateIVRInterface()
{
  return new B2BIVRInterface( *this );
}

void SBCTrunk::OnTransactionCreated(
  const SIPMessage & request,
  SIPTransaction *& transaction
)
{
  /// nothing to do here.  each specific trunk should
  /// implement this function for their specific custom handlers
}


void SBCTrunk::OnConfigChanged( 
  OSSAppConfig & config,
  const char * /*_section*/  
)
{
  int workerThreadCount = 1;
  
  

  //B2BUAConnection::SetSeizeTimeout( config.GetInteger( configKeySection, configKeySeizeTimeout, 0 ) );
  //B2BUAConnection::SetAlertingTimeout( config.GetInteger( configKeySection, configKeyAlertingTimeout, 0 ) );
  
  // Enable Feature SIP Session Timers
  GetB2BUAEndPoint()->EnableSessionTimer( FALSE );

  Encryption::Engine::m_Key = (const char *)config.GetString( configKeySection, configKeyEncryptionKey, Encryption::Engine::m_DefKey );
  OString encMode = config.GetString( configKeySection, configKeyEncryption, "XOR" );
  if( encMode *= "XOR" )
    Encryption::Engine::m_Type = Encryption::Engine::Type_XOR;
  else if( encMode *= "DiffShift" )
    Encryption::Engine::m_Type = Encryption::Engine::Type_DiffShift;

 
  m_AcceptAllCalls = config.GetBoolean( configKeyTrustedDomainSection, configKeyAcceptAllCalls, 1 );

  /// create the domain account database
  PStringArray domains;
  for( PINDEX i = 0; i <  config.GetListSize( configKeyTrustedDomainSection, configKeyTrustedDomainList ); i++ )
    domains.AppendString( config.GetListItem( configKeyTrustedDomainSection, configKeyTrustedDomainList, i ) );
  AddTrustedDomains( domains, TRUE );

  /// chech whether we should enable local Refer
  BOOL localRefer = config.GetBoolean( configKeySection, 
    configKeyEnableLocalRefer, 0 );
  GetB2BUAEndPoint()->EnableLocalRefer( localRefer );

  PStringArray privacyDomains;
  for( PINDEX i = 0; i <  config.GetListSize( configKeyPrivacyTrustedDomainSection, configKeyPrivacyDomain ); i++ )
    privacyDomains.AppendString( config.GetListItem( configKeyPrivacyTrustedDomainSection, configKeyPrivacyDomain, i ) );
  AddPrivacyTrustedDomains( privacyDomains, TRUE );
  SetPrivacyDefaultRealm( config.GetString( configKeyPrivacyTrustedDomainSection, configKeyPrivacyDefaultRealm, "" ) );

  Initialize( workerThreadCount );

  m_RoutingHandler->RefreshStaticRoutes();

}


//////////////////////////////////////////////////////////////////////////////

SBCTrunkManager::SBCTrunkManager( 
  OpenSBCDaemon * mainProcess,
  OpenSBC * mainTrunk
)
{
  m_MainProcess = mainProcess;
  m_MainTrunk = mainTrunk;
}
  
BOOL SBCTrunkManager::CreateTrunkProcess(
  WORD sipPort,
  const char * trunkName,
  OSSAppConfig * config
)
{
  PWaitAndSignal lock( m_TrunkProcessListMutex );

  if( GetTrunkProcess( trunkName ) != NULL )
  {
    PTRACE( 1, "Attempt to create a none unique trunk process - " << trunkName );
    return FALSE;
  }

  SBCTrunkProcess * trunkProcess = new SBCTrunkProcess( this, sipPort, trunkName, config);

  BOOL ok = m_TrunkProcessList.SetAt( trunkName, trunkProcess );
  if( !ok )
    delete trunkProcess;
  else
    trunkProcess->OnTrunkStart();

  return ok;
}

BOOL SBCTrunkManager::CreateTrunkProcess(
  WORD httpPort,
  WORD sipPort,
  const char * trunkName,
  const char * configTemplate
)
{
  PWaitAndSignal lock( m_TrunkProcessListMutex );
  if( GetTrunkProcess( trunkName ) != NULL )
  {
    PTRACE( 1, "Attempt to create a none unique trunk process - " << trunkName );
    return FALSE;
  }

  SBCTrunkProcess * trunkProcess = new SBCTrunkProcess( this, httpPort, sipPort, trunkName, configTemplate);

  BOOL ok = m_TrunkProcessList.SetAt( trunkName, trunkProcess );
  if( !ok )
    delete trunkProcess;
  else
    trunkProcess->OnTrunkStart();

  return ok;

}

SBCTrunkProcess * SBCTrunkManager::GetTrunkProcess(
  const char * trunkName
)
{
  PWaitAndSignal lock( m_TrunkProcessListMutex );
  return m_TrunkProcessList.GetAt( trunkName );
}

SBCTrunk * SBCTrunkManager::OnCreateTrunk( 
  SBCTrunkProcess * trunkProcess 
)
{
  return m_MainProcess->OnCreateTrunk( trunkProcess );
}

void SBCTrunkManager::OnCleanup()
{
  PWaitAndSignal lock( m_TrunkProcessListMutex );
  PINDEX count = m_TrunkProcessList.GetSize();
  for( PINDEX i = 0; i < count; i++ )
  {
    ((SBCTrunkProcess &)m_TrunkProcessList.GetDataAt( i )).OnTrunkStop();
    //m_TrunkProcessList.GetDataAt( i ).GetTrunk()->OnSignalShutDown();
  }
}

