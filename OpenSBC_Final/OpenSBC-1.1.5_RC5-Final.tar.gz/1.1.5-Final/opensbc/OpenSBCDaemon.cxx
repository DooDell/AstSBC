#include "OpenSBC.h"
#include "SBCRoutingHandler.h"
#include "SBCCallHandler.h"
#include "SBCAuthHandler.h"
#include "SBCIVRHandler.h"

/// Status pages
#include "SBCGarbageCollectorPage.h"
#include "SBCCallStatusPage.h"
#include "SBCMemoryDumpPage.h"


#if HAS_PYTHON_SAPI
#include "SBCScriptHandler.h"
#endif

#include "SBCTrunk.h"
#include "Version.h"
#include "Encryption.h"
#include "ResourceCounter.h"
#include "Solegy.h"


#include "SBCConfigParams.h"
#include "SBCBackDoorTrunk.h"
#include "SBCCALEATrunk.h"

#include "SBCSIPTrunk.h"
#include "SBCSIPTrunkRegSession.h"

#ifdef ENABLE_SWITCHED_ENDPOINT
#if ENABLE_SWITCHED_ENDPOINT
#include "SBCSwitchEndPoint.h"
using namespace SWITCH;
#endif
#endif

OpenSBCDaemon::OpenSBCDaemon() : OSSApplication( "OpenSBC", FALSE )
{
  m_DefaultLogger = NULL;
  m_IsInitialized = FALSE;
  m_HasExtendedArgs = FALSE;
  m_SBC = NULL;
  m_EndPoint = NULL;
  m_Registrar = NULL;
  m_Proxy = NULL;
  m_MediaServer = NULL;
  m_TrunkManager = NULL;

#if PMEMORY_CHECK
  m_HeapAllocationNumber = 0;
#endif 

  /*
  
 
  args.Parse("v-version."
             "d-daemon."
             "c-console."
             "h-help."
             "x-execute."
             "p-pid-file:"
             "H-handlemax:"
             "i-ini-file:"
             "k-kill."
             "t-terminate."
             "s-status."
             "l-log-file:"
             "u-uid:"
             "g-gid:"
             "C-core-size:"
             "T-control:"
             "D-debug."
             "P-http-port:"
             "X-misc-param-1:"
             "Y-misc-param-2:"
             "Z-misc-param-3:");
*/


  SetMajorVersion( SBC_MAJOR_VERSION );
  SetMinorVersion( SBC_MINOR_VERSION );
  SetBuildNumber( SBC_BUILD_NUMBER );
  SetRevisionNumber( SBC_REVISION_NUMBER );

#ifdef WIN32
#if !CONSOLE_SVCPROC
  PArgList & args = GetArguments();
  if (args.HasOption('l')) 
  {
    systemLogFileName = args.GetOptionString('l');
    if (systemLogFileName.IsEmpty()) 
    {
      cout << "error: must specify file name for -l" << endl;
    }
    else if (PDirectory::Exists(systemLogFileName))
      systemLogFileName = PDirectory(systemLogFileName) + PProcess::Current().GetFile().GetFileName() + ".log";
  }else
  {
    systemLogFileName = GetFile().GetDirectory() + "opensbc.log";
  }
#endif
#endif
 

  SBCPHPSapi::PHP5_startup();
 

}

OpenSBCDaemon::~OpenSBCDaemon()
{

  SBCPHPSapi::PHP5_shutdown();

  if( m_SBC != NULL )
    delete m_SBC;

  if( m_EndPoint != NULL )
    delete m_EndPoint;


  if( m_Registrar != NULL )
    delete m_Registrar;

  if( m_Proxy != NULL )
    delete m_Proxy;

  if( m_MediaServer != NULL )
    delete m_MediaServer;

  if( m_DefaultLogger != NULL )
    delete m_DefaultLogger;
}

class SBCPHPHandler : public SBCPHPSapi
{
public:
  SBCPHPHandler( OpenSBCDaemon & sbc,
                 const PHTTPSpace & urlSpace ) 
    : SBCPHPSapi( urlSpace ),
      m_Daemon( sbc ) 
  {
  }

  bool PHP_evaluate(
    const std::string & funcName,
    PHPVariantMap & in,
    PHPVariantMap & out 
  )
  {
    return m_Daemon.PHP_evaluate( funcName, in, out );
  }

  OpenSBCDaemon & m_Daemon;
};

PHTTPServer * OpenSBCDaemon::OnCreateHTTPServer(const PHTTPSpace & urlSpace)
{
  return new SBCPHPHandler( *this, urlSpace );
}

bool OpenSBCDaemon::PHP_evaluate(
  const std::string & /*func*/,
  PHPVariantMap & /*in*/,
  PHPVariantMap & /*out*/ 
)
{
#if 0
  if( func       == "SBC::GetCompilationDate" )
  {
    PString cd = GetCompilationDate().AsString();
    out["SBC::String"] = std::string( (const char *)cd );
  }else if( func == "sbc.get_start_time" )
  {
    
  }else if( func == "sbc.get_oss_info" )
  {
  }
#endif
  return false;
}

// pure virtual from OSSApplication
void OpenSBCDaemon::OnStart( 
  OSSAppConfig & config 
)
{
  /// zero out thread count
  PThread::m_Count.SetValue(0);

  OString confVersionId = config.GetVersionId();
  if( confVersionId.IsEmpty() )
    confVersionId = "(empty)";
  
  if( config.GetVersionId() != XML_CONFIG_ID )
  {
    PTRACE( 1, "*** FATAL ERROR *** Attempt to load incorrect version of oss-application.conf.xml!!!" );
    PTRACE( 1, "*** FATAL ERROR *** oss-application.conf.xml version " << confVersionId << " FOUND." );
    PTRACE( 1, "*** FATAL ERROR *** oss-application.conf.xml version " << XML_CONFIG_ID << " EXPECTED!!!" );
    
#ifdef _WIN32
    OStringStream errorStrm;
    errorStrm << "*** FATAL ERROR *** oss-application.conf.xml version " << confVersionId << " FOUND."
    << " oss-application.conf.xml version " << XML_CONFIG_ID << " EXPECTED!!!";
    MessageBox(NULL, errorStrm.str().c_str(), GetName(), MB_TASKMODAL);
#endif

    exit( 1 );
  }
  
  if( SIPTransportManager::m_IfTableMutex == NULL )
    SIPTransportManager::m_IfTableMutex = new PMutex();
  PTRACE( 1, "Interface Address: " << SIPTransportManager::GetDefaultInterfaceAddress() );
  
  if( HasExtendedArgs() )  
    m_InstanceId = m_ExtendedArgs.GetParameter( "iid" );

  int logLevel = config.GetInteger( configKeySection, configKeyAppLogLevel, 3 );
  
  
  m_LogFilePrefix = GetLogDirectory() + "/" + config.GetString( 
    configKeySection, configKeyAppLogFilePrefix, "b2bua" ) ;

  if( !m_InstanceId.IsEmpty() )
    m_LogFilePrefix = (const char *)(GetLogDirectory() + "/" + m_InstanceId);
  
  if( m_SBC == NULL )
  {
    OString mode = m_ExtendedArgs.GetParameter( "ua-mode" );
  
    if( mode.IsEmpty() )
      mode = (const char *)config.GetString( configKeySection, configKeySBCMode, "B2B Only Mode" );

    B2BUserAgent::UAMode uaMode = B2BUserAgent::B2BOnlyMode;

    if( mode == "B2B Only Mode" || mode == "B2BOnlyMode" )
      uaMode = B2BUserAgent::B2BOnlyMode;
    else if( mode == "B2BUpperReg Mode" || mode == "B2BUpperRegMode" )
      uaMode = B2BUserAgent::B2BUpperRegMode;

    LoggingIncrementingFileStream * defLogger = NULL;
    if( ( uaMode == B2BUserAgent::B2BOnlyMode ) &&
          config.GetType() == OSSAppConfig::XMLRPCClientProvider )
    {
      OString addr = m_ExtendedArgs.GetParameter( "syslog" );
      if( addr.IsEmpty() )
        addr = "127.0.0.1:514";
      
      SIPURI sysLogAddress( addr );
      Logger::SetDefaultLogStream( 
        new LoggingSystemLogStream( 
          m_InstanceId, 
          PIPSocket::Address( "127.0.0.1"  ),
          sysLogAddress.GetAddress(),
          (WORD)sysLogAddress.GetPort().AsInteger(),
          TRUE ) );

    }else
    {
      defLogger = new LoggingIncrementingFileStream( m_LogFilePrefix.c_str(), OString( GetProcessID() ).c_str() );
      PTRACE( 1, "Log-Level: " << logLevel << " >>> " << defLogger->GetFile()->GetFilePath() );
      SetDefaultLogger( defLogger );
      Logger::SetDefaultLogStream( defLogger );
    }

    m_SBC = new OpenSBC( this, uaMode, FALSE, TRUE );

    if( uaMode == B2BUserAgent::B2BOnlyMode )
    {
      PTRACE( 1, "Running in Back To Back Mode" );
    }else if( uaMode == B2BUserAgent::B2BUpperRegMode )
    {
      PTRACE( 1, "Running in Back To Back with Upper Registration Mode" );
    }
#ifdef ENABLE_SWITCHED_ENDPOINT
#if ENABLE_SWITCHED_ENDPOINT
    if( m_EndPoint == NULL )
    {
      m_EndPoint = new SBCSwitchEndPoint(*m_SBC, config.GetInteger( configKeySection, configKeySessionThreadCount, 10 ), 1024 * 2 );
    }
#else
    if( m_EndPoint == NULL )
      m_EndPoint = new SBCB2BUAEndPoint( *m_SBC, config.GetInteger( configKeySection, configKeySessionThreadCount, 10 ), 1024 * 2 );
#endif
#else
    if( m_EndPoint == NULL )
      m_EndPoint = new SBCB2BUAEndPoint( *m_SBC, config.GetInteger( configKeySection, configKeySessionThreadCount, 10 ), 1024 * 2 );
#endif
    m_SBC->SetEndPoint( m_EndPoint );

    if( m_Registrar == NULL )
    {
      m_Registrar = new B2BUserAgent::Registrar( *m_SBC, 1, 1024 * 2 );
      m_Registrar->GetRegistrationDB().RecoverRegistrations();
    }

    m_SBC->SetRegistrar( m_Registrar );

    if( m_Proxy == NULL )
      m_Proxy = new B2BUserAgent::Proxy( *m_SBC, 1, 1024 * 2 );

    BOOL enableMediaServer = config.GetBoolean( configMediaServerSection, configKeyEnableMediaServer, TRUE );
    
    if( enableMediaServer && m_MediaServer == NULL  )
    {

      OpenSBC * mainSBC = GetSBC();
      SIPURI bindAddress((const char *)config.GetString( configKeySIPTransportSection, configKeyMediaServerInterfaceAddress, "sip:*:5066" ));
      PIPSocket::Address iface = PIPSocket::Address( bindAddress.GetHost() );
      if( !iface.IsValid() )
        iface = mainSBC->GetTransportManager()->GetDefaultInterfaceAddress( FALSE );
      WORD port = (WORD)bindAddress.GetPort().AsUnsigned();

      m_MediaServer = new MS::MediaServer( m_EndPoint );
      m_MediaServer->SetInterfaceAddress( iface.AsSTLString() );
      m_MediaServer->SetListenerPortBase( port );
      m_SBC->SetMediaServer( m_MediaServer );
    }

    m_SBC->SetProxy( m_Proxy );

    m_SBC->OnStart( config );

  }

  OnCreateTrunks( config );

  PTRACE( 1, "OpenSBC STARTED " << m_InstanceId ); 
}

BOOL OpenSBCDaemon::OnGetTailFile( PFilePath & tailFile )
{
	if( m_DefaultLogger == NULL )
		return FALSE;

  tailFile = m_DefaultLogger->GetFile()->GetFilePath();
  return TRUE;
}

void OpenSBCDaemon::OnCreateTrunks( OSSAppConfig & config  )
{
  if( m_TrunkManager == NULL )
    m_TrunkManager = new SBCTrunkManager( this, m_SBC );

  BOOL enableCaleaPort = config.GetBoolean( configKeySection, 
    configKeyEnableCaleaPort, TRUE );
  BOOL enableTrunkPort = config.GetBoolean( configKeySection, 
    configKeyEnableTrunkPort, TRUE );

  // if we are in B2BUpperRegMode then enable backdoor port always
  if( m_SBC->GetUAMode() == OpenSBC::B2BUpperRegMode )
    m_TrunkManager->CreateTrunkProcess( 5062, "Backdoor", &config );

  if( enableCaleaPort )
    m_TrunkManager->CreateTrunkProcess( 5064, "CALEA", &config );

  if( enableTrunkPort )
    m_TrunkManager->CreateTrunkProcess( 5066, "SIP", &config );
}

SBCTrunk * OpenSBCDaemon::OnCreateTrunk( SBCTrunkProcess * trunkProcess )
{
  PString trunkName = trunkProcess->GetName();
  if( trunkName *=  "Backdoor"  )
    return new SBCBackDoorTrunk( trunkProcess );
  else if( trunkName *= "CALEA" )
    return new SBCCALEATrunk( trunkProcess );
  else if( trunkName *= "SIP" )
    return new SBCSIPTrunk( trunkProcess );

  PAssertAlways( PLogicError );

  return NULL;
}

void OpenSBCDaemon::OnStop()
{

  if( m_TrunkManager != NULL )
  {
    m_TrunkManager->OnCleanup();
    delete m_TrunkManager;
    m_TrunkManager = NULL;
  }
  
  

  if( m_EndPoint != NULL )
  {
    //m_EndPoint->GetUserAgent().Terminate();
    delete m_EndPoint;
    m_EndPoint = NULL;
  }

  if( m_Registrar != NULL )
  {
    delete m_Registrar;
    m_Registrar = NULL;
  }

  if( m_Proxy != NULL )
  {
    delete m_Proxy;
    m_Proxy = NULL;
  }

  if( m_MediaServer != NULL )
  {
    delete m_MediaServer;
    m_MediaServer = NULL;
  }

  if( m_SBC != NULL )
  {
    m_SBC->OnStop();
    m_SBC->Terminate();
    delete m_SBC;
    m_SBC = NULL;
  }

  OSSApplication::OnStop();
  
#ifndef WIN32
  _exit( 0 );
#endif
}

OSSAppConfig * OpenSBCDaemon::OnCreateAppConfig()
{
  OString configMode = m_ExtendedArgs.GetParameter( "config-mode" );
  OString xmlRPCPort =  m_ExtendedArgs.GetParameter( "xml-rpc-port" );
  OString xmlRPCServer = m_ExtendedArgs.GetParameter( "xml-rpc-server" );
  OString instanceId = m_ExtendedArgs.GetParameter( "iid" );

  WORD port = static_cast<WORD>(xmlRPCPort.IsEmpty() ? 10000 : xmlRPCPort.AsInteger());
  if( configMode.IsEmpty() )
  {
    return new OSSAppConfig( this, OSSAppConfig::HTTPDefaultProvider, port );
  }else
  {
    if( (configMode *= "XMLRPCClientProvider") && !xmlRPCServer.IsEmpty() )
    {
      return new OSSAppConfig( this, OSSAppConfig::XMLRPCClientProvider, port, xmlRPCServer, instanceId );
    }else if( configMode *= "XMLRPCAndHTTPServerProvider" )
    {
      return new OSSAppConfig( this, OSSAppConfig::XMLRPCAndHTTPServerProvider, port );
    }else if( configMode *= "XMLRPCServerProviderOnly" )
    {
      return new OSSAppConfig( this, OSSAppConfig::XMLRPCServerProviderOnly, port );
    }
  }

  return new OSSAppConfig( this, OSSAppConfig::HTTPDefaultProvider, port );
}

#if defined(_MSC_VER)
#pragma warning(push)
#pragma warning(disable:4311)
#endif

void OpenSBCDaemon::OnConfigChanged( 
  OSSAppConfig & config,
  const char * section 
)
{
  PThread::Create( 
      PCREATE_NOTIFIER( 
      OnConfigChanged ), 
      (INT)(OSSAppConfig*)&config, 
      PThread::AutoDeleteThread,
      PThread::NormalPriority,
      section  );

}


#if defined(_MSC_VER)
#pragma warning(pop)
#endif

void OpenSBCDaemon::OnConfigChanged( PThread & thrd, INT data )
{
  static BOOL firstRun = TRUE;


  OSSAppConfig * _config = reinterpret_cast<OSSAppConfig*>(data);
  const char * section = static_cast<const char *>(thrd.GetThreadName());

  if( _config != NULL )
  {
    OSSAppConfig & config = *_config;
    PTRACE( 1, "Configuration change detected" ); 

    
    
    if( firstRun )
    {
      int logLevel = config.GetInteger( configKeySection, configKeyAppLogLevel, 3 );
      OString syslogAddress = config.GetString( configKeySection, 
        configKeySysLogServer, "127.0.0.1" );

      OString logPrefix = config.GetString( 
        configKeySection, configKeyAppLogFilePrefix, "b2bua" );

      if( !m_InstanceId.IsEmpty() )
        logPrefix  += "-" + m_InstanceId;

      Logger::SetDefaultLevel( logLevel );
      PTRACE( 1, "Setting SIP Log Level to " << logLevel );
      
      int ptraceLevel = config.GetInteger( configKeySection, configKeyCoreLogLevel, 1 );
      SetPTraceLevel( ptraceLevel );
      PTRACE( 1, "Setting PTRACE Log Level to " << ptraceLevel );
    }

    

    

    if( m_SBC != NULL )
      m_SBC->OnConfigChanged( config, section );

    m_IsInitialized = TRUE;

    if( firstRun )
    {
      if( m_SBC->GetUAMode() == B2BUserAgent::B2BOnlyMode && 
            config.GetType() == OSSAppConfig::XMLRPCClientProvider )
      {

        OString serverURL = GetExtendedArgs().GetParameter( "xml-rpc-server" );
        if( !serverURL.IsEmpty() )
        {
          PArray<PStringToString>  cmd;
          PArray<PStringToString>  response;
          PStringToString * cmdParams = new PStringToString();
          cmdParams->SetAt( "iid", GetExtendedArgs().GetParameter( "iid" ) );
          cmd.SetAt( 0, cmdParams );
          config.SendRequest( "B2BUA.Startup", cmd, response, serverURL.c_str() );
        }
      }

      // Set the User-Agent header sent by OSBC in SIP requests
      OStringStream uaNameDflt;
      uaNameDflt << "OpenSBC v" << SBC_MAJOR_VERSION << "." << SBC_MINOR_VERSION << "." << SBC_BUILD_NUMBER << "-" << SBC_REVISION_NUMBER;
      OString uaName = config.GetString( configKeySection, configKeyUserAgentName, uaNameDflt.str().c_str() );
      if( uaName.IsEmpty() )
        uaName = uaNameDflt.str();
      m_SBC->SetUserAgentBuildName( uaName.c_str() );

      SBCTrunkProcess * tp = this->m_TrunkManager->GetTrunkProcess( "SIP" );
      if( tp != NULL )
      {
        SBCSIPTrunk * sipTrunk = dynamic_cast<SBCSIPTrunk *>(tp->GetTrunk());
        if( sipTrunk != NULL )
        {
          sipTrunk->OnInitialConfigChanged( *_config, section );
        }
      }
    }
    firstRun = FALSE;
  } 

 
}

void OpenSBCDaemon::OnSIGUSR1()
{
  m_SBC->OnSignalShutDown();
  Terminate();
}

void OpenSBCDaemon::OnSIGUSR2()
{
  m_SBC->OnSignalShutDown();
  Terminate();
}

void OpenSBCDaemon::OnHandleCommandArgs(
    PINDEX i,
    const PString & arg
)
{
  if( i == 0 )  /// 'X'
  {
    m_HasExtendedArgs = TRUE;
    m_ExtendedArgs = (const char *)arg;
    PTRACE( 1, m_ExtendedArgs.AsString() );
  }
}

void OpenSBCDaemon::SetPTraceLevel( unsigned level )
{
#if PTRACING
  PTrace::SetLevel( level );
  PTrace::ClearOptions( PTrace::Timestamp );
  PTrace::SetOptions( PTrace::DateAndTime  );
#endif
}

PString OpenSBCDaemon::GetReleaseDate()
{
  PStringStream stream;
  stream << __DATE__ << " " << __TIME__;
  return stream;
}

void OpenSBCDaemon::OnAdditionalHTTPResource(
  PHTTPSimpleAuth & authority
)
{
  httpNameSpace.AddResource( new SBCRegistrationStatusPage( *this, authority ), PHTTPSpace::Overwrite );
  httpNameSpace.AddResource( new SBCTrunkRegistrationStatusPage( *this, authority ), PHTTPSpace::Overwrite );
  httpNameSpace.AddResource( new SBCResourceCounterPage( *this, authority ), PHTTPSpace::Overwrite );
  httpNameSpace.AddResource( new SBCListenerListPage( *this, authority ), PHTTPSpace::Overwrite );
  httpNameSpace.AddResource( new SBCGarbageCollectorPage( *this, authority ), PHTTPSpace::Overwrite );
  httpNameSpace.AddResource( new SBCCallStatusPage( *this, authority ), PHTTPSpace::Overwrite );
#if PMEMORY_CHECK
  httpNameSpace.AddResource( new SBCMemoryDumpPage( *this, authority ), PHTTPSpace::Overwrite );
#endif
}

void OpenSBCDaemon::OnAdditionalHTTPLinks( 
  PHTML & html 
)
{
  html << PHTML::Paragraph() << "<center>" << PHTML::HotLink("OpenSBC Registration Status") << "OpenSBC Registration Status" << PHTML::HotLink();
  html << PHTML::Paragraph() << "<center>" << PHTML::HotLink("SIP Trunk Registration Status") << "SIP Trunk Registration Status" << PHTML::HotLink();
  html << PHTML::Paragraph() << "<center>" << PHTML::HotLink("OpenSBC Resource Counters") << "OpenSBC Resource Counters" << PHTML::HotLink();
  html << PHTML::Paragraph() << "<center>" << PHTML::HotLink("OpenSBC Transport Status") << "OpenSBC Transport Status" << PHTML::HotLink();
  html << PHTML::Paragraph() << "<center>" << PHTML::HotLink(SBCGarbageCollectorPage::GetLinkName()) << SBCGarbageCollectorPage::GetLinkName() << PHTML::HotLink();
  html << PHTML::Paragraph() << "<center>" << PHTML::HotLink(SBCCallStatusPage::GetLinkName()) << SBCCallStatusPage::GetLinkName() << PHTML::HotLink();
#if PMEMORY_CHECK  
  html << PHTML::Paragraph() << "<center>" << PHTML::HotLink(SBCMemoryDumpPage::GetLinkName()) << SBCMemoryDumpPage::GetLinkName() << PHTML::HotLink();
#endif
}

static void SpliceMacro(PString & text, const PString & token, const PString & value)
{

  PRegularExpression RegEx("<?!--#status[ \t\r\n]+" + token + "[ \t\r\n]*-->?",
                           PRegularExpression::Extended|PRegularExpression::IgnoreCase);
  PINDEX pos, len;
  while (text.FindRegEx(RegEx, pos, len))
    text.Splice(value, pos, len);
}


PCREATE_SERVICE_MACRO_BLOCK(SBCRegInfo,P_EMPTY,P_EMPTY,htmlBlock)
{
  OpenSBCDaemon * app = dynamic_cast<OpenSBCDaemon *>( OSSApplication::GetInstance() );
  return app->OnLoadRegistrationStatus( htmlBlock );
}

PString OpenSBCDaemon::OnLoadRegistrationStatus( 
  const PString & htmlBlock 
)
{
#if 0
  RegistrationDatabase & regDB = GetSBC()->GetRegistrar()->GetRegistrationDB();
  PWaitAndSignal lock( regDB.GetMutex() );
  OString substitution;

  for( PINDEX i = 0; i < regDB.GetSize(); i++ )
  {
    CachePointer * cacheData = regDB.CreatePointer( i );
    if( cacheData != NULL )
    {
      SIPMessage * reg = dynamic_cast<SIPMessage *>(cacheData->GetObject());
      if( reg != NULL )
      {
        PString insert = htmlBlock;
        //PString inst = insert.c_str();
        SpliceMacro(insert, "URI", (*cacheData)->GetObjectIdentifier() );
        SpliceMacro(insert, "AOR", reg->GetContactTopURI().AsString( FALSE ) );
        SpliceMacro(insert, "Expires", OString( (*cacheData)->GetLifeSpan() ) );
        SpliceMacro(insert, "Call-ID", reg->GetCallId());
        substitution+=(const char *)insert;
      }

      delete cacheData;
    }
  }

  return substitution;
#endif
  OString substitution;
  REGISTRAR::Registrar * registrar = GetSBC()->GetLocalRegistrar();
  PWaitAndSignal lock( registrar->m_RegistrationListMutex );
  int count = registrar->m_RegistrationList.GetSize();
  for( PINDEX i = 0; i < count; i++ )
  {
    REGISTRAR::Registration & reg = registrar->m_RegistrationList.GetDataAt(i);

    Contact contacts;

    OString aor = reg.GetURI().AsString();
    reg.ListRecords( contacts );

    for( PINDEX j = 0; j < contacts.GetSize(); j++ )
    {
      ContactURI binding;
      contacts.GetURI( binding, j );
      OString expires;
      binding.GetParameter("expires", expires );

      PString insert = htmlBlock;
      //PString inst = insert.c_str();
      SpliceMacro(insert, "AOR", aor );
      SpliceMacro(insert, "BINDING", binding.GetURI().AsString() );
      SpliceMacro(insert, "EXPIRES", expires );
      substitution+=(const char *)insert;

    }
    
  }
  return substitution;
}

BOOL SBCRegistrationStatusPage::Post(PHTTPRequest & request,
                          const PStringToString & data,
                          PHTML & msg)
{
  
  PTRACE(2, "Main\tClear call POST received " << data);

  msg << PHTML::Title() << "Accepted Control Command" << PHTML::Body()
      << PHTML::Heading(1) << "Accepted Control Command" << PHTML::Heading(1);

  app.OnPostControl(data, msg);


  msg << PHTML::Paragraph()
      << PHTML::HotLink(request.url.AsString()) << "Reload page" << PHTML::HotLink()
      << "&nbsp;&nbsp;&nbsp;&nbsp;"
      << PHTML::HotLink("/") << "Home page" << PHTML::HotLink();

  PServiceHTML::ProcessMacros(request, msg, "html/status.html",
                              PServiceHTML::LoadFromFile|PServiceHTML::NoSignatureForFile);
                              
  return TRUE;
}

BOOL OpenSBCDaemon::OnPostControl(const PStringToString & data, PHTML & msg)
{
  BOOL ok = FALSE;
  for( PINDEX i = 0; i < data.GetSize(); i++ )
  {
    OString key = data.GetKeyAt(i);
    OString command = data.GetDataAt(i);

    if (command == "Unregister") 
    {
      SIPSession::GCRef session = GetSBC()->GetRegistrar()->FindGCRefByCallId( key );
      if( session != NULL )
      {
        ok = TRUE;
        session->Destroy();

        msg << PHTML::Heading(2) << "AOR removed for Call-ID " << key << PHTML::Heading(2);

      }else
      {
        msg << PHTML::Heading(2) << "No Registration Found for Call-ID " << key  << PHTML::Heading(2);
      }
    }
  }
  return ok;
}

void OpenSBCDaemon::OnAdditionalXMLRPCMethods(
  PStringArray & methods
)
{
  methods.AppendString( "Registrar.GetRegStatus" );
  methods.AppendString( "Registrar.Unregister" );
  methods.AppendString( "Routing.AddRelayRoute" );
  methods.AppendString( "Proxy.Startup" );
  methods.AppendString( "B2BUA.Startup" );
}

void OpenSBCDaemon::OnCustomXMLRPCRequest(
  const PString & method,
  PArray<PStringToString> & request,
  PArray<PStringToString> & response
)
{
  if( !m_IsInitialized )
  {
    PStringToString * immediateResponse = new PStringToString();
    immediateResponse->SetAt( "ResponseCode", "999" );
    immediateResponse->SetAt( "ResponseMessage", "Server Not Ready" );
    response.SetAt( 0, immediateResponse );
    return;
  }

  PStringToString * requestParams = dynamic_cast<PStringToString*>(request.GetAt(0));

  if( method == "Registrar.GetRegStatus" )
  {
    RegistrationDatabase & regDB = GetSBC()->GetRegistrar()->GetRegistrationDB();
    PWaitAndSignal lock( regDB.GetMutex() );
    OString substitution;

    PStringToString * immediateResponse = new PStringToString();
    immediateResponse->SetAt( "ResponseCode", "0" );
    immediateResponse->SetAt( "ResponseMessage", "Ok" );
    response.SetAt( 0, immediateResponse );
    
    for( PINDEX i = 0; i < regDB.GetSize(); i++ )
    {
      CachePointer * cacheData = regDB.CreatePointer( i );
      if( cacheData != NULL )
      {
        SIPMessage * reg = dynamic_cast<SIPMessage *>(cacheData->GetObject());
        if( reg != NULL )
        {
          PStringToString * record = new PStringToString();
          record->SetAt( "URI", (*cacheData)->GetObjectIdentifier() );
          record->SetAt( "AOR", reg->GetContactTopURI().AsString( FALSE ) );
          record->SetAt( "Expires", OString( (*cacheData)->GetLifeSpan() ) );
          record->SetAt( "Call-ID", reg->GetCallId());
          response.SetAt( i + 1, record );
        }
        delete cacheData;
      }
    }
  }else if( method == "Routing.AddRelayRoute" )
  {
    PStringToString * immediateResponse = new PStringToString();
    if( requestParams == NULL )
    { 
      immediateResponse->SetAt( "ResponseCode", "999" );
      immediateResponse->SetAt( "ResponseMessage", "Missing Route parameter" );
      response.SetAt( 0, immediateResponse );
      return;
    }else
    {
      PString * route = requestParams->GetAt( "Route" );
      if( route == NULL || route->IsEmpty() )
      {
        immediateResponse->SetAt( "ResponseCode", "999" );
        immediateResponse->SetAt( "ResponseMessage", "Missing Route parameter" );
        response.SetAt( 0, immediateResponse );
        return;
      }

      GetSBC()->GetSBCRoutingHandler()->AppendAppRelayRoutes( *route );
      immediateResponse->SetAt( "ResponseCode", "0" );
      immediateResponse->SetAt( "ResponseMessage", "Ok" );
      response.SetAt( 0, immediateResponse );
      return;
    }
  }else if( method == "Registrar.Unregister" )
  {
    PString * key = requestParams->GetAt( "Call-ID" );
    PStringToString * immediateResponse = new PStringToString();
    if( key == NULL || key->IsEmpty() )
    {
      immediateResponse->SetAt( "ResponseCode", "999" );
      immediateResponse->SetAt( "ResponseMessage", "Missing Call-ID parameter" );
      response.SetAt( 0, immediateResponse );
      return;
    }

    SIPSession::GCRef session = GetSBC()->GetRegistrar()->FindGCRefByCallId( (const char *)*key );
    OStringStream msg;
    if( session != NULL )
    {
      session->Destroy();
      msg << "AOR removed for Call-ID " << *key ;
    }else
    {
      msg << "No Registration Found for Call-ID " << *key ;
    }

    immediateResponse->SetAt( "ResponseCode", "0" );
    immediateResponse->SetAt( "ResponseMessage", "Ok" );
    response.SetAt( 0, immediateResponse );

    PStringToString * message = new PStringToString();
    message->SetAt( "Message", msg.str().c_str() );
    response.SetAt( 1, message );
    return;
  }
}

const PString& OpenSBCDaemon::GetName() const
{
  return PProcess::GetName();
}

SBCRegistrationStatusPage::SBCRegistrationStatusPage(OpenSBCDaemon & _app, PHTTPAuthority & auth)
  : PServiceHTTPString("OpenSBC Registration Status", "", "text/html; charset=UTF-8", auth),
    app(_app)
{
  
  PHTML html;

  html << PHTML::Title("OpenSBC Registration Status")
       << "<meta http-equiv=\"Refresh\" content=\"30\">\n"
       << PHTML::Body()
       << app.GetPageGraphic()

       << PHTML::Paragraph()
       << PHTML::HotLink("OpenSBC Registration Status") << "Reload page" << PHTML::HotLink()
       << "&nbsp;&nbsp;&nbsp;&nbsp;"
       << PHTML::HotLink("/") << "Home page" << PHTML::HotLink()

       << PHTML::Paragraph() /*<< "<center>"*/
       << PHTML::Form("POST")
       << PHTML::TableStart("border=1")
       << PHTML::TableRow()
       << PHTML::TableHeader()
       << "&nbsp;AOR&nbsp;"
       << PHTML::TableHeader()
       << "&nbsp;BINDING&nbsp;"
       << PHTML::TableHeader()
       << "&nbsp;EXPIRES&nbsp;"
       << "<!--#macrostart SBCRegInfo-->"
         << PHTML::TableRow()
         << PHTML::TableData()
         << "<!--#status AOR-->"
         << PHTML::TableData()
         << "<!--#status BINDING-->"
         << PHTML::TableData()
         << "<!--#status EXPIRES-->"
       << "<!--#macroend SBCRegInfo-->"
       << PHTML::TableEnd()

       
       << PHTML::Form()
       << PHTML::HRule()

       << app.GetCopyrightText()
       << PHTML::Body();

  string = html;

}

PCREATE_SERVICE_MACRO_BLOCK(SBCTrunkRegInfo,P_EMPTY,P_EMPTY,htmlBlock)
{
  OpenSBCDaemon * app = dynamic_cast<OpenSBCDaemon *>( OSSApplication::GetInstance() );
  return app->OnLoadTrunkRegistrationStatus( htmlBlock );
}

PString OpenSBCDaemon::OnLoadTrunkRegistrationStatus( 
  const PString & htmlBlock 
)
{
  SBCTrunkProcess * trunkProcess = m_TrunkManager->GetTrunkProcess( "SIP" );
  if( trunkProcess == NULL )
    return "";

  SBCSIPTrunk * trunk = dynamic_cast<SBCSIPTrunk *>(trunkProcess->GetTrunk());
  SBCSIPTrunkRegManager * regManager = trunk->GetTrunkRegManager();
  if( regManager == NULL )
    return "";

  SBCSIPTrunkReg * trunkReg = regManager->GetSIPTrunkReg( 0 );
  OString substitution;
  if( trunkReg != NULL )
  {
  
    for( PINDEX i = 0;; i++ )
    {
      SIPSession::GCRef regRef = trunkReg->GetRegSessionByIndex( i );
      if( regRef == NULL )
        break;

      SBCSIPTrunkRegSession * regSession = dynamic_cast<SBCSIPTrunkRegSession *>( regRef.GetObject() );
      SIPMessage msg = regSession->GetRequest();
      OString callId = msg.GetCallId();
      OString uri = msg.GetToURI().AsString( FALSE );
      OString contact = msg.GetTopContactURI().AsString( FALSE );
      
      PString insert = htmlBlock;
      //PString inst = insert.c_str();
      SpliceMacro(insert, "URI", msg.GetToURI().AsString( FALSE ) );
      SpliceMacro(insert, "AOR", msg.GetTopContactURI().AsString( FALSE ) );
      SpliceMacro(insert, "Call-ID", msg.GetCallId());
      SpliceMacro(insert, "Status", regSession->GetRegistrationStatus() );
      substitution+=(const char *)insert;
    }
  }
  return substitution;
}

SBCTrunkRegistrationStatusPage::SBCTrunkRegistrationStatusPage(OpenSBCDaemon & _app, PHTTPAuthority & auth)
  : PServiceHTTPString("SIP Trunk Registration Status", "", "text/html; charset=UTF-8", auth),
    app(_app)
{
  
  PHTML html;

  html << PHTML::Title("SIP Trunk Registration Status")
       << "<meta http-equiv=\"Refresh\" content=\"30\">\n"
       << PHTML::Body()
       << app.GetPageGraphic()

       << PHTML::Paragraph()
       << PHTML::HotLink("SIP Trunk Registration Status") << "Reload page" << PHTML::HotLink()
       << "&nbsp;&nbsp;&nbsp;&nbsp;"
       << PHTML::HotLink("/") << "Home page" << PHTML::HotLink()

       << PHTML::Paragraph() /*<< "<center>"*/
       << PHTML::Form("POST")
       << PHTML::TableStart("border=1")
       << PHTML::TableRow()
       << PHTML::TableHeader()
       << "&nbsp;URI&nbsp;"
       << PHTML::TableHeader()
       << "&nbsp;AOR&nbsp;"
       << PHTML::TableHeader()
       << "&nbsp;Call-ID&nbsp;"
       << PHTML::TableHeader()
       << "&nbsp;Status&nbsp;"
       << "<!--#macrostart SBCTrunkRegInfo-->"
         << PHTML::TableRow()
         << PHTML::TableData()
         << "<!--#status URI-->"
         << PHTML::TableData()
         << "<!--#status AOR-->"
         << PHTML::TableData()
         << "<!--#status Call-ID-->"
         << PHTML::TableData()
         << "<!--#status Status-->"
         << PHTML::TableData()
       << "<!--#macroend SBCTrunkRegInfo-->"
       << PHTML::TableEnd()

       
       << PHTML::Form()
       << PHTML::HRule()

       << app.GetCopyrightText()
       << PHTML::Body();

  string = html;

}

BOOL SBCTrunkRegistrationStatusPage::Post(PHTTPRequest & request,
                          const PStringToString & data,
                          PHTML & msg)
{
  
  PTRACE(2, "Main\tClear call POST received " << data);

  msg << PHTML::Title() << "Accepted Control Command" << PHTML::Body()
      << PHTML::Heading(1) << "Accepted Control Command" << PHTML::Heading(1);

  app.OnPostControl(data, msg);


  msg << PHTML::Paragraph()
      << PHTML::HotLink(request.url.AsString()) << "Reload page" << PHTML::HotLink()
      << "&nbsp;&nbsp;&nbsp;&nbsp;"
      << PHTML::HotLink("/") << "Home page" << PHTML::HotLink();

  PServiceHTML::ProcessMacros(request, msg, "html/status.html",
                              PServiceHTML::LoadFromFile|PServiceHTML::NoSignatureForFile);
                              
  return TRUE;
}


PCREATE_SERVICE_MACRO_BLOCK(SBCCounters,P_EMPTY,P_EMPTY,htmlBlock)
{
  OpenSBCDaemon * app = dynamic_cast<OpenSBCDaemon *>( OSSApplication::GetInstance() );
  return app->OnLoadResourceCounters( htmlBlock );
}

SBCResourceCounterPage::SBCResourceCounterPage(OpenSBCDaemon & _app, PHTTPAuthority & auth)
  : PServiceHTTPString("OpenSBC Resource Counters", "", "text/html; charset=UTF-8", auth),
                       app(_app)
{
  
  PHTML html;

  html << PHTML::Title("OpenSBC Resource Counters")
      << "<meta http-equiv=\"Refresh\" content=\"5\">\n"
      << PHTML::Body()
      << app.GetPageGraphic()

      << PHTML::Paragraph()
      << PHTML::HotLink("OpenSBC Resource Counters") << "Reload page" << PHTML::HotLink()
      << "&nbsp;&nbsp;&nbsp;&nbsp;"
      << PHTML::HotLink("/") << "Home page" << PHTML::HotLink()

      << PHTML::Paragraph() /*<< "<center>"*/
      << PHTML::Form("POST")
      << PHTML::TableStart("border=1")
      << PHTML::TableRow()
      
      << PHTML::TableHeader()
      << "&nbsp;ICT&nbsp;"
      << PHTML::TableHeader()
      << "&nbsp;NICT&nbsp;"
      << PHTML::TableHeader()
      << "&nbsp;IST&nbsp;"
      << PHTML::TableHeader()
      << "&nbsp;NIST&nbsp;"
      << PHTML::TableHeader()
      << "&nbsp;Timer&nbsp;"
      << PHTML::TableHeader()
      << "&nbsp;CallSession&nbsp;"
      << PHTML::TableHeader()
      << "&nbsp;Connection&nbsp;"
      << PHTML::TableHeader()
      << "&nbsp;Registration&nbsp;"
      << PHTML::TableHeader()
      << "&nbsp;RTPSession&nbsp;"
      << PHTML::TableHeader()
      << "&nbsp;EventQueue&nbsp;"
      << PHTML::TableHeader()
      << "&nbsp;Cache&nbsp;"
      << PHTML::TableHeader()
      << "&nbsp;Garbage&nbsp;"
      << PHTML::TableHeader()
      << "&nbsp;Threads&nbsp;"
  
      << "<!--#macrostart SBCCounters-->"
      << PHTML::TableRow()
      
      << PHTML::TableData()
      << "<!--#status ICT-->"

      << PHTML::TableData()
      << "<!--#status NICT-->"

      << PHTML::TableData()
      << "<!--#status IST-->"

      << PHTML::TableData()
      << "<!--#status NIST-->"
      
      << PHTML::TableData()
      << "<!--#status Timer-->"

      << PHTML::TableData()
      << "<!--#status CallSession-->"

      << PHTML::TableData()
      << "<!--#status Connection-->"

      << PHTML::TableData()
      << "<!--#status Registration-->"

      << PHTML::TableData()
      << "<!--#status RTPSession-->"

      << PHTML::TableData()
      << "<!--#status EventQueue-->"

      << PHTML::TableData()
      << "<!--#status Cache-->"

      << PHTML::TableData()
      << "<!--#status Garbage-->"

      << PHTML::TableData()
      << "<!--#status Threads-->"
      
      << "<!--#macroend SBCCounters-->"
      << PHTML::TableEnd()

      << PHTML::TableStart("border=1")
      << PHTML::TableRow()

      << PHTML::TableHeader()
      << "&nbsp;Total Connections&nbsp;"
      << PHTML::TableHeader()
      << "&nbsp;Total Registrations&nbsp;"
      << PHTML::TableHeader()
      << "&nbsp;Total Seizures&nbsp;"
      << PHTML::TableHeader()
      << "&nbsp;Failed Connections&nbsp;"
      << PHTML::TableHeader()
      << "&nbsp;Average Call Duration&nbsp;"
      << PHTML::TableHeader()
      << "&nbsp;Highest Call Duration&nbsp;"

      << "<!--#macrostart SBCCounters-->"
      << PHTML::TableRow()

      << PHTML::TableData()
      << "<!--#status TotalConnection-->"

      << PHTML::TableData()
      << "<!--#status TotalRegistration-->"

      << PHTML::TableData()
      << "<!--#status TotalSeizure-->"

      << PHTML::TableData()
      << "<!--#status FailedConnection-->"

      << PHTML::TableData()
      << "<!--#status AverageCallDuration-->"

      << PHTML::TableData()
      << "<!--#status HighestCallDuration-->"

      << "<!--#macroend SBCCounters-->"
      << PHTML::TableEnd()

       
      << PHTML::Form()
      << PHTML::HRule()

      << app.GetCopyrightText()
      << PHTML::Body();

  string = html;

}

PString OpenSBCDaemon::OnLoadResourceCounters( 
    const PString & htmlBlock 
                                               )
{

  PString substitution;
  PString insert = htmlBlock;
     
  RCLOCK();
  SpliceMacro(insert, "ICT", (int)ResourceCounter::m_RC_ICT );
  SpliceMacro(insert, "NICT", (int)ResourceCounter::m_RC_NICT);
  SpliceMacro(insert, "IST", (int)ResourceCounter::m_RC_IST);
  SpliceMacro(insert, "NIST", (int)ResourceCounter::m_RC_NIST);
  SpliceMacro(insert, "Timer", (int)ResourceCounter::m_RC_Timer);
  SpliceMacro(insert, "CallSession", (int)ResourceCounter::m_RC_CallSession );
  SpliceMacro(insert, "Connection", (int)ResourceCounter::m_RC_Connection );
  SpliceMacro(insert, "Registration", (int)ResourceCounter::m_RC_Registration );
  SpliceMacro(insert, "RTPSession", (int)ResourceCounter::m_RC_RTPSession);
  SpliceMacro(insert, "EventQueue", (int)ResourceCounter::m_RC_EventQueue );
  SpliceMacro(insert, "Cache", (int)ResourceCounter::m_RC_Cache );
  SpliceMacro(insert, "Garbage", (int)ResourceCounter::m_RC_Garbage);
  SpliceMacro(insert, "Threads", (int)PThread::m_Count);

  SpliceMacro(insert, "TotalConnection", (int)ResourceCounter::m_RC_TotalConnection);
  SpliceMacro(insert, "TotalRegistration", (int)ResourceCounter::m_RC_TotalRegistration);
  SpliceMacro(insert, "TotalSeizure", (int)ResourceCounter::m_RC_TotalSeizure);
  SpliceMacro(insert, "FailedConnection", (int)ResourceCounter::m_RC_FailedConnection);
  SpliceMacro(insert, "AverageCallDuration", (int)ResourceCounter::m_RC_AverageCallDuration);
  SpliceMacro(insert, "HighestCallDuration", (int)ResourceCounter::m_RC_HighestCallDuration);
  
  substitution+=insert;
 
  return substitution;
}


PCREATE_SERVICE_MACRO_BLOCK(SBCListener,P_EMPTY,P_EMPTY,htmlBlock)
{
  OpenSBCDaemon * app = dynamic_cast<OpenSBCDaemon *>( OSSApplication::GetInstance() );
  return app->OnLoadListenerList( htmlBlock );
}


SBCListenerListPage::SBCListenerListPage(OpenSBCDaemon & _app, PHTTPAuthority & auth)
  : PServiceHTTPString("OpenSBC Transport Status", "", "text/html; charset=UTF-8", auth),
                       app(_app)
{
  
  PHTML html;

  html << PHTML::Title("OpenSBC Transport Status")
//      << "<meta http-equiv=\"Refresh\" content=\"5\">\n"
      << PHTML::Body()
      << app.GetPageGraphic()

      << PHTML::Paragraph()
      << PHTML::HotLink("OpenSBC Transport Status") << "Reload page" << PHTML::HotLink()
      << "&nbsp;&nbsp;&nbsp;&nbsp;"
      << PHTML::HotLink("/") << "Home page" << PHTML::HotLink()

      << PHTML::Paragraph() /*<< "<center>"*/
      << PHTML::Form("POST")
      << PHTML::TableStart("border=1")
      << PHTML::TableRow()
      
      << PHTML::TableHeader()
      << "&nbsp;User Agent Name&nbsp;"

      << PHTML::TableHeader()
      << "&nbsp;Listener Address&nbsp;"
      
      << PHTML::TableHeader()
      << "&nbsp;Packets Read&nbsp;"

      << PHTML::TableHeader()
      << "&nbsp;Packets Sent&nbsp;"

      << PHTML::TableHeader()
      << "&nbsp;Write Thread&nbsp;"

      << PHTML::TableHeader()
      << "&nbsp;Read Thread&nbsp;"

      << PHTML::TableHeader()
      << "&nbsp;Transport Error&nbsp;"

      
  
      << "<!--#macrostart SBCListener-->"
      << PHTML::TableRow()
      
      << PHTML::TableData()
      << "<!--#status User Agent Name-->"

      << PHTML::TableData()
      << "<!--#status Listener Address-->"

      << PHTML::TableData()
      << "<!--#status Packets Read-->"

      << PHTML::TableData()
      << "<!--#status Packets Sent-->"

      << PHTML::TableData()
      << "<!--#status Write Thread-->"

      << PHTML::TableData()
      << "<!--#status Read Thread-->"

      << PHTML::TableData()
      << "<!--#status Transport Error-->"
      
      << "<!--#macroend SBCListener-->"
      << PHTML::TableEnd()
       
      << PHTML::Form()
      << PHTML::HRule()

      << app.GetCopyrightText()
      << PHTML::Body();

  string = html;

}




PString OpenSBCDaemon::OnLoadListenerList( 
  const PString & htmlBlock 
)
{
  SIPTransport::ListenerInfo info;
  SIPTransport::Statistics stats;

  GetSBC()->GetTransportManager()->GetTransportListenerInfo( SIPTransport::UDP, info );
  GetSBC()->GetTransportManager()->GetTransportStatistics( SIPTransport::UDP, stats );

  OString substitution;
  PINDEX i = 0;

  /// main trunk
  for( i = 0; i < info.m_InterfaceAddress.GetSize(); i++ )
  {
    PString insert = htmlBlock;
    if( i == 0 )
      SpliceMacro(insert, "User Agent Name", "Main Trunk" );
    //else
    //  SpliceMacro(insert, "User Agent Name", "");
    SpliceMacro(insert, "Listener Address", info.m_InterfaceAddress[i]  );

    if( i == 0 )
    {
      SpliceMacro(insert, "Packets Read", stats.m_PacketsRead  );
      SpliceMacro(insert, "Packets Sent", stats.m_PacketsSent  );
      SpliceMacro(insert, "Write Thread", stats.m_WriteThreadRunning ? "Yes" : "No"  );
      SpliceMacro(insert, "Read Thread", stats.m_ReadThreadRunning ? "Yes" : "No"  );
      SpliceMacro(insert, "Transport Error", PString( stats.m_LastSocketError ) + " " + PString( stats.m_LastSocketErrorText )  );
    }

    substitution+=(const char *)insert;
  }

  for( i = 0; i < info.m_FailedInterfaceAddress.GetSize(); i++ )
  {
    PString insert = htmlBlock;
    PStringStream strm;
    strm << info.m_FailedInterfaceAddress[i] << " *** FAILED ***";
    SpliceMacro(insert, "Listener Address",  strm );
    substitution+=(const char *)insert;
  }

  ///SIP Trunks
  SBCTrunkProcess * backdoor = m_TrunkManager->GetTrunkProcess( "Backdoor" );
  if( backdoor != NULL )
  {
    SIPTransport::ListenerInfo trunkInfo;
    SIPTransport::Statistics trunkStats;
    backdoor->GetTrunk()->GetTransportManager()->GetTransportListenerInfo( SIPTransport::UDP, trunkInfo );
    backdoor->GetTrunk()->GetTransportManager()->GetTransportStatistics( SIPTransport::UDP, trunkStats );

    for( i = 0; i < trunkInfo.m_InterfaceAddress.GetSize(); i++ )
    {
      PString insert = htmlBlock;
      if( i == 0 )
        SpliceMacro(insert, "User Agent Name", "Backdoor Trunk" );

      SpliceMacro(insert, "Listener Address", trunkInfo.m_InterfaceAddress[i]  );

      if( i == 0 )
      {
        SpliceMacro(insert, "Packets Read", trunkStats.m_PacketsRead  );
        SpliceMacro(insert, "Packets Sent", trunkStats.m_PacketsSent  );
        SpliceMacro(insert, "Write Thread", trunkStats.m_WriteThreadRunning ? "Yes" : "No"  );
        SpliceMacro(insert, "Read Thread", trunkStats.m_ReadThreadRunning ? "Yes" : "No"  );
        SpliceMacro(insert, "Transport Error", PString( trunkStats.m_LastSocketError ) + " " + PString( trunkStats.m_LastSocketErrorText )  );
      }

      substitution+=(const char *)insert;
    }

    for( i = 0; i < trunkInfo.m_FailedInterfaceAddress.GetSize(); i++ )
    {
      PString insert = htmlBlock;
      PStringStream strm;
      strm << trunkInfo.m_FailedInterfaceAddress[i] << " *** FAILED ***";
      SpliceMacro(insert, "Listener Address",  strm );
      substitution+=(const char *)insert;
    }
  }

  
  SBCTrunkProcess * calea = m_TrunkManager->GetTrunkProcess( "CALEA" );
  if( calea != NULL )
  {
    SIPTransport::ListenerInfo trunkInfo;
    SIPTransport::Statistics trunkStats;
    calea->GetTrunk()->GetTransportManager()->GetTransportListenerInfo( SIPTransport::UDP, trunkInfo );
    calea->GetTrunk()->GetTransportManager()->GetTransportStatistics( SIPTransport::UDP, trunkStats );

    for( i = 0; i < trunkInfo.m_InterfaceAddress.GetSize(); i++ )
    {
      PString insert = htmlBlock;
      if( i == 0 )
        SpliceMacro(insert, "User Agent Name", "CALEA Trunk" );

      SpliceMacro(insert, "Listener Address", trunkInfo.m_InterfaceAddress[i]  );

      if( i == 0 )
      {
        SpliceMacro(insert, "Packets Read", trunkStats.m_PacketsRead  );
        SpliceMacro(insert, "Packets Sent", trunkStats.m_PacketsSent  );
        SpliceMacro(insert, "Write Thread", trunkStats.m_WriteThreadRunning ? "Yes" : "No"  );
        SpliceMacro(insert, "Read Thread", trunkStats.m_ReadThreadRunning ? "Yes" : "No"  );
        SpliceMacro(insert, "Transport Error", PString( trunkStats.m_LastSocketError ) + " " + PString( trunkStats.m_LastSocketErrorText )  );
      }

      substitution+=(const char *)insert;
    }

    for( i = 0; i < trunkInfo.m_FailedInterfaceAddress.GetSize(); i++ )
    {
      PString insert = htmlBlock;
      PStringStream strm;
      strm << trunkInfo.m_FailedInterfaceAddress[i] << " *** FAILED ***";
      SpliceMacro(insert, "Listener Address", strm  );
      substitution+=(const char *)insert;
    }
  }

  SBCTrunkProcess * sipTrunk = m_TrunkManager->GetTrunkProcess( "SIP" );
  if( sipTrunk != NULL )
  {
    SIPTransport::ListenerInfo trunkInfo;
    SIPTransport::Statistics trunkStats;
    sipTrunk->GetTrunk()->GetTransportManager()->GetTransportListenerInfo( SIPTransport::UDP, trunkInfo );
    sipTrunk->GetTrunk()->GetTransportManager()->GetTransportStatistics( SIPTransport::UDP, trunkStats );

    for( i = 0; i < trunkInfo.m_InterfaceAddress.GetSize(); i++ )
    {
      PString insert = htmlBlock;
      if( i == 0 )
        SpliceMacro(insert, "User Agent Name", "SIP Trunk" );

      SpliceMacro(insert, "Listener Address", trunkInfo.m_InterfaceAddress[i]  );

      if( i == 0 )
      {
        SpliceMacro(insert, "Packets Read", trunkStats.m_PacketsRead  );
        SpliceMacro(insert, "Packets Sent", trunkStats.m_PacketsSent  );
        SpliceMacro(insert, "Write Thread", trunkStats.m_WriteThreadRunning ? "Yes" : "No"  );
        SpliceMacro(insert, "Read Thread", trunkStats.m_ReadThreadRunning ? "Yes" : "No"  );
        SpliceMacro(insert, "Transport Error", PString( trunkStats.m_LastSocketError ) + " " + PString( trunkStats.m_LastSocketErrorText )  );
      }

      substitution+=(const char *)insert;
    }

    for( i = 0; i < trunkInfo.m_FailedInterfaceAddress.GetSize(); i++ )
    {
      PString insert = htmlBlock;
      PStringStream strm;
      strm << trunkInfo.m_FailedInterfaceAddress[i] << " *** FAILED ***";
      SpliceMacro(insert, "Listener Address", strm  );
      substitution+=(const char *)insert;
    }
  }

  if( m_MediaServer != NULL )
  {
    SIPTransport::ListenerInfo trunkInfo;
    SIPTransport::Statistics trunkStats;
    m_MediaServer->GetSIPEndPoint()->GetTransportManager().GetTransportListenerInfo( SIPTransport::UDP, trunkInfo );
    m_MediaServer->GetSIPEndPoint()->GetTransportManager().GetTransportStatistics( SIPTransport::UDP, trunkStats );

    for( i = 0; i < trunkInfo.m_InterfaceAddress.GetSize(); i++ )
    {
      PString insert = htmlBlock;
      if( i == 0 )
        SpliceMacro(insert, "User Agent Name", "Media Server Trunk" );

      SpliceMacro(insert, "Listener Address", trunkInfo.m_InterfaceAddress[i]  );

      if( i == 0 )
      {
        SpliceMacro(insert, "Packets Read", trunkStats.m_PacketsRead  );
        SpliceMacro(insert, "Packets Sent", trunkStats.m_PacketsSent  );
        SpliceMacro(insert, "Write Thread", trunkStats.m_WriteThreadRunning ? "Yes" : "No"  );
        SpliceMacro(insert, "Read Thread", trunkStats.m_ReadThreadRunning ? "Yes" : "No"  );
        SpliceMacro(insert, "Transport Error", PString( trunkStats.m_LastSocketError ) + " " + PString( trunkStats.m_LastSocketErrorText )  );
      }

      substitution+=(const char *)insert;
    }

    for( i = 0; i < trunkInfo.m_FailedInterfaceAddress.GetSize(); i++ )
    {
      PString insert = htmlBlock;
      PStringStream strm;
      strm << trunkInfo.m_FailedInterfaceAddress[i] << " *** FAILED ***";
      SpliceMacro(insert, "Listener Address", strm  );
      substitution+=(const char *)insert;
    }
  }

  

  return substitution;
}

void OpenSBCDaemon::GetHTMLFormHeader( PHTML & html, const char * title )
{
  html  << PHTML::Title(title)
        //<< "<meta http-equiv=\"Refresh\" content=\"5\">\n"
        << PHTML::Body()
        << GetPageGraphic()

        << PHTML::Paragraph()
        << PHTML::HotLink(title) << "Reload page" << PHTML::HotLink()
        << "&nbsp;&nbsp;&nbsp;&nbsp;"
        << PHTML::HotLink("/") << "Home page" << PHTML::HotLink()

        << PHTML::Paragraph() /*<< "<center>"*/
        << PHTML::Form("POST");
}

void OpenSBCDaemon::GetHTMLFormFooter( PHTML & html )
{
  html  << PHTML::Form()
        << PHTML::HRule()
        << GetCopyrightText()
        << PHTML::Body();
}


PString OpenSBCDaemon::GetPageGraphic()
{
  PFile header;
  if (header.Open("header.html", PFile::ReadOnly))
    return header.ReadString(header.GetLength());

  PHTML html(PHTML::InBody);
  html << PHTML::TableStart()
       << PHTML::TableRow()
       << PHTML::TableData();

  if (gifHTML.IsEmpty())
    html << PHTML::Heading(1) << productNameHTML << "&nbsp;" << PHTML::Heading(1);
  else
    html << gifHTML;

  html << PHTML::TableData()
       << PHTML::Bold() << GetName() << PHTML::Bold() << PHTML::BreakLine()
       << GetOSClass() << ' ' << GetOSName()
       << " Version " << GetVersion(TRUE) << PHTML::BreakLine()
       << ' ' << "Compile Date: " << GetCompilationDate().AsString("d MMMM yyyy") << PHTML::BreakLine()
       << ' ' << "Up Since: " << m_ApplicationUpTime << PHTML::BreakLine()
       << ' ' << "Directory: " << OSSApplication::GetApplicationDirectory() << PHTML::BreakLine()
       << "By "
       << PHTML::HotLink(manufacturersHomePage) << GetManufacturer() << PHTML::HotLink()
       << ", "
       << PHTML::HotLink("mailto:" + manufacturersEmail) << manufacturersEmail << PHTML::HotLink()
       << PHTML::TableEnd()
       << PHTML::HRule();

  return html;
}



