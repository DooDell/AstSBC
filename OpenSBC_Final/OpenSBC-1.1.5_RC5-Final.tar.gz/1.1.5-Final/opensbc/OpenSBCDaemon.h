#ifndef OPENSBCDAEMON_H
#define OPENSBCDAEMON_H

#include <ptlib.h>

#ifndef WIN32
#include <sbcbuildopts.h>
#else
#include <sbcbuildopts-win32.h>
#endif
#include "OSSApplication.h"
#include "B2BUA.h"
#include "SBCB2BUAEndPoint.h"
#include "MediaServer.h"
#include "SBCPHPSapi.h"
#include "Solegy.h"
#include "HTTPSessionManager.h"

class OpenSBCDaemon : public OSSApplication
{
  PCLASSINFO( OpenSBCDaemon, OSSApplication );
public:

  OpenSBCDaemon();

  ~OpenSBCDaemon();

  
  // pure virtual from OSSApplication
  virtual void OnStart( 
    OSSAppConfig & config 
  );

  virtual void OnStop();

  virtual void OnConfigChanged( 
    OSSAppConfig & config,
    const char * section = NULL
  );

  #if CONSOLE_SVCPROC
  void Main();
  #endif

  virtual void OnSIGUSR1();

  virtual void OnSIGUSR2();

  virtual PHTTPServer * OnCreateHTTPServer(
    const PHTTPSpace & urlSpace
  );

  PDECLARE_NOTIFIER( PThread, OpenSBCDaemon, OnConfigChanged );

  virtual void OnHandleCommandArgs(
      PINDEX i,
      const PString & arg
  );

  virtual OSSAppConfig * OnCreateAppConfig();

  virtual void OnAdditionalHTTPResource( 
    PHTTPSimpleAuth & authority
  );

  virtual void OnAdditionalHTTPLinks( 
    PHTML & html 
  );

  virtual void GetHTMLFormHeader( PHTML & html, const char * title );

  virtual void GetHTMLFormFooter( PHTML & html );

  PString OnLoadRegistrationStatus( 
    const PString & htmlBlock 
  );

  PString OnLoadTrunkRegistrationStatus( 
    const PString & htmlBlock 
  );
  
  PString OnLoadResourceCounters( 
    const PString & htmlBlock 
  );

  PString OnLoadListenerList( 
    const PString & htmlBlock 
  );

  BOOL OnPostControl(
    const PStringToString & data, 
    PHTML & msg
  );

  virtual void OnAdditionalXMLRPCMethods(
    PStringArray & moreMethods
  );

  virtual void OnCustomXMLRPCRequest(
    const PString & method,
    PArray<PStringToString> & request,
    PArray<PStringToString> & response
  );

  virtual const PString& GetName() const;

  virtual PString GetPageGraphic();

  bool PHP_evaluate(
    const std::string & funcName,
    PHPVariantMap & in,
    PHPVariantMap & out 
  );

  void OnCreateTrunks( OSSAppConfig & config );
  SBCTrunk * OnCreateTrunk( SBCTrunkProcess * trunkProcess );

  void SetPTraceLevel( unsigned level );

  virtual PString GetReleaseDate();

  BOOL OnGetTailFile( PFilePath & tailFile );

  PINLINE OpenSBC * GetSBC(){ return m_SBC; };
  PINLINE const PString & GetInstanceId()const{ return m_InstanceId; };
  PINLINE const SIPURI & GetExtendedArgs()const{ return m_ExtendedArgs; };
  PINLINE BOOL HasExtendedArgs()const{ return m_HasExtendedArgs; };
  PINLINE SBCTrunkManager * GetTrunkManager()const{ return m_TrunkManager; };
  PINLINE void SetDefaultLogger( LoggingIncrementingFileStream * logger ){ m_DefaultLogger = logger; };
#if PMEMORY_CHECK 
  PINLINE DWORD GetHeapAllocationNumber()const{ return m_HeapAllocationNumber; };
  DWORD m_HeapAllocationNumber;
#endif
protected:
  LoggingIncrementingFileStream * m_DefaultLogger;
  OpenSBC * m_SBC;
  SBCB2BUAEndPoint * m_EndPoint;
  B2BUserAgent::Registrar * m_Registrar;
  B2BUserAgent::Proxy * m_Proxy;
  MS::MediaServer * m_MediaServer;
  PString m_InstanceId;
  SIPURI m_ExtendedArgs;
  BOOL m_HasExtendedArgs;
  BOOL m_IsInitialized;
  SBCTrunkManager * m_TrunkManager;
  OString m_LogFilePrefix;
  PTime m_ApplicationUpTime;
};

class SBCRegistrationStatusPage : public PServiceHTTPString
{
  PCLASSINFO( SBCRegistrationStatusPage, PServiceHTTPString );

  public:
    SBCRegistrationStatusPage(
      OpenSBCDaemon & app, PHTTPAuthority & auth);
    
    virtual BOOL Post(
      PHTTPRequest & request,
      const PStringToString &,
      PHTML & msg
    );
  
  private:
    OpenSBCDaemon & app;
};

class SBCTrunkRegistrationStatusPage : public PServiceHTTPString
{
  PCLASSINFO( SBCRegistrationStatusPage, PServiceHTTPString );

  public:
    SBCTrunkRegistrationStatusPage(
      OpenSBCDaemon & app, PHTTPAuthority & auth);
    
    virtual BOOL Post(
      PHTTPRequest & request,
      const PStringToString &,
      PHTML & msg
    );
  
  private:
    OpenSBCDaemon & app;
};


class SBCResourceCounterPage : public PServiceHTTPString
{
  PCLASSINFO( SBCResourceCounterPage, PServiceHTTPString );

  public:
    SBCResourceCounterPage(
      OpenSBCDaemon & app, PHTTPAuthority & auth
    );
      
  private:
    OpenSBCDaemon & app;
};

class SBCListenerListPage : public PServiceHTTPString
{
  PCLASSINFO( SBCListenerListPage, PServiceHTTPString );

  public:
    SBCListenerListPage(
      OpenSBCDaemon & app, PHTTPAuthority & auth
    );
      
  private:
    OpenSBCDaemon & app;
};

#endif



