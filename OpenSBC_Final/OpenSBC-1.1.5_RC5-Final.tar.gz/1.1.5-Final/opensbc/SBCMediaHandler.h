/*
 *
 * B2BMediaInterface.h
 * 
 * Open SIP Stack ( OSS )
 *
 * Copyright (C) 2006 Joegen E. Baclor. All Rights Reserved.
 *
 * Version: MPL 1.1/GPL 2.0/LGPL 2.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is OpenSIPStack Library.
 *
 * The Initial Developer of the Original Code is Joegen E. Baclor.
 *
 * Contributor(s):
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * $Log: SBCMediaHandler.h,v $
 * Revision 1.3  2009/06/22 08:59:34  joegenbaclor
 * modified setting of RTP port range to not use opal manager
 *
 * Revision 1.2  2009/05/27 12:40:34  joegenbaclor
 * Initial upload of switch related classes
 *
 * Revision 1.1  2009/03/26 06:18:14  joegenbaclor
 * Moved RTP/SDP media handler to the application layer
 *
 *
 */

#ifndef SBCMEDIAHANDLER_H
#define SBCMEDIAHANDLER_H

#include "B2BMediaInterface.h"


using namespace B2BUA;

class SBCMediaHandler : public B2BMediaInterface
{
  PCLASSINFO( SBCMediaHandler, B2BMediaInterface );
public:
  SBCMediaHandler(  
    B2BUserAgent & b2bua 
  );

  virtual ~SBCMediaHandler();

  virtual BOOL OnIncomingSDPOffer(
    B2BUAConnection & connection,
    B2BUACall & call,
    const SIPMessage & sdp
  );

  virtual BOOL OnIncomingSDPAnswer(
    B2BUAConnection & connection,
    B2BUACall & call,
    const SIPMessage & sdp
  );

  virtual BOOL OnRequireSDPOffer(
    B2BUAConnection & connection,
    B2BUACall & call,
    SIPMessage & offer
  );

  virtual BOOL OnRequireSDPAnswer(
    B2BUAConnection & connection,
    B2BUACall & call,
    const SIPMessage & offer,
    SIPMessage & answer
  );

  BOOL CreateRTPSession(
    B2BUAConnection & connection,
    B2BUACall & call,
    const SIPMessage & sdp,
    BOOL createOnlyIfPrivate = TRUE
  );

  BOOL CreateRTPSession(
    const OString & callId,
    unsigned sessionId,
    const PIPSocket::Address & localAddress,
    const PIPSocket::Address & targetAddress,
    const PIPSocket::Address & receivedAddress,
    WORD targetPort,
    RTP_SessionManager & manager,
    BOOL isEncrypted = FALSE
  );

  BOOL TranslateSDPOffer(
    B2BUAConnection & connection,
    B2BUACall & call,
    SIPMessage & offer
  );

  BOOL TranslateSDPAnswer(
    B2BUAConnection & connection,
    B2BUACall & call,
    const SIPMessage & offer,
    SIPMessage & answer
  );

  BOOL OnOpenMediaStreams(
    B2BUAConnection & connection
  );

public:



  PINLINE BOOL GetProxyPrivateContact()const{ return m_ProxyPrivateContact; };
  PINLINE BOOL GetProxyViaReceived()const{ return m_ProxyViaReceived; };
  PINLINE BOOL GetProxyViaSendAddress()const{ return m_ProxyViaSendAddress; };
  PINLINE BOOL GetProxyViaRPort()const{ return m_ProxyViaRPort; };
  PINLINE BOOL GetProxyAllMedia()const{ return m_ProxyAllMedia; };

  PINLINE void SetProxyPrivateContact( BOOL enable ){ m_ProxyPrivateContact = enable; };
  PINLINE void SetProxyViaReceived( BOOL enable ){ m_ProxyViaReceived = enable; };
  PINLINE void SetProxyViaSendAddress( BOOL enable ){ m_ProxyViaSendAddress = enable; };
  PINLINE void SetProxyViaRPort( BOOL enable ){ m_ProxyViaRPort = enable; };
  PINLINE void SetProxyAllMedia( BOOL enable ){ m_ProxyAllMedia = enable; };

private:
  PMutex m_MediaStreamsMutex;

  PDICTIONARY( RTPSocketList, POrdinalKey, PUDPSocket );
  PLIST( RTPSelectList, PUDPSocket );
  PMutex m_RTPSocketListMutex;
  RTPSocketList m_RTPSocketList;
  RTPSelectList m_RTPSelectList;

  BOOL m_ProxyPrivateContact;
  BOOL m_ProxyViaReceived;
  BOOL m_ProxyViaSendAddress;
  BOOL m_ProxyViaRPort;
  BOOL m_ProxyAllMedia;
  

};


#endif



