/*
 *
 * SBCSIPTrunkReg.h
 *
 * Open SIP Stack ( OSS )
 *
 * Copyright (c) opensipstack.org.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either expressed or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is OpenSIPStack.
 *
 * The Initial Developer of the Original Code is opensipstack.org.
 *
 * The author of this code is Joegen E. Baclor
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * The OpenSIPStack Library includes some GPL/LGPL code libraries that MAY be 
 * enabled at compile time using the --enable-gpllibs configure switch.  If
 * enabled, the content of this file is published under the terms of GNU 
 * General Public License Version 2.  For a detailed list of the available
 * GPL code, see $(opensipstack)/gnu/README file.
 *
 * $Log: SBCSIPTrunkReg.h,v $
 * Revision 1.7  2009/06/01 03:16:55  joegenbaclor
 * Added outbound call class for sip trunks
 *
 * Revision 1.6  2008/11/25 01:45:24  joegenbaclor
 * Added send-reg attribute to disable sending registration to trunk provider which does
 *  not require it
 *
 * Revision 1.5  2007/10/02 16:42:56  joegenbaclor
 * Marking initial release of SIP Trunking
 *
 * Revision 1.4  2007/09/11 14:29:05  joegenbaclor
 * More trunking work
 *
 * Revision 1.3  2007/09/11 02:31:53  joegenbaclor
 * More work on trunks
 *
 * Revision 1.2  2007/09/04 21:58:13  joegenbaclor
 * More work on SIP Trunks.
 *
 * Revision 1.1  2007/08/30 03:21:45  joegenbaclor
 * Added SIP Trunk Classes
 *
 *
 */

#ifndef SBCSIPTRUNKREG_H
#define SBCSIPTRUNKREG_H

#include "RegisterSessionManager.h"
#include "SIPUserAgent.h"
#include "OString.h"
#include "SBCSIPTrunkConfig.h"

using namespace UACORE;
using namespace SIP;
using namespace Tools;

class SBCSIPTrunkAccount : public PObject
{
  PCLASSINFO( SBCSIPTrunkAccount, PObject );
public:

  PINLINE SBCSIPTrunkAccount()
  {
    m_Expires = 0;
    m_SendReg = TRUE;
  }

  PINLINE SBCSIPTrunkAccount(
    const char * userName,
    const char * authUser,
    const char * password,
    const char * inboundRoute,
    long expires,
    BOOL sendReg = TRUE
  )
  {
    m_UserName = userName;
    m_Password = password;
    m_InboundRoute = inboundRoute;
    m_AuthUser = authUser;
    m_Expires = expires;
    m_SendReg = sendReg;
  }

  PINLINE SBCSIPTrunkAccount(
    const SBCSIPTrunkAccountConfig & config 
  )
  {
    operator=( config );
  }

  PINLINE SBCSIPTrunkAccount( const SBCSIPTrunkAccount & account )
  {
    operator=( account );
  }

  PINLINE SBCSIPTrunkAccount & operator=( const SBCSIPTrunkAccount & account )
  {
    m_UserName = account.m_UserName;
    m_AuthUser = account.m_AuthUser;
    m_Password = account.m_Password;
    m_InboundRoute = account.m_InboundRoute;
    m_Expires = account.m_Expires;
    m_SendReg = account.m_SendReg;
    return *this;
  }

  PINLINE SBCSIPTrunkAccount & operator=( const SBCSIPTrunkAccountConfig & account )
  {
    m_UserName = account.GetUser();
    m_AuthUser = account.GetAuthUser();
    m_Password = account.GetPassword();
    m_InboundRoute = account.GetInboundRoute();
    m_Expires = account.GetExpires();
    m_SendReg = account.WillSendReg();
    return *this;
  }


  PINLINE void SetUserName( const char * user ){ m_UserName = user; };
  PINLINE const OString & GetUserName()const{ return m_UserName; };
  PINLINE void SetPassword( const char * pwd ){ m_Password = pwd; };
  PINLINE const OString & GetPassword()const{ return m_Password; };
  PINLINE void SetInboundRoute( const char * inboundRoute ){ m_InboundRoute = inboundRoute; };
  PINLINE const OString & GetInboundRoute()const{ return m_InboundRoute; };
  PINLINE void SetExpires( long expires ){ m_Expires = expires; };
  PINLINE long GetExpires()const{ return m_Expires; };
  PINLINE void SetAuthUser( const char * user ){ m_AuthUser = user; };
  PINLINE const OString & GetAuthUser()const{ return m_AuthUser; };
  PINLINE void SetSendReg( BOOL send ){ m_SendReg = send; };
  PINLINE BOOL WillSendReg()const{ return m_SendReg; };
  PDICTIONARY( Collection, PCaselessString, SBCSIPTrunkAccount );
protected:
  OString m_UserName;
  OString m_AuthUser;
  OString m_Password;
  OString m_InboundRoute;
  long m_Expires;
  BOOL m_SendReg;
};


class SBCSIPTrunkReg : public RegisterSessionManager
{
  PCLASSINFO( SBCSIPTrunkReg, RegisterSessionManager );
public:

  SBCSIPTrunkReg(
    SBCSIPTrunkConfig * config,
    SIPUserAgent & trunk,
    PINDEX sessionThreadCount = 1,
    PINDEX stackSize = 1024 * 2
  );

  virtual ~SBCSIPTrunkReg();

  virtual BOOL OnRequestA1Hash(
      const SIPURI & userURL,
      OString & a1,
      RegisterSession & session
  );

  void OnConfigChanged(
    SBCSIPTrunkConfig * config
  );

  /// returns a new Client RegisterSession.  Users may override this function
  /// to return their own implementation of the RegisterSession object
  virtual SIPSession * OnCreateClientSession(
    const ProfileUA & profile,
    const OString & sessionId
  );

  virtual void OnAddTrunkAccount(
    const SBCSIPTrunkAccount & account
  );

  virtual void OnRemoveTrunkAccount(
    const SBCSIPTrunkAccount & account
  );

  BOOL FindTrunkAccount(
    SBCSIPTrunkAccount & account
  )const;

  BOOL HasTrunkAccount( const char * user )const;

  BOOL GetEgressAuthInfo(
    const SIPMessage & msg,
    OString & userName,
    OString & authUser,
    OString & password
  );

  BOOL GetIngressRoute(
    const SIPMessage & msg,
    SIPURI & inboundRoute
  );

  PINLINE const OString & GetTrunkName()const{ return m_TrunkName; };
  PINLINE const OStringArray & GetTrunkRouteSet()const{ return m_TrunkRouteSet; };
  PINLINE const OString & GetTrunkDomain()const{ return m_TrunkDomain; };
  PINLINE const OString & GetTrunkType()const{ return m_TrunkType; };
  PINLINE const OString & GetTrunkDescription()const{ return m_TrunkDescription; };
  PINLINE long GetTrunkExpires()const{ return m_TrunkExpires; };

  PDICTIONARY( Collection, PCaselessString, SBCSIPTrunkReg );
protected:
  BOOL AddTrunkAccount(
    const SBCSIPTrunkAccount & account
  );

  BOOL RemoveTrunkAccount(
    const char * userName
  );

  PMutex m_TrunkAccountsMutex;
  SBCSIPTrunkAccount::Collection m_TrunkAccounts;
  PMutex m_ConfigMutex;
  SBCSIPTrunkConfig * m_Config;

  OString m_TrunkName;
  OStringArray m_TrunkRouteSet;
  OString m_TrunkDomain;
  OString m_TrunkType;
  OString m_TrunkDescription;
  long m_TrunkExpires;
};




#endif


