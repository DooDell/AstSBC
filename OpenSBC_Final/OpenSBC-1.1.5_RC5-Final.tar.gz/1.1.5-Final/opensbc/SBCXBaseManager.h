#ifndef SBCXBASEMANAGER_H
#define SBCXBASEMANAGER_H

#include "XBase.h"

#ifdef HAS_XBASE
#include "SBCConnection.h"
class SBCXBaseManager;

class LATATable : public XBaseSchema
{
  PCLASSINFO( LATATable, XBaseSchema );
public:
  LATATable( SBCXBaseManager * manager );
  BOOL Initialize();

  PMutex m_TableMutex;
  SBCXBaseManager * m_Manager;
  int m_LATA;//AddField( "LATA", XBaseSchema::FLD_CHAR,     3    );
  int m_C_CODE;//AddField( "C_CODE",  XBaseSchema::FLD_CHAR,  3    );
  int m_NPA;//AddField( "NPA",  XBaseSchema::FLD_CHAR,     3    );
  int m_NXX;//AddField( "NXX",  XBaseSchema::FLD_CHAR,     3    );
  int m_DESC;//AddField( "DESC", XBaseSchema::FLD_CHAR,     100    );
};

class LATACarrierTable : public XBaseSchema
{
  PCLASSINFO( LATACarrierTable, XBaseSchema );
public:
  LATACarrierTable( SBCXBaseManager * manager );
  BOOL Initialize();

  PMutex m_TableMutex;
  SBCXBaseManager * m_Manager;
  int m_LATA;//AddField( "LATA", XBaseSchema::FLD_CHAR,     3    );
  int m_ROUTE_1;//AddField( "ROUTE_1",  XBaseSchema::FLD_CHAR,  30    );
  int m_ROUTE_2;//AddField( "ROUTE_2",  XBaseSchema::FLD_CHAR,  30    );
  int m_ROUTE_3;//AddField( "ROUTE_3",  XBaseSchema::FLD_CHAR,  30    );
  int m_ROUTE_4;//AddField( "ROUTE_4",  XBaseSchema::FLD_CHAR,  30    );
  int m_ROUTE_5;//AddField( "ROUTE_5",  XBaseSchema::FLD_CHAR,  30    );
  int m_DESC;//AddField( "DESC", XBaseSchema::FLD_CHAR,     100    );
};

class NpaNxxTable : public XBaseSchema
{
  PCLASSINFO( NpaNxxTable, XBaseSchema );
public:
  NpaNxxTable( SBCXBaseManager * manager );
  BOOL Initialize();

  PMutex m_TableMutex;
  int m_C_CODE;//AddField( "C_CODE",  XBaseSchema::FLD_CHAR,  3    );
  int m_NPA;//AddField( "NPA",  XBaseSchema::FLD_CHAR,     3    );
  int m_NXX;//AddField( "NXX",  XBaseSchema::FLD_CHAR,     3    );
  int m_DESC;//AddField( "DESC", XBaseSchema::FLD_CHAR,     100    );
  int m_ROUTE_1;//AddField( "ROUTE_1",  XBaseSchema::FLD_CHAR,  30    );
  int m_ROUTE_2;//AddField( "ROUTE_2",  XBaseSchema::FLD_CHAR,  30    );
  int m_ROUTE_3;//AddField( "ROUTE_3",  XBaseSchema::FLD_CHAR,  30    );
  int m_ROUTE_4;//AddField( "ROUTE_4",  XBaseSchema::FLD_CHAR,  30    );
  int m_ROUTE_5;//AddField( "ROUTE_5",  XBaseSchema::FLD_CHAR,  30    );
  SBCXBaseManager * m_Manager;
};

class CDRTable : public XBaseSchema
{
  PCLASSINFO( NpaNxxTable, XBaseSchema );
public:
  CDRTable( SBCXBaseManager * manager );
  BOOL Initialize();
  PMutex m_TableMutex;
  SBCXBaseManager * m_Manager;
};

class SBCXBaseManager : public PObject
{
  PCLASSINFO( SBCXBaseManager, PObject );
public:
  SBCXBaseManager();
  ~SBCXBaseManager();
  BOOL CreateTables();
  const PFilePath & GetDBDirectory()const{ return m_DBDirectory; };

  BOOL FindLATACarrier(
    const OString & dialString,
    OStringArray & routes
  );

  BOOL FindNPANXX(
    const OString & dialString,
    OStringArray & routes
  );
protected:
  PFilePath m_DBDirectory;
  LATATable * m_LATATable;
  LATACarrierTable * m_LATACarrierTable;
  NpaNxxTable * m_NpaNxxTable;
};

#endif //HAS_XBASE
#endif //SBCXBASEMANAGER_H


