/*
 *
 * SBCSIPTrunkConfig.cxx
 *
 * Open SIP Stack ( OSS )
 *
 * Copyright (c) opensipstack.org.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either expressed or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is OpenSIPStack.
 *
 * The Initial Developer of the Original Code is opensipstack.org.
 *
 * The author of this code is Joegen E. Baclor
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * The OpenSIPStack Library includes some GPL/LGPL code libraries that MAY be 
 * enabled at compile time using the --enable-gpllibs configure switch.  If
 * enabled, the content of this file is published under the terms of GNU 
 * General Public License Version 2.  For a detailed list of the available
 * GPL code, see $(opensipstack)/gnu/README file.
 *
 * $Log: SBCSIPTrunkConfig.cxx,v $
 * Revision 1.5  2008/12/02 02:57:18  joegenbaclor
 * setting send-reg default to yes
 *
 * Revision 1.4  2008/11/25 01:45:24  joegenbaclor
 * Added send-reg attribute to disable sending registration to trunk provider which does
 *  not require it
 *
 * Revision 1.3  2007/10/17 03:17:39  joegenbaclor
 * More work on sip trunks
 *
 * Revision 1.2  2007/09/11 14:29:05  joegenbaclor
 * More trunking work
 *
 * Revision 1.1  2007/09/04 21:58:13  joegenbaclor
 * More work on SIP Trunks.
 *
 *
 */

#include "SBCSIPTrunkConfig.h"

SBCSIPTrunkAccountConfig::SBCSIPTrunkAccountConfig(
  PXMLElement * config
)
{
  m_Config = config;
}

OString SBCSIPTrunkAccountConfig::GetUser()const
{
  return static_cast<const char *>(m_Config->GetAttribute( "user-name" ));
}

OString SBCSIPTrunkAccountConfig::GetAuthUser()const
{
  return static_cast<const char *>(m_Config->GetAttribute( "auth-user-name" ));
}

OString SBCSIPTrunkAccountConfig::GetPassword()const
{
  return static_cast<const char *>(m_Config->GetAttribute( "auth-password" ));
}

long SBCSIPTrunkAccountConfig::GetExpires()const
{
  OString exp = static_cast<const char *>(m_Config->GetAttribute( "expires" ));
  if( exp.IsEmpty() )
    return 0;

  return exp.AsInteger();
}

OString SBCSIPTrunkAccountConfig::GetInboundRoute()const
{
  return static_cast<const char *>(m_Config->GetAttribute( "inbound-route" ));
}

BOOL SBCSIPTrunkAccountConfig::IsEnabled()const
{
  return (m_Config->GetAttribute( "enabled" ) *= "true");
}

BOOL SBCSIPTrunkAccountConfig::WillSendReg()const
{
  return !(m_Config->GetAttribute( "send-reg" ) *= "no");
}




//////////////////////////////////////////////////////////////////////////


SBCSIPTrunkConfig::SBCSIPTrunkConfig( 
  PXMLElement * config
)
{
  m_TransientAccountIndex = 0;
  m_Config = config;
  PXMLElement * accounts = m_Config->GetElement( "trunk-accounts" );
  if( accounts != NULL )
  {
    for(PINDEX i = 0; ;i++)
    {
      PXMLElement * acct = accounts->GetElement( "account", i );
      if( acct == NULL )
        break;
      
      SBCSIPTrunkAccountConfig * acctConfig = new SBCSIPTrunkAccountConfig( acct );
      OString user = acctConfig->GetUser();
      if( !user.IsEmpty() )
        m_Accounts.SetAt( user.c_str(), acctConfig );
      else
        delete acctConfig;
    }
  }

  accounts = m_Config->GetElement( "transient-accounts" );
  if( accounts != NULL )
  {
    for(PINDEX i = 0; ;i++)
    {
      PXMLElement * acct = accounts->GetElement( "account", i );
      if( acct == NULL )
        break;
      
      SBCSIPTrunkAccountConfig * acctConfig = new SBCSIPTrunkAccountConfig( acct );
      OString user = acctConfig->GetUser();
      if( !user.IsEmpty() )
        m_TransientAccounts.SetAt( user.c_str(), acctConfig );
      else
        delete acctConfig;
    }
  }
}

const SBCSIPTrunkAccountConfig * SBCSIPTrunkConfig::GetActiveTransientAccount()
{
  PWaitAndSignal lock( m_AccountsMutex );
  if( m_TransientAccounts.GetSize() == 0 )
    return NULL;

  if( m_TransientAccountIndex >= m_TransientAccounts.GetSize() )
    m_TransientAccountIndex = 0;

  SBCSIPTrunkAccountConfig & account = m_TransientAccounts.GetDataAt( m_TransientAccountIndex );

  ++m_TransientAccountIndex;

  return &account;
}

OString SBCSIPTrunkConfig::GetTrunkName()const
{
  return static_cast<const char *>(m_Config->GetAttribute( "trunk-name" ));
}
  
OString SBCSIPTrunkConfig::GetRouteSet()const
{
  return static_cast<const char *>(m_Config->GetAttribute( "route-set" ));
}
  
OString SBCSIPTrunkConfig::GetDomain()const
{
  return static_cast<const char *>(m_Config->GetAttribute( "sip-domain" ));
}
  
OString SBCSIPTrunkConfig::GetTrunkType()const
{
  return static_cast<const char *>(m_Config->GetAttribute( "trunk-type" ));
} 
  
OString SBCSIPTrunkConfig::GetTrunkDescription()const
{
  PXMLElement * desc = m_Config->GetElement( "description" );
  if( desc == NULL )
    return OString::Empty();

  return static_cast<const char *>(desc->GetData());
}
  
BOOL SBCSIPTrunkConfig::IsTrunkEnabled()const
{
  return (m_Config->GetAttribute( "enabled" ) *= "true");
}

long SBCSIPTrunkConfig::GetExpires()const
{
  OString exp = static_cast<const char *>(m_Config->GetAttribute( "expires" ));
  if( exp.IsEmpty() )
    return 3600;

  return exp.AsInteger();
}

SBCSIPTrunkAccountConfig & SBCSIPTrunkConfig::operator[]( PINDEX i )
{
  PWaitAndSignal lock( m_AccountsMutex );

  if( i >= m_Accounts.GetSize() )
    PAssertAlways( PLogicError );

  return m_Accounts.GetDataAt( i );
}

const SBCSIPTrunkAccountConfig * SBCSIPTrunkConfig::operator[]( const char * name )
{
  PWaitAndSignal lock( m_AccountsMutex );
  return m_Accounts.GetAt( name );
}

