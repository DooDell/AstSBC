#if ENABLE_CSCRIPT

#ifndef SBCCONNECTIONSCRIPT_H
#define SBCCONNECTIONSCRIPT_H

#include "SBCConnection.h" 

namespace B2BUA
{
  class SBCConnectionScript
  {
  public:
    static void RegisterModuleFuncs();
    
    static BOOL LoadScriptModule(
      const PFilePath & module,
      BOOL autoReload
    );
    
    static BOOL Enter( 
      const char * eventData,
      SBCConnection * conn,
      SIPMessage * msg 
    );

    static SBCConnection * m_SBCConnection;
  };
}

#endif

#endif //#if ENABLE_CSCRIPT


