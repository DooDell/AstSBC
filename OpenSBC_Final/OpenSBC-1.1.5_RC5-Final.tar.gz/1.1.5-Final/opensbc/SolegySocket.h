/*
 *
 * SolegySocket.h
 *
 * Open SIP Stack ( OSS )
 *
 * Copyright (c) opensipstack.org.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either expressed or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is OpenSIPStack.
 *
 * The Initial Developer of the Original Code is opensipstack.org.
 *
 * The author of this code is Joegen E. Baclor
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * The OpenSIPStack Library includes some GPL/LGPL code libraries that MAY be 
 * enabled at compile time using the --enable-gpllibs configure switch.  If
 * enabled, the content of this file is published under the terms of GNU 
 * General Public License Version 2.  For a detailed list of the available
 * GPL code, see $(opensipstack)/gnu/README file.
 *
 * $Log: SolegySocket.h,v $
 * Revision 1.10  2009/02/06 09:50:38  joegenbaclor
 * Added email alert notification support
 *
 * Revision 1.9  2009/02/03 05:58:06  joegenbaclor
 * Added ability to not send PING for aggregated RTTS sessions
 *
 * Revision 1.8  2009/01/25 04:46:05  joegenbaclor
 * Introduced capability to use only the RTTS server with the lowest load
 *
 * Revision 1.7  2009/01/15 03:16:57  joegenbaclor
 * added close function for solegy sockets to allow other modules to explicitly delete the udp socket when used outside of the manager
 *
 * Revision 1.6  2008/12/31 05:04:50  joegenbaclor
 * Introduced mutex for Solegy socket read-write operations
 *
 * Revision 1.5  2008/10/22 05:06:25  joegenbaclor
 * Added MPL License Header
 *
 *
 */

#ifndef SOLEGYSOCKET_H
#define SOLEGYSOCKET_H

#include <ptlib.h>
#include <ptlib/sockets.h>
#include <ptclib/pstun.h>

#include "OString.h"
using namespace Tools;

namespace SOLEGY
{
  class SolegySessionManager;
  class SolegySocket : public PObject
  {
    PCLASSINFO( SolegySocket, PObject );
  public:
    SolegySocket(
      SolegySessionManager * manager,
      const PIPSocket::Address & serverAddress,
      WORD serverPort = 0,
      const PTimeInterval & expire = 60000,
      BOOL enablePingTimer = TRUE
    );

    BOOL Open(
      const PIPSocket::Address & iface,
      WORD portBase, 
      WORD portMax,
      PSTUNClient * stun = NULL
    );

    BOOL Close( BOOL autoDeleteSocket );

    BOOL Write(
      std::string & str
    );

    BOOL IsReliableTransport()const{ return m_IsReliableTransport; };
    PUDPSocket * GetSocket()const{ return m_Socket; };
    const PIPSocket::Address & GetRTTSSeverAddress()const{ return m_RTTSServerAddress; };
    WORD GetRTTSServerPort()const{ return m_RTTSServerPort; };
    void Enable( BOOL yes = TRUE ){ m_Enabled = yes; };
    void Disable( BOOL yes = FALSE ){ m_Enabled = yes; };
    BOOL IsEnabled()const{ return m_Enabled; };
    void SetPingExpireInterval( int expires ){ m_PingExpireInterval = expires; };
    void OnPINGACK( const char * ack );
    void OnServerSNChanged();
    void OnPingTimeout();
    void ValidateServer();
    PINLINE int GetServerSessionLoad()const{ return m_ServerSessionLoad; };
    PINLINE void SerServerSessionLoad( int load ){ m_ServerSessionLoad = load; };
    PINLINE void SetReliable( BOOL reliable ){ m_IsReliableTransport = reliable; };
    BOOL MarkLastFatalTimeout( const OString & sessionId, const OString & method );
    PINLINE PTimeInterval GetLastFatalTimeout()const{ return m_LastFatalTimeout; };

  protected:
    SolegySessionManager * m_Manager;
    BOOL m_IsReliableTransport;
    PMutex m_PingMutex;
    PTimer m_PingTimer;
    PDECLARE_NOTIFIER( PTimer, SolegySocket, OnPingTimer );
    PTimeInterval m_PingExpireInterval;
    
    int m_PingRetryInterval;
    OString m_ServerSN;
    OString m_ClientSN;
    BOOL m_Pinging;
    OString m_CurrentPingRequest;
    int m_PINGSequence;
    int m_ServerSessionLoad;
    PUDPSocket * m_Socket;
    PIPSocket::Address m_RTTSServerAddress;
    WORD m_RTTSServerPort;
    BOOL m_Enabled;

    PMutex m_TimeoutReportMutex;
    PTimeInterval m_LastFatalTimeout;
    PStringList m_TimeoutReportList;

    public: static PMutex m_ReadWriteMutex;
  };
}

#endif
