<HTML>
<HEAD>
<TITLE>OpenSBC HTTP Admin</TITLE>
</HEAD>
<BODY>
<TABLE>
<TR>
<?PHP oss_evaluate( "func", "val"); ?>
	<TD><img src="/banner.jpg" alt="OpenSBC" width=380 height=101 align=absmiddle>
	<TD><B>OpenSBC</B>
	<BR>Windows XP Version 1.1.5-2
	<BR>Compile Date: 8 March 2008
	<BR>Up Since: Thu, 13 Mar 2008 14:54:22 +0800
	<BR>By <A HREF="http://www.opensipstack.org">opensipstack.org</A>, <A HREF="mailto:info@opensipstack.org">info@opensipstack.org</A>
</TABLE >
</BODY>
</HTML>