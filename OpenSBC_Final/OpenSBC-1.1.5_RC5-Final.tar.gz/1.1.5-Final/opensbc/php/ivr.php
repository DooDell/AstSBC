<?php
	if (!function_exists('getallheaders'))
	{
		function getallheaders()
		{
			foreach ($_SERVER as $name => $value)
			{
				if (substr($name, 0, 5) == 'HTTP_')
				{
					$headers[str_replace(' ', '-', ucwords(strtolower(str_replace('_', ' ', substr($name, 5)))))] = $value;
				}
			}
			return $headers;
		}
	}
	
	function getsipheaders( $http_headers )
	{
		foreach ($http_headers as $name => $value)
		{
			if (substr($name, 0, 9) == 'X-CC-SIP-')
			{
				$headers[substr($name, 9)] = $value;
			}
		}
		return $headers;
	}
	
	function IVRPlayPrompt( $id, $location, $index )
	{
		header( "X-CC-IVR-Play-Prompt_" . $index . ":" . $location . ";id=" . $id );	
	}
	
	function IVRDisconnect( $reason )
	{
		header( "X-CC-IVR-Call-Disconnect: " . $reason );
	}
	
	function IVRSetDTMFGrammar(
		$identifier,
        $maxDigits, /// maximum digit to be collected
        $termChar, /// terminating char to end collection
        $canStopPlayBack = true,
        $collectTimeout = 30000,
        $perDigitTimeout = 10000 )
    {
		header( "X-CC-IVR-Digit-Grammar: " . 
		        $identifier . "," . 
		        $maxDigits . "," . 
		        $termChar . "," . 
		        $canStopPlayBack . "," . 
		        $collectTimeout . "," . 
		        $perDigitTimeout );
    }
    
    function IVRGetInputBuffer( $http_headers )
    {
		return $http_headers["X-CC-IVR-Input-Buffer"];
	}
	
	function IVRSetCookie( $key, $value )
	{
		header( "X-CC-IVR-Cookie-" . $key . ": " . $value );
	}
	
	function IVRGetCookie( $http_headers, $key )
    {
		$id = "X-CC-IVR-Cookie-" . $key;
		return $http_headers[$id];
	}
	
	function IVRTransferCall( $sipURI )
	{
		header( "X-CC-IVR-Transfer: " . $sipURI );
	}
	
	function IVROnOpenChannel( $http_headers )
	{
		IVRPlayPrompt( "greeting", "file:prompts/basic/welcome.wav", 0 );
		IVRPlayPrompt( "enter-pin", "file:prompts/basic/enter_pin.wav", 1 );
		IVRSetDTMFGrammar( "enter-pin", 20, "#", true, 30000, 20000 );
	}
	
	function IVROnEndPlaying( $http_headers )
	{
		if( is_array( $http_headers ) )
		{
			$id = $http_headers["X-CC-IVR-Prompt-ID"];
			if( $id == "greeting" )
			{
				//IVRPlayPrompt( "goodbye", "file:prompts/basic/goodbye.wav", 0 );
			}else if( $id == "goodbye" )
			{
				IVRDisconnect( "Normal Call Clearing" );
			}
		}
	}
	
	function IVROnEndCollection( $http_headers )
	{
		$input = IVRGetInputBuffer( $http_headers );
        
        if( $input == "12345" )
		{
			IVRTransferCall( "sip:18005558355@proxy01.sipphone.com" );
		}else
		{
		    $pinRetry = IVRGetCookie( $http_headers, "Pin-Retry" );
		    if( $pinRetry == null  )
				$pinRetry = 0;
			
			if( $pinRetry < 2 )
			{	
				IVRPlayPrompt( "enter-pin", "file:prompts/basic/invalid_pin.wav", 0 );
				IVRPlayPrompt( "enter-pin", "file:prompts/basic/enter_pin.wav", 1 );
				IVRSetDTMFGrammar( "enter-pin", 20, "#", true, 30000, 20000 );
				$pinRetry++;
				IVRSetCookie( "Pin-Retry", $pinRetry );
			}
			else
			{
				IVRPlayPrompt( "goodbye", "file:prompts/basic/goodbye.wav", 0 );
			}
		}
	}
	
	
	$http_headers = getallheaders();
	$method = $http_headers["X-CC-Method"];
	
	if( $method == "IVROnOpenChannel" )
		IVROnOpenChannel( $http_headers );
	else if( $method == "IVROnEndPlaying" )
		IVROnEndPlaying( $http_headers );
	else if( $method == "IVROnEndCollection" )
		IVROnEndCollection( $http_headers );


?>