<?php
	if (!function_exists('getallheaders'))
	{
		function getallheaders()
		{
			foreach ($_SERVER as $name => $value)
			{
				if (substr($name, 0, 5) == 'HTTP_')
				{
					$headers[str_replace(' ', '-', ucwords(strtolower(str_replace('_', ' ', substr($name, 5)))))] = $value;
				}
			}
			return $headers;
		}
	}
	
	function getsipheaders( $http_headers )
	{
		foreach ($http_headers as $name => $value)
		{
			if (substr($name, 0, 9) == 'X-CC-SIP-')
			{
				$headers[substr($name, 9)] = $value;
			}
		}
		return $headers;
	}
	
	function validate_account( $account )
	{
		/** Initialize the SIP Accounts here.  Each item should contain the action (1)accept (2)deny ()challenge.
		  * If the action is a challenge, this function will generate the a1 hash based on user and password combo.
		  */
	  
	    $SIPACCOUNT["joegen@192.168.0.161"] = array( "challenge", "joegen", "192.168.0.161", "joegen" );
	    
		/** End of SIP Accounts */
	
	    
		$action = $SIPACCOUNT[$account];
		if( is_array( $action ) )
		{
			if( $action[0] == "challenge" )
			{
				$a1 = md5($action[1].":".$action[2].":".$action[3]);
				header( "X-CC-AUTH-Hash: ".$a1 );
			}
			header( "X-CC-AUTH-Status: ".$action[0] );
			
			/** this is where you specify whether OpenSBC should
			  * use Media server or simply b2bua mode to process
			  * the call.  Mores are:
			  *	1.  msdb - enable media server processing 
			  * 2.  wsdb - basic B2BUA auth and routing
			  */
			  
			header( "X-CC-App-Logic: msdb" );
			
			return $action[0];
		}
	}	
	
	function handle_auth( $http_headers )
	{
		$_SIP = getsipheaders( $http_headers );			
		$user = $_SIP["From-User"];
		$host = $_SIP["From-Host"];
		$account = $user."@".$host;
		$action = validate_account( $account );
	}
	
	$http_headers = getallheaders();
	$method = $http_headers["X-CC-Method"];
	
	if( $method == "AUTH" )
		handle_auth( $http_headers );
?>