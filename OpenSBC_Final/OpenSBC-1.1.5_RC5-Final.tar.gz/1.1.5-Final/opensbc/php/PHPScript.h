/*
 *
 * PHPScript.h
 * 
 * Open SIP Stack ( OSS )
 *
 * Copyright (c) opensipstack.org.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either expressed or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is OpenSIPStack.
 *
 * The Initial Developer of the Original Code is opensipstack.org.
 *
 * The author of this code is Joegen E. Baclor
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * The OpenSIPStack Library includes some GPL/LGPL code libraries that MAY be 
 * enabled at compile time using the --enable-gpllibs configure switch.  If
 * enabled, the content of this file is published under the terms of GNU 
 * General Public License Version 2.  For a detailed list of the available
 * GPL code, see $(opensipstack)/gnu/README file.
 *
 * $Log: PHPScript.h,v $
 * Revision 1.5  2008/03/11 02:10:07  joegenbaclor
 * Revised PHP Sapi implementation and removed python from configure script check
 *
 * Revision 1.4  2008/03/09 04:59:19  joegenbaclor
 * Added PHP Queue as a separate class
 *
 * Revision 1.3  2008/03/08 13:25:17  joegenbaclor
 * Added session variable and cookie support in PHP
 *
 * Revision 1.2  2008/03/07 15:11:25  joegenbaclor
 * Added PHP SAPI Support in HTTP Server
 *
 * Revision 1.1  2008/03/07 04:20:50  joegenbaclor
 * Added PHP Classes
 *
 *
 */


#ifndef PHP_SCRIPT_H
#define PHP_SCRIPT_H
#include <string>
#include <map>
#include <vector>
#include <utils/Variant.h>

namespace PHP
{
  typedef UTILS::Variant PHPVariant;
  typedef std::map<std::string, PHPVariant> PHPVariantMap;
  typedef std::vector<PHPVariant> PHPVariantArray;
  typedef std::map<std::string, std::string> GETData;
  typedef std::map<std::string, std::string> POSTData;
  typedef std::map<std::string, std::string> COOKIEData;

  class PHPScript
  {
  public:
    PHPScript( int argc, char **argv, const std::string & inc_path  );
    ~PHPScript();

    int LoadScript( const std::string & file );

    int ExecuteScript( const std::string & file );

    bool PHPEvaluate( 
      const std::string & funcName,
      PHPVariantMap & in,
      PHPVariantMap & out
    );
    
    virtual bool OnCPPEvaluate(
      const std::string & funcName,
      PHPVariantMap & in,
      PHPVariantMap & out 
    ) = 0;

    virtual bool OnCPPStoreCookie(
      const std::string & cookieName,
      const std::string & cookieValue
    ) = 0;

    virtual bool OnSessionGlobal(
      const std::string & sessionId,
      const std::string & varName,
      PHPVariantMap & out
    );

    virtual void OnSessionGlobalStart();

    virtual void OnSessionGlobalDestroy();

    virtual void OnPHPEcho( const std::string & str );

  protected:
    void ***tsrm_ls;
    bool m_IsSessionActive;
    std::string m_SessionId;
    GETData m_GETData;
    POSTData m_POSTData;
    COOKIEData m_COOKIEData;
  };

};
#endif

