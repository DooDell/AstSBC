<?php
	if (!function_exists('getallheaders'))
	{
		function getallheaders()
		{
			foreach ($_SERVER as $name => $value)
			{
				if (substr($name, 0, 5) == 'HTTP_')
				{
					$headers[str_replace(' ', '-', ucwords(strtolower(str_replace('_', ' ', substr($name, 5)))))] = $value;
				}
			}
			return $headers;
		}
	}
	
	function getsipheaders( $http_headers )
	{
		foreach ($http_headers as $name => $value)
		{
			if (substr($name, 0, 9) == 'X-CC-SIP-')
			{
				$headers[substr($name, 9)] = $value;
			}
		}
		return $headers;
	}
	
	function handle_callstop( $http_headers )
	{
		$_SIP = getsipheaders( $http_headers );			
		$caller = $_SIP["From-User"];
		$caller_host = $_SIP["From-Host"];
		$callee = $_SIP["R-URI-User"];
        $callee_host = $_SIP["R-URI-Host"];     
	}
	
	function handle_callreject( $http_headers )
	{
		$_SIP = getsipheaders( $http_headers );			
		$caller = $_SIP["From-User"];
		$caller_host = $_SIP["From-Host"];
		$callee = $_SIP["R-URI-User"];
        $callee_host = $_SIP["R-URI-Host"];     
	}
	
	$http_headers = getallheaders();
	$method = $http_headers["X-CC-Method"];
	
	if( $method == "CALLSTOP" )
		handle_callstop( $http_headers );
	else if( $method == "CALLREJECT" )
		handle_callreject( $http_headers );
?>

