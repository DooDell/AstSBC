<?php

	include_once( "rttsclient.php" );
    include_once( "authrequest.php" );
		
	/// Sucess constants
	define("SESSION_AUTHORIZED", 201);
    
	/// None Fatal Failures
	define("SESSION_FAILURE", 400);
	define("SESSION_FORBIDDEN", 401);
	define("SESSION_REQUIRE_A1_HASH", 402);
	define("SESSION_REQUIRE_SECURITY_CODE", 403);
	
	/// Fatal Failures
	define("SESSION_UNKNOWN_FATAL_FAILURE", 501);
	define("SESSION_ACQUIRE_FAILURE", 501);
	
	class ServiceQuery
	{
		protected $m_UserName;
		protected $m_UserDomain;
		protected $m_UserHost;
		protected $m_ServiceTarget;
		protected $m_AuthA1Hash;
		protected $m_AuthSecurityCode;
		protected $m_CSeq;
		
		protected $m_ClientAddress;
		protected $m_ClientPortMin;
		protected $m_ClientPortMax;
		protected $m_ClientPortRegistry;
		protected $m_ServerList;
		protected $m_CurrentServerAddress;
		protected $m_CurrentServerPort;
		
		public function __construct(
			$clientAddress,
			$clientPortMin,
			$clientPortMax,
			$clientPortRegistry,
			$serverList,
			$userName,
			$userDomain,
			$userHost,
			$serviceTarget,
			$authA1Hash,
			$authSecurityCode
		)
		{
			$this->m_ClientAddress = $clientAddress;
			$this->m_ClientPortMin = $clientPortMin;
			$this->m_ClientPortMax = $clientPortMax;
			$this->m_ClientPortRegistry = $clientPortRegistry;
			$this->m_ServerList = $serverList;
			$this->m_CurrentServerPort = 0;
			
			$this->m_UserName = $userName;
			$this->m_UserDomain = $userDomain;
			$this->m_UserHost = $userHost;
			$this->m_ServiceTarget = $serviceTarget;
			$this->m_AuthA1Hash = $authA1Hash;
			$this->m_AuthSecurityCode = $authSecurityCode;
			$this->m_CSeq = 0;
		}
		
		private function AppendAdditionalHeaders( &$packet )
		{
			$start_packet->SetHeader( "X-CC-RTTS-Server", 
				$this->m_CurrentServerAddress . ":" . 
				$this->m_CurrentServerPort );
				
			$start_packet->SetHeader("X-CC-Trn-Agent",  "PHP RTTS Client 1.0" );
		}
		 
		protected function AcquireSession()
		{
			$rttsIndex = -1;
			for( $i = 0; $i < sizeof( $serverList ) ; $i++ )
			{
				$this->m_CurrentServerAddress = $this->m_ServerList[$i][0];
			    $this->m_CurrentServerPort = $this->m_ServerList[$i][1];
				
				$client = new RTTSClient( 
				$this->m_ClientAddress, 
				$this->m_ClientPortMin, 
				$this->m_ClientPortMax, 
				$this->m_ClientPortRegistry, 
				$this->m_CurrentServerAddress, 
				$this->m_CurrentServerPort ); 
				
				$packet = new RTBEPacket( 
				    "START",
					"MyLocalId-123",
					$sessionid,
					$cseq );
			
				$this->AppendAdditionalHeaders( $packet );
	
				if($client->WritePacket($start_packet, $response ))
				{
					$rttsIndex = $i;
					break;
				}
			}
			
			return $rttsIndex != -1;
			
		}
		
		protected function OnSessionAuthorized()
		{
		}
		
		
		public function Execute()
		{
			if( !AcquireSession() )
				return SESSION_ACQUIRE_FAILURE;
			
			$ret = Authenticate();
			if( $ret == SESSION_AUTHORIZED )
				return OnSessionAuthorized(); 
			return $ret;
		}
		
		
	}
?>
