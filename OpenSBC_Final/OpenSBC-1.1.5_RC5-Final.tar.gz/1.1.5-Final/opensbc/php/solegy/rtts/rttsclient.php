<?php
	class RTTSClient
	{
		private $m_Socket;
		private $m_ClientAddress;
		private $m_ClientPortMin;
		private $m_ClientPortMax;
		private $m_ClientPort;
		private $m_ClientPortRegistry;
		private $m_ServerAddress;
		private $m_ServerPort;
		private $m_ReadTimeout;
		
		public $m_LastSocketError;
		public $m_SocketLastErrorMsg;
		
		public function __construct( 
			$clientAddress, 
			$clientPortMin,
			$clientPortMax,
			$clientPortRegistry, 
			$serverAddress, 
			$serverPort, 
			$readTimeout = 5 )
		{
			set_time_limit(0); // <- We do not want PHP to be timing out on us!
			
			$this->m_ClientAddress = $clientAddress;
			$this->m_ClientPortMin = $clientPortMin;
			$this->m_ClientPortMax = $clientPortMax;
			$this->m_ClientPortRegistry = $clientPortRegistry;
			$this->m_ServerAddress = $serverAddress;
			$this->m_ServerPort = $serverPort;
			$this->m_ReadTimeout = $readTimeout;
		}
		
		
		private function CreateSocket()
		{
			$this->m_Socket = socket_create(AF_INET, SOCK_DGRAM, getprotobyname("udp"));
			
		    $lastPort = $this->m_ClientPortMin - 1;

			if( is_file($this->m_ClientPortRegistry) )
			{
				$file = fopen( $this->m_ClientPortRegistry, "r+");
				if( $file )
				{
					flock( $file, LOCK_EX );
					$lastPort = (int)fgets($file);
				}
			}else
			{
				$file = fopen( $this->m_ClientPortRegistry, "a+"); /// nothing to read.  just open it
				flock( $file, LOCK_EX );
			}

			if( $lastPort > $this->m_ClientPortMax )
				$lastPort = $this->m_ClientPortMin;
			
			for( $retry = 0; $retry < 20 && $lastPort <= $this->m_ClientPortMax; $retry++ )
			{
				$this->m_ClientPort = $lastPort + 1;
				if( ++$lastPort > $this->m_ClientPortMax )
				{
					$this->m_ClientPort = $lastPort = $this->m_ClientPortMin;
				}		
				
				if( socket_bind($this->m_Socket, $this->m_ClientAddress, $this->m_ClientPort ) )
				{
					socket_set_nonblock  ( $this->m_Socket  );  // <-- we will use select to read
						
					settype($lastPort, "string");
					ftruncate( $file, 0 );
					fseek( $file, 0 );
					fputs( $file, $lastPort, strlen($lastPort) );
					
					fclose( $file );
					return true;
				}
			}
			
			
			
			fclose( $file );
			
			$this->m_LastSocketError = socket_last_error();
            socket_strerror($this->m_LastSocketErrorMsg);
			
			return false;
		}
		
		private function WriteString( $string )
		{
			return socket_sendto(
				$this->m_Socket, 
				$string, 
				strlen($string), 
				0,
				$this->m_ServerAddress,
				$this->m_ServerPort );
		}
		
		private function ReadString( &$string )
		{
			/* Prepare the read array */
			$fdset   = array($this->m_Socket);
			$write  = NULL;
			$except = NULL;
			
			if( socket_select($fdset, $write, $except, 1) <= 0 )
			{
				$this->m_LastSocketError = socket_last_error();
            	socket_strerror($this->m_LastSocketErrorMsg);
				return false;
			}
			
			$string = socket_read($this->m_Socket, 10240);
			return true;
			
		}
		
		private function CloseSocket()
		{
			return socket_close($this->m_Socket);
		}
		
		public function WritePacket( &$request, &$response )
		{
			$ok = false;
			if( $this->CreateSocket())
			{
				$request->SetHeader( "X-CC-RTTS-Client", 
					$this->m_ClientAddress . ":" . $this->m_ClientPort );
					
				for( $i = 0; $i < $this->m_ReadTimeout; $i++ )
				{ 
					$ok = false;
					if( $this->WriteString( $request->AsString() ) )
						$ok = $this->ReadString( $buff );
					if( $ok )
					{
						$response = new RTBEPacket( $buff );
						break;
					}
				}
			}
			
			$this->CloseSocket();
						
			return $ok;
		}
	};
?>