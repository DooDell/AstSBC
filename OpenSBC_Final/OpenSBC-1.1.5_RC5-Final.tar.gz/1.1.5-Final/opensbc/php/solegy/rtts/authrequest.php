<?php
    include_once("rtbepacket.php");
	
	class AuthRequest extends RTBEPacket
	{
		public function __construct( 
			$localId,
			$sessionId,
			$sequence,
			$callerHostAddress,
			$fromUserName,
			$fromHost,
			$dialString
		)
		{
			parent::__construct(
				"AUTH",
				$localId,
				$sessionId,
			    $sequence );
				
			parent::SetHeader( "HOST" , $callerHostAddress );
			parent::SetHeader( "ANI" , $fromUserName );
			parent::SetHeader( "DOMAIN" , $fromHost );
			parent::SetHeader( "DNIS" , $dialString );
		}
	};
?>