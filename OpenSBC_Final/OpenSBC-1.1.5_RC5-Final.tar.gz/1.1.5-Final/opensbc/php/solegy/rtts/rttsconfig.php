<?php
    $RTTS_SERVER = Array( 
	    //array( "70.42.73.14", 7823 )//,
		//array( "70.42.73.18", 7823 ),
		array( "70.42.73.19", 7823 )
	);
	
	
	$RTTS_CLIENT_ADDRESS = $_SERVER["SERVER_ADDR"];;
	$RTTS_CLIENT_PORT_MIN = 59000;
	$RTTS_CLIENT_PORT_MAX = 65000;
	$RTTS_PORT_REGISTRY = "c:\\rttsport.lock";
?>
