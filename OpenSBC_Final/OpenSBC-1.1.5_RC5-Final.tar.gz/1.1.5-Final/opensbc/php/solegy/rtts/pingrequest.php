<?php
    include_once("rtbepacket.php");
	
	class PingRequest extends RTBEPacket
	{
		public function __construct( 
			$localSerial,
			$localId,
			$sessionId,
			$sequence )
		{
			parent::__construct(
				"PING",
				$localId,
				$sessionId,
			    $sequence );
				
			parent::SetHeader( "SERIAL" , $localSerial);
		}
	};
?>
