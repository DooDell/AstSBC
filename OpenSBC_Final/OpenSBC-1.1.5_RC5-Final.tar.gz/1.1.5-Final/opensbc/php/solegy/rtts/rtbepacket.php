<?php
	include_once( "rttsclient.php" );
	include_once( "../tools/stringtokenizer.php" );
	
	class RTBEPacket
	{
		protected $m_Method;
		protected $m_LocalId;
		protected $m_SessionId;
		protected $m_Sequence;
		protected $m_Headers;
		
		public function __construct()
		{
			$argv = func_get_args();
			$argc = func_num_args();
			switch( $argc )
			{
				case 1:
					$this->ConstructFromString($argv[0]);
					break;
				case 4:
					$this->ConstructWithKnownParams( $argv[0], $argv[1], $argv[2], $argv[3] );
					break;
				default:
			}
		}
		
		protected function ConstructWithKnownParams( 
			$method,
			$localId,
			$sessionId,
			$packetSequence 
		)
		{
			$this->m_Method = $method;
			$this->m_LocalId = $localId;
			$this->m_SessionId = $sessionId;
			$this->m_Sequence = $packetSequence;
			//$this->m_Headers = array("" );
		}
		
		protected function ConstructFromString( $string )
		{
			$tokens = new StringTokenizer();
			if( !$tokens->Tokenize( $string, "\n" ))
			{
				echo "String Tokenizer Failed!";
				return;
			}else{
				$count = $tokens->GetSize();
				$method = $tokens->GetAt(0);
				
				if( $method != "" )
				{
					$this->m_Method = trim($method);
					
					for( $i = 1; $i < $count; $i++ )
					{
						$nextToken = $tokens->GetAt($i);
						if( StringTokenizer::AsKeyValuePair( $nextToken, "=", $key, $value ) )
						{
							if( $key == "LOCALID" )
							{
								$this->m_LocalId = $value;
							}else if( $key == "SESSION-ID" )
							{
								$this->m_SessionId = $value;
							}else if( $key == "SEQ" )
							{
								$this->m_Sequence = $value;
							}else
							{
								$this->m_Headers[$key] = $value;
							}
						}
					}
				}
			}
		}
		
		public function GetMethod(){ return $this->m_Method; }
		public function GetLocalId(){ return $this->m_LocalId; }
		public function GetSessionId(){ return $this->m_SessionId; }
		public function GetSequence(){ return $this->m_Sequence; }

		public function AsString(  )
		{
			$packet = $this->m_Method . "\r\n";
			$packet = $packet . "LOCALID=" . $this->m_LocalId . "\r\n";
			$packet = $packet . "SESSION-ID=" . $this->m_SessionId . "\r\n";
			$packet = $packet . "SEQ=" . $this->m_Sequence . "\r\n";
			
			if( is_array($this->m_Headers))
			{
				foreach ($this->m_Headers as $name => $value)
				{
					$packet = $packet . $name . "=" . $value . "\r\n";
				}
			}
			
			return $packet;
		}
		
		public function SetHeader( $key, $value )
		{
			if( !is_array( $this->m_Headers ) )
			{
				$this->m_Headers = array( $key => $value );
			}else
			{
				$this->m_Headers[$key]=$value;
			}		
		}
		
		public function GetHeader($key)
		{
			if( !is_array( $this->m_Headers ))
				return "";
			if( !isset($this->m_Headers[$key]))
				return "";
			return $this->m_Headers[$key];
		}
		
		public function GetHeaderAt($index, &$key, &$value)
		{
			if( !is_array( $this->m_Headers ))
				return false;
				
			$values = array_values($this->m_Headers);
			$keys = array_keys($this->m_Headers);
			
			if( sizeof($values) == 0 || 
			    sizeof($keys) != sizeof($values) || 
				$index >= sizeof($keys) )
				return false;
			
			$key = $keys[$index];
			$value = $values[$index];
			
			return true;
		}
		
	};
?>
