/*
 *
 * SBCSwitchEndPoint.cxx
 *
 * Open SIP Stack ( OSS )
 *
 * Copyright (c) opensipstack.org.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either expressed or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is OpenSIPStack.
 *
 * The Initial Developer of the Original Code is opensipstack.org.
 *
 * The author of this code is Joegen E. Baclor
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * The OpenSIPStack Library includes some GPL/LGPL code libraries that MAY be 
 * enabled at compile time using the --enable-gpllibs configure switch.  If
 * enabled, the content of this file is published under the terms of GNU 
 * General Public License Version 2.  For a detailed list of the available
 * GPL code, see $(opensipstack)/gnu/README file.
 *
 * $Log: SBCSwitchEndPoint.cxx,v $
 * Revision 1.5  2009/06/09 07:11:49  joegenbaclor
 * added ivr leg class
 *
 * Revision 1.4  2009/06/03 11:57:16  joegenbaclor
 * Checking in MOH feature
 *
 * Revision 1.3  2009/06/01 09:47:28  joegenbaclor
 * more IVR related work
 *
 * Revision 1.2  2009/05/29 09:31:32  joegenbaclor
 * Added Switch IVR Classes
 *
 * Revision 1.1  2009/05/27 12:40:34  joegenbaclor
 * Initial upload of switch related classes
 *
 *
 */


#include "SBCSwitchEndPoint.h"
#include "SBCSwitchConnection.h"
#include "SBCSwitchLeg1.h"
#include "SBCSwitchLeg2.h"
#include "SBCSwitchIVRLeg.h"
#include "OpenSBC.h"
#include "SBCSwitchRTPSession.h"

#define new PNEW

using namespace SWITCH;

SBCSwitchEndPoint::SBCSwitchEndPoint(
  SIPUserAgent & ua,
  PINDEX sessionThreadCount,
  PINDEX stackSize,
  WORD rtpPortBase,
  WORD rtpPortMax
) : SBCB2BUAEndPoint( ua, sessionThreadCount, stackSize )
{
  SIPURI::RegisterScheme( "ivr" );
  m_CurrentRTPPort = rtpPortBase - 2;
  SetRTPPortBase( rtpPortBase, rtpPortMax );
}

SBCSwitchEndPoint::~SBCSwitchEndPoint()
{
}

B2BUAConnection * SBCSwitchEndPoint::OnCreateB2BUA(
  const SIPMessage & request,
  const OString & _sessionId,
  B2BUACall * call
)
{
  OString sessionId = _sessionId + "-connection";
  SBCSwitchConnection * connection = new SBCSwitchConnection( *this, sessionId );
  B2BUserAgent& ua = dynamic_cast<B2BUserAgent&>(m_UserAgent);
  
  if( !ua.OnPostCreateB2BUA( this, connection,call ) )
  {
    delete connection;
    return NULL;
  }
  
  ProfileUA & profile = GetUserAgent().GetDefaultProfile();
  connection->AttachSwitchMedia( (SBCSwitchMedia *)OnCreateMediaSession( profile, _sessionId, connection ) );

  return connection;
}

CallSession * SBCSwitchEndPoint::OnCreateServerCallSession(
  SIPMessage & request,
  const OString & sessionId
)
{
  if( !request.IsInvite() )
    return NULL;

  OString toTag = request.GetToTag();
  if( !toTag.IsEmpty() )
  {
    SIPMessage response;
    request.CreateResponse( response, SIPMessage::Code481_TransactionDoesNotExist, "None Existent Session" );
    SendRequest( response, NULL, request.GetTransaction() );
    return NULL;
  }

  /// incoming INVITE... create a session
  SBCSwitchLeg1 * call = new SBCSwitchLeg1( *this, request, sessionId );
  call->SetLegIndex( 0 );
  SBCSwitchConnection * b2bua = (SBCSwitchConnection *)CreateB2BUA( request, call );

  if( b2bua == NULL )
  { 
    /// this can only happen if the maximum connection  count has been reached
    SIPMessage response;
    request.CreateResponse( response, SIPMessage::Code500_InternalServerError, call->GetCallAnswerResponseWarning() );
    SendRequest( response, NULL, request.GetTransaction() );
    delete call;
    return NULL;
  }

  call->SetB2BUAConnection( b2bua );
  return call;
}

CallSession * SBCSwitchEndPoint::OnCreateClientCallSession(
  const ProfileUA & profile,
  const OString & sessionId
)
{
  SBCSwitchConnection * connection = dynamic_cast<SBCSwitchConnection*>( profile.GetUserData() );
  if( connection == NULL || connection->GetRoutes().GetSize() == 0 )
    return NULL;

  CallSession * call = NULL;
  SIPURI route = connection->GetRoutes()[0];
  if( route.GetScheme() *= "ivr" )
  {
    call = new SBCSwitchIVRLeg( *this, sessionId, profile );
  }else
  {
    call = new SBCSwitchLeg2( *this, sessionId, profile );;
  }

  call->SetLegIndex( 1 );
  call->EnableSessionTimer( m_EnableSessionTimer );
  return call;
}

CallSession * SBCSwitchEndPoint::OnCreateMediaSession(
  const ProfileUA & profile,
  const OString & _sessionId,
  SBCSwitchConnection * conn
)
{
  OpenSBC & sbc = dynamic_cast<OpenSBC&>(this->GetUserAgent());
  SBCAuxiliaryUA * auxUA = sbc.GetAuxiliaryEndPoint();
  OString sessionId = _sessionId + "-0xMS";
  SBCSwitchMedia * session = new SBCSwitchMedia( this, auxUA->m_EP, conn, sessionId, profile );
  session->SetLegIndex( 2 );
  session->EnableSessionTimer( FALSE );
  if( !auxUA->m_EP->ManageSession( session ) )
  {
    LOG_CONTEXT( LogError(), session->GetSessionId().c_str(), "!!! Auxiliary EndPoint failed to manager session !!" )
    delete session;
    return NULL;
  }
  
  return session;
}

BOOL SBCSwitchEndPoint::CreateRTPSession(
    RTP_SessionManager & manager,
    CallSession & call,
    unsigned sessionId,
    const PIPSocket::Address & localAddress,
    const PIPSocket::Address & targetAddress,
    const PIPSocket::Address & receivedAddress,
    WORD targetPort,
    BOOL isEncrypted
  )
{

  SBCSwitchDTMFInterface * dtmfIface = dynamic_cast<SBCSwitchDTMFInterface*>( &call );
  if( dtmfIface == NULL )
  {
    PTRACE( 1, "RTP: Attempt to create an RTP Session for a NULL call or a none-descendant of SBCSwitchDTMFInterface" ); 
    return FALSE;
  }

  SBCSwitchRTPInterface * rtpIface = dynamic_cast<SBCSwitchRTPInterface*>( &call );
  if( rtpIface == NULL )
  {
    PTRACE( 1, "RTP: Attempt to create an RTP Session for a NULL call or a none-descendant of SBCSwitchRTPInterface" ); 
    return FALSE;
  }

  SBCSwitchRTPSession * rtpSession = (SBCSwitchRTPSession*)manager.GetSession(sessionId);
  if(  rtpSession == NULL )
  {
    rtpSession = new SBCSwitchRTPSession(sessionId);
    rtpSession->SetWillSendReport( FALSE );
    rtpSession->AttachDTMFInterface( dtmfIface );
    rtpSession->AttachRTPInterface( rtpIface );

    WORD firstPort = AcquireRTPPort();
    WORD nextPort = firstPort;
    while (!rtpSession->Open(localAddress,
                            nextPort, nextPort,
                            0x10/*IPTOS_LOWDELAY*/,
                            NULL,
                            NULL)) 
    {
      nextPort = AcquireRTPPort();
      if (nextPort == firstPort) 
      {
        LOG_CONTEXT( LogError(), call.GetCallId().c_str(), "RTP: Unable to create RTP session.  Bind Error" );
        delete rtpSession;
        return FALSE;
      }
    }
    manager.AddSession( rtpSession );
  }

  rtpSession->SetEncryption( isEncrypted );

  rtpSession->SetLocalAddress(localAddress);
  if( targetAddress.IsValid() && targetPort != 0 )
  {
    if( !SIPTransport::IsPrivateNetwork( targetAddress ) )
    {
      rtpSession->SetRemoteSocketInfo( targetAddress, targetPort, TRUE );
      rtpSession->SetRemoteSocketInfo( targetAddress, targetPort + 1, FALSE );
    }else
    {
      rtpSession->SetRemoteSocketInfo( 0, 0, TRUE );
      rtpSession->SetRemoteSocketInfo( 0, 0 + 1, FALSE );
      rtpSession->SetTemporaryRemoteSocketInfo( receivedAddress, targetPort, TRUE );
      rtpSession->SetTemporaryRemoteSocketInfo( receivedAddress, targetPort + 1, FALSE );
    }
  }

  
  
  return TRUE;
}


BOOL SBCSwitchEndPoint::CreateRTPSession(
  SBCB2BUACall & call,
  unsigned sessionId,
  const PIPSocket::Address & localAddress,
  const PIPSocket::Address & targetAddress,
  const PIPSocket::Address & receivedAddress,
  WORD targetPort,
  BOOL isEncrypted,
  int rfc2833Payload
)
{
  BOOL ok = CreateRTPSession( 
    call.GetRTPSessionManager(), 
    call, 
    sessionId, 
    localAddress, 
    targetAddress, 
    receivedAddress, 
    targetPort, 
    isEncrypted );
  
  SBCSwitchRTPSession * rtp = (SBCSwitchRTPSession *)call.GetRTPSessionManager().GetSession( sessionId );
  if( rtp == NULL )
    return FALSE;

  rtp->SetRFC2833PayLoad( rfc2833Payload );
  

  return ok;
}






