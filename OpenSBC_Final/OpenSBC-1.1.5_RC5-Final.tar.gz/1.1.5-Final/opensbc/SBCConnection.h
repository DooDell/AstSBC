/*
 *
 * SBCConnection.h
 *
 * Open SIP Stack ( OSS )
 *
 * Copyright (c) opensipstack.org.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either expressed or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is OpenSIPStack.
 *
 * The Initial Developer of the Original Code is opensipstack.org.
 *
 * The author of this code is Joegen E. Baclor
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * The OpenSIPStack Library includes some GPL/LGPL code libraries that MAY be 
 * enabled at compile time using the --enable-gpllibs configure switch.  If
 * enabled, the content of this file is published under the terms of GNU 
 * General Public License Version 2.  For a detailed list of the available
 * GPL code, see $(opensipstack)/gnu/README file.
 *
 * $Log: SBCConnection.h,v $
 * Revision 1.11  2009/05/20 08:42:33  joegenbaclor
 * *** empty log message ***
 *
 * Revision 1.10  2009/04/15 12:27:31  joegenbaclor
 * *** empty log message ***
 *
 * Revision 1.9  2009/04/13 05:48:57  joegenbaclor
 * Removed transport pool
 *
 * Revision 1.8  2009/04/13 03:25:51  joegenbaclor
 * Using session events to trigger accounting send request
 *
 * Revision 1.7  2009/04/06 04:08:41  joegenbaclor
 * Using sIPSessionEvent to signal RTTS packet arrival
 *
 * Revision 1.6  2009/02/02 06:13:50  joegenbaclor
 * implemented 3xx handler
 *
 * Revision 1.5  2009/01/03 12:14:24  joegenbaclor
 * Reimplemented DestroyConenction to enqueue a session event instead to avoid further race conditons and dead locks.
 * We also implemented B2BUAConnection::IsSafeReference() to further guaranty the integrity of connection pointers.
 *
 * Revision 1.4  2008/12/22 06:51:46  joegenbaclor
 * Application Timers for Alerting and Connect is causing a deadlock on connection destruction.
 * To address this issue, we modified opensipstack to take care of the timers in the ICT Layer.
 *
 * Revision 1.3  2008/12/17 04:51:35  joegenbaclor
 * Introduced a new handler for cancelled calls in SBCConnection. As opposed to
 * the old behavior of blindly sending CANCEL to the UAS while abruptly destroying the
 * call, the new handler would wait for final response from the UAS before the call
 * is queued for deletion.  Hopefully this would eradicate the chances of race conditions
 * that may happen when multiple methods are interrupted by a call to cancel.
 *
 * Revision 1.2  2008/10/29 06:24:20  joegenbaclor
 * Addded SBCWArningBeepStreamer class
 * Bug fixes in rtts session destruction
 *
 * Revision 1.1  2008/10/27 09:44:04  joegenbaclor
 * Subclassing B2BUA objects to give OpenSBC a more fine grained control
 *
 *
 */

#ifndef SBCCONNECTION_H
#define SBCCONNECTION_H


#include "B2BUAConnection.h"
namespace B2BUA
{

  class SBCConnection : public B2BUAConnection
  {
    PCLASSINFO( SBCConnection, B2BUAConnection );
  public:

    enum CallControlEvent
    {
      Event_InitializeCallControl = B2BUAConnection::NumSessionEvent,
      Event_ProcessCallArrivalQueue,
      Event_OnReceivedAccountingPacket,
      Event_OnSendAccountingStart,
      Event_OnSendAccountingAuth,
      Event_OnSendAccountingSignIn,
      Event_OnSendAccountingSetup,
      Event_OnSendAccountingCallStart,
      Event_OnSendAccountingCallStop,
      Event_OnSendAccountingError,
      Event_OnSendAccountingStop,
      Event_OnTransferReject,
      Event_OnDumpAuditTrail,
      NumCallControlEvent
    };

    SBCConnection(
      B2BUAEndPoint & ep,
      const OString & sessionId
    );

    virtual ~SBCConnection();

    void OnSessionEvent(
      SIPSessionEvent & sessionEvent
    );

    void EnforceDisconnectedState( 
      const SIPMessage & message 
    );
    /** PRE-CONNECT */
    virtual void OnHandlePreConnectState( 
      B2BUACall & call,
      const SIPMessage & msg
    );

    void HandleAbandonedState(
      B2BUACall & call,
      const SIPMessage & msg
    );

    BOOL IsMerged(
      B2BUACall & call,
      const SIPMessage & msg
    );

    void HandleLeg1PreConnect(
      B2BUACall & call,
      const SIPMessage & msg
    );

    void HandleLeg2PreConnect(
      B2BUACall & call,
      const SIPMessage & msg
    );

    BOOL HandleLeg2PreConnect_1xx(
      B2BUACall & call,
      const SIPMessage & msg
    );

    BOOL HandleLeg2PreConnect_2xx(
      B2BUACall & call,
      const SIPMessage & msg
    );

    void HandleLeg2PreConnect_3xx(
      B2BUACall & call,
      const SIPMessage & msg
    );

    void HandleLeg2PreConnect_4xx_6xx(
      B2BUACall & call,
      const SIPMessage & msg
    );

    void HandleLeg2PreConnectAuthentication(
      B2BUACall & call,
      const SIPMessage & msg
    ); 
    /** END-PRE-CONNECT */

    virtual void OnHandleStateConnected( 
      B2BUACall & call,
      const SIPMessage & msg
    );

    virtual void OnFinalizeCallDestruction( 
      SIPSessionEvent & event 
    );

    void WarnTransferUAC();

    BOOL m_IsAbandoned;
  };
};

#endif







