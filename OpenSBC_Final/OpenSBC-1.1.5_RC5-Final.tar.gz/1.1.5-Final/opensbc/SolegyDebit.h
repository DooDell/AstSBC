/*
 *
 * SolegyDebit.h
 *
 * Open SIP Stack ( OSS )
 *
 * Copyright (c) opensipstack.org.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either expressed or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is OpenSIPStack.
 *
 * The Initial Developer of the Original Code is opensipstack.org.
 *
 * The author of this code is Joegen E. Baclor
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * The OpenSIPStack Library includes some GPL/LGPL code libraries that MAY be 
 * enabled at compile time using the --enable-gpllibs configure switch.  If
 * enabled, the content of this file is published under the terms of GNU 
 * General Public License Version 2.  For a detailed list of the available
 * GPL code, see $(opensipstack)/gnu/README file.
 *
 * $Log: SolegyDebit.h,v $
 * Revision 1.22  2008/11/19 04:10:54  joegenbaclor
 * Bug:  Media server cals unable to properly route to media server listener ue to recent
 *  changes in outbound proxy handling
 *
 * Revision 1.21  2008/10/22 05:06:25  joegenbaclor
 * Added MPL License Header
 *
 *
 */

#ifndef SOLEGYDEBIT_H
#define SOLEGYDEBIT_H

#include "Solegy.h"

namespace SOLEGY
{

  class SolegyDebit : public SolegySession
  {
    PCLASSINFO( SolegyDebit, SolegySession );
  public:
    SolegyDebit(
      SolegySessionManager * manager,
      SolegySocket * socket,
      B2BUAConnection * sipConnection,
      const char * localSessionId
    );

    ~SolegyDebit();

    void OnIVREvent(
      B2BUAConnection * conn,
      const B2BIVRInterface::B2BIVREvent * evt
    );

    virtual void SetupOutbound( SIPMessage & invite );
    virtual BOOL SetupInbound( const  SIPMessage & invite );
    virtual BOOL Start( const SIPMessage & msg  );
    void Validate_PIN( const OString & pin );
    void Validate_TELNUMBER( const OString & number );
    void Do_CALLTRANSFER( const OString & number );
    void HandlePreAuthenticatedCall();

    virtual BOOL OnPrepareSIGNINInfo( OStringStream & strm );
    virtual BOOL OnPrepareSETUPInfo( OStringStream & strm );

    virtual BOOL OnReceived_AUTH( const OString & packet );
    virtual void OnReceived_SIGNIN_ERROR( const OString & packet );
    virtual BOOL OnReceived_SIGNIN( const OString & packet );
    virtual BOOL OnReceived_SETUP( const OString & packet );
    virtual void OnReceived_SETUP_ERROR( const OString & packet );

    virtual void CallDisconnect( const OString & reason );
    virtual void OnTransferReject( const SIPMessage & reject );
    virtual void OnIVRPromptTimeout();

    void IVRAnnounce_Welcome( int silence = 0 );
    void IVRAnnounce_CollectPin( int silence = 0 );
    void IVRAnnounce_WelcomeAndCollectPin( int silence = 0 );
    void IVRAnnounce_Balance( int silence = 0 );
    void IVRAnnounce_CollectNumber( int silence = 0 );
    void IVRAnnounce_BalanceAndCollectNumber( int silence = 0 );
    void IVRAnnounce_CallDuration( int silence = 0 );
    void IVRAnnounce_CallTransfer( int silence = 0 );
    void IVRAnnounce_GoodBye( const OString & reasonId = "", int silence = 0 );
    //Errors
    void IVRAnnounce_InvalidPin( int silence = 0 );
    void IVRAnnounce_InvalidNumber( int silence = 0 );
    void IVRAnnounce_CallTransferError( int silence = 0 );
    void IVRAnnounce_AccountDepleted( int silence = 0 );
    
    int m_InvalidPinRetry;
    int m_InputTimeout;
    BOOL m_IsPINLess;
    SolegyPromptManager * m_IVR;
  };

}

#endif


