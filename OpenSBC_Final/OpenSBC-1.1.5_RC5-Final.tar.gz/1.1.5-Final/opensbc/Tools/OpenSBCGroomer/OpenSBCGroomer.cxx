/*
 *
 * OpenSBCGroomer.cxx
 *
 * Open SIP Stack ( OSS )
 *
 * Copyright (c) opensipstack.org.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either expressed or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is OpenSIPStack.
 *
 * The Initial Developer of the Original Code is opensipstack.org.
 *
 * The author of this code is Joegen E. Baclor
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * The OpenSIPStack Library includes some GPL/LGPL code libraries that MAY be 
 * enabled at compile time using the --enable-gpllibs configure switch.  If
 * enabled, the content of this file is published under the terms of GNU 
 * General Public License Version 2.  For a detailed list of the available
 * GPL code, see $(opensipstack)/gnu/README file.
 *
 * $Log: OpenSBCGroomer.cxx,v $
 * Revision 1.68  2009/04/14 00:36:35  joegenbaclor
 * Do not process 100 rel in the groomer
 *
 * Revision 1.67  2009/03/31 02:37:10  joegenbaclor
 * Introduced Threadpool based solegy transport
 *
 * Revision 1.66  2009/03/17 02:24:44  joegenbaclor
 * introduced bypassing of ICT responses for fater response time
 *
 * Revision 1.65  2009/03/05 07:20:54  joegenbaclor
 * added ingress validation
 *
 * Revision 1.64  2009/03/05 06:41:45  joegenbaclor
 * removed error validation in callstop
 *
 * Revision 1.63  2009/03/05 05:10:54  joegenbaclor
 * send 4005 in callstop for questionable CDR's
 *
 * Revision 1.62  2009/03/04 09:33:31  joegenbaclor
 * *** empty log message ***
 *
 * Revision 1.61  2009/03/04 07:21:02  joegenbaclor
 * fixed flen
 *
 * Revision 1.60  2009/03/04 07:01:24  joegenbaclor
 * reprocessing support
 *
 * Revision 1.59  2009/03/03 08:05:47  joegenbaclor
 * *** empty log message ***
 *
 * Revision 1.58  2009/03/02 12:41:44  joegenbaclor
 * delete force disconnect statefile when an actual BYE is received
 *
 * Revision 1.57  2009/03/02 12:36:45  joegenbaclor
 * added via in force disconnect request
 *
 * Revision 1.56  2009/03/02 12:23:33  joegenbaclor
 * Fixed bug in force disconnect route-set
 *
 * Revision 1.55  2009/03/02 05:22:51  joegenbaclor
 * corrected typo
 *
 * Revision 1.54  2009/03/02 04:53:34  joegenbaclor
 * Fixed bug in upper registration as reported by kiaser where x-lite  is not able to register when stateful reg is in effect
 *
 * Revision 1.53  2009/03/02 02:06:14  joegenbaclor
 * support for mid dialog force disconnect
 *
 * Revision 1.52  2009/02/27 04:19:58  joegenbaclor
 * Minor bug fixes
 *
 * Revision 1.51  2009/02/25 12:28:07  joegenbaclor
 * *** empty log message ***
 *
 * Revision 1.50  2009/02/25 12:14:35  joegenbaclor
 * *** empty log message ***
 *
 * Revision 1.49  2009/02/25 10:34:19  joegenbaclor
 * *** empty log message ***
 *
 * Revision 1.48  2009/02/25 10:31:20  joegenbaclor
 * more logging
 *
 * Revision 1.47  2009/02/25 09:10:27  joegenbaclor
 * typo
 *
 * Revision 1.46  2009/02/25 09:07:41  joegenbaclor
 * logging enhancements
 *
 * Revision 1.45  2009/02/25 03:08:24  joegenbaclor
 * *** empty log message ***
 *
 * Revision 1.44  2009/02/25 02:53:17  joegenbaclor
 * *** empty log message ***
 *
 * Revision 1.43  2009/02/25 02:33:29  joegenbaclor
 * *** empty log message ***
 *
 * Revision 1.42  2009/02/25 01:08:06  joegenbaclor
 * *** empty log message ***
 *
 * Revision 1.41  2009/02/25 00:55:51  joegenbaclor
 * *** empty log message ***
 *
 * Revision 1.40  2009/02/25 00:49:43  joegenbaclor
 * *** empty log message ***
 *
 * Revision 1.39  2009/02/25 00:45:29  joegenbaclor
 * more ts glitches
 *
 * Revision 1.38  2009/02/25 00:36:44  joegenbaclor
 * more timestamp related fix
 *
 * Revision 1.37  2009/02/25 00:15:17  joegenbaclor
 * *** empty log message ***
 *
 * Revision 1.36  2009/02/24 23:44:20  joegenbaclor
 * updated version
 *
 * Revision 1.35  2009/02/24 23:40:38  joegenbaclor
 * fixed down cast issue in timestamp
 *
 * Revision 1.34  2009/02/24 09:14:35  joegenbaclor
 * Fixed bug in rtts commit
 *
 * Revision 1.33  2009/02/23 14:26:20  joegenbaclor
 * Added solegy fraud detection class
 *
 * Revision 1.32  2009/02/23 11:52:51  joegenbaclor
 * *** empty log message ***
 *
 * Revision 1.31  2009/02/23 11:37:44  joegenbaclor
 * fixed bug in strip-left-digits processing
 *
 * Revision 1.30  2009/02/20 06:57:11  joegenbaclor
 * Added rtts-commit-prefix param
 *
 * Revision 1.29  2009/02/04 08:32:50  joegenbaclor
 * fixed route index
 *
 * Revision 1.28  2009/02/03 12:52:23  joegenbaclor
 * oops.  typo in last commit!
 *
 * Revision 1.27  2009/02/03 12:50:47  joegenbaclor
 * Fixed bugs in previous commit for strict routing
 *
 * Revision 1.26  2009/02/03 09:45:29  joegenbaclor
 * Introduced digit stripping
 *
 * Revision 1.25  2009/02/03 07:59:42  joegenbaclor
 * added strict route support
 *
 * Revision 1.24  2009/02/03 00:33:22  joegenbaclor
 * incremented version
 *
 * Revision 1.23  2009/02/03 00:31:09  joegenbaclor
 * Fixed crashes during CANCEL
 *
 * Revision 1.22  2009/02/01 06:06:57  joegenbaclor
 * Fixed CANCE_Handler bug.  Made rtts-commit-dnis configurable
 *
 * Revision 1.21  2009/01/28 07:39:20  joegenbaclor
 * Send inbound request-uri user as DNIS to RTTS
 *
 * Revision 1.20  2008/12/03 12:54:28  joegenbaclor
 * Added support for route-set in routing
 *
 * Revision 1.19  2008/12/02 11:02:54  joegenbaclor
 * Added CAT uploder support
 *
 * Revision 1.18  2008/11/21 05:21:56  joegenbaclor
 * ommited RS in CAT logs
 *
 * Revision 1.17  2008/11/20 12:05:16  joegenbaclor
 * Added CAT support for error responses
 *
 * Revision 1.16  2008/11/20 11:01:09  joegenbaclor
 * Added CAT Log support for stateful calls
 *
 * Revision 1.15  2008/11/18 11:53:54  joegenbaclor
 * Bug:  Check m_RTTSPingHandler access for NULL pointer
 *
 * Revision 1.14  2008/11/11 03:27:09  joegenbaclor
 * Fixed GCC related compile errors
 *
 * Revision 1.13  2008/11/11 02:54:47  joegenbaclor
 * Feature:  Introducing RTTS aggregation of groomer and osbc
 * Bug:  Disconnect calls if ParseRouting has an empty result set
 *
 * Revision 1.12  2008/11/07 00:32:20  joegenbaclor
 * Added partial RTBE support
 *
 * Revision 1.11  2008/11/06 01:15:54  joegenbaclor
 * Added Loose route support
 *
 * Revision 1.10  2008/11/05 23:33:00  joegenbaclor
 * Added PAI support
 *
 * Revision 1.9  2008/11/05 14:09:26  joegenbaclor
 * relay ACK just in case we receive one
 *
 * Revision 1.8  2008/11/05 13:46:37  joegenbaclor
 * Memleak!  event should be deleted in ProcessEvent
 *
 * Revision 1.7  2008/11/05 12:59:59  joegenbaclor
 * Fixed bug in via (wrong port!)
 *
 * Revision 1.6  2008/11/05 09:14:16  joegenbaclor
 * Added ability to verify routes in command line
 *
 * Revision 1.5  2008/11/05 02:30:56  joegenbaclor
 * introduced routing via child xml files to allow for lazy evaluation of routes
 *
 * Revision 1.4  2008/11/04 06:18:20  joegenbaclor
 * Correcting typo
 *
 * Revision 1.3  2008/11/04 06:02:21  joegenbaclor
 * Routeing bug fixes
 *
 * Revision 1.2  2008/11/02 14:48:57  joegenbaclor
 * Bug fixes for GCC make environment
 *
 * Revision 1.1  2008/11/02 14:18:32  joegenbaclor
 * Initial CVS upload
 *
 *
 */

#include <ptlib.h>
#include <ptclib/pxml.h>
#include <ptlib/sockets.h>
#include <SIPMessage.h>
#include <SIPUserAgent.h>


#define APP_VERSION "1.0.0-40"
#define UA_NAME "OpenSBCGroomer " APP_VERSION

static int PREFIX_MATCH_LEN = 5;

using namespace SIP;
using namespace SIPFSM;
using namespace SIPParser;

#define TRANSACTION_THREAD_COUNT  100
#define RTTS_SERVER_PORT          7823
#define RTTS_PORT_BASE            8000
#define RTTS_PORT_MAX             65000
#define RTTS_EXPIRES              60000
#define RTTS_PING_TIMEOUT         5000
#define RTTS_START_TIMEOUT        5000
#define RTTS_AUTH_TIMEOUT         5000
#define RTTS_SIGNIN_TIMEOUT       5000
#define RTTS_SETUP_TIMEOUT        8000
#define RTTS_CALLSTART_TIMEOUT    8000
#define RTTS_CALLSTOP_TIMEOUT     8000
#define HEADER_PAYLOAD_MAX_SIZE   2048

static PString GetSafeFileName( const SIPMessage & response )
{
  PString xlat( response.GetCallId().c_str() );
  static const char * safeChars = "abcdefghijklmnopqrstuvwxyz"
                          "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
                          "0123456789@.";
  PINDEX pos = (PINDEX)-1;
  while ((pos += (int)(1+strspn(&xlat[pos+1], safeChars))) < xlat.GetLength())
    xlat.Splice(psprintf("%%%02X", (BYTE)xlat[pos]), pos, 1);
  return xlat;
}

class OpenSBCGroomer : public SIPUserAgent
{
  PCLASSINFO( OpenSBCGroomer, SIPUserAgent );
public:
  PSyncPoint m_TermSync;
  PDICTIONARY( RouteBlock, PString, PString );
  PDICTIONARY( RouteBlockParams, PString, PStringToString );
  PDICTIONARY( RouteGroup, PString, RouteBlock );
  PDICTIONARY( RouteHosts, PString, RouteGroup );
  PMutex m_RouteHostBlockMutex;
  RouteHosts * m_RouteHostBlock;
  RouteBlockParams m_RouteBlockParams;
  RouteBlock * m_CatchAllRouteBlocks;
  RouteBlock * m_RouteXMLBlocks;
  SIPURI m_ListenerAddress;
  PIPSocket::Address m_ListenerIP;
  WORD m_ListenerPort;
  PString m_RouteFile;
  PDICTIONARY( ICTCollection, PString, SIPMessage );
  ICTCollection m_ICTCollection;
  PMutex m_ICTCollectionMutex;

  PMutex m_RTTSServerMutex;
  PStringArray m_RTTSServers;
  PStringToString m_RTTSValidatedServers;
  WORD m_RTTSSocketBase;
  PMutex m_RTTSSocketMutex;
  PMutex m_RTTSCommitMutex;

  PTimeInterval m_LastBlockingReset;
  PLIST( BlockedHost, PString );
  BlockedHost m_BlockedHost;
  PMutex m_BlockedHostMutex;

  PString m_RTTSReprocessArg;
 
  OpenSBCGroomer() : SIPUserAgent( "OpenSBCGroomer", TRANSACTION_THREAD_COUNT )
  {
    SIPURI::RegisterScheme( "rtts" );
    SIPURI::RegisterScheme( "wsdb" );
    SIPURI::RegisterScheme( "msdb" );
    SIPURI::RegisterScheme( "cnam" );
    SIPURI::RegisterScheme( "wspt" );

    m_RouteHostBlock = NULL;
    m_CatchAllRouteBlocks = NULL;
    m_RouteXMLBlocks = NULL;
    m_RTTSSocketBase = RTTS_PORT_BASE;
    m_RTTSPingHandler = NULL;
    m_LastBlockingReset = PTimer::Tick();
    m_AllowRequire100Rel = FALSE; ///  the groomer would only proxy 100 rel
  }

  ~OpenSBCGroomer()
  {
    delete m_RouteHostBlock;
    delete m_CatchAllRouteBlocks;
    delete m_RouteXMLBlocks;
    delete m_RTTSPingHandler;
  }

#ifdef WIN32
  static BOOL WINAPI Win32SignalHandler(DWORD dwCtrlType) 
  {
    switch( dwCtrlType )
    {
      case CTRL_C_EVENT:
      case CTRL_BREAK_EVENT:
      case CTRL_CLOSE_EVENT:
      case CTRL_LOGOFF_EVENT:
      case CTRL_SHUTDOWN_EVENT:
        dynamic_cast<OpenSBCGroomer&>(PProcess::Current()).TerminateProc();
        return TRUE;
      default:
        return FALSE;
    }
  }
#endif
 
  BOOL InitOSRequirements()
  {
#if WIN32
    SetConsoleCtrlHandler(&OpenSBCGroomer::Win32SignalHandler, TRUE);
#endif
   return TRUE;
  }
  
  class RTTS_PING_Handler : public PThread, Logger
  {
    PCLASSINFO( RTTS_PING_Handler, PThread );
  public:
    PSyncPoint m_ExitSync;
    OpenSBCGroomer * m_Groomer;
    RTTS_PING_Handler( OpenSBCGroomer * groomer ) : PThread( 1024000, PThread::NoAutoDeleteThread, PThread::NormalPriority, "RTTS_PING_Handler" )
    {
      m_Groomer = groomer;
    }

    void StopPinging()
    {
      m_ExitSync.Signal();
    }

    void StartPinging()
    {
      Resume();
    }

    void SendPing()
    {
      for( int i = 0; i < m_Groomer->m_RTTSServers.GetSize(); i++ )
      {
        m_Groomer->m_RTTSServerMutex.Wait();
        PString currentRTTS = m_Groomer->m_RTTSServers[i];
        PIPSocket::Address rtts( currentRTTS );
        m_Groomer->m_RTTSServerMutex.Signal();

        if( rtts.IsValid() )
        {
          OString response;
          if( m_Groomer->RTTS_PING( rtts, RTTS_SERVER_PORT, response ) )
          {
            OString serial;
            if( m_Groomer->RTTS_ParseHeader( "SERIAL", serial, response ) )
            {
              m_Groomer->m_RTTSServerMutex.Wait();
              PString * oldSerial = m_Groomer->m_RTTSValidatedServers.GetAt( currentRTTS );
              
              if( oldSerial != NULL )
              {
                if( *oldSerial != serial.c_str() )
                  m_Groomer->RTTS_SerialChanged( currentRTTS );
              }

              LOG( LogInfo(), "RTTS Server Validated " << "ADDR: " << currentRTTS << " SERIAL: " << serial );

              m_Groomer->m_RTTSValidatedServers.SetAt( currentRTTS, serial.c_str() );
              m_Groomer->m_RTTSServerMutex.Signal();
            }
          }else
          {
            LOG( LogWarning(), "RTTS Server TIMEOUT!!! " << "ADDR: " << currentRTTS  );
          }
        }
      }
    }

    void Main()
    {
      BOOL firstRun = TRUE;
      int currentWait = 0;
      while( !m_ExitSync.Wait( firstRun ? 0 : 10 ) )
      {
        firstRun = FALSE;
        
        if( currentWait == 0 )
        {
          SendPing();
        }else
        {
          m_Groomer->CommitRTTSEntries();
        }

        currentWait += 10;
        if( currentWait >= RTTS_EXPIRES )
          currentWait = 0;
      }
    }
  } * m_RTTSPingHandler;

  BOOL LoadRoutes( const PFilePath & path )
  {
    PWaitAndSignal lock( m_RouteHostBlockMutex );
    delete m_RouteHostBlock;
    m_RouteHostBlock = new RouteHosts();
    delete m_CatchAllRouteBlocks;
    m_CatchAllRouteBlocks = new RouteBlock();

    PXML routeXML;
    if( !routeXML.LoadFile( path ) )
      return FALSE;

    PString matchlen = routeXML.GetRootElement()->GetAttribute( "prefix-match-length" );
    if( !matchlen.IsEmpty() )
      PREFIX_MATCH_LEN = matchlen.AsInteger();

    PXMLElement * solegyBlock = routeXML.GetElement( "solegy" );
    if( solegyBlock != NULL )
    {
      PXMLElement * rttsBlock = solegyBlock->GetElement( "rtts" );
      if( rttsBlock != NULL )
      {
        for( PINDEX i = 0;; i++ )
        {
          PXMLElement * rtts = rttsBlock->GetElement( "server", i );
          if( rtts == NULL )
            break;

          PString rttsAddress = rtts->GetData();
          if( !rttsAddress.IsEmpty() )
            m_RTTSServers.AppendString( rttsAddress );
        }

        if( m_RTTSServers.GetSize() > 0 )
          m_RTTSPingHandler = new RTTS_PING_Handler( this );
      }
    }
    

    for( PINDEX i = 0;;i++ )
    {
      PXMLElement * hostBlock = routeXML.GetElement( "block", i );
      if( hostBlock == NULL )
        break;

      PString currentHostBlock =  hostBlock->GetAttribute( "host" );
      PString currentHostFilter = hostBlock->GetAttribute( "filter" );
      PString currentHostCatchAll = hostBlock->GetAttribute( "catch-all" );
      PString currentRouteFile = hostBlock->GetAttribute( "route-file" );
      
      if( !currentHostFilter.IsEmpty() )
        currentHostBlock = currentHostBlock + "/" + currentHostFilter;
      else
        currentHostBlock = currentHostBlock + "/" + "*";

      PStringToString * currentRouteBlockParams = new PStringToString();
      for( PINDEX i = 0; i < hostBlock->GetNumAttributes(); i++ )
      {
        PString key = hostBlock->GetKeyAttribute(i);
        PString attr = hostBlock->GetDataAttribute(i);
        currentRouteBlockParams->SetAt( key, attr );
      }
     
      if( currentRouteBlockParams->GetSize() > 0 )
      {
        m_RouteBlockParams.SetAt( currentHostBlock, currentRouteBlockParams );
      }else
      {
        delete currentRouteBlockParams; 
        currentRouteBlockParams = NULL;
      }

      if( !currentHostCatchAll.IsEmpty() )
      {
        m_CatchAllRouteBlocks->SetAt( currentHostBlock, new PString( currentHostCatchAll ) );
      }

      if( !currentRouteFile.IsEmpty() )
      {
        RouteGroup * routeGroup = m_RouteHostBlock->GetAt( currentHostBlock );
        if( routeGroup == NULL )
        {
          routeGroup = new RouteGroup();
          m_RouteHostBlock->SetAt( currentHostBlock, routeGroup );
        }

        if( m_RouteXMLBlocks == NULL )
          m_RouteXMLBlocks = new RouteBlock();

        m_RouteXMLBlocks->SetAt( currentHostBlock, new PString( currentRouteFile ) );

      }else if( hostBlock->GetElement( "route", 0 ) == NULL )
      {
        RouteGroup * routeGroup = m_RouteHostBlock->GetAt( currentHostBlock );
        if( routeGroup == NULL )
        {
          routeGroup = new RouteGroup();
          m_RouteHostBlock->SetAt( currentHostBlock, routeGroup );
        }
      }else
      {
        BOOL hasRoute = FALSE;
        for( PINDEX ii = 0;;ii++ )
        {
          PXMLElement * route = hostBlock->GetElement( "route", ii );
          if( route == NULL )
            break;

          PString routeFilter = route->GetAttribute( "filter" );
          if( routeFilter.GetLength() < PREFIX_MATCH_LEN )
          {
            PError << "Filter is too short (filter=\"" << routeFilter << "\") expecting match length of " << PREFIX_MATCH_LEN << endl;
            continue;
          }

          PString routeData = route->GetData();
          PString groupBlock = routeFilter.Left( PREFIX_MATCH_LEN );

          PersistRoute( currentHostBlock, groupBlock, routeFilter, routeData );

          hasRoute = TRUE;
        }

        if( !hasRoute )
        {
          RouteGroup * routeGroup = m_RouteHostBlock->GetAt( currentHostBlock );
          if( routeGroup == NULL )
          {
            routeGroup = new RouteGroup();
            m_RouteHostBlock->SetAt( currentHostBlock, routeGroup );
          }
        }
      }
    }
    return m_RouteHostBlock->GetSize() > 0;
  }

  void PersistRoute( const PString & hostBlock, const PString & groupBlock, const PString & routeFilter, const PString & routeData )
  {
    RouteGroup * routeGroup = m_RouteHostBlock->GetAt( hostBlock );
    if( routeGroup == NULL )
    {
      routeGroup = new RouteGroup();
      m_RouteHostBlock->SetAt( hostBlock, routeGroup );
    }

    RouteBlock * routeBlock = routeGroup->GetAt( groupBlock );
    if( routeBlock == NULL )
    {
      routeBlock = new RouteBlock();
      routeGroup->SetAt( groupBlock, routeBlock );
    }

    if( !routeBlock->Contains( routeFilter ) )
    {
      OString rdata = (const char *)routeData;

      if( rdata.Find("*") != P_MAX_INDEX )
        rdata.Replace( "*", routeFilter );

      SIPURI target = rdata;
      if( target.GetUser().IsEmpty() )
         target.SetUser( routeFilter );
      
      routeBlock->SetAt( routeFilter, new PString( target.AsString().c_str() ) );
    }
  }

  BOOL FindRoute( const PString & dialString, const PIPSocket::Address & host, PString & result, PStringToString & routeParams )
  {
    PWaitAndSignal lock( m_RouteHostBlockMutex );

    if( dialString.GetLength() < PREFIX_MATCH_LEN )
    {
      result = "Dial String Too Short";
      return FALSE;
    }

    if( m_RouteHostBlock == NULL )
    {
      result = "Route Table Not Loaded";
      return FALSE;
    }

    PString hostString = host.AsString() + "/*";
    PString currentHostString = hostString;
    RouteGroup * routeGroup = m_RouteHostBlock->GetAt( hostString );

    if( routeGroup == NULL )
    {
      ///try if there is a group with a filter
      for( int i = 0; i < m_RouteHostBlock->GetSize(); i++ )
      {
        PString hostKey = m_RouteHostBlock->GetKeyAt(i);
        if( hostKey.GetLength() >= hostString.GetLength() || hostKey.Left( hostString.GetLength() ) == hostString )
        {
          /// check if the filter matches the dialstring
          /// Case: <block host="10.0.0.1" filter="1212"></block>
          PStringArray hostKeytokens = hostKey.Tokenise( "/" );
          if( hostKeytokens.GetSize() == 2 )
          {
            PString filter = hostKeytokens[1];
            if( dialString.Left( filter.GetLength() ) == filter )
            {
              currentHostString = hostKey;
              routeGroup = m_RouteHostBlock->GetAt( hostKey );
            }
          }
        }
      }

      if( routeGroup == NULL ) // still null
      {
        hostString = "*";
        for( int i = 0; i < m_RouteHostBlock->GetSize(); i++ )
        {
          PString hostKey = m_RouteHostBlock->GetKeyAt(i);
          
          if( hostKey.GetLength() >= hostString.GetLength() || hostKey.Left( hostString.GetLength() ) == hostString )
          {
            /// check if the filter matches the dialstring
            /// Case: <block host="*" filter="1212"></block>
            ///PString filter = hostKey.Mid( hostString.GetLength() + 1 );
            ///if( dialString.Left( filter.GetLength() ) == filter )
            ///{
            ///  currentHostString = hostKey;
            ///  routeGroup = m_RouteHostBlock->GetAt( hostKey );
            ///}


            PStringArray hostKeytokens = hostKey.Tokenise( "/" );
            if( hostKeytokens.GetSize() == 2 )
            {
              PString filter = hostKeytokens[1];
              if( dialString.Left( filter.GetLength() ) == filter )
              {
                currentHostString = hostKey;
                routeGroup = m_RouteHostBlock->GetAt( hostKey );
              }
            }
          }
        }
      }

      if( routeGroup == NULL )
      {
        ///Case: <block host="*"></block>
        currentHostString = "*/*";
        routeGroup = m_RouteHostBlock->GetAt( "*/*" );
      }
    }

    int stripLeft = 0;
    RouteBlock * routeBlock = NULL;
    PString groupBlock = dialString.Left( PREFIX_MATCH_LEN );
    if( routeGroup == NULL )
    {
      result = "No Valid Route Blocks Defined";
      return FALSE;
    }else
    {
      PStringToString * blockParams = m_RouteBlockParams.GetAt( currentHostString );
      if( blockParams != NULL )
        routeParams = *blockParams;
 
      PString * stripLeftStr = routeParams.GetAt( "strip-left-digits" );
      if( stripLeftStr != NULL )
        stripLeft = stripLeftStr->AsInteger();
        

      routeBlock = routeGroup->GetAt( groupBlock );
      if( routeBlock == NULL && m_RouteXMLBlocks != NULL)
      {
        ///check if route-block got delayed because of xml-route-file
        PString * routeXML = m_RouteXMLBlocks->GetAt( currentHostString );
        if( routeXML != NULL )
        {
          if( !routeXML->IsEmpty() )
          {
            PXML xmlRouteBlocks;
            if( xmlRouteBlocks.LoadFile( *routeXML ) )
            {
              PXMLElement * hostBlock = xmlRouteBlocks.GetRootElement();
              for( PINDEX ii = 0;;ii++ )
              {
                PXMLElement * route = hostBlock->GetElement( "route", ii );
                if( route == NULL )
                  break;

                PString routeFilter = route->GetAttribute( "filter" );
                if( routeFilter.GetLength() < PREFIX_MATCH_LEN )
                {
                  PError << "Filter is too short (filter=\"" << routeFilter << "\") expecting match length of " << PREFIX_MATCH_LEN << endl;
                  continue;
                }

                PString routeData = route->GetData();
                PString groupBlock = routeFilter.Left( PREFIX_MATCH_LEN );

                PersistRoute( currentHostString, groupBlock, routeFilter, routeData );
              }
            }
          }

          routeBlock = routeGroup->GetAt( groupBlock );
        }

      }
    }

    
    if( routeBlock == NULL )
    {
      PString * catchAll = m_CatchAllRouteBlocks->GetAt( currentHostString );
      if( catchAll != NULL )
      {
        result = catchAll->Trim();
        OString rdata = (const char *)result;

        OString ds = dialString ;
        if( stripLeft > 0 && dialString.GetLength() > stripLeft )
          ds = dialString.Mid( stripLeft );

        if( rdata.Find("*") != P_MAX_INDEX )
          rdata.Replace( "*", ds );

        SIPURI target = rdata;
        if( target.GetUser().IsEmpty() )
          target.SetUser( ds );

        result = target.AsString();
        return TRUE;
      }else
      {
        result = "No Group Block Defined For Prefix " + groupBlock;
        return FALSE;
      }
    }

    PString  * routeData = routeBlock->GetAt( dialString );
    if( routeData == NULL )
    {
      PString * catchAll = m_CatchAllRouteBlocks->GetAt( currentHostString );
      if( catchAll != NULL )
      {
        result = catchAll->Trim();
        OString rdata = (const char *)result;

        OString ds = dialString ;
        if( stripLeft > 0 && dialString.GetLength() > stripLeft )
          ds = dialString.Mid( stripLeft );

        if( rdata.Find("*") != P_MAX_INDEX )
          rdata.Replace( "*", ds );

        SIPURI target = rdata;
        if( target.GetUser().IsEmpty() )
          target.SetUser( ds );

        result = target.AsString();
        return TRUE;
      }else
      {
        result = "None Routable Number " + dialString;
        return FALSE;
      }
    }else
    {
      OString ds = dialString ;
      if( stripLeft > 0 && dialString.GetLength() > stripLeft )
      {
        ds = dialString.Mid( stripLeft );
        SIPURI target((const char *)routeData->Trim());
        target.SetUser( ds );
        result = target.AsString().c_str();
      }else
      {
        result = routeData->Trim();
      }
    }
    return TRUE;
  }

  void Main( BOOL wait = TRUE, BOOL noSIP = FALSE )
  {
    if( !InitOSRequirements() )
    {
      PError << "Unable to initialize OS Requirements" << endl;
      TerminateProc();
      return;
    }

    if( !PDirectory::Exists( "proxy-state" ) )
    {
      if( !PDirectory::Create( "proxy-state" ) )
      {
        PError << "Unable to create proxy-state directory";
        return;
      }
    }

    if( !PDirectory::Exists( "proxy-force-disconnect" ) )
    {
      if( !PDirectory::Create( "proxy-force-disconnect" ) )
      {
        PError << "Unable to create proxy-force-disconnect directory";
        return;
      }
    }

    if( !PDirectory::Exists( "rtts-commit" ) )
    {
      if( !PDirectory::Create( "rtts-commit" ) )
      {
        PError << "Unable to create rtts-commit directory";
        return;
      }
    }

    PFilePath archived = "rtts-commit/archived";
    PFilePath backoff =  "rtts-commit/backoff";
    if( !PDirectory::Exists( archived ) )
      PDirectory::Create( archived );

    if( !PDirectory::Exists( backoff ) )
      PDirectory::Create( backoff );
    

    m_ListenerIP = m_ListenerAddress.GetAddress();
    m_ListenerPort = (WORD)m_ListenerAddress.GetPort().AsUnsigned();
    if( m_ListenerPort == 0 )
      m_ListenerPort = 5060;

    if( !noSIP )
    {
      GetDefaultProfile().GetTransportProfile().EnableUDP( m_ListenerIP, m_ListenerPort );
      Initialize( );
      if( !StartTransportThreads() )
      {
        PError << "Unable to initialize listener at " << m_ListenerAddress << endl;
        TerminateProc();
        return;
      }
    }

    if( m_RTTSPingHandler != NULL )
      m_RTTSPingHandler->StartPinging();

    if( wait )
      while( !m_TermSync.Wait( 1000 ) );
  }

  void TerminateProc()
  {
    if( m_RTTSPingHandler != NULL )
    {
      m_RTTSPingHandler->StopPinging();
      m_RTTSPingHandler->WaitForTermination();
    }
    dynamic_cast<SIPUserAgent *>(this)->Terminate();
    m_TermSync.Signal(); 
  }


/// SIP Stuffs begin here
  void ProcessEvent( SIPStackEvent * event )
  {
    if( event->GetType() == SIPStackEvent::UnknownTransaction )
    {
      SIPUnknownTransaction* evt = dynamic_cast<SIPUnknownTransaction*>(event);
      if( evt != NULL )
      {
        if( evt->GetMessage().IsAck() )
        {
          SIPMessage ack = evt->GetMessage();

          if( ack.HasRoute() && ack.GetRouteSize() > 0 )
          {
            SIPURI routeURI = ack.GetTopRouteURI();
            if( routeURI.GetAddress() == m_ListenerIP )
            {
              unsigned long routePort = routeURI.GetPort().AsUnsigned();
              if( routePort == 0 )
                routePort = 5060;
              if( routePort == m_ListenerPort )
              {
                ack.PopTopRouteURI();
              }
            }
          }
          TransportWrite( ack );
        }
      }
    }else if( event->GetType() == SIPStackEvent::Message )
    {
      SIPMessageArrival* evt = dynamic_cast<SIPMessageArrival*>(event);
      if( evt != NULL )
      {
        SIPMessage message = evt->GetMessage();
        if( message.IsResponse() )
        {
          if( message.GetViaSize() > 1 )
          {
            message.PopTopVia();
            TransportWrite( message );
          }
        }
      }
    }
    
    delete event;
  }

  void SendERROR( const SIPMessage & request, SIPTransaction *& transaction, SIPMessage::StatusCodes code, const OString & reason = PString::Empty() )
  {
    SIPMessage * response = new SIPMessage();
    request.CreateResponse( *response, code, reason );
    SIPParser::Server h( UA_NAME );
    response->SetServer( h );
    transaction->EnqueueEvent(new SIPEvent( response ));
  }

  class INVITE_Handler : public SIPTransactionBypass, public Logger
  {
    PCLASSINFO( INVITE_Handler, SIPTransactionBypass );
  public:
    BOOL m_IsLooseRouter;
    SIPMessage m_StateMsg;
    BOOL m_IsRTTSTransaction;

    INVITE_Handler( OpenSBCGroomer & ua ) : m_Groomer( ua )
    {
      m_AutoDeleteBypass = FALSE;
      m_IsLooseRouter = FALSE;
      m_IsRTTSTransaction = FALSE;
    }

    ~INVITE_Handler()
    {
      if( m_ISTInvite.IsValid() )
      {
        PWaitAndSignal lock( m_Groomer.m_ICTCollectionMutex );
        m_Groomer.m_ICTCollection.RemoveAt( m_ISTInvite.GetCallId().c_str() );
      }
    }

    void OnTimerExpire( SIPTimerEvent & /*timer*/, SIPTransaction * transaction )
    {
      if( transaction->GetType() == SIPTransaction::ICT )
      {
        SIPMessage outbound;
        m_ISTInvite.CreateResponse( outbound, SIPMessage::Code408_RequestTimeout );
        transaction->GetManager().FindTransactionAndAddEvent( outbound, FALSE, 0 );   
      }
    }

    void OnReceivedMessage( const SIPMessage & message, SIPTransaction * transaction )
    {
      if( transaction->GetType() == SIPTransaction::IST )
      {
        if( message.IsInvite() && message.GetToTag().IsEmpty() )
        {
          m_ISTInvite = message;
        
          PString route;
          PStringToString routeParams;

         

          if( !m_Groomer.RouteINVITE( message, transaction, route, routeParams ) )
          {
            m_Groomer.SendERROR( message, transaction, SIPMessage::Code404_NotFound, route);
          }else
          {
            SIPURI targetURI( (const char *)route );
            ProxyINVITE( message, targetURI, transaction, routeParams );
          }
        }else
        {
          /// simply proxy in-dialog invites
        }
      }else if( transaction->GetType() == SIPTransaction::ICT )
      {
        if( message.IsResponse() )
        {
          /// preserve the ialog state so that BYE requests can perform dialog state reconstruction
          if( m_IsLooseRouter && message.Is2xx() )
          {
            DumpDialogState( message );
            DumpForceDisconnectState( message );
          }else if( message.GetStatusCode() >= 400 )
          {
            DumpErrorDialogState( message );
          }else if( message.GetStatusCode() >= 180  )
          {
            PTime now;
            PString at( now.GetTimeInSeconds() );
            From from = m_StateMsg.GetFrom();
            from.AddParameter( "AT", at );
            m_StateMsg.SetFrom( from );
          }

          SIPMessage outbound = message;

          /// reencode from header from IST just incase ProxyINVITE rewrote it
          outbound.SetFrom( m_ISTInvite.GetFrom() );

          outbound.PopTopVia();
          SIPParser::TransactionId tid; 
          transaction->GetManager().FindTransactionAndAddEvent( outbound, FALSE, 0 );   
        }
      }
    }

    void DumpDialogState( const SIPMessage & response )
    {
      PTextFile ds;
      OStringStream fn;
      fn << "proxy-state/" << GetSafeFileName( response );
      if( !ds.Open( fn.str().c_str() ) )
        return;

      PTime now;
      PString ct( now.GetTimeInSeconds() );
      From from = m_StateMsg.GetFrom();
      from.AddParameter( "CT", ct );
      m_StateMsg.SetFrom( from );
      m_StateMsg.SetTo( response.GetTo() );

      Contact contact;
      SIPURI uacContact, uasContact;
      uacContact = m_ISTInvite.GetContactTopURI();
      uasContact = response.GetContactTopURI();
      contact.AddURI( uacContact );
      contact.AddURI( uasContact );
      m_StateMsg.AppendContact( contact );
      

      if( response.GetRecordRouteSize() )
      {
        RecordRouteList rrList;
        if( response.GetRecordRouteList( rrList ) )
          m_StateMsg.SetRecordRouteList( rrList );
      }
      
      ds << m_StateMsg;
    }

    void DumpForceDisconnectState( const SIPMessage & response )
    {
      PTextFile ds;
      OStringStream fn;
      fn << "proxy-force-disconnect/" << GetSafeFileName( response );
      if( !ds.Open( fn.str().c_str() ) )
        return;

      SIPMessage bye;
      RequestLine rline;
      rline.SetMethod( "BYE" );
      rline.SetRequestURI( response.GetContactTopURI() );
      rline.SetVersion( "SIP/2.0" );
      
      bye.SetStartLine( rline );
      bye.SetFrom( response.GetFrom() );
      bye.SetTo( response.GetTo() );
      
      CallId callId;
      response.GetCallId( callId );
      bye.SetCallId( callId );
      
      CSeq cseq;
      response.GetCSeq( cseq );
      cseq.SetSequence( cseq.GetSequence() + 1000 );
      cseq.SetMethod( "BYE" );
      bye.SetCSeq( cseq );

      Via via;
      via.SetAddress( m_Groomer.m_ListenerIP.AsSTLString() );
      via.SetPort( m_Groomer.m_ListenerPort );
      via.SetBranch( ParserTools::GenBranchParameter() );
      via.AddParameter( "rport", "" );
      bye.AppendVia( via );


      int recordRouteCount = response.GetRecordRouteSize();
      for( PINDEX i = 0; i < recordRouteCount; i++ )
      {
        //m_Groomer.m_ListenerIP, m_Groomer.m_ListenerPort
        RecordRoute recordRoute = response.GetRecordRouteAt( i );
        for( int j = 0; j < recordRoute.GetSize(); j++ )
        {
          RouteURI routeURI;
          if( recordRoute.GetURI( routeURI, j ) )
          {
            OString host = routeURI.GetURI().GetHost();
            OString port = routeURI.GetURI().GetPort();
            if( port.IsEmpty() || port == "0" )
              port = "5060";

            if( m_Groomer.m_ListenerIP.AsSTLString() == host &&  m_Groomer.m_ListenerPort == port.AsUnsigned() )
              goto commit_file;

            Route route;
            route.AddURI( routeURI );
            bye.AppendRoute( route, TRUE ); /// add it to the bottom of the list
          }
        }
      }
      
commit_file:
      ds << bye;
    }

    void DumpErrorDialogState( const SIPMessage & response )
    {
      /*
      PTime now;
      OStringStream strm;
      strm << now.AsString("yyyy/MM/dd hh:mm:ss.uuu");
      strm << " [" << m_StateMsg.GetCallId().c_str() << "]";
      strm << " CS:" << response.GetStatusCode();

      strm << " OC:" << m_StateMsg.GetFromURI().GetUser();
      strm << "<" << m_StateMsg.GetFromURI().GetHost() << ">";
      strm << " TC:" << m_StateMsg.GetRequestURI().GetUser();

      strm << "(" << m_StateMsg.GetRequestURI().GetUser() << ")";
      strm << "<" << m_StateMsg.GetRequestURI().GetHost() << ">";  

      strm << " RT:0";
      strm << " CT:0";

      //strm << " RS:" << "null";
      strm << " MS:" << m_StateMsg.GetRequestURI().GetUser();
      strm << " PN:" << m_StateMsg.GetFromURI().GetUser();

      OStringStream m;
      PString sf = GetSafeFileName( response );
      m << "CAT/CAT" << now.GetYear() << now.GetMonth() << now.GetDay() << sf;

      PFilePath fp( m.str().c_str() ); 
      PTextFile catLog( fp, PFile::ReadWrite );
      catLog.WriteLine( strm.str().c_str() );
      */
    }

 

    BOOL AssertCallBlockingRules( SIPMessage & outbound, const SIPURI & targetRoute, SIPTransaction * transaction, PStringToString & routeParams )
    {
      /// check if we are asserting an ingress proxy
      PString * ingress = routeParams.GetAt( "ingress" );
      if( ingress != NULL )
      {
        PIPSocket::Address ingressIP( *ingress );
        if( outbound.GetTopVia().GetReceiveAddress() != ingressIP )
        {
          OStringStream error;
          error << "Use " << ingressIP << " As Ingress";
          m_Groomer.SendERROR( outbound, transaction, SIPMessage::Code403_Forbidden, error.str() );
          return FALSE;
        }
      }

      /// check loop
      if( outbound.DecrementMaxForwards() < 1 )
      {
        m_Groomer.SendERROR( outbound, transaction, SIPMessage::Code483_TooManyHops );
        return FALSE;
      }
      
      if( m_Groomer.IsHostBlocked( outbound ) )
      {
        m_Groomer.SendERROR( outbound, transaction, SIPMessage::Code403_Forbidden, "Host Temporarily Blocked" );
        return FALSE;
      }

      return TRUE;
    }

    BOOL ProxyINVITE( const SIPMessage & request, const SIPURI & targetRoute, SIPTransaction * transaction, PStringToString & routeParams )
    {
      SIPMessage outbound = request;
      OString cid = request.GetCallId();
  
      if( !AssertCallBlockingRules( outbound, targetRoute, transaction, routeParams ) )
        return FALSE;

      BOOL enforcePAI = routeParams.Contains( "enforce-pai" );
      if( enforcePAI )
      {
        PString * val = routeParams.GetAt( "enforce-pai" );
        enforcePAI = val != NULL && *val == "1";
      }

      m_IsLooseRouter = routeParams.Contains( "lr" );
      BOOL insertRouteSet = routeParams.Contains( "route-set" );

      if( enforcePAI )
      {
        From  from = outbound.GetFrom();
        ContactURI paiURI(from.GetURI(), from.GetDisplayName());
        PAssertedIdentity pai;
        pai.AddURI( paiURI );
        Privacy privacy( "id" );
        SIPURI privURI( "sip:anonymous@anonymous.invalid" );
        from.SetURI( privURI );

        outbound.SetFrom( from );
        outbound.AppendPAssertedIdentity( pai );
        outbound.SetPrivacy( privacy );
      }

      
      /// check route header if its resolves to us 
      if( outbound.HasRoute() && outbound.GetRouteSize() > 0 )
      {

        Route r = outbound.GetRouteAt(0);
        RouteURI ruri;
        r.GetURI( ruri, 0 ); 
        if( !ruri.IsLooseRouter() )
        {
          unsigned long routePort = ruri.GetURI().GetPort().AsUnsigned();
          if( routePort == 0 )
            routePort = 5060;

          if( outbound.GetRequestURI().GetAddress() == m_Groomer.m_ListenerIP && 
            ( ruri.GetURI().GetAddress() != m_Groomer.m_ListenerIP || routePort != m_Groomer.m_ListenerPort ) )
          {
            outbound.SetRequestURI( ruri.GetURI() );
            outbound.PopTopRouteURI();
          }
        }else
        {
          SIPURI routeURI = outbound.GetTopRouteURI();
          if( routeURI.GetAddress() == m_Groomer.m_ListenerIP )
          {
            unsigned long routePort = routeURI.GetPort().AsUnsigned();
            if( routePort == 0 )
              routePort = 5060;
            if( routePort == m_Groomer.m_ListenerPort )
            {
              outbound.PopTopRouteURI();
            }
          }
        }

        /// We will not allow incoming INVITEs with proprietary route-sets
        if( outbound.HasRoute() && outbound.GetRouteSize() > 0 )
        {
          m_Groomer.SendERROR( request, transaction, SIPMessage::Code403_Forbidden, "Not Allowing Relay Via Route-Set" );
          return FALSE;
        }
      }

      if( insertRouteSet )
      {
        PString * routeSet = routeParams.GetAt( "route-set" );
        if( routeSet != NULL )
        {
          PStringArray routeSetList = routeSet->Tokenise( ',' );
          Route route;
          for( int i = 0; i < routeSetList.GetSize(); i++ )
          {
            RouteURI ruri( (const char *)routeSetList[i] );
            ruri.SetLooseRouter();
            route.AddURI( ruri, TRUE );
          }
          outbound.RemoveAllRoutes();
          if( route.GetSize() > 0 )
            outbound.AppendRoute( route );
        }
      }

      /// set our via
      Via via;
      via.SetAddress( m_Groomer.m_ListenerIP.AsSTLString() );
      via.SetPort( m_Groomer.m_ListenerPort );
      via.SetBranch( ParserTools::GenBranchParameter() );
      via.AddParameter( "rport", "" );
      outbound.AppendVia( via );

      if( m_IsLooseRouter )
      {
        RecordRoute rr;
        RouteURI  ru;
        ru.SetLooseRouter( TRUE );
        SIPURI ruURI( m_Groomer.m_ListenerIP, m_Groomer.m_ListenerPort );
        ru.SetURI( ruURI );
        rr.AddURI( ru );
        outbound.AppendRecordRoute( rr );
      }

      
      if( targetRoute.GetScheme() != "sip" )
      {
        return RTTSProxyINVITE( outbound, targetRoute, transaction, routeParams );
      }else
      {
        outbound.SetRequestURI( targetRoute );
        PWaitAndSignal lock( m_Groomer.m_ICTCollectionMutex );
        m_Groomer.m_ICTCollection.SetAt( outbound.GetCallId().c_str(), new SIPMessage( outbound ) );
        transaction->GetManager().FindTransactionAndAddEvent( outbound, FALSE, 0, this );
      }

      Via topVia = m_ISTInvite.GetTopVia();
      Via bottomVia = m_ISTInvite.GetBottomVia();
      topVia.AddParameter( "downstream-host", bottomVia.GetURI().GetHost() );
      m_StateMsg.AppendVia( topVia );

      PTime now;
      PString st( now.GetTimeInSeconds() );
      From from = m_ISTInvite.GetFrom();
      from.AddParameter( "ST", st );

      if( routeParams.Contains( "rtts-commit" ) )
      {
        PString * rttsCommit = routeParams.GetAt( "rtts-commit" );
        if( *rttsCommit != "0" )
        {
          if( rttsCommit != NULL )
          {
            OString uasTarget = outbound.GetRequestURI().GetHost();
            LOG_CONTEXT( LogInfo(), cid.c_str(), "!!! RTTS-UAS-TARGET=" << uasTarget << "!!!" );
            from.AddParameter( "rtts-commit", (const char *)(*rttsCommit) );
            from.AddParameter( "rtts-uas-target", uasTarget );
          }

          PString * rttsCommitPrefix = routeParams.GetAt( "rtts-commit-prefix" );
          PString * rttsCommitDNIS = routeParams.GetAt( "rtts-commit-dnis" );

          if( rttsCommitDNIS != NULL && rttsCommitPrefix != NULL )
            *rttsCommitDNIS = *rttsCommitPrefix + *rttsCommitDNIS;

          if( rttsCommitDNIS == NULL || *rttsCommitDNIS == "inbound" )
            m_StateMsg.SetStartLine( m_ISTInvite.GetRequestLine() );
          else
            m_StateMsg.SetStartLine( outbound.GetRequestLine() );

          PString * ingress = routeParams.GetAt( "ingress" );
          if( ingress != NULL )
            from.AddParameter( "ingress", (const char *)*ingress, TRUE );
        }
      }


      m_StateMsg.SetFrom( from );
      m_StateMsg.SetTo( m_ISTInvite.GetTo() );

      CallId callId( m_ISTInvite.GetCallId() );
      m_StateMsg.SetCallId( callId );

      return TRUE;
    }
    
    BOOL RTTSProxyINVITE( SIPMessage & request, const SIPURI & targetRoute, SIPTransaction * transaction, PStringToString & routeParams )
    {
      if( targetRoute.GetScheme() *= "wsdb" )
      {
        m_IsRTTSTransaction = TRUE;
        OString response;
        if( !m_Groomer.RTTS_START( request, response ) )
        {
          m_Groomer.SendERROR( m_ISTInvite, transaction, SIPMessage::Code480_TemporarilyNotAvailable, "No Available RTTS Resource (START)" );
          return FALSE;
        }

        /// AUTHENTICATE
        OString authResponse;
        if( !m_Groomer.RTTS_AUTH( request, authResponse ) )
        {
          m_Groomer.SendERROR( m_ISTInvite, transaction, SIPMessage::Code480_TemporarilyNotAvailable, "RTTS Protocol Exception (AUTH)" );
          return FALSE;
        }else{
          OString error;
          if( m_Groomer.RTTS_ParseHeader( "ERROR", error, authResponse ) )
          {
            m_Groomer.SendERROR( m_ISTInvite, transaction, SIPMessage::Code480_TemporarilyNotAvailable, "RTTS-"+error );
            return FALSE;
          }
        }
        LOG( LogInfo(), authResponse );

        /// SIGNIN
        OString signinResponse;
        if( !m_Groomer.RTTS_SIGNIN( request, signinResponse ) )
        {
          m_Groomer.SendERROR( m_ISTInvite, transaction, SIPMessage::Code480_TemporarilyNotAvailable, "RTTS Protocol Exception (SIGNIN)" );
          return FALSE;
        }else{
          OString error;
          if( m_Groomer.RTTS_ParseHeader( "ERROR", error, signinResponse ) )
          {
            m_Groomer.SendERROR( m_ISTInvite, transaction, SIPMessage::Code480_TemporarilyNotAvailable, "RTTS-"+error );
            return FALSE;
          }
        }
        LOG( LogInfo(), signinResponse );

        /// SETUP
        OString setupResponse;
        if( !m_Groomer.RTTS_SETUP( request, setupResponse ) )
        {
          m_Groomer.SendERROR( m_ISTInvite, transaction, SIPMessage::Code480_TemporarilyNotAvailable, "RTTS Protocol Exception (SETUP)" );
          return FALSE;
        }else{
          OString error;
          if( m_Groomer.RTTS_ParseHeader( "ERROR", error, setupResponse ) )
          {
            m_Groomer.SendERROR( m_ISTInvite, transaction, SIPMessage::Code480_TemporarilyNotAvailable, "RTTS-"+error );
            return FALSE;
          }
        }
        LOG( LogInfo(), setupResponse );


        PString * sbc = routeParams.GetAt( "sbc" );
        if( sbc != NULL )
        {
          SIPURI ruri((const char *)*sbc);
          ruri.SetUser( request.GetRequestURI().GetUser() );
          request.SetRequestURI( ruri );
          PWaitAndSignal lock( m_Groomer.m_ICTCollectionMutex );
          m_Groomer.m_ICTCollection.SetAt( request.GetCallId().c_str(), new SIPMessage( request ) );
          transaction->GetManager().FindTransactionAndAddEvent( request, FALSE, 0, this );
          return TRUE;
        }
        
      }else
      {
        m_Groomer.SendERROR( m_ISTInvite, transaction, SIPMessage::Code480_TemporarilyNotAvailable, targetRoute.GetScheme() + " - Unsupported RTTS Scheme" );
        /// NOT WSDB SCHEME
      }
      return TRUE;
    }


    SIPMessage m_ISTInvite;
    OpenSBCGroomer & m_Groomer;
  };

  class BYE_Handler : public SIPTransactionBypass
  {
    PCLASSINFO( BYE_Handler, SIPTransactionBypass );
  public:

    BYE_Handler( OpenSBCGroomer & ua ) : m_Groomer( ua )
    {
      m_AutoDeleteBypass = FALSE;
    }

    void OnTimerExpire( SIPTimerEvent & /*timer*/, SIPTransaction * transaction )
    {
      if( transaction->GetType() == SIPTransaction::ICT || transaction->GetType() == SIPTransaction::NICT)
      {
        SIPMessage outbound;
        m_MidDialogRequest.CreateResponse( outbound, SIPMessage::Code408_RequestTimeout );
        transaction->GetManager().FindTransactionAndAddEvent( outbound, FALSE, 0 );   
      }
    }

    void DumpDialogState( const SIPMessage & message )
    {
      PTextFile ds;
      OStringStream fn;
      PString sf = GetSafeFileName( message );
      fn << "proxy-state/" << sf;
      if( !ds.Open( fn.str().c_str() ) )
        return;

      ds.SetPosition( PFile::Start );
      int flen = ds.GetLength();
      if( flen == 0 )
        return;

      PBYTEArray buff( flen );
      if( !ds.Read( buff.GetPointer( flen ), flen ) )
        return;

      SIPMessage stateMsg( buff );
      ds.Close();
      

      PFile::Remove( fn.str().c_str(), TRUE );

      OString rttsCommit;
      if( stateMsg.GetFrom().GetParameter( "rtts-commit", rttsCommit ) && rttsCommit == "1" )
      {
        PWaitAndSignal lock( m_Groomer.m_RTTSCommitMutex );
        PFilePath oldPath = fn.str().c_str();
        PFilePath newPath = oldPath.GetDirectory().GetParent() + "rtts-commit" + "/" + oldPath.GetFileName();

        OString ct;
        stateMsg.GetFrom().GetParameter( "CT", ct );
        PTime now;
        int callTime = 0;
        if( !ct.IsEmpty() )
          callTime = now.GetTimeInSeconds() - ct.AsInteger();
        
        From from = stateMsg.GetFrom();
        from.AddParameter( "CD", OString( callTime ) );
        stateMsg.SetFrom( from );

        PTextFile callState;
        if( callState.Open( newPath ) )
          callState << stateMsg;
      }

      /// get rid of force disconnect state file
      OStringStream fs;
      fs << "proxy-force-disconnect/" << GetSafeFileName( message );
      PFile::Remove( fs.str().c_str(), TRUE );
    }

    void DumpCATLog( const SIPMessage & stateMsg, const PString & sf )
    {
      PTime now;
      OStringStream strm;
      strm << now.AsString("yyyy/MM/dd hh:mm:ss.uuu");
      strm << " [" << stateMsg.GetCallId().c_str() << "]";
      strm << " CS:200";

      strm << " OC:" << stateMsg.GetFromURI().GetUser();
      strm << "<" << stateMsg.GetFromURI().GetHost() << ">";
      strm << " TC:" << stateMsg.GetRequestURI().GetUser();

      strm << "(" << stateMsg.GetRequestURI().GetUser() << ")";
      strm << "<" << stateMsg.GetRequestURI().GetHost() << ">";

      OString st, at, ct;
      stateMsg.GetFrom().GetParameter( "ST", st );
      stateMsg.GetFrom().GetParameter( "AT", at );
      stateMsg.GetFrom().GetParameter( "CT", ct );

      int ringTime = 0;
      int callTime = 0;

      if( !at.IsEmpty() && !ct.IsEmpty() )
        ringTime = ct.AsInteger() - at.AsInteger();
      else if( !st.IsEmpty() && !ct.IsEmpty() )
        ringTime = ct.AsInteger() - st.AsInteger();

      if( !ct.IsEmpty() )
        callTime = now.GetTimeInSeconds() - ct.AsInteger();
      

      strm << " RT:" << ringTime;
      strm << " CT:" << callTime;

      //strm << " RS:" << "null";
      strm << " MS:" << stateMsg.GetRequestURI().GetUser();
      strm << " PN:" << stateMsg.GetFromURI().GetUser();

      OStringStream m;
      m << "rtts-commit/CAT" << now.GetYear() << now.GetMonth() << now.GetDay() << sf;

      PFilePath fp( m.str().c_str() ); 
      PTextFile catLog( fp, PFile::ReadWrite );
      catLog.WriteLine( strm.str().c_str() );
    }

    void OnReceivedMessage( const SIPMessage & message, SIPTransaction * transaction )
    {
      if(  transaction->GetType() == SIPTransaction::NIST )
      {
        if( message.IsRequest() )
        {
          DumpDialogState( message );
          m_MidDialogRequest = message;
          SIPMessage outbound = message;
          /// set our via
          Via via;
          via.SetAddress( m_Groomer.m_ListenerIP.AsSTLString() );
          via.SetPort( m_Groomer.m_ListenerPort );
          via.SetBranch( ParserTools::GenBranchParameter() );
          via.AddParameter( "rport", "" );
          outbound.AppendVia( via );

          if( outbound.HasRoute() && outbound.GetRouteSize() > 0 )
          {
            SIPURI routeURI = outbound.GetTopRouteURI();
            if( routeURI.GetAddress() == m_Groomer.m_ListenerIP )
            {
              unsigned long routePort = routeURI.GetPort().AsUnsigned();
              if( routePort == 0 )
                routePort = 5060;
              if( routePort == m_Groomer.m_ListenerPort )
              {
                outbound.PopTopRouteURI();
              }
            }
          }

          transaction->GetManager().FindTransactionAndAddEvent( outbound, FALSE, 0, this );
        }
      }else if( transaction->GetType() == SIPTransaction::NICT )
      {
        if( message.IsResponse() )
        {
          SIPMessage outbound = message;
          outbound.PopTopVia();
          transaction->GetManager().FindTransactionAndAddEvent( outbound, FALSE, 0 );  
        }
      }
    }
   
    SIPMessage m_MidDialogRequest;
    OpenSBCGroomer & m_Groomer;
  };

  class MIDDIALOG_Handler : public SIPTransactionBypass
  {
    PCLASSINFO( MIDDIALOG_Handler, SIPTransactionBypass );
  public:

    MIDDIALOG_Handler( OpenSBCGroomer & ua ) : m_Groomer( ua )
    {
      m_AutoDeleteBypass = FALSE;
    }

    void OnTimerExpire( SIPTimerEvent & /*timer*/, SIPTransaction * transaction )
    {
      if( transaction->GetType() == SIPTransaction::ICT || transaction->GetType() == SIPTransaction::NICT)
      {
        SIPMessage outbound;
        m_MidDialogRequest.CreateResponse( outbound, SIPMessage::Code408_RequestTimeout );

        if( transaction->GetType() == SIPTransaction::ICT )
        {
          DumpDialogState( outbound );
          ForceDialogTermination( outbound, transaction );
        }
        transaction->GetManager().FindTransactionAndAddEvent( outbound, FALSE, 0 );  
      }
    }

    void OnReceivedMessage( const SIPMessage & message, SIPTransaction * transaction )
    {
      if( transaction->GetType() == SIPTransaction::IST || transaction->GetType() == SIPTransaction::NIST )
      {
        if( message.IsRequest() )
        {
          m_MidDialogRequest = message;
          SIPMessage outbound = message;
          /// set our via
          Via via;
          via.SetAddress( m_Groomer.m_ListenerIP.AsSTLString() );
          via.SetPort( m_Groomer.m_ListenerPort );
          via.SetBranch( ParserTools::GenBranchParameter() );
          via.AddParameter( "rport", "" );
          outbound.AppendVia( via );

          if( outbound.HasRoute() && outbound.GetRouteSize() > 0 )
          {
            SIPURI routeURI = outbound.GetTopRouteURI();
            if( routeURI.GetAddress() == m_Groomer.m_ListenerIP )
            {
              unsigned long routePort = routeURI.GetPort().AsUnsigned();
              if( routePort == 0 )
                routePort = 5060;
              if( routePort == m_Groomer.m_ListenerPort )
              {
                outbound.PopTopRouteURI();
              }
            }
          }

          transaction->GetManager().FindTransactionAndAddEvent( outbound, FALSE, 0, this );
        }
      }else if( transaction->GetType() == SIPTransaction::ICT || transaction->GetType() == SIPTransaction::NICT )
      {
        if( message.IsResponse() )
        {
          SIPMessage outbound = message;
          outbound.PopTopVia();
          transaction->GetManager().FindTransactionAndAddEvent( outbound, FALSE, 0 );  
          if( transaction->GetType() == SIPTransaction::ICT && message.GetStatusCode() >= 300 )
          {
            DumpDialogState( message );
            ForceDialogTermination( message, transaction );
          }
        }
      }
    }

    void DumpDialogState( const SIPMessage & message )
    {
      PTextFile ds;
      OStringStream fn;
      PString sf = GetSafeFileName( message );
      fn << "proxy-state/" << sf;
      if( !ds.Open( fn.str().c_str() ) )
        return;

      ds.SetPosition( PFile::Start );
      int flen = ds.GetLength();
      if( flen == 0 )
        return;

      PBYTEArray buff( flen );
      if( !ds.Read( buff.GetPointer( flen ), flen ) )
        return;

      SIPMessage stateMsg( buff );
      ds.Close();
      

      PFile::Remove( fn.str().c_str(), TRUE );

      OString rttsCommit;
      if( stateMsg.GetFrom().GetParameter( "rtts-commit", rttsCommit ) && rttsCommit == "1" )
      {
        PWaitAndSignal lock( m_Groomer.m_RTTSCommitMutex );
        PFilePath oldPath = fn.str().c_str();
        PFilePath newPath = oldPath.GetDirectory().GetParent() + "rtts-commit" + "/" + oldPath.GetFileName();

        OString ct;
        stateMsg.GetFrom().GetParameter( "CT", ct );
        PTime now;
        int callTime = 0;
        if( !ct.IsEmpty() )
          callTime = now.GetTimeInSeconds() - ct.AsInteger();
        
        From from = stateMsg.GetFrom();
        from.AddParameter( "CD", OString( callTime ) );
        stateMsg.SetFrom( from );

        PTextFile callState;
        if( callState.Open( newPath ) )
          callState << stateMsg;
      }
    }

    void ForceDialogTermination( const SIPMessage & message, SIPTransaction * transaction )
    {
      PTextFile ds;
      OStringStream fn;
      PString sf = GetSafeFileName( message );
      fn << "proxy-force-disconnect/" << sf;
      if( !ds.Open( fn.str().c_str() ) )
        return;

      ds.SetPosition( PFile::Start );
      int flen = ds.GetLength();
      if( flen == 0 )
        return;

      PBYTEArray buff( flen );
      if( !ds.Read( buff.GetPointer( flen ), flen ) )
        return;

      SIPMessage bye( buff );
      ds.Close();
      
      PFile::Remove( fn.str().c_str(), TRUE );
  
      bye.SetNICTNullTransaction();
      transaction->GetManager().FindTransactionAndAddEvent( bye, FALSE );
    }
   
    SIPMessage m_MidDialogRequest;
    OpenSBCGroomer & m_Groomer;
  };

  class CANCEL_Handler : public SIPTransactionBypass
  {
    PCLASSINFO( CANCEL_Handler, SIPTransactionBypass );
  public:

    CANCEL_Handler( OpenSBCGroomer & ua ) : m_Groomer( ua )
    {
      m_AutoDeleteBypass = TRUE;
    }

    void OnTimerExpire( SIPTimerEvent & /*timer*/, SIPTransaction * transaction )
    {
    }

    void OnReceivedMessage( const SIPMessage & message, SIPTransaction * transaction )
    { 
      if( !message.IsCancel() || m_CancelRequest.IsValid() )
        return;

      m_CancelRequest = message;
      SIPFiniteStateMachine& fsm = dynamic_cast<SIPFiniteStateMachine&>(transaction->GetManager());

      PWaitAndSignal lock(  m_Groomer.m_ICTCollectionMutex );
      SIPMessage * ict = m_Groomer.m_ICTCollection.GetAt( message.GetCallId().c_str() );
      if( ict != NULL )
      {
        SIPMessage invite = *ict;
        fsm.CancelInviteClientTransaction( invite, TRUE );
      }

      fsm.CancelInviteServerTransaction( message ); 

      SIPMessage ok;
      m_CancelRequest.CreateResponse( ok, SIPMessage::Code200_Ok );
      transaction->GetManager().FindTransactionAndAddEvent( ok, FALSE, 0 );   

    }

    SIPMessage m_CancelRequest;
    OpenSBCGroomer & m_Groomer;
  };

  class INVALID_REQUEST_Handler : public SIPTransactionBypass
  {
    PCLASSINFO( INVALID_REQUEST_Handler, SIPTransactionBypass );
  public:

    INVALID_REQUEST_Handler( OpenSBCGroomer & ua ) : m_Groomer( ua )
    {
      m_AutoDeleteBypass = TRUE;
    }

    void OnTimerExpire( SIPTimerEvent & /*timer*/, SIPTransaction * transaction )
    {
    }

    void OnReceivedMessage( const SIPMessage & message, SIPTransaction * transaction )
    { 
      m_Groomer.SendERROR( message, transaction, SIPMessage::Code405_MethodNotAllowed, "Not Processing Request" );
    }

    OpenSBCGroomer & m_Groomer;
  };


  BOOL RouteINVITE( const SIPMessage & invite, SIPTransaction * transaction, PString & route, PStringToString & routeParams )
  {
    OString dialString = invite.GetRequestURI().GetUser();
    if( dialString.IsEmpty() )
    {
      /// check if the invite has a route-set and if it's strict router
      if( invite.HasRoute() )
      {
        Route r = invite.GetRouteAt(0);
        RouteURI ruri;
        r.GetURI( ruri, 0 ); 
        if( !ruri.IsLooseRouter() )
        {
          if( invite.GetRequestURI().GetAddress() == m_ListenerIP && 
            ruri.GetURI().GetAddress() != m_ListenerIP )
          {
            dialString = ruri.GetURI().GetUser();
          }
        }
      }

      if( dialString.IsEmpty() )
      {
        route = "No User In Request URI";
        return FALSE;
      }
    }

    const Via & via = invite.GetTopVia();
    PIPSocket::Address host = via.GetReceiveAddress();

    BOOL ok = FindRoute( dialString, host, route, routeParams );
    return ok;
  }

  void OnTransactionCreated( const SIPMessage & request, SIPTransaction *& transaction )
  {
    if( transaction->GetType() == SIPTransaction::NICT || transaction->GetType() == SIPTransaction::ICT )
      return;

    if( transaction->GetType() == SIPTransaction::IST && request.GetToTag().IsEmpty() )
    {
      transaction->SetBypassHandler( new INVITE_Handler( *this ), TRUE );
    }else if( request.IsBye() )
    {
      transaction->SetBypassHandler( new BYE_Handler( *this ), TRUE );
    }else if( !request.IsCancel() && !request.GetToTag().IsEmpty() )
    {
      transaction->SetBypassHandler( new MIDDIALOG_Handler( *this ), TRUE );
    }else if( request.IsCancel() )
    {
      transaction->SetBypassHandler( new CANCEL_Handler( *this ), TRUE );
    }else
    {
      transaction->SetBypassHandler( new INVALID_REQUEST_Handler( *this ), TRUE );
    }
  }

  void SetRTTSMinBufferSize(PUDPSocket & sock, int buftype)
  {
    int sz = 0;
    if (sock.GetOption(buftype, sz)) {
      if (sz >= 10240)
        return;
    }

    sock.SetOption(buftype, 10240);
  }

  PUDPSocket * GetNextRTTSSocket(
    const PIPSocket::Address & iface
  )
  {
    PWaitAndSignal lock( m_RTTSSocketMutex );

    PIPSocket::Address localAddress = iface;
    WORD localDataPort    = m_RTTSSocketBase;
    PUDPSocket * sock = new PUDPSocket();
    
    while (!sock->Listen(localAddress, 1, localDataPort))
    {
      sock->Close();
      if ((localDataPort > RTTS_PORT_MAX) || (localDataPort > 0xfffd))
      {
        delete sock;
        sock = NULL;
        return NULL; // If it ever gets to here the OS has some SERIOUS problems!
      }
      localDataPort++;
    }

    m_RTTSSocketBase = localDataPort + 1;
    
    if( m_RTTSSocketBase < RTTS_PORT_BASE || m_RTTSSocketBase > RTTS_PORT_MAX )
      m_RTTSSocketBase = RTTS_PORT_BASE;
 
    SetRTTSMinBufferSize(*sock, SO_RCVBUF);
    SetRTTSMinBufferSize(*sock, SO_SNDBUF);

    return sock;
  }

  BOOL RTTS_ParseHeader( 
    const char * name, 
    OString & value, 
    const OString & packet
  )
  {
    int len = (int)strlen(name);
    PINDEX loc = 0;
   
    PINDEX size = packet.GetLength();
    for( ;; )
    {
      loc = packet.Find( name, loc );
      if( loc == P_MAX_INDEX )
      {
        return FALSE;
      }

      if( loc == 0 || ::isspace(packet[loc-1]) )
      {
        char eq = packet[loc + len]; 
        if( loc + len + 1 < size && eq == '=' )
        {
          loc = loc + len + 1;
          int i = 0;
          char val[HEADER_PAYLOAD_MAX_SIZE];
          memset( val, '\0', HEADER_PAYLOAD_MAX_SIZE );
          while( loc < size &&  packet[loc] != '\r' && packet[loc] != '\n' )
            val[i++] = packet[loc++];
          value = (const char *)&val[0];
          return TRUE;
        }else
        {
          loc++;
        }
      }else
      {
        loc++;
      }
    }
    
    return FALSE;
  }

  BOOL IsHostBlocked( const SIPMessage & outbound )
  {
    PWaitAndSignal lock( m_BlockedHostMutex );
    int count = m_BlockedHost.GetSize();
    if( count == 0 )
      return FALSE;

    PTimeInterval now = PTimer::Tick();
    if( now.GetMinutes() - m_LastBlockingReset.GetMinutes() >= 15 )
    {
      m_LastBlockingReset = now;
      m_BlockedHost.RemoveAll();
      return FALSE;
    }

    Via via = outbound.GetBottomVia();
    OString viaHost = via.GetURI().GetHost().Trim();

    for( int i = 0; i < count; i++ )
      if( m_BlockedHost[i] == viaHost.c_str() )
        return TRUE;

    return FALSE;
  }

  void BlockHost( const SIPMessage & invite )
  {
    OString hostToBlock;
    if( invite.GetTopVia().GetParameter( "downstream-host", hostToBlock ) )
    {
      PWaitAndSignal lock( m_BlockedHostMutex );
      m_BlockedHost.Append( new PString( hostToBlock.c_str() ) );
    }
  }

  BOOL RTTS_WritePacket( const char * packet, const SIPURI & rtts, int timeout, OString & response )
  {
    WORD port = (WORD)rtts.GetPort().AsUnsigned();
    PIPSocket::Address addr= rtts.GetAddress();
    return RTTS_WritePacket( packet, addr, port, timeout, response );
  }

  BOOL RTTS_WritePacket( const char * packet, const PIPSocket::Address & addr, WORD port, int timeout, OString & response )
  {
    
    PUDPSocket * sock = GetNextRTTSSocket( m_ListenerIP );
    sock->SetSendAddress( addr, port );
    sock->SetReadTimeout( timeout / 10 );
    
    int count = 10;
    int readCount = 0;
    for( int i = 0; i < count; i++ )
    {
      sock->WriteString( packet );
      char buf[HEADER_PAYLOAD_MAX_SIZE];
      memset( buf, 0, HEADER_PAYLOAD_MAX_SIZE );
      if( sock->Read( buf, HEADER_PAYLOAD_MAX_SIZE ) )
      {
        readCount = sock->GetLastReadCount();
        if( readCount >= 10 ) 
        {
          //buf[sock->GetLastReadCount()] = '\0';
          response = (const char *)&buf[0];
          break;
        }
      }
    }

    sock->Close();
    delete sock;
    return readCount >= 10;
  }

  BOOL RTTS_PING( const PIPSocket::Address & addr, WORD port, OString & response )
  {
    static int serial = PProcess::Current().GetProcessID();
    static PAtomicInteger sequence = 0;
    
    OStringStream strm;
    strm << "PING" << endl;
    strm << "SERIAL=" << serial << endl;
    strm << "EXPIRES=" << RTTS_EXPIRES / 1000 << endl;
    strm << "SEQ=" << ++sequence << endl << endl;

    return RTTS_WritePacket( strm.str().c_str(), addr, port, RTTS_PING_TIMEOUT, response );
  }

  void RTTS_PrapareHeader( SIPMessage & invite, OStringStream & strm )
  {
    XBillingVector * billingVector = invite.GetXBillingVector();

    OString currentSequence;
    billingVector->GetParameter( "SEQ", currentSequence );

    strm << "SESSION-ID=" << invite.GetTopVia().GetBranch() << endl
         << "LOCALID=" << invite.GetCallId() << endl
         << "SEQ=" << currentSequence << endl << endl;
  }

  BOOL RTTS_UpdateSequence( SIPMessage & invite, OString & response )
  {
    XBillingVector * billingVector = invite.GetXBillingVector();
    if( billingVector == NULL )
      return FALSE;

    OString oldSeqParam;
    billingVector->GetParameter( "SEQ", oldSeqParam );


    OString newSeqParam;
    if( !RTTS_ParseHeader( "SEQ", newSeqParam, response ) )
      return FALSE;

    if( oldSeqParam.AsInteger() >= newSeqParam.AsInteger() )
      return FALSE;

    billingVector->SetParameter( "SEQ", newSeqParam );

    return TRUE;
  }

  BOOL RTTS_START( SIPMessage & invite, OString & response )
  {
    OString cid = invite.GetCallId();
    OString sid = invite.GetTopVia().GetBranch();
    OStringStream packet;
    packet << "START" << endl;
    packet << "User-Agent=OpenSBCGroomer" << endl;
    packet << "User-Agent-Version=" << APP_VERSION << endl;

    packet << "SESSION-ID=" << sid.c_str() << endl
         << "LOCALID=" << cid.c_str() << endl
         << "SEQ=0";

    PWaitAndSignal lock( m_RTTSServerMutex );
    static int m_CurrentRTTSIndex = 0;
    
    int count = m_RTTSValidatedServers.GetSize();

    SIPURI rttsURI;
    rttsURI.SetScheme( "rtts" );
    
    rttsURI.SetPort( OString( RTTS_SERVER_PORT ) ); 
  
    LOG_CONTEXT( LogInfo(), cid.c_str(), ">>> START SESSION-ID=" << sid.c_str()  );

    for( int i=0; i<count ;i++)
    {
      PIPSocket::Address rtts = m_RTTSValidatedServers.GetKeyAt( m_CurrentRTTSIndex % count );
      ++m_CurrentRTTSIndex;
      if( rtts.IsValid() )
      {
        LOG_CONTEXT( LogDebug(), cid.c_str(), ">>> " << packet.str().c_str() );

        rttsURI.SetHost( rtts.AsSTLString() );
        if( RTTS_WritePacket( packet.str().c_str(), rttsURI, RTTS_START_TIMEOUT, response ) )
        { 
          LOG_CONTEXT( LogDebug(), cid.c_str(), "<<< " << response );
          invite.SetXBillingVector( new XBillingVector( rttsURI ) );
          return RTTS_UpdateSequence( invite, response );
        }
      }
    }

    return FALSE;
  }

  BOOL RTTS_AUTH( SIPMessage & invite, OString & response )
  {
    OString cid = invite.GetCallId();

    XBillingVector * billingVector = invite.GetXBillingVector();
    if( billingVector == NULL )
      return FALSE;
  
    Via via = invite.GetTopVia();
    OStringStream packet;
    packet << "AUTH" << endl;
    RTTS_PrapareHeader( invite, packet );

    OString ingress;
    if( invite.GetFrom().GetParameter( "ingress", ingress ) )
    {
      OString downStreamHost;
      if( via.GetParameter( "downstream-host", downStreamHost ) )
        packet << "HOST=" << downStreamHost << endl;
      else
         packet << "HOST=" << via.GetReceiveAddress().AsString() << endl;
    }else
    {
      packet << "HOST=" << via.GetReceiveAddress().AsString() << endl;
    }   
    
    OString downStreamHost;
    if( via.GetParameter( "downstream-host", downStreamHost ) )
      packet << "DOWNSTREAM-HOST=" << downStreamHost << endl;

    SIPURI rURI;
    invite.GetRequestURI(rURI);
    packet << "DNIS=" << rURI.GetUser() << endl;

    OString s_ani, s_domain;
    if( !invite.HasPAssertedIdentity() )
    {
      s_ani = invite.GetFromURI().GetUser();
      s_domain = invite.GetFromURI().GetHost();

      
    }else
    {
      PAssertedIdentity pai = invite.GetPAssertedIdentityAt(0);
      ContactURI paiURI;
      pai.GetURI( paiURI );
      s_ani = paiURI.GetURI().GetUser();
      s_domain = paiURI.GetURI().GetHost();
    }

    packet << "ANI=" << s_ani << endl;
    packet << "DOMAIN=sip:" << s_domain << endl; 

    LOG_CONTEXT( LogInfo(), cid.c_str(), ">>> AUTH " 
      << "HOST=" << via.GetReceiveAddress().AsString() << " "
      << "DNIS=" << rURI.GetUser() << " "
      << "ANI=" << s_ani << " "
      << "DOMAIN=" << s_domain );

    LOG_CONTEXT( LogDebug(), cid.c_str(), ">>> " << packet.str().c_str() );

    if( RTTS_WritePacket( packet.str().c_str(), billingVector->GetURI(), RTTS_AUTH_TIMEOUT, response ) )
    {
      OString bsid;
      if( RTTS_ParseHeader( "BRANDSERVICEID", bsid, response ) )
        billingVector->SetParameter( "BSID", bsid );

      LOG_CONTEXT( LogDebug(), cid.c_str(), "<<< " << response );
      return RTTS_UpdateSequence( invite, response );
    }

    return FALSE;
  }

  BOOL RTTS_SIGNIN( SIPMessage & invite,  OString & response )
  {
    OString cid = invite.GetCallId();
    XBillingVector * billingVector = invite.GetXBillingVector();
    if( billingVector == NULL )
      return FALSE;

    OString bsid;
    if( !billingVector->GetParameter( "BSID", bsid ) )
      return FALSE;

    OStringStream packet;
    packet << "SIGNIN" << endl;
    RTTS_PrapareHeader( invite, packet );
    OString billingType = bsid.Left( 2 );

    LOG_CONTEXT( LogDebug(), cid.c_str(), ">>> " << packet.str().c_str() );

    if( billingType *= "WS" )
    {
      if( RTTS_WritePacket( packet.str().c_str(), billingVector->GetURI(), RTTS_SIGNIN_TIMEOUT, response ) )
      {
        LOG_CONTEXT( LogDebug(), cid.c_str(), "<<< " << response );
        return RTTS_UpdateSequence( invite, response );
      }
    }

    return FALSE;
  }

BOOL RTTS_ParseRoute( 
  const OString & setupPacket,
  const SIPMessage & invite,
  SIPMessage::Collection & rtbeRouteList,
  BOOL ignoreRoutes
)
{
  if( rtbeRouteList.GetSize() > 0 )
    return TRUE;

  OString routingHeader;
  if( !RTTS_ParseHeader( "ROUTING", routingHeader, setupPacket ) )
    return FALSE;

  if( routingHeader.IsEmpty() )
    return FALSE;

  SIPURI rURI;
  invite.GetRequestURI(rURI);
  const SIPURI & fURI = invite.GetFromURI();
  size_t len = routingHeader.GetLength();
  size_t i = 0;

  if( ignoreRoutes )
  {
    SIPMessage * relayroute = new SIPMessage();
    
    const RequestLine & rLine = invite.GetRequestLine();
    From from = invite.GetFrom();

    relayroute->SetStartLine(rLine);
    relayroute->SetFrom( from );
    rtbeRouteList.Append( relayroute );
    goto CNAM;
  }

  
  for( ;; )
  {
    SIPURI fromURI = fURI;
    SIPURI reqURI = rURI;
    size_t elementIndex = 0;
    char scheme[50];
    memset( scheme, '\0', 50 );

    for( ;; )
    {
      char c = routingHeader[i];
      if( c != ':' && !::isspace(c) )
        scheme[elementIndex++] = routingHeader[i];
      else if( c == ':' )
      {
        i++;
        break;
      }

      if(i++ >= len )
        goto CNAM;
        //return rtbeRouteList.GetSize() != 0;
    }

  
    elementIndex = 0;
    char fromUser[256];
    memset( fromUser, '\0', 256 );

    for( ;; )
    {
      char c = routingHeader[i];
      if( c != '*' && !::isspace(c) )
        fromUser[elementIndex++] = routingHeader[i];
      else if( c == '*' )
      {
        i++;
        break;
      }

      if(i++ >= len )
        goto CNAM;
        //return rtbeRouteList.GetSize() != 0;
    }

    elementIndex = 0;
    char dnis[256];
    memset( dnis, '\0', 256 );

    for( ;; )
    {
      char c = routingHeader[i];
      if( c != '@' && !::isspace(c) )
        dnis[elementIndex++] = routingHeader[i];
      else if( c == '@' )
      {
        i++;
        break;
      }

      if(i++ >= len )
        return rtbeRouteList.GetSize() != 0;
    }

    elementIndex = 0;
    char fromHost[256];
    memset( fromHost, '\0', 256 );

    for( ;; )
    {
      char c = routingHeader[i];
      if( c != ':' && !::isspace(c) )
        fromHost[elementIndex++] = routingHeader[i];
      else if( c == ':' )
      {
        i++;
        break;
      }

      if(i++ >= len )
        return rtbeRouteList.GetSize() != 0;
    }

    elementIndex = 0;
    char targetPort[5];
    memset( targetPort, '\0', 5 );

    for( ;; )
    {
      char c = routingHeader[i];
      if( c != ':' && !::isspace(c) )
        targetPort[elementIndex++] = routingHeader[i];
      else if( c == ':' )
      {
        i++;
        break;
      }

      if(i++ >= len )
        goto CNAM;
        //return rtbeRouteList.GetSize() != 0;
    }

    elementIndex = 0;
    char target[256];
    memset( target, '\0', 256 );

    for( ;; )
    {
      char c = routingHeader[i];
      if( c != ';' && !::isspace(c) )
        target[elementIndex++] = routingHeader[i];
      else if( c == ';' )
      {
        i++;
        break;
      }
      if(i++ >= len )
        goto CNAM;
        //return rtbeRouteList.GetSize() != 0;
    }

    if( strcmp( scheme, "sip" ) == 0 )
    {
      /// populate the routelist
      if( dnis[0] != '\0' )
        reqURI.SetUser( (const char *)&dnis[0] );
      
      if( target[0] != '\0' )
        reqURI.SetHost( (const char *)&target[0] );

      if( targetPort[0] != '\0' )
        reqURI.SetPort( (const char *)&targetPort[0] );
      else 
        reqURI.SetPort( "" );

      if( fromUser[0] != '\0' )
      {
        if( strcmp( fromUser, "NULL" ) == 0 )
          fromURI.SetUser("");
        else if( strcmp( fromUser, "null" ) != 0 )
          fromURI.SetUser( (const char *)&fromUser[0] );
      }

      if( fromHost[0] != '\0' )
        fromURI.SetHost( (const char *)&fromHost[0] );


      #if 0  /// test timeout
      SIPMessage * timeoutRoute = new SIPMessage();
      RequestLine rLine = "INVITE sip:12345@10.0.0.1:5060 SIP/2.0";
      From from;
      from.SetURI( fromURI );
      timeoutRoute->SetStartLine(rLine);
      timeoutRoute->SetFrom( from );
      rtbeRouteList.Append( timeoutRoute );
      #endif

      #if 0  /// test 404
      SIPURI dummyreqURI = "sip:1@fwd.pulver.com";
      SIPMessage * dummyRoute = new SIPMessage();
      RequestLine dummyrLine;
      dummyrLine.SetMethod( "INVITE" );
      dummyrLine.SetRequestURI( dummyreqURI );
      From dummyfrom;
      dummyfrom.SetURI( fromURI );
      dummyRoute->SetStartLine(dummyrLine);
      dummyRoute->SetFrom( dummyfrom );
      rtbeRouteList.Append( dummyRoute );
      #endif

      #if 1
      SIPMessage * newRoute = new SIPMessage();
      RequestLine rLine;
      rLine.SetMethod( "INVITE" );
      rLine.SetRequestURI( reqURI );
      From from;
      from.SetURI( fromURI );
      newRoute->SetStartLine(rLine);
      newRoute->SetFrom( from );
      rtbeRouteList.Append( newRoute );
      
      #endif
    }
  }

CNAM:
  ///parse CNAM 
  OString cnamInfo;
  int routeCount = rtbeRouteList.GetSize();

  if( RTTS_ParseHeader( "CNAMINFO", cnamInfo, setupPacket ) )
  {
    OStringArray cnamTokens;
    cnamInfo.Tokenise(cnamTokens, ";" );  
    int cnamCount = cnamTokens.GetSize();
    int count = routeCount <= cnamCount ? routeCount : cnamCount;

    for( PINDEX i = 0; i < count; i++ )
    {
      if( !cnamTokens[i].IsEmpty() )
      {
        if( cnamTokens[i][0] != ';' )
        {
          SIPMessage &route = rtbeRouteList[i];
          route.AddInternalHeader( "CNAM", cnamTokens[i] );
        }
      }
    }
  }

  OString finalRoute;
  if( !ignoreRoutes && RTTS_ParseHeader( "FINALROUTEURL", finalRoute, setupPacket ) )
  {
    ///FINALROUTEURL=sip:finalroute::70.42.73.172

    SIPURI finalRouteRURI;
    if( rtbeRouteList.GetSize() > 0 )
      finalRouteRURI = rtbeRouteList[0].GetRequestURI();
    else
      finalRouteRURI = invite.GetRequestURI();
    
    OStringArray tokens = finalRoute.Tokenise(":");
    if( tokens.GetSize() == 4 )
    {
      finalRouteRURI.SetHost( tokens[3] );
      finalRouteRURI.SetPort( tokens[2] );

      SIPMessage * newRoute = new SIPMessage();
      RequestLine rLine;
      rLine.SetMethod( "INVITE" );
      rLine.SetRequestURI( finalRouteRURI );
      From from;
      from.SetURI( fURI );
      newRoute->SetStartLine(rLine);
      newRoute->SetFrom( from );
      newRoute->AddInternalHeader( "rtts-call-accounting", "off" );
      rtbeRouteList.Append( newRoute );
    }
  }

  OString routeSetCount;
  if( RTTS_ParseHeader( "ROUTE-SET-COUNT", routeSetCount, setupPacket ) )
  {
    static const char route_indices[20][14] = { 
      "ROUTE-SET[0]",
      "ROUTE-SET[1]",
      "ROUTE-SET[2]",
      "ROUTE-SET[3]",
      "ROUTE-SET[4]",
      "ROUTE-SET[5]",
      "ROUTE-SET[6]",
      "ROUTE-SET[7]",
      "ROUTE-SET[8]",
      "ROUTE-SET[9]",
      "ROUTE-SET[10]",
      "ROUTE-SET[11]",
      "ROUTE-SET[12]",
      "ROUTE-SET[13]",
      "ROUTE-SET[14]",
      "ROUTE-SET[15]",
      "ROUTE-SET[16]",
      "ROUTE-SET[17]",
      "ROUTE-SET[18]",
      "ROUTE-SET[19]"
    };

    int count = routeSetCount.AsInteger();
    for( int i = 0; i < count && i < 20 && i < routeCount; i++ )
    {
      OString currentRouteEntry;
      if( RTTS_ParseHeader( route_indices[i], currentRouteEntry, setupPacket ) )
      {
         SIPMessage &route = rtbeRouteList[i];
         route.AddInternalHeader( "ROUTE-SET", currentRouteEntry );
      }
    }
  }

  return rtbeRouteList.GetSize() != 0;
}

  BOOL RTTS_SETUP( SIPMessage & invite, OString & response )
  {
    OString cid = invite.GetCallId();
    XBillingVector * billingVector = invite.GetXBillingVector();
    if( billingVector == NULL )
      return FALSE;

    OStringStream packet;
    packet << "SETUP" << endl;
    RTTS_PrapareHeader( invite, packet );
    packet << "DIALSTRING=" << invite.GetRequestURI().GetUser() << endl;
    OString stamp;
    if( invite.GetFrom().GetParameter( "CDRTIME", stamp ) )
    {
      packet << "CDRTIME=" << stamp << endl;
    }

    LOG_CONTEXT( LogDebug(), cid.c_str(), ">>> " << packet.str().c_str() );

    if( RTTS_WritePacket( packet.str().c_str(), billingVector->GetURI(), RTTS_SETUP_TIMEOUT, response ) )
    {
      LOG_CONTEXT( LogDebug(), cid.c_str(), "<<< " << response );

      OString routing;
      if( RTTS_ParseHeader( "ROUTING", routing, response ) )
        invite.SetXRoutingVector( new XRoutingVector( routing ) );

      if( routing.IsEmpty() )
        return FALSE;
     
      OString uasTarget;
      if( !invite.GetFrom().GetParameter( "rtts-uas-target", uasTarget ) )
      {
        Contact contact;
        invite.GetContactAt( contact, 0 );
        if( contact.GetSize() == 2 )
        {
          ContactURI contactURI;
          contact.GetURI( contactURI, 1 );
          uasTarget = contactURI.GetURI().GetHost();
        }
      }

      if( uasTarget.IsEmpty() )
      {
        LOG_CONTEXT( LogError(), cid.c_str(), "!!! RTTS-UAS-TARGET parameter is not set !!! [" << invite.GetFrom() << "]" );
        uasTarget = invite.GetRequestURI().GetHost();
      }

      /// determine the route index to use
      SIPMessage::Collection rttsRoutes;
      if( RTTS_ParseRoute( response, invite, rttsRoutes, FALSE ) )
      {
        int count = rttsRoutes.GetSize();
        BOOL found = FALSE;
        for( int i = 0; i < count; i++ )
        {
          SIPMessage currentRoute = rttsRoutes[i];
          if( uasTarget *= currentRoute.GetRequestURI().GetHost() )
          {
            billingVector->AddParameter( "TRMH", OString(i + 1) );
            found = TRUE;
            break;
          }
        }

        if( !found )
        {
          LOG_CONTEXT( LogError(), cid.c_str(), "!!! RTTS-UAS-TARGET " << uasTarget << " not specified in route list !!!" );
          billingVector->AddParameter( "TRMH", "0" );
        }
      }

      OString bblft;
      if( RTTS_ParseHeader( "BASICBLOCKSLEFT", bblft, response ) )
        billingVector->AddParameter( "BBLFT", bblft );

      OString blft;
      if( RTTS_ParseHeader( "BLOCKSLEFT", blft, response ) )
        billingVector->AddParameter( "BLFT", blft );

      OString tlft;
      if( RTTS_ParseHeader( "TIMELEFT", tlft, response ) )
        billingVector->AddParameter( "TLFT", tlft );

      OString bctlft;
      if( RTTS_ParseHeader( "BASICCHARGETIMELEFT", bctlft, response ) )
        billingVector->AddParameter( "BCTLFT", bctlft );

      OString cnam;
      if( RTTS_ParseHeader( "CNAMINFO", cnam, response ) )
      {
        if( cnam != ";" )
          billingVector->SetDisplayName( ParserTools::Quote( "cnam" ) );
      }

      

      return RTTS_UpdateSequence( invite, response );
    }

    return FALSE;
  }

  BOOL RTTS_CALLSTART( SIPMessage & invite,  OString & response )
  {
    OString cid = invite.GetCallId();
    XBillingVector * billingVector = invite.GetXBillingVector();
    if( billingVector == NULL )
      return FALSE;

    OString termHost;
    if( !billingVector->GetParameter( "TRMH", termHost ) )
      return FALSE;

    OStringStream packet;
    packet << "CALLSTART" << endl;
    RTTS_PrapareHeader( invite, packet );
    packet << "TERMINATINGHOST=" << termHost << endl;
    OString stamp;
    if( invite.GetFrom().GetParameter( "CDRTIME", stamp ) )
    {
      packet << "CDRTIME=" << stamp << endl;
    }

    LOG_CONTEXT( LogDebug(), cid.c_str(), ">>> " << packet.str().c_str() );

    if( RTTS_WritePacket( packet.str().c_str(), billingVector->GetURI(), RTTS_CALLSTART_TIMEOUT, response ) )
    {
      LOG_CONTEXT( LogDebug(), cid.c_str(), "<<< " << response );
      return RTTS_UpdateSequence( invite, response );
    }

    return FALSE;
  }

  BOOL RTTS_CALLSTOP( SIPMessage & invite,  OString & response )
  {
    OString cid = invite.GetCallId();
    XBillingVector * billingVector = invite.GetXBillingVector();
    if( billingVector == NULL )
      return FALSE;

    OString callDuration;
    if( !invite.GetFrom().GetParameter( "CD", callDuration ) )
    {
      if( !invite.GetFrom().GetParameter( "NQTIME", callDuration ) )
      {
        if( !invite.GetFrom().GetParameter( "QTIME", callDuration ) )
        {
          callDuration = "3600";
          From from = invite.GetFrom();
          from.AddParameter( "QTIME", callDuration );
          invite.SetFrom( from );
        }
      }
    }

    OStringStream packet;
    packet << "CALLSTOP" << endl;
    RTTS_PrapareHeader( invite, packet );
    packet << "DURATION=" << callDuration << endl;

    if( invite.GetFrom().FindParameter( "QTIME" ) != P_MAX_INDEX )
    {
      packet << "ERROR=4005" << endl;
    }

    OString s_ani, s_domain;
    if( !invite.HasPAssertedIdentity() )
    {
      s_ani = invite.GetFromURI().GetUser();
      s_domain = invite.GetFromURI().GetHost();
    }else
    {
      PAssertedIdentity pai = invite.GetPAssertedIdentityAt(0);
      ContactURI paiURI;
      pai.GetURI( paiURI );
      s_ani = paiURI.GetURI().GetUser();
      s_domain = paiURI.GetURI().GetHost();
    }

    OString s_via = invite.GetTopVia().GetURI().GetHost();
    OString s_dnis = invite.GetRequestURI().GetUser();
    
    LOG_CONTEXT( LogInfo(), cid.c_str(), ">>> CALLSTOP " 
      << "HOST=" << s_via << " "
      << "DNIS=" << s_dnis << " "
      << "ANI=" << s_ani << " "
      << "DOMAIN=" << s_domain << " "
      << "DURATION=" << callDuration );

    LOG_CONTEXT( LogDebug(), cid.c_str(), ">>> " << packet.str().c_str() );

    if( RTTS_WritePacket( packet.str().c_str(), billingVector->GetURI(), RTTS_CALLSTOP_TIMEOUT, response ) )
    {
      LOG_CONTEXT( LogDebug(), cid.c_str(), "<<< " << response );
      return RTTS_UpdateSequence( invite, response );
    }

    return FALSE;
  }

  class RTTS_STOP_Thread : public PThread
  {
    PCLASSINFO( RTTS_STOP_Thread, PThread );
  public:
    OpenSBCGroomer * m_Groomer;
    OString m_Packet;
    SIPURI m_RTTS;
    RTTS_STOP_Thread( OpenSBCGroomer * groomer, const OString & packet, const SIPURI & rtts )
      : PThread( 10240 )
    {
      m_Groomer = groomer;
      m_RTTS = rtts;
      m_Packet = packet;
      Resume();
    }
    
    void Main()
    {
      OString response;
      m_Groomer->RTTS_WritePacket( m_Packet.c_str(), m_RTTS, 3000, response );
    }

  };
  void RTTS_STOP( SIPMessage & invite )
  {
    OString cid = invite.GetCallId();
    XBillingVector * billingVector = invite.GetXBillingVector();
    if( billingVector == NULL )
      return;


    OStringStream packet;
    packet << "STOP" << endl;
    RTTS_PrapareHeader( invite, packet );

    if( invite.GetFrom().FindParameter( "QTIME" ) != P_MAX_INDEX )
    {
      packet << "ERROR=4005" << endl;
    }

    LOG_CONTEXT( LogDebug(), cid.c_str(), ">>> " << packet.str().c_str() );

    new RTTS_STOP_Thread( this, packet.str(), billingVector->GetURI() );
  }

  void RTTS_SerialChanged( PString & server )
  {
    /// this method is called by the PING handler if the serial id of an rtts server has changed
  }


  BOOL GetRTTSCommitEntry( PFilePath & catLog )
  {
    PWaitAndSignal lock( m_RTTSCommitMutex );
    PDirectory rttsCommitDir( "rtts-commit" );
    if( !rttsCommitDir.Open() )
      return FALSE;

    for( ;; )
    {

      if( rttsCommitDir.GetEntryName() == "archived" )
      {
        if( !rttsCommitDir.Next() )
          break;
      }if( rttsCommitDir.GetEntryName() == "backoff" )
      {
        if( !rttsCommitDir.Next() )
        {
          catLog = "";
          break;
        }
      }else
      {
        catLog = rttsCommitDir + rttsCommitDir.GetEntryName();
        PFileInfo info;
        PFile::GetInfo( catLog, info );
        if( info.type != PFileInfo::RegularFile && !rttsCommitDir.Next())
        {
          catLog = "";
          break;
        }else if( info.type == PFileInfo::RegularFile )
        {
          break;
        }
      }
    }
    rttsCommitDir.Close();
    return !catLog.IsEmpty();
  }

  void RTTS_Reprocess( PString & arg )
  {
    /*
    "Example 4: ./OpenSBCGroomer --reprocess-rtts runawaycalls/7/30\n"
    "Example 5: ./OpenSBCGroomer --reprocess-rtts questionable/7/30\n"
    "Example 6: ./OpenSBCGroomer --reprocess-rtts backoff/7\n";
    */
    PStringArray tokens = arg.Tokenise( '/' );
    if( tokens.GetSize() < 2 )
      return;

    if( tokens[0] == "runawaycalls" && tokens.GetSize() == 3 )
    {
      RTTS_Reprocess_Runaway( tokens[1].AsInteger(), tokens[2].AsInteger(), FALSE );
    }else if( tokens[0] == "questionable" && tokens.GetSize() == 3 )
    {
      RTTS_Reprocess_Runaway( tokens[1].AsInteger(), tokens[2].AsInteger(), TRUE );
    }else if( tokens[0] == "backoff"  )
    {
      RTTS_Reprocess_Backoff( tokens[1].AsInteger() );
    }
  }

  void RTTS_Reprocess_Runaway( int days, int duration, BOOL questionable )
  {
    PDirectory folder( "proxy-state" );
    if( !folder.Open() )
      return;

    BOOL firstTime = TRUE;
    for( ;; )
    {
      PFilePath stateFile;
      {
        if( !firstTime  )
        {
          if( !folder.Next() )
          {
            stateFile = "";
            break;
          }
        }
        firstTime = FALSE;
        stateFile = folder + folder.GetEntryName();
        PTextFile catFile;
        PFileInfo info;
        PFile::GetInfo( stateFile, info );
        PTime now;
        int age = now.GetDayOfYear() - info.modified.GetDayOfYear();
        if( age > days  )
          continue;

        if( info.type != PFileInfo::RegularFile )
          continue;
        
        if( info.type == PFileInfo::RegularFile )
        {
          if( !catFile.Open( stateFile ) )
            continue;

          catFile.SetPosition( PFile::Start );
          int flen = catFile.GetLength();
          if( flen == 0 )
            continue;
#if WIN32
          PStringStream buff;
          for( ;; )
          {
            PString line;
            if( !catFile.ReadLine( line ) )
              break;
            buff << line.Trim() << "\r\n";
          }
          SIPMessage stateMsg( (const char *)buff );
#else
          PBYTEArray buff( flen );
          if( !catFile.Read( buff.GetPointer( flen ), flen ) )
            continue;
          SIPMessage stateMsg( (const char *)buff.GetPointer(flen) );
#endif
          From from = stateMsg.GetFrom();
          OString qtime( duration * 60 );
          if( questionable )
            from.AddParameter( "QTIME", qtime );
          else
            from.AddParameter( "NQTIME", qtime );

          stateMsg.SetFrom( from ); 
          catFile.Close();
          if( RTTS_Commit( stateMsg ) )
          {
            PFilePath archived = "rtts-commit/archived/" + stateFile.GetFileName();
            PFile::Move( stateFile, archived, TRUE );
          }
        }
      }
    }
    folder.Close();
  }

  void RTTS_Reprocess_Backoff( int days )
  {
    PDirectory folder( "rtts-commit/backoff" );
    if( !folder.Open() )
      return;

    BOOL firstTime = TRUE;
    for( ;; )
    {
      PFilePath stateFile;
      {
        if( !firstTime  )
        {
          if( !folder.Next() )
          {
            stateFile = "";
            break;
          }
        }
        firstTime = FALSE;
        stateFile = folder + folder.GetEntryName();
        PTextFile catFile;
        PFileInfo info;
        PFile::GetInfo( stateFile, info );
        PTime now;
        int age = now.GetDayOfYear() - info.modified.GetDayOfYear();
        if( age > days  )
          continue;

        if( info.type != PFileInfo::RegularFile )
          continue;
        
        if( info.type == PFileInfo::RegularFile )
        {
          if( !catFile.Open( stateFile ) )
            continue;

          catFile.SetPosition( PFile::Start );
          int flen = catFile.GetLength();
          if( flen == 0 )
            continue;

#if WIN32
          PStringStream buff;
          for( ;; )
          {
            PString line;
            if( !catFile.ReadLine( line ) )
              break;
            buff << line.Trim() << "\r\n";
          }
          SIPMessage stateMsg( (const char *)buff );
#else
          PBYTEArray buff( flen );
          if( !catFile.Read( buff.GetPointer( flen ), flen ) )
            continue;
          SIPMessage stateMsg( (const char *)buff.GetPointer(flen) );
#endif
          catFile.Close();
          if( RTTS_Commit( stateMsg ) )
          {
            PFilePath archived = "rtts-commit/archived/" + stateFile.GetFileName();
            PFile::Move( stateFile, archived, TRUE );
          }
        }
      }
    }
    folder.Close();
  }

  BOOL RTTS_Commit( SIPMessage & invite )
  {
    OString response;
    OString error;
    if( !RTTS_START( invite, response ) )
      return FALSE;

    if( !RTTS_AUTH( invite, response ) )
    {
      RTTS_STOP( invite );
      return FALSE;
    }else 
    {
      if( RTTS_ParseHeader( "ERROR", error, response ) )
      { 
        BlockHost( invite );
        RTTS_STOP( invite );
        return FALSE;
      }
    }

    if( !RTTS_SIGNIN( invite, response ) )
    {
      RTTS_STOP( invite );
      return FALSE;
    }else 
    {
      if( RTTS_ParseHeader( "ERROR", error, response ) )
      { 
        RTTS_STOP( invite );
        return FALSE;
      }
    }

    if( !RTTS_SETUP( invite, response ) )
    {
      RTTS_STOP( invite );
      return FALSE;
    }else 
    {
      if( RTTS_ParseHeader( "ERROR", error, response ) )
      { 
        RTTS_STOP( invite );
        return FALSE;
      }
    }

    XBillingVector * billingVector = invite.GetXBillingVector();
    if( billingVector == NULL )
      return FALSE;

    if( !RTTS_CALLSTART( invite, response ) )
    {
      RTTS_STOP( invite );
      return FALSE;
    }else 
    {
      if( RTTS_ParseHeader( "ERROR", error, response ) )
      { 
        RTTS_STOP( invite );
        return FALSE;
      }
    }

    if( !RTTS_CALLSTOP( invite, response ) )
    {
      RTTS_STOP( invite );
      return FALSE;
    }

    RTTS_STOP( invite );

    return TRUE;
  }

  void CommitRTTSEntries()
  {
    PFilePath path;
    if( GetRTTSCommitEntry( path ) )
    {
      PFilePath archive = path.GetDirectory() + "archived" + "/" + path.GetFileName();
      PTextFile catFile;
      
      if( !catFile.Open( path ) )
      {
        PFilePath backoff = path.GetDirectory() + "backoff" + "/" + path.GetFileName();
        PFile::Move( path, backoff, TRUE );
        return;
      }

      catFile.SetPosition( PFile::Start );
      int flen = catFile.GetLength();
      if( flen == 0 )
      {
        PFile::Remove( path, TRUE );
        return;
      }

#if WIN32
      PStringStream buff;
      for( ;; )
      {
        PString line;
        if( !catFile.ReadLine( line ) )
          break;
        buff << line.Trim() << "\r\n";
      }
      SIPMessage stateMsg( (const char *)buff );
#else
      PBYTEArray buff( flen );
      if( !catFile.Read( buff.GetPointer( flen ), flen ) )
      {
        PFilePath backoff = path.GetDirectory() + "backoff" + "/" + path.GetFileName();
        PFile::Move( path, backoff, TRUE );
        return;
      }
      SIPMessage stateMsg( (const char *)buff.GetPointer(flen) );
#endif

      
      From from = stateMsg.GetFrom();
      OString ct;
      PInt64 timeInSeconds;
      if( from.GetParameter( "CT", ct ) )
      {
        timeInSeconds = ct.AsInt64();
      }else
      {
        PFileInfo info;
        catFile.GetInfo( info );
        timeInSeconds = info.modified.GetTimeInSeconds();
      }

      PInt64 ts = timeInSeconds * 1000;
      OStringStream strTS;
      strTS << ts;
      OString cid = stateMsg.GetCallId(); 
      LOG_CONTEXT( LogInfo(), cid.c_str(), "!!! RTTS-CONTEXT( " << from << ") !!!" );
      from.AddParameter( "CDRTIME", strTS.str().c_str() );
      stateMsg.SetFrom( from );

      catFile.Close();
      PFile::Move( path, archive, TRUE );

      if( !RTTS_Commit( stateMsg ) )
      {
        //if( archive.Right( 1 ) != "-"  )
        //  PFile::Move( archive, path + "-", TRUE );
        //else
        //{
          PFilePath backoff = path.GetDirectory() + "backoff" + "/" + path.GetFileName().Left( path.GetFileName().GetLength() - 10);
          PFile::Move( archive, backoff, TRUE );
        //}
      }
    }
  }
  
};


class Process : public PProcess
{
  PCLASSINFO( Process, PProcess );
public:
  SIPURI m_ListenerAddress;
  PString m_RouteFile;
  PString m_RTTSReprocessArg;

  void Main()
  {
    SetMaxHandles( 65535 );
    
    if( !ParseArgs() )
      return;

    OpenSBCGroomer groomer;
    groomer.m_RouteFile = m_RouteFile;
    groomer.m_ListenerAddress = m_ListenerAddress;

    if( !groomer.LoadRoutes( m_RouteFile ) )
    {
      PError << "Unable to load Route File";
      return;
    }

    if( !m_RTTSReprocessArg.IsEmpty() )
    {
      groomer.Main( FALSE, TRUE );
      PThread::Sleep( 5000 );
      groomer.RTTS_Reprocess( m_RTTSReprocessArg );
      groomer.Terminate();
      PThread::Sleep( 1000 );
      _exit( -1 );
    }
    
    groomer.Main();
  }

  BOOL ParseArgs()
  {
    PArgList & args = GetArguments();
    args.Parse("t-trace-level."
               "v-version."
               "h-help."
               "p-pid-file:"
               "r-route-xml-file:"
               "i-interface-address:"
               "y-verify-host:"
               "z-verify-number:"
               "R-reprocess-rtts:");

    Logger::SetDefaultLevel( args.GetOptionCount( 't' ) );

    if( args.HasOption( 'h' ) )
    {
      DisplayUsage(); 
      return FALSE;
    }else if( args.HasOption( 'v' ) )
    {
      DisplayVersion();
      return FALSE;
    }else if( args.HasOption( 'R' ) )
    {
      m_RTTSReprocessArg = args.GetOptionString( 'R' );
      if( !args.HasOption( 'i' ) )
      {
        PError << "Interface Address not specified!  Please set the -i flag" << endl;
        DisplayUsage();
        return FALSE;
      }else
      {
        m_ListenerAddress = args.GetOptionString( 'i' );
      }

      if( !args.HasOption( 'r' ) )
      {
        PError << "Route XML file not specified!  Please set the -r flag" << endl;
        DisplayUsage();
        return FALSE;
      }

      m_RouteFile = args.GetOptionString( 'r' );

      return TRUE;
    }

    if( args.HasOption( 'y' ) || args.HasOption( 'z' ) && args.HasOption( 'r' ) )
    {
      DisplayRoute( args.GetOptionString( 'y' ), args.GetOptionString( 'z' ), args.GetOptionString( 'r' ) );
      return FALSE;
    }

    if( args.HasOption( 'p' ) )
    {
      PString pidFile = args.GetOptionString( 'p' );
      DumpProcessId( pidFile );
    }

    if( !args.HasOption( 'i' ) )
    {
      PError << "Interface Address not specified!  Please set the -i flag" << endl;
      DisplayUsage();
      return FALSE;
    }else
    {
      m_ListenerAddress = args.GetOptionString( 'i' );
    }

    if( !args.HasOption( 'r' ) )
    {
      PError << "Route XML file not specified!  Please set the -r flag" << endl;
      DisplayUsage();
      return FALSE;
    }

    m_RouteFile = args.GetOptionString( 'r' );

    return TRUE;
  }

  void DumpProcessId( const PFilePath & path )
  {
    PTextFile pidFile( path );
    if( pidFile.IsOpen() )
    {
      PString pid( GetProcessID() );
      pidFile.WriteString( pid );
    }
  }

  void DisplayUsage()
  {
    PError << "usage:  -v|-h\n"
            "  -t                     Trace level.  Example -ttt means Log Level 3\n"
            "  -h --help              output this help message and exit\n"
            "  -v --version           display version information and exit\n"
            "  -p --pid-file          name or absolute path for pid file\n"
            "  -r --route-xml-file    name or absolute path for xml route file\n"
            "  -i --interface-address interface address to be used for listener in SIP URI format\n"
            "  -y --verify-host       used to verify host block.  output route to console\n"
            "  -z --verify-number     used to verify number.  output route to console\n"
            "  -R --reprocess-rtts    used to reprocess failed transactions.\n\n"
            "Example 1: ./OpenSBCGroomer -p pid.txt -r routes.xml -i sip:192.168.0.253:5060\n"
            "Example 2: ./OpenSBCGroomer --verify-number 12127773456\n"
            "Example 3: ./OpenSBCGroomer --verify-host 192.168.0.100\n"
            "Example 4: ./OpenSBCGroomer -r route.xml -i sip:192.168.0.253:5060 --reprocess-rtts runawaycalls/7/30\n"
            "Example 5: ./OpenSBCGroomer -r route.xml -i sip:192.168.0.253:5060 --reprocess-rtts questionable/7/30\n"
            "Example 6: ./OpenSBCGroomer -r route.xml -i sip:192.168.0.253:5060 --reprocess-rtts backoff/7\n";
  }

  void DisplayVersion()
  {
    PError << "Product Name: " << "OpenSBCGroomer" << endl
           << "Manufacturer: " << "opensipstack.org" << endl
           << "Version     : " << APP_VERSION << endl
           << "System      : " << GetOSName() << '-'
                             << GetOSHardware() << ' '
                             << GetOSVersion() << endl
           << "Release-Date: " << GetReleaseDate() << endl;
  }

  void DisplayRoute( const PString & host, const PString & number, const PString & routeFile )
  {
    OpenSBCGroomer groomer;

    if( !groomer.LoadRoutes( routeFile ) )
    {
      PError << "Enable to load Route File";
      return;
    }

    PIPSocket::Address hostIP = 0;
    if( !host.IsEmpty() )
      hostIP = PIPSocket::Address( host );

    PString result;
    PStringToString routeParams;
    groomer.FindRoute( number, hostIP, result, routeParams );
    PError << "ROUTE: " << result << endl;
    PError << "PARAMS: " << routeParams << endl;
  }


};
PCREATE_PROCESS( Process );




