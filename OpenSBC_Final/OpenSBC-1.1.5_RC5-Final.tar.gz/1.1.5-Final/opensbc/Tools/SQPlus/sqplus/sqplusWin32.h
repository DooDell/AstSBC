#ifndef _SQ_PLUS_WIN32_H_
#define _SQ_PLUS_WIN32_H_

#include "sqplus.h"
#include "SquirrelBindingsUtilsWin32.h"

#endif //_SQ_PLUS_WIN32_H_