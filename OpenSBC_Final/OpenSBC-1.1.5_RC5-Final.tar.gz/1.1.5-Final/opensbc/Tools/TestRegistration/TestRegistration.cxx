#ifdef _DEBUG
//#include "vld.h"
#endif

#include <ptlib.h>
#include <ptclib/pxml.h>
#include <ptlib/sockets.h>
#include <SIPMessage.h>
#include <SIPUserAgent.h>

using namespace SIP;
using namespace SIPFSM;
using namespace SIPParser;
class TestRegistration;
class REGISTER;
class Process;

#define APP_VERSION "1.0.0-0"
#define UA_NAME "OSBC Registration Tester " APP_VERSION


class REGISTER : public SIPMessage, public SIPTransactionBypass
{
public:
  PString m_User;
  PString m_AuthUser;
  PString m_AuthPass;
  PString m_Domain;
  PString m_ContactURI;
  SIPURI m_Proxy;
  int m_Expires;
  TestRegistration * m_UA;
  PIPSocket::Address m_ListenerIP;
  WORD m_ListenerPort;
  SIPTransactionBypass * m_Scenario;
  PTimer m_RefreshTimer;
  PDECLARE_NOTIFIER( PTimer, REGISTER, OnSendRefresh );
  
  REGISTER( TestRegistration * ua, PXMLElement * account );
  ~REGISTER();
  BOOL Start();

  virtual void OnReceivedMessage(
    const SIPMessage & message,
    SIPTransaction * transaction
  );

  virtual void OnTimerExpire(
    SIPTimerEvent & timer,
    SIPTransaction * transaction
  );

  BOOL SendAuthenticator( const SIPMessage & response );
  void StartRefreshTimer( const SIPMessage & response );
  void StartRefreshTimer( int secs );
  BOOL SendRefresh();

};

class TestRegistration : public SIPUserAgent
{
public:
  SIPURI m_ListenerAddress;
  PString m_ScenarioXML;
  PIPSocket::Address m_ListenerIP;
  WORD m_ListenerPort;

  PLIST( RegSessions, SIPMessage );
  RegSessions m_RegSessions;

  TestRegistration( const SIPURI &listenerAddress, const PString & routeFile )
    : SIPUserAgent( UA_NAME )
  {
    m_ListenerAddress = listenerAddress;
    m_ScenarioXML = routeFile;
    m_ListenerIP = m_ListenerAddress.GetAddress();
    m_ListenerPort = (WORD)m_ListenerAddress.GetPort().AsUnsigned();
    if( m_ListenerPort == 0 )
      m_ListenerPort = 5060;

    m_RegSessions.DisallowDeleteObjects();
  }


  void ProcessEvent( SIPStackEvent * event )
  {
    if( event->GetType() == SIPStackEvent::UnknownTransaction )
    {
      SIPUnknownTransaction* evt = dynamic_cast<SIPUnknownTransaction*>(event);
      if( evt != NULL && evt->GetMessage().IsAck())
      {
        SIPMessage ack = evt->GetMessage();

        if( ack.HasRoute() && ack.GetRouteSize() > 0 )
        {
          SIPURI routeURI = ack.GetTopRouteURI();
          if( routeURI.GetAddress() == m_ListenerIP )
          {
            unsigned long routePort = routeURI.GetPort().AsUnsigned();
            if( routePort == 0 )
              routePort = 5060;
            if( routePort == m_ListenerPort )
            {
              ack.PopTopRouteURI();
            }
          }
        }

        TransportWrite( ack );
      }
    }
    
    delete event;
  }

  BOOL RunTest()
  {
   

    GetDefaultProfile().GetTransportProfile().EnableUDP( m_ListenerIP, m_ListenerPort );
    Initialize( );
    if( !StartTransportThreads() )
    {
      PError << "Unable to initialize listener at " << m_ListenerAddress << endl;
      dynamic_cast<SIPUserAgent *>(this)->Terminate();
      return FALSE;
    }

    PXML xml;
    if( !xml.LoadFile( m_ScenarioXML ) )
    {
      PError << "Unable to load XML Scenario file " << m_ScenarioXML << endl;
      dynamic_cast<SIPUserAgent *>(this)->Terminate();
      return FALSE;
    }

    int index = 0;
    for(;;)
    {
      PXMLElement * acct = xml.GetElement( "ACCOUNT", index++ );
      if( acct == NULL )
        break;


      REGISTER * msg = new REGISTER( this, acct );
      m_RegSessions.Append( dynamic_cast<SIPMessage*>(msg) );
      msg->Start();
       
    }
    return TRUE;
  }
  
  void TerminateSessions()
  {
    while( m_RegSessions.GetSize() > 0 )
    {
      REGISTER * msg = dynamic_cast<REGISTER *>(m_RegSessions.RemoveAt(0));
      delete msg;
    }
  }

};

class Scenario_Normal : public SIPTransactionBypass
{
  PCLASSINFO( Scenario_Normal, SIPTransactionBypass );
public:
  REGISTER & m_Reg;

  Scenario_Normal( REGISTER & reg ) : m_Reg( reg )
  {
  }

  void OnReceivedMessage(
    const SIPMessage & message,
    SIPTransaction * transaction
  )
  {
    if( message.IsResponse() )
    {
      switch( message.GetStatusCode() )
      {
        case( SIPMessage::Code401_Unauthorized ):
          m_Reg.SendAuthenticator( message );
          break;
        case( SIPMessage::Code200_Ok ):
          m_Reg.StartRefreshTimer( message );
          break;
        default:
          m_Reg.StartRefreshTimer( 10 );
          break;
      }
    }
  }

  void OnTimerExpire(
    SIPTimerEvent & timer,
    SIPTransaction * transaction
  )
  {
    m_Reg.StartRefreshTimer( 10 );
  }
};

REGISTER::REGISTER( TestRegistration * ua, PXMLElement * account )
{
  /*
  <ACCOUNT user="joegen" 
        auth-user="joegen" 
        auth-pass="joegen" 
        domain="testdomain.com" 
        proxy="sip:192.168.0.253:15070"
        expires="3600"
        scenario="normal"/>*/
  m_UA = ua;
  m_User = account->GetAttribute( "user" );
  m_AuthUser = account->GetAttribute( "auth-user" );
  m_AuthPass = account->GetAttribute( "auth-pass" );
  m_ContactURI = account->GetAttribute( "contact-uri" );
  m_Domain = account->GetAttribute( "domain" );
  m_Proxy = SIPURI( (const char *)account->GetAttribute( "proxy" ) );
  m_Expires = account->GetAttribute( "expires" ).AsInteger();
  m_ListenerIP = m_UA->m_ListenerIP;
  m_ListenerPort = m_UA->m_ListenerPort;
  m_Scenario = NULL;
  if( account->GetAttribute( "scenario" ) *= "normal" )
  {
    m_Scenario = new Scenario_Normal( *this ); 
  }
}

REGISTER::~REGISTER()
{
  delete m_Scenario;
}

BOOL REGISTER::Start()
{
  OStringStream msg;
  msg << "REGISTER " << "sip:" << m_User << "@" << m_Domain << " SIP/2.0" << "\r\n";
  msg << "From: <sip:" << m_User << "@" << m_Domain << ">" << ";tag=" << ParserTools::GenTagParameter() << "\r\n";
  msg << "To: <sip:" << m_User << "@" << m_Domain << ">" << "\r\n";
  msg << "Contact: " << "<" << m_ContactURI << ">;expires=" << m_Expires << "\r\n";
  msg << "Route: <" << m_Proxy << ">;lr" << "\r\n";
  msg << "Via:" << "SIP/2.0/UDP " << m_ListenerIP << ":" << m_ListenerPort << ";branch=" << ParserTools::GenBranchParameter() << "\r\n";
  msg << "CSeq: 1 REGISTER" << "\r\n";
  msg << "Call-ID: " << ParserTools::GenGUID() << "\r\n";
  msg << "Date: " << ParserTools::GetRFC1123Date() << "\r\n";
  msg << "Content-Length: 0" << "\r\n";
  msg << "User-Agent: " << UA_NAME << "\r\n";
  msg << "\r\n";
  Parse( msg.str() );

  m_UA->GetStack().FindTransactionAndAddEvent( *this, FALSE, 0, dynamic_cast<SIPTransactionBypass*>(this) );
  return this->IsValid();
}

void REGISTER::StartRefreshTimer( const SIPMessage & response )
{
  int expires = 0;
  for( int i = 0; i < response.GetContactSize(); i++ )
  {
    Contact c;
    response.GetContactAt( c, i );
    for( int j = 0; j < c.GetSize(); j++ )
    {
      ContactURI curi;
      c.GetURI( curi, j );
      if( curi.GetURI().AsString( FALSE ) *= m_ContactURI )
      {
        OString value;
        if( curi.GetParameter( "expires", value ) )
          expires = value.AsInteger();
        break;
      }
    }

    if( expires > 0 )
      break;
  }

  StartRefreshTimer( expires );
}

void REGISTER::StartRefreshTimer( int expires )
{
  if( expires > 0 )
  {
    m_RefreshTimer =  PTimer( 0, expires );
    m_RefreshTimer.SetNotifier( PCREATE_NOTIFIER( OnSendRefresh ) );
    m_RefreshTimer.Resume();
  }
}

void REGISTER::OnSendRefresh( PTimer &, INT )
{
  SendRefresh();
}

BOOL REGISTER::SendRefresh()
{
  Via via = GetTopVia();
  via.AddParameter( "branch", ParserTools::GenBranchParameter(), TRUE );
  SetViaAt( 0, via );

  IncrementCSeq();

  Date date( ParserTools::GetRFC1123Date() );
  SetDate( date );
  
  m_UA->GetStack().FindTransactionAndAddEvent( *this, FALSE, 0, dynamic_cast<SIPTransactionBypass*>(this) ); 
  
  return this->IsValid();
}

BOOL REGISTER::SendAuthenticator( const SIPMessage & challenge )
{
  WWWAuthenticate wwwAuth;
  if( !challenge.GetWWWAuthenticate( wwwAuth ) )
    return FALSE;

  OString realm;
  wwwAuth.GetParameter( "realm", realm );
  ParserTools::UnQuote( realm );
  OString nonce;
  wwwAuth.GetParameter( "nonce", nonce );
  ParserTools::UnQuote( nonce );

  MD5::A1Hash a1( m_AuthUser,realm, m_AuthPass );
  MD5::A2Hash a2( "REGISTER", GetRequestURI().AsString( FALSE ) );
  OString hResponse = MD5::MD5Authorization::Construct( a1.AsString(), nonce, a2.AsString() );

  OString opaque;
  wwwAuth.GetParameter( "opaque", opaque );
  ParserTools::UnQuote( opaque );

  Authorization authorization;
  authorization.SetLeadString( "Digest" );
  authorization.AddParameter( "username", ParserTools::Quote( m_AuthUser ) );
  authorization.AddParameter( "realm", ParserTools::Quote( realm ) );
  authorization.AddParameter( "nonce", ParserTools::Quote( nonce ) );
  authorization.AddParameter( "uri", ParserTools::Quote( GetRequestURI().AsString( FALSE ) ) );
  authorization.AddParameter( "response", ParserTools::Quote( hResponse ) );
  authorization.AddParameter( "opaque", ParserTools::Quote(opaque) );
  authorization.AddParameter( "algorithm", "MD5" );

  SetAuthorization( authorization );

  Via via = GetTopVia();
  via.AddParameter( "branch", ParserTools::GenBranchParameter(), TRUE );
  SetViaAt( 0, via );

  IncrementCSeq();
  
  TransactionId tid;
  m_UA->GetStack().FindTransactionAndAddEvent( *this, FALSE, 0, dynamic_cast<SIPTransactionBypass*>(this) ); 
  
  return this->IsValid();
}


void REGISTER::OnReceivedMessage(
  const SIPMessage & message,
  SIPTransaction * transaction
)
{
  m_Scenario->OnReceivedMessage( message, transaction );
}

void REGISTER::OnTimerExpire(
  SIPTimerEvent & timer,
  SIPTransaction * transaction
)
{
  m_Scenario->OnTimerExpire( timer, transaction );
}

class Process : public PProcess
{
  PCLASSINFO( Process, PProcess );
public:
  SIPURI m_ListenerAddress;
  PString m_ScenarioXML;
  PSyncPoint m_TermSync;

  void DisplayUsage()
  {
    PError << "usage:  -v|-h\n"
            "  -t                     Trace level.  Example -ttt means Log Level 3\n"
            "  -h --help              output this help message and exit\n"
            "  -v --version           display version information and exit\n"
            "  -p --pid-file          name or absolute path for pid file\n"
            "  -r --register-xml-file    name or absolute path for xml register file\n"
            "  -i --interface-address interface address to be used for listener in SIP URI format\n"
            "Example: ./TestRegistration -p pid.txt -r register.xml -i sip:192.168.0.253:5060\n";
  }

  void DisplayVersion()
  {
    PError << "Product Name: " << "OSBC Registration Tester" << endl
           << "Manufacturer: " << "opensipstack.org" << endl
           << "Version     : " << APP_VERSION << endl
           << "System      : " << GetOSName() << '-'
                             << GetOSHardware() << ' '
                             << GetOSVersion() << endl
           << "Release-Date: " << GetReleaseDate() << endl;
  }

  void DumpProcessId( const PFilePath & path )
  {
    PTextFile pidFile( path );
    if( pidFile.IsOpen() )
    {
      PString pid( GetProcessID() );
      pidFile.WriteString( pid );
    }
  }

  BOOL ParseArgs()
  {
    PArgList & args = GetArguments();
    args.Parse("t-trace-level."
               "v-version."
               "h-help."
               "p-pid-file:"
               "r-register-xml-file:"
               "i-interface-address:" );

    Logger::SetDefaultLevel( args.GetOptionCount( 't' ) );

    if( args.HasOption( 'h' ) )
    {
      DisplayUsage(); 
      return FALSE;
    }else if( args.HasOption( 'v' ) )
    {
      DisplayVersion();
      return FALSE;
    }

    
    if( args.HasOption( 'p' ) )
    {
      PString pidFile = args.GetOptionString( 'p' );
      DumpProcessId( pidFile );
    }

    if( !args.HasOption( 'i' ) )
    {
      PError << "Interface Address not specified!  Please set the -i flag" << endl;
      DisplayUsage();
      return FALSE;
    }else
    {
      m_ListenerAddress = args.GetOptionString( 'i' );
    }

    if( !args.HasOption( 'r' ) )
    {
      PError << "Route XML file not specified!  Please set the -r flag" << endl;
      DisplayUsage();
      return FALSE;
    }

    m_ScenarioXML = args.GetOptionString( 'r' );

    return TRUE;
  }

  void Main()
  {
    if( !ParseArgs() )
      return;

    TestRegistration tester( m_ListenerAddress, m_ScenarioXML );
    if( tester.RunTest() )
    {
      while( !m_TermSync.Wait( 500 ) );
    }

    Sleep( 8000 );
    tester.Terminate();
    Sleep( 5000 );
    tester.TerminateSessions();

  }
};

PCREATE_PROCESS( Process );



