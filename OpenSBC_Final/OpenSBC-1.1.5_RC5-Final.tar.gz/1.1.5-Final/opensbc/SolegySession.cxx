/*
 *
 * SolegySession.cxx
 *
 * Open SIP Stack ( OSS )
 *
 * Copyright (c) opensipstack.org.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either expressed or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is OpenSIPStack.
 *
 * The Initial Developer of the Original Code is opensipstack.org.
 *
 * The author of this code is Joegen E. Baclor
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * The OpenSIPStack Library includes some GPL/LGPL code libraries that MAY be 
 * enabled at compile time using the --enable-gpllibs configure switch.  If
 * enabled, the content of this file is published under the terms of GNU 
 * General Public License Version 2.  For a detailed list of the available
 * GPL code, see $(opensipstack)/gnu/README file.
 *
 *
 */

#include "Solegy.h"
#include "SolegySession.h"
#include "OpenSBC.h"
#include "Nonce.h"

using namespace SOLEGY;


#define new PNEW
#define HEADER_PAYLOAD_MAX_SIZE 2048
#define MAX_START_RETRY 2

using namespace SIPParser;

static OString GenGUID( const PIPSocket::Address & localAddress, const PIPSocket::Address & remoteAddress)
{
  // Want time of UTC in 0.1 microseconds since 15 Oct 1582.
  PInt64 TimeStamp;
  static PInt64 deltaTime = PInt64(10000000)*24*60*60*
                            (  16            // Days from 15th October
                             + 31            // Days in December 1583
                             + 30            // Days in November 1583
#ifdef _WIN32
                             + (1601-1583)*365   // Whole years
                             + (1601-1583)/4);   // Leap days

  // Get nanoseconds since 1601
#ifndef _WIN32_WCE
  GetSystemTimeAsFileTime((LPFILETIME)&TimeStamp);
#else
  SYSTEMTIME SystemTime;
  GetSystemTime(&SystemTime);
  SystemTimeToFileTime(&SystemTime, (LPFILETIME)&TimeStamp);
#endif // _WIN32_WCE

  TimeStamp /= 100;
#else // _WIN32
                             + (1970-1583)*365 // Days in years
                             + (1970-1583)/4   // Leap days
                             - 3);             // Allow for 1700, 1800, 1900 not leap years

#ifdef P_VXWORKS
  struct timespec ts;
  clock_gettime(0,&ts);
  TimeStamp = (ts.tv_sec*(PInt64)1000000 + ts.tv_nsec*1000)*10;
#else
  struct timeval tv;
  gettimeofday(&tv, NULL);
  TimeStamp = (tv.tv_sec*(PInt64)1000000 + tv.tv_usec)*10;
#endif // P_VXWORKS
#endif // _WIN32

  TimeStamp += deltaTime;

  PBYTEArray guidArray(16);
  guidArray[0] = localAddress.Byte1();
  guidArray[1] = localAddress.Byte2();
  guidArray[2] = localAddress.Byte3();
  guidArray[3] = localAddress.Byte4();
  guidArray[4] = remoteAddress.Byte1();
  guidArray[5] = remoteAddress.Byte2();
  guidArray[6] = remoteAddress.Byte3();
  guidArray[7] = remoteAddress.Byte4();
  guidArray[8] = (BYTE)(TimeStamp&0xff);
  guidArray[9] = (BYTE)((TimeStamp>>8)&0xff);
  guidArray[10] = (BYTE)((TimeStamp>>16)&0xff);
  guidArray[11] = (BYTE)((TimeStamp>>24)&0xff);
  guidArray[12] = (BYTE)((TimeStamp>>32)&0xff);
  guidArray[13] = (BYTE)((TimeStamp>>40)&0xff);
  guidArray[14] = (BYTE)((TimeStamp>>48)&0xff);
  guidArray[15] = (BYTE)(((TimeStamp>>56)&0x0f) + 0x10);

  OStringStream strm;
  char fillchar = strm.fill();
  strm << hex << setfill('0')
       << setw(2) << (unsigned)(BYTE)guidArray[0]
       << setw(2) << (unsigned)(BYTE)guidArray[1]
       << setw(2) << (unsigned)(BYTE)guidArray[2]
       << setw(2) << (unsigned)(BYTE)guidArray[3]
       << setw(2) << (unsigned)(BYTE)guidArray[4]
       << setw(2) << (unsigned)(BYTE)guidArray[5]
       << setw(2) << (unsigned)(BYTE)guidArray[6]
       << setw(2) << (unsigned)(BYTE)guidArray[7]
       << setw(2) << (unsigned)(BYTE)guidArray[8]
       << setw(2) << (unsigned)(BYTE)guidArray[9]
       << setw(2) << (unsigned)(BYTE)guidArray[10]
       << setw(2) << (unsigned)(BYTE)guidArray[11]
       << setw(2) << (unsigned)(BYTE)guidArray[12]
       << setw(2) << (unsigned)(BYTE)guidArray[13]
       << setw(2) << (unsigned)(BYTE)guidArray[14]
       << setw(2) << (unsigned)(BYTE)guidArray[15]
       << dec << setfill(fillchar);

  return strm.str();
}

#define RTTS_LOG( detail ) \
{ \
  if( m_B2BUAConnection != NULL ) \
  LOG( m_B2BUAConnection->LogInfo(), "=== RTTS: " << detail ); \
}

SolegySession::SolegySession( 
  SolegySessionManager * manager,
  SolegySocket * socket,
  B2BUAConnection * sipConnection,
  const char * localSessionId,
  BOOL accountingOff,
  BOOL ignoreRouting
)
{
  m_SessionManager = manager;
  m_SIPConnectionReference = GCCREATEREF( sipConnection, "SolegySession ", "B2BUAConnection" );
  m_B2BUAConnection = dynamic_cast<SBCConnection *>( m_SIPConnectionReference.GetObject() );
  m_Socket = socket;
  m_Sequence = 0;
  m_RetryTimerInterval = 500;
  m_ErrorRetryTimerInterval = ERROR_RETRY_INTERVAL;
  m_LocalSessionId = localSessionId;
  PIPSocket::Address localAddress = m_SessionManager->GetRTTSClientAddress();
  PIPSocket::Address remoteAddress = m_Socket->GetRTTSSeverAddress();
  m_RemoteSessionId = GenGUID( localAddress, remoteAddress );
  m_MaxStartRetryCount = 0;
  m_EnableDigestProcessing = FALSE;
  m_State = START;
  m_LastErrorState = NONE;
  m_IsCallStopPending = FALSE;
  m_SendStopOnCallStopEvent = FALSE;
  m_AccountingOff = accountingOff;
  m_IgnoreRouting = ignoreRouting;
  m_CallDuration = 0;
  m_RingDuration = 0;
  m_CallDuration = 0;
  m_CanSendCallStop = FALSE;
  m_BillingVector = NULL;
  m_RoutingVector = NULL;
  m_AbortRetry = FALSE;
  m_HasReceivedSTART = FALSE;

  m_FailoverCount = 0;
  m_CurrentRouteIndex = 0;
  
  LOG( sipConnection->LogDebug(), "RTTS: " << "*** SOLEGY SESSION CREATED ***" );
}

SolegySession::~SolegySession()
{
  delete m_BillingVector;
  delete m_RoutingVector; 
  if( m_B2BUAConnection != NULL  )
  {
    LOG( m_B2BUAConnection->LogInfo(), "*** SOLEGY SESSION DESTROYED ***"  );
    m_B2BUAConnection->AttachCallController( NULL );
    m_B2BUAConnection->EnqueueSessionEvent( new SIPSessionEvent( *m_B2BUAConnection, B2BUAConnection::DestroySession, m_STOPMessage ) );
    m_B2BUAConnection = NULL;
  }
}

BOOL SolegySession::SetupInbound( const  SIPMessage & invite )
{
  m_CurrentInboundInvite = invite;
  
  if( m_State == AUTH )
  {
    if( m_EnableAuth == "1" )
      return AuthenticateInbound( invite );
  }

  return TRUE;
}

BOOL SolegySession::AuthenticateInbound( const SIPMessage & request )
{
  
  if( request.HasProxyAuthorization() )
  {
    return TRUE;
  }else
  {
    RTTS_LOG( "Authenticating Inbound INVITE" );
    //MD5::Nonce opaque;
    MD5::Nonce nonce;

    SIPParser::From from;
    OString host = request.GetFrom().GetURI().GetHost();

    
    PIPSocket::Address iface;
    WORD ifacePort = 5060;
    GetB2BUAConnection()->GetTransportManager()->GetUDPTransport()->GetListenerAddress( request.GetSourceAddress(), iface, ifacePort );
    

    ProxyAuthenticate proxyAuthenticate;
    proxyAuthenticate.SetLeadString( "Digest" );
    proxyAuthenticate.AddParameter( "realm", ParserTools::Quote( host ) );
    proxyAuthenticate.AddParameter( "algorithm", "MD5" );
    OStringStream opaqueValue;
    opaqueValue << "sip:" << iface << ":" << ifacePort << "-" << nonce.AsString();
    proxyAuthenticate.AddParameter( "nonce", ParserTools::Quote(opaqueValue.str()));

    if( m_B2BUAConnection != NULL && m_B2BUAConnection->IsSafeReference() )
    {
      m_State = AUTHPENDING;
      m_B2BUAConnection->SetLocallyAuthenticated();
      m_B2BUAConnection->SetSessionState( B2BUAConnection::LocalAuthenticationPending );
      /// Stop the application timers to make sure they dont fire when we are in RemoteAuthenticationPending state
      //m_B2BUAConnection->StopSeizeTimer();
      //m_B2BUAConnection->StopAlertingTimer();
      /// start the auto destructor timer at the value of Timer B
      m_B2BUAConnection->StartAutoDestructTimer( 32000 );
      
      SIPMessage authChallenge;
      request.CreateResponse( authChallenge, 
      SIPMessage::Code407_ProxyAuthenticationRequired );
      authChallenge.SetProxyAuthenticate( proxyAuthenticate );
      m_B2BUAConnection->GetLeg1Call()->SendRequest( authChallenge, request.GetTransaction() );
    }
  }
  return TRUE;
}

void SolegySession::SetupOutbound( SIPMessage & invite )
{
  PWaitAndSignal lock( m_RTBERouteListMutex );

  invite.SetXBillingVector( NULL );
  invite.SetXRoutingVector( NULL );

  if( m_State == RESET )
  {
    SIPURI rURI = invite.GetRequestURI();
    if( m_B2BUAConnection != NULL && m_B2BUAConnection->IsSafeReference() )
    {
      m_B2BUAConnection->RemoveRoutes();
      m_B2BUAConnection->AddRoute( rURI );
    }
    return;
  }

  if( m_State != SETUP )
    return;

  int count = m_RTBERouteList.GetSize();
  if( count == 0 )
    return;

  m_RTBERouteList.DisallowDeleteObjects();
  SIPMessage * route = (SIPMessage *)m_RTBERouteList.RemoveAt(0);
  m_RTBERouteList.AllowDeleteObjects();
  if( route != NULL )
  {
    OString accountingOff = route->GetInternalHeader( "rtts-call-accounting" );
    if( accountingOff == "off" )
      m_AccountingOff = TRUE;
    else
      m_AccountingOff = FALSE;

    SIPURI rURI = route->GetRequestURI();
    const SIPURI &  fURI = route->GetFromURI();

    RTTS_LOG( "Route -> " <<  rURI);

    invite.SetRequestURI( rURI );
    invite.SetFromURI( fURI );
#if 0
    SIPURI toURI = invite.GetTo().GetURI();
    toURI.SetUser( rURI.GetUser() );
    invite.SetToURI( toURI );
#else
    invite.SetToURI( rURI );
#endif

    OString cnamHeader;
    cnamHeader = route->GetInternalHeader( "CNAM" );
    if( !cnamHeader.IsEmpty() )
    {
      From from = invite.GetFrom();
      OStringStream cnam;
      RTTS_LOG( "Setting CNAM - " <<  cnamHeader);
      cnam << '"' << cnamHeader << '"';
      from.SetDisplayName( cnam.str() );
      invite.SetFrom( from );
    }

    

    if( m_B2BUAConnection != NULL && m_B2BUAConnection->IsSafeReference() )
    {
      m_B2BUAConnection->RemoveRoutes();
      m_B2BUAConnection->AddRoute( rURI );

      OString routeSet;
      routeSet = route->GetInternalHeader( "ROUTE-SET" );
      m_B2BUAConnection->SetOutboundRouteSet( routeSet );
    }
    delete route;
  }


  m_SessionManager->ValidateRegisteredRoute( invite );

  m_CurrentOutboundInvite = invite;
  m_CallStartTime = m_CallTryingTime = PTime();
}

BOOL SolegySession::Start( const SIPMessage & msg )
{
  m_SessionManager->EnqueueConnectionEvent( 
    new SolegySessionManager::ConnectionEvent( 
    SolegySessionManager::ConnectionEvent::START,
    msg, this ) ); 
  return TRUE;
}

BOOL SolegySession::InternalStart( const SIPMessage & msg )
{
  XBillingVector * billingVector = msg.GetXBillingVector();
  XRoutingVector * routingVector = msg.GetXRoutingVector();

  if( billingVector != NULL && routingVector != NULL )
  {
    State oldState = m_State;
    m_State = SETUP;

    m_BillingVector = (XBillingVector*)billingVector->Clone();
    m_RoutingVector = (XRoutingVector*)routingVector->Clone();
    
    m_ORIGSDP = msg.GetBody();

    m_LocalSessionId = msg.GetCallId();
    m_RemoteSessionId = msg.GetTopVia().GetBranch();
    OString seq;
    m_BillingVector->GetParameter( "SEQ", seq );
    m_Sequence = (WORD)seq.AsInteger();

    //BSID=WS:sip:70.42.72.53/ani=777;SEQ=4;BCTLFT=60;BLFT=1;BBLFT=1;TLFT=60
    m_BillingVector->GetParameter( "BBLFT", m_BASICBLOCKSLEFT );
    m_BillingVector->GetParameter( "BCTLFT", m_BASICCHARGETIMELEFT );
    m_BillingVector->GetParameter( "TLFT", m_TIMELEFT );

    if( SolegyParser::ParseRouteVector( msg, m_RTBERouteList ) )\
    {
      CallConnect();
      return TRUE;
    }

    m_State = oldState;
  }



  if( m_State == START )
  {
    /// check the host early and se if its banned
    const Via &via = msg.GetTopVia();
    if( !m_SessionManager->IsLBHost( via.GetURI() ) )
    {
      m_HOST = via.GetReceiveAddress().AsString();
    }else
    {
      if( msg.GetViaSize() > 1 )
      {
        Via via2;
        msg.GetViaAt( 1, via2 );
        m_HOST = via2.GetReceiveAddress().AsString();
      }else
      {
        m_HOST = via.GetReceiveAddress().AsString();
      }
    }

    /// check if this host is banned temporarily becasue of no funds
    {
      PWaitAndSignal lock(m_SessionManager->m_NoFundHostListMutex);
      OString banId = m_HOST + msg.GetRequestURI().GetUser().Left(5);
      PTime * banStartTime = m_SessionManager->m_NoFundHostList.GetAt( banId.c_str() ); 
      if( banStartTime != NULL )
      {
        PTime now;
        if( now.GetTimeInSeconds() - banStartTime->GetTimeInSeconds() < (60 * 15) )
        {
          /// Reject the call here.
          CallDisconnect( "Your Account Has No Funds Left" );
          return FALSE;
        }else
        {
          /// Ban has graduated
          m_SessionManager->m_NoFundHostList.RemoveAt( banId.c_str() );
        }
      }
    }

    m_SessionManager->EnqueueEvent( "SendSTART", this );
    return TRUE;
  }else if( m_State == AUTHPENDING )
  {
    m_SessionManager->EnqueueEvent( "SendSIGNIN", this );
    return TRUE;
  }
  return FALSE;
}

BOOL SolegySession::Stop( const SIPMessage & msg )
{
#if 0
  m_SessionManager->EnqueueConnectionEvent( 
    new SolegySessionManager::ConnectionEvent( 
    SolegySessionManager::ConnectionEvent::STOP,
    msg, this ) );
#else
  if( m_B2BUAConnection != NULL  )
  {
    if( m_State == TERMINATED )
      return TRUE;

    m_B2BUAConnection->EnqueueSessionEvent(
      new SIPSessionEvent( *m_B2BUAConnection, SBCConnection::Event_OnSendAccountingStop, msg )
    );
  }
#endif
  return TRUE;
}

BOOL SolegySession::InternalStop( const SIPMessage & msg  )
{ 
  m_STOPMessage = msg;
  OString error;
  /*if( m_State == NO_RESOURCE || !m_HasReceivedSTART )
  {
    m_CallTimer.Stop();
    m_CallWarningTimer.Stop();
    m_AutoDestructTimer.Stop();
    StopErrorRetryTimer();
    m_State = TERMINATED;
    m_SessionManager->EnqueueEvent( "TERMINATE", this );
    return TRUE;
  }else */if( m_State > AUTH && m_State < CALLSTART && m_LastErrorState == NONE )
  {
    SolegyParser::RTTSError rttsError = SolegyParser::ErrorAbandoned;
    if( msg.IsResponse() || msg.GetStatusCode() >= 400 )
       rttsError = SolegyParser::ConvertSIPToRTTSError( msg );
    error = SolegyParser::ConvertRTTSErrorToString( rttsError );
    OnDumpCallAuditTrail();
  }

  /// We do not want to mutex this function to 
  /// avoid collisions between the SIP and RTTS layers
  /// Instead we just make sure that SendSTOP() gets called no matter what
  m_AutoDestructTimer = PTimer( 5000 );
  m_AutoDestructTimer.SetNotifier( PCREATE_NOTIFIER( OnAutoDestructTimer ) );
  m_AutoDestructTimer.Resume();

  if( !m_IsCallStopPending && m_State != CALLSTART )
  {
    m_STOPErrorString = error;
    m_SessionManager->EnqueueEvent( "SendSTOP", this );
  }else if( m_IsCallStopPending )
  {
    LOG( m_B2BUAConnection->LogInfo(), "=== RTTS: " << "CALL-STOP still sending.  Delaying STOP until CALLSTOP completes" );
    m_SendStopOnCallStopEvent = TRUE;
  }else
  {
    LOG( m_B2BUAConnection->LogInfo(), "=== RTTS: " << "CALL-STOP needs to be sent.  Delaying STOP until CALLSTOP completes" );
    m_SendStopOnCallStopEvent = TRUE;
    m_SessionManager->EnqueueEvent( "SendCALLSTOP", this );
  }

  LOG( m_B2BUAConnection->LogInfo(), "=== RTTS: " << "STOP routine queued with status code=[" << error << "]" );
  return TRUE;
}

void SolegySession::PrepareHeader( OStringStream & strm )
{
  strm << "SESSION-ID=" << m_RemoteSessionId << endl
  << "LOCALID=" << m_LocalSessionId << endl
  << "SEQ=" << m_Sequence << endl << endl;
}

BOOL SolegySession::WritePacket( BOOL isError )
{
  //PWaitAndSignal lock1( m_PacketQueueMutex );
  if( m_Socket == NULL )
    return FALSE;

  OString packet;
  if( isError )
    packet = m_CurrentErrorPacket;
  else
    packet = m_CurrentPacket;


  if( packet.IsEmpty() )
    return FALSE;

  B2BUAConnection * conn = GetB2BUAConnection();
  if( conn != NULL )
  {
    PIPSocket::Address remoteAddress = m_Socket->GetRTTSSeverAddress();
    WORD remotePort = m_Socket->GetRTTSServerPort();

    PIPSocket::Address localAddress;
    WORD localPort = 0;
    m_Socket->GetSocket()->GetLocalAddress( localAddress, localPort );
    
    char method[256];
    memset( method, '\0', 256 );
    const char * bytes = packet.c_str();
    size_t len = packet.GetLength();
    for( size_t i = 0; i < len && i < 256 && bytes[i] != '\n' && bytes[i] != '\r'; i++ )
      method[i] = bytes[i];
    
    OStringStream traceStream;
    traceStream <<  ">>> RTTS: " 
      << method << " "; 
      
    traceStream  << localAddress << ":" << localPort << "->";
    traceStream  << remoteAddress << ":" << remotePort;
    traceStream  << " enc=0" << " bytes=" <<  (unsigned)packet.length();

    OStringStream strPacket;
    strPacket << packet;

    COMPOUND_LOG( conn->LogInfo(), traceStream.str(), conn->LogDebugHigh(), strPacket );
  }

  return m_Socket->Write( packet );
}

BOOL SolegySession::SendSTART()
{
  //PWaitAndSignal lock( m_PacketQueueMutex );

  if( m_State == STOP )
    return FALSE;

  m_State = START;
  OStringStream strm;
  strm << "START" << endl;
  PrepareHeader( strm );
  m_CurrentPacket = strm.str();
  WritePacket();
  StartRetryTimer( 3000 );

  return TRUE;
}

BOOL SolegySession::SendSTARTFailover()
{
  //PWaitAndSignal lock( m_SocketMutex );
  if( ++m_MaxStartRetryCount <= MAX_START_RETRY )
  {
    m_Socket = this->m_SessionManager->GetNextAvailableTransport();
    if( m_Socket == NULL )
      return FALSE;
#if 0 /// RTTS currently do not support SEQ other than ZERO in START packet
    m_Sequence++;
#endif
    RTTS_LOG( "Executing START Failover" );
    m_SessionManager->EnqueueEvent( "SendSTART", this );
    return TRUE;
  }

  return FALSE;
}

void SolegySession::OnAutoDestructTimer( PTimer &, INT )
{
  m_SessionManager->EnqueueEvent( "SendSTOP", this );
}

BOOL SolegySession::SendSTOP()
{
  RTTS_LOG( "Starting STOP Procedure" );
  //PWaitAndSignal lock( m_PacketQueueMutex );
 
  if( m_State >= STOP )
  {
    RTTS_LOG( "Ignoring STOP command.  State is already STOP." );
    return FALSE;
  }

  BOOL sendPacket = (m_State != NO_RESOURCE && m_HasReceivedSTART);

 
  m_State = STOP;
  m_CallTimer.Stop();
  m_CallWarningTimer.Stop();
  m_AutoDestructTimer.Stop();
  StopErrorRetryTimer();

  if( sendPacket )
  {
    OStringStream strm;
    strm << "STOP" << endl;
    PrepareHeader( strm );

    if( m_ErrorRouteList.GetSize() > 0 )
    {
      strm << "ROUTE-ERROR=";
      for( PINDEX i = 0; i < m_ErrorRouteList.GetSize(); i++ )
      {
        strm << m_ErrorRouteList[i];
        if( i + 1 < m_ErrorRouteList.GetSize() )
          strm << ",";
      }
    }

    m_CurrentPacket = strm.str();
  }else
  {
    m_CurrentPacket = "";
  }

  /// Just start the retry timer even if sendPAcket is false
  /// since we call TERMINATE on retry timeout
  StartRetryTimer( 3000 );
  StopErrorRetryTimer();

  if( sendPacket )
    WritePacket();

  return TRUE;
}

BOOL SolegySession::SendAUTH()
{
  //PWaitAndSignal lock( m_PacketQueueMutex );

  if( m_State == STOP )
    return FALSE;

  m_CanSendCallStop = FALSE;
  m_State = AUTH;
  OStringStream strm;
  strm << "AUTH" << endl;
  PrepareHeader( strm );

  if( !OnPrepareAUTHInfo( strm ) )
    return FALSE;

  m_CurrentPacket = strm.str();
  WritePacket();
  StartRetryTimer( AUTH_TIMEOUT );

  return TRUE;
}

BOOL SolegySession::OnPrepareAUTHInfo( 
  OStringStream & strm 
)
{
  OString domain, user, dialString;
  if( m_B2BUAConnection != NULL && m_B2BUAConnection->IsSafeReference() )
  {
    const SIPMessage & invite = m_B2BUAConnection->GetCallArrivalQueue().GetMessage();

    /************************************************************/
    //detect spoofed host
    const char * sdomain = invite.GetFromURI().GetHost().c_str();
    const char * svia = invite.GetBottomVia().GetAddress().c_str();
    PIPSocket::Address viaIP( svia );
    PIPSocket::Address hostIP( sdomain );
    
    m_SessionManager->m_FraudDetector->ProcessHostSpoofing( invite );

    /************************************************************/

    const Via &via = invite.GetTopVia();
    
    if( m_HOST.IsEmpty() )
    {
      if( !m_SessionManager->IsLBHost( via.GetURI() ) )
      {
        m_HOST = via.GetReceiveAddress().AsString();
      }else
      {
        if( invite.GetViaSize() > 1 )
        {
          Via via2;
          invite.GetViaAt( 1, via2 );
          m_HOST = via2.GetReceiveAddress().AsString();
        }else
        {
          m_HOST = via.GetReceiveAddress().AsString();
        }
      }
    }

    strm << "HOST=sip:" << m_HOST << endl;
    
    SIPURI rURI;
    invite.GetRequestURI(rURI);
    dialString = rURI.GetUser();
    strm << "DNIS=" << dialString << endl;

    if( !invite.HasPAssertedIdentity() )
    {
      user = invite.GetFromURI().GetUser();
      strm << "ANI=" << user << endl;
      domain = invite.GetFromURI().GetHost();
      strm << "DOMAIN=sip:" << domain << endl; 
    }else
    {
      PAssertedIdentity pai = invite.GetPAssertedIdentityAt(0);
      ContactURI paiURI;
      pai.GetURI( paiURI );
      user = paiURI.GetURI().GetUser();
      strm << "ANI=" << user << endl;
      domain = paiURI.GetURI().GetHost();
      strm << "DOMAIN=sip:" << domain << endl; 
    }

    m_ORIGSDP = invite.GetBody();
  }

  LOG( m_B2BUAConnection->LogInfo(),  "=== RTTS: AUTH " << "<" << domain  << "/" << m_HOST << "> " << user << "<->" << dialString );

  return TRUE;
}

BOOL SolegySession::SendSIGNIN()
{
  //PWaitAndSignal lock( m_PacketQueueMutex );

  if( m_State == STOP )
    return FALSE;

  OStringStream strm;
  strm << "SIGNIN" << endl;
  PrepareHeader( strm );

  OnPrepareSIGNINInfo( strm );

  m_CanSendCallStop = FALSE;
  m_State = SIGNIN;
  m_CurrentPacket = strm.str();
  WritePacket();
  StartRetryTimer( SIGNIN_TIMEOUT );

  return TRUE;
}

BOOL SolegySession::OnPrepareSIGNINInfo(
  OStringStream & /*strm*/
)
{
  return FALSE;
}

BOOL SolegySession::SendSETUP()
{
  //PWaitAndSignal lock( m_PacketQueueMutex );

  if( m_State == STOP )
    return FALSE;

  m_CanSendCallStop = FALSE;
  m_State = SETUP;
  OStringStream strm;
  strm << "SETUP" << endl;
  PrepareHeader( strm );

  OnPrepareSETUPInfo( strm );
  {
    PWaitAndSignal lock( m_RTBERouteListMutex );
    m_RTBERouteList.RemoveAll();
  }

  m_CurrentRouteIndex = 0;
  m_CurrentPacket = strm.str();
  WritePacket();
  StartRetryTimer( SETUP_TIMEOUT );

  return TRUE;
}

BOOL SolegySession::OnPrepareSETUPInfo(
  OStringStream & /*strm*/
)
{
  return FALSE;
}

static PString GetSafeFileName( const SIPMessage & msg )
{
  PString xlat( msg.GetCallId().c_str() );
  static const char * safeChars = "abcdefghijklmnopqrstuvwxyz"
                          "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
                          "0123456789@.";
  PINDEX pos = (PINDEX)-1;
  while ((pos += (int)(1+strspn(&xlat[pos+1], safeChars))) < xlat.GetLength())
    xlat.Splice(psprintf("%%%02X", (BYTE)xlat[pos]), pos, 1);
  return xlat;
}

void SolegySession::DumpCallState()
{
  /// Preserve dialog state cookie just in case of restart
  SIPMessage leg1Bye, leg2Bye;
  m_B2BUAConnection->GetLeg1Call()->CreateRequestWithinDialog( SIPMessage::Method_BYE, leg1Bye );
  CSeq cseq1( "BYE", leg1Bye.GetCSeqNumber() + 100 );
  leg1Bye.SetCSeq( cseq1 );

  if( m_B2BUAConnection->GetLeg2Call() == NULL )
    return;

  m_B2BUAConnection->GetLeg2Call()->CreateRequestWithinDialog( SIPMessage::Method_BYE, leg2Bye );
  CSeq cseq2( "BYE", leg2Bye.GetCSeqNumber() + 100 );
  leg2Bye.SetCSeq( cseq2 );
  PTime now;
  OStringStream stop;
  stop	<< "CALLSTOP" << endl
        << "SESSION-ID=" << m_RemoteSessionId << endl
		    << "LOCALID=" << m_LocalSessionId << endl
        << "SEQ=" << m_Sequence + 1 << endl << endl
		    << "CALL-START-TIME=" << now.GetTimeInSeconds() << endl
        << "RTTS-SERVER-ADDR=" << m_Socket->GetRTTSSeverAddress() << endl 
        << "RTTS-SERVER-PORT=" << m_Socket->GetRTTSServerPort() << endl;

  m_StateFile = this->m_SessionManager->m_RTTSStateDIR + "/" + GetSafeFileName( leg1Bye );
  PTextFile stateFile( m_StateFile, PFile::ReadWrite );
  if( stateFile.IsOpen() )
  {
    stateFile.WriteString( leg1Bye.AsString().c_str() ); 
    stateFile.WriteLine( "-*-*-" );
    stateFile.WriteString( leg2Bye.AsString().c_str() );
    stateFile.WriteLine( "-*-*-" );
    stateFile.WriteString( stop.str().c_str() );
    stateFile.WriteLine( "-*-*-" );
  }
  stateFile.Close();
}

void SolegySession::RemoveCallState()
{
  PFile::Remove( m_StateFile, TRUE );
}

BOOL SolegySession::SendCALLSTART()
{
  //PWaitAndSignal packetmutex( m_PacketQueueMutex );
  PWaitAndSignal timerMutex( m_TimerMutex );

 
  if( m_State == STOP || m_State < SETUP )
  {
    RTTS_LOG( "*** CALL-START ABORT *** Wrong State =" << m_State );
    return FALSE;
  }

  m_CanSendCallStop = TRUE;
  m_State = CALLSTART;

  m_CallStartTime = PTime();
  PTimeInterval diff = m_CallStartTime - m_CallTryingTime;
  m_RingDuration = diff.GetInterval()/1000;

  m_CallTimer.Stop();
  m_CallWarningTimer.Stop();

  SolegyParser::ParseHeader( "BASICCHARGETIMELEFT", m_BASICCHARGETIMELEFT, m_SETUPResponse ); 

  PTimeInterval chargeTime;
  if( m_BASICCHARGETIMELEFT.Find( "E" ) != P_MAX_INDEX )
  {
     if( SolegyParser::ParseHeader( "TIMELEFT", m_TIMELEFT, m_SETUPResponse ) )
        chargeTime = PTimeInterval( 0, m_TIMELEFT.AsInteger() );
  }else if( !m_BASICCHARGETIMELEFT.IsEmpty() )
  {
    chargeTime = PTimeInterval( 0, m_BASICCHARGETIMELEFT.AsInteger() );
  }else
  {
    if( SolegyParser::ParseHeader( "TIMELEFT", m_TIMELEFT, m_SETUPResponse ) )
        chargeTime = PTimeInterval( 0, m_TIMELEFT.AsInteger() );
  }

  if( chargeTime.GetSeconds() < 10 )
  {
    chargeTime = PTimeInterval( 0, 10 );
  }
  
  m_CallTimer = PTimer( chargeTime );
  m_CallTimer.SetNotifier( PCREATE_NOTIFIER( OnCallTimerExpire ) );
  m_CallTimer.Resume();
  LOG( m_B2BUAConnection->LogInfo(), "=== RTTS: Call-Timer=" << chargeTime.GetSeconds() << " seconds" );

  if( chargeTime.GetSeconds() > 60 )
  {
    m_CallWarningTimer = PTimer( (long)(chargeTime.GetMilliSeconds() - 60000) );
    m_CallWarningTimer.SetNotifier( PCREATE_NOTIFIER( OnCallWarningTimerExpire ) );
    m_CallWarningTimer.Resume();
  }
  
  DumpCallState();
  
  OStringStream strm;
  strm << "CALLSTART" << endl;
  PrepareHeader( strm );
  OnPrepareCALLSTARTInfo( strm );
  m_CurrentPacket = strm.str();
  WritePacket();
  StartRetryTimer( CALLSTART_TIMEOUT );

  return TRUE;
}

void SolegySession::OnCallTimerExpire( PTimer &, INT )
{
  if( m_B2BUAConnection != NULL && m_B2BUAConnection->IsSafeReference())
  {
    LOG( m_B2BUAConnection->LogInfo(), "RTTS:  Maximum Call Time Exceeded!" );
  }
  CallDisconnect( "RTTS-8012 Call Time Exceeded" );
}

void SolegySession::OnCallWarningTimerExpire( PTimer &, INT )
{
  if( m_B2BUAConnection != NULL && m_B2BUAConnection->IsSafeReference() )
  {
    LOG( m_B2BUAConnection->LogInfo(), "RTTS:  Sending CALL WARNING Beep via INFO " );
    m_B2BUAConnection->GetLeg1Call()->SendINFODTMF( "1", 160 );
  }
}

BOOL SolegySession::OnPrepareCALLSTARTInfo(
  OStringStream & strm
)
{ 
  if( m_B2BUAConnection != NULL && m_B2BUAConnection->IsSafeReference() )
  {
    SolegyParser::ParseMediaAttributes(
      m_ORIGSDP,//m_B2BUAConnection->GetLeg1SDP(),
      m_B2BUAConnection->GetLeg1TranslatedSDP(),
      m_B2BUAConnection->GetLeg2SDP(),
      m_B2BUAConnection->GetLeg2TranslatedSDP(),
      m_ORIGMEDIACODEC,
      m_ORIGMEDIADSTADDRESS,
      m_ORIGMEDIASRCADDRESS,
      m_TERMMEDIACODEC,
      m_TERMMEDIADSTADDRESS,
      m_TERMMEDIASRCADDRESS
    );
  }

  strm << "TERMINATINGHOST=" << (m_CurrentRouteIndex + 1) << endl;
  strm << "ORIGMEDIACODEC=" << m_ORIGMEDIACODEC << endl;
  strm << "ORIGMEDIADSTADDRESS=" << m_ORIGMEDIADSTADDRESS << endl;
  strm << "ORIGMEDIASRCADDRESS=" << m_ORIGMEDIASRCADDRESS << endl;
  strm << "TERMMEDIACODEC=" << m_TERMMEDIACODEC << endl;
  strm << "TERMMEDIADSTADDRESS=" << m_TERMMEDIADSTADDRESS << endl;
  strm << "TERMMEDIASRCADDRESS=" << m_TERMMEDIASRCADDRESS << endl;

  if( m_ErrorRouteList.GetSize() > 0 )
  {
    strm << "ROUTE-ERROR=";
    for( PINDEX i = 0; i < m_ErrorRouteList.GetSize(); i++ )
    {
      strm << m_ErrorRouteList[i];
      if( i + 1 < m_ErrorRouteList.GetSize() )
        strm << ",";
    }
    m_ErrorRouteList.clear();
  }

  return TRUE;
}



BOOL SolegySession::SendCALLSTOP()
{
  //PWaitAndSignal packetMutex( m_PacketQueueMutex );
  PWaitAndSignal timerMutex( m_TimerMutex );

  m_CallTimer.Stop();
  m_CallWarningTimer.Stop();
  m_State = CALLSTOP;

  m_CallStopTime = PTime();
  PTimeInterval diff = m_CallStopTime - m_CallStartTime;
  m_CallDuration = diff.GetInterval()/1000;

  RemoveCallState();
  OnDumpCallAuditTrail();

  
  OStringStream strm;
  strm << "CALLSTOP" << endl;
  PrepareHeader( strm );
  OnPrepareCALLSTOPInfo( strm );
  m_CurrentPacket = strm.str();
  WritePacket();
  StartRetryTimer( CALLSTOP_TIMEOUT );

  return TRUE;
}

BOOL SolegySession::OnPrepareCALLSTOPInfo(
  OStringStream & strm
)
{
  strm << "DURATION=" << m_CallDuration << endl;
  return TRUE;
}

BOOL SolegySession::SendERROR( int routeIndex )
{
  //PWaitAndSignal lock( m_PacketQueueMutex );

  if( m_State == STOP )
    return FALSE;

  OStringStream strm;
  strm << "ERROR" << endl;
  PrepareHeader( strm );

  strm << "ERROR=" << m_ErrorString << endl;
  strm << "TERMINATINGHOST=" << (routeIndex + 1) << endl;
  strm << "ROUTE=" << routeIndex << endl; /// (Historical)For compatibility with old versions of RTTS

  m_CurrentErrorPacket = strm.str();

  StartErrorRetryTimer( 3000 );

  WritePacket( TRUE );

  return TRUE;
}


void SolegySession::StartRetryTimer( const PTimeInterval & timeout )
{
  ///start the retransmision timer
  PWaitAndSignal lock( m_TimerMutex );
  m_AbortRetry = FALSE;

  if( !m_CurrentPacket.IsEmpty() )
  {
    m_RetryTimerInterval = 500;
    m_RetryTimer.Stop();
    m_RetryTimer = PTimer( m_RetryTimerInterval );
    m_RetryTimer.SetNotifier( PCREATE_NOTIFIER(OnRetryTimer) );
    m_RetryTimer.Resume();
  }

  m_TimeoutTimer.Stop();
  m_TimeoutTimer = PTimer( timeout );
  m_TimeoutTimer.SetNotifier( PCREATE_NOTIFIER(OnRetryTimeout) );
  m_TimeoutTimer.Resume();
}

void SolegySession::StopRetryTimer()
{
  PWaitAndSignal lock( m_TimerMutex );
  m_AbortRetry = TRUE;
  m_RetryTimer.Stop();
  m_TimeoutTimer.Stop();
}

void SolegySession::StartErrorRetryTimer( const PTimeInterval & timeout )
{
  ///start the retransmision timer
  PWaitAndSignal lock( m_TimerMutex );
  m_ErrorRetryTimer.Stop();
  m_ErrorRetryTimerInterval = ERROR_RETRY_INTERVAL;
  m_ErrorRetryTimer = PTimer( m_ErrorRetryTimerInterval );
  m_ErrorRetryTimer.SetNotifier( PCREATE_NOTIFIER(OnErrorRetryTimer) );
  m_ErrorRetryTimer.Resume();
}

void SolegySession::StopErrorRetryTimer()
{
  PWaitAndSignal lock( m_TimerMutex );
  m_ErrorRetryTimer.Stop();
  //m_ErrorTimeoutTimer.Stop();
}

void SolegySession::OnRetryTimer()
{
  //PWaitAndSignal lock( m_PacketQueueMutex );
  if( m_Socket == NULL && m_AbortRetry )
    return;

  m_Socket->Write( m_CurrentPacket );
  if( m_RetryTimerInterval < 2000 )
    m_RetryTimerInterval = m_RetryTimerInterval * 2;

  m_RetryTimer.SetInterval( m_RetryTimerInterval );
  m_RetryTimer.Resume();
}

void SolegySession::OnRetryTimer( PTimer & /*timer*/, INT )
{
  PWaitAndSignal lock( m_TimerMutex );
  m_SessionManager->EnqueueEvent( "RETRY", this );
}

void SolegySession::OnRetryTimeout( PTimer &, INT )
{
  PWaitAndSignal lock( m_TimerMutex );
  m_SessionManager->EnqueueEvent( "RETRY-TIMEOUT", this );
}

void SolegySession::OnErrorRetryTimer( PTimer & /*timer*/, INT )
{
  PWaitAndSignal lock( m_TimerMutex );
  if( m_State != STOP )
    m_SessionManager->EnqueueEvent( "ERROR-RETRY", this );
}


void SolegySession::OnErrorRetryTimer()
{
  //PWaitAndSignal lock( m_PacketQueueMutex );
  m_Socket->Write( m_CurrentErrorPacket );
  if( m_ErrorRetryTimerInterval < ERROR_RETRY_INTERVAL + 3 )
  {
    m_ErrorRetryTimerInterval++;
    m_ErrorRetryTimer.SetInterval( m_ErrorRetryTimerInterval );
    m_ErrorRetryTimer.Resume();
    return;
  }
}



void SolegySession::OnReceived_TIMEOUT()
{
  if( !m_AbortRetry )
  {
    m_RetryTimerInterval = 500;
    StopRetryTimer();
  }

  if( m_State != STOP )
  {
    /// lets back-off from this server for a maximum of 1 minute
    //GetSocket()->SetReliable( FALSE );
  }

  switch(m_State)
  {
  case START:
    RTTS_LOG( "START-8888 SERVER: " << GetSocket()->GetRTTSSeverAddress() << " LOAD: " <<  GetSocket()->GetServerSessionLoad() );
    GetSocket()->MarkLastFatalTimeout( GetRemoteSessionId(), "START" );
    OnReceived_START_TIMEOUT();
    break;
  case AUTH:
    RTTS_LOG( "AUTH-8888 SERVER: " << GetSocket()->GetRTTSSeverAddress() << " LOAD: " <<  GetSocket()->GetServerSessionLoad() );
    GetSocket()->MarkLastFatalTimeout( GetRemoteSessionId(), "AUTH" );
    OnReceived_AUTH_TIMEOUT();
    break;
  case SIGNIN:
    RTTS_LOG( "SIGNIN-8888 SERVER: " << GetSocket()->GetRTTSSeverAddress() << " LOAD: " <<  GetSocket()->GetServerSessionLoad() );
    GetSocket()->MarkLastFatalTimeout( GetRemoteSessionId(), "SIGNIN" );
    OnReceived_SIGNIN_TIMEOUT();
    break;
  case SETUP:
    RTTS_LOG( "SETUP-8888 SERVER: " << GetSocket()->GetRTTSSeverAddress() << " LOAD: " <<  GetSocket()->GetServerSessionLoad() );
    GetSocket()->MarkLastFatalTimeout( GetRemoteSessionId(), "SETUP" );
    OnReceived_SETUP_TIMEOUT();
    break;
  case CALLSTART:
    RTTS_LOG( "CALLSTART-8888 SERVER: " << GetSocket()->GetRTTSSeverAddress() << " LOAD: " <<  GetSocket()->GetServerSessionLoad() );
    GetSocket()->MarkLastFatalTimeout( GetRemoteSessionId(), "CALLSTART" );
    OnReceived_CALLSTART_TIMEOUT();
    break;
  case CALLSTOP:
    RTTS_LOG( "CALLSTOP-8888 SERVER: " << GetSocket()->GetRTTSSeverAddress() << " LOAD: " <<  GetSocket()->GetServerSessionLoad() );
    GetSocket()->MarkLastFatalTimeout( GetRemoteSessionId(), "CALLSTOP" );
    OnReceived_CALLSTOP_TIMEOUT();
    break;
  case STOP:
    OnReceived_STOP_TIMEOUT();
    break;
  default:
    break;
  }
}

void SolegySession::OnReceived_START_TIMEOUT()
{
  m_LastFailoverState = START;
  if( !SendSTARTFailover() )
  {
    m_State = NO_RESOURCE;
    m_Socket = NULL;
    CallDisconnect( "RTTS-8888 No RTTS Resource" );
  }
}

void SolegySession::OnReceived_AUTH_TIMEOUT()
{
  m_LastFailoverState = AUTH;
  if( !SendSTARTFailover() )
  {
    m_State = NO_RESOURCE;
    m_Socket = NULL;
    CallDisconnect( "RTTS-8888 No RTTS Resource" );
  }
}

void SolegySession::OnReceived_SIGNIN_TIMEOUT()
{
  m_LastFailoverState = SIGNIN;
  //if( !SendSTARTFailover() )
    CallDisconnect( "RTTS-8888 SIGNIN-TIMEOUT" );
}

void SolegySession::OnReceived_SETUP_TIMEOUT()
{
  m_LastFailoverState = SETUP;
  //if( !SendSTARTFailover() )
    CallDisconnect( "RTTS-8888 SETUP-TIMEOUT" );
}

void SolegySession::OnReceived_CALLSTART_TIMEOUT()
{
  m_SessionManager->EnqueueEvent( "SendCALLSTOP", this );
  m_LastFailoverState = CALLSTART;
  //if( !SendSTARTFailover() )
    CallDisconnect( "RTTS-8888 CALLSTART-TIMEOUT" );
}

void SolegySession::OnReceived_CALLSTOP_TIMEOUT()
{
  // dump to recon before grabbing the mutex
  m_SessionManager->DumpCDRRecon( this );

  //PWaitAndSignal lock( m_PacketQueueMutex );
  m_IsCallStopPending = FALSE;
  if( m_SendStopOnCallStopEvent )
    m_SessionManager->EnqueueEvent( "SendSTOP", this );
}

void SolegySession::OnReceived_STOP_TIMEOUT()
{
  m_State = TERMINATED;
  m_SessionManager->EnqueueEvent( "TERMINATE", this );
}

void SolegySession::OnIVREvent(
  B2BUAConnection * /*conn*/,
  const B2BIVRInterface::B2BIVREvent * /*evt*/
)
{
}

void SolegySession::EnqueuePacket( const PString & packet )
{
  PWaitAndSignal lock( m_PacketQueueMutex );
  if( GetState() == SolegySession::TERMINATED && packet != "TERMINATE" )
    return;
  m_PacketQueue.Enqueue( new PString( packet ) );
}

PString * SolegySession::DequeuePacket()
{
  PWaitAndSignal lock( m_PacketQueueMutex );
  return m_PacketQueue.Dequeue();
}

void SolegySession::ProcessEvent()
{
  PString * packet = DequeuePacket();
  if( packet != NULL )
  {
    ProcessPacket( (const char *)*packet );
    delete packet;
  }
}

void SolegySession::ProcessPacket( const OString & _packet )
{
  //PWaitAndSignal lock( m_PacketQueueMutex );
  OString packet = _packet;
  int routeIndex = -1;
  if( packet.Left( 9 ) == "SendERROR" )
  {
    routeIndex = packet.Right( 1 ).AsInteger();
    packet = "SendERROR";
  }

  if( m_State == NO_RESOURCE )
    return;

  if( packet == "SendSTART" )
  {
    SendSTART();
    return;
  }else if( packet == "SendAUTH" )
  {
    SendAUTH();
    return;
  }else if( packet == "SendSIGNIN" )
  {
    SendSIGNIN();
    return;
  }else if( packet == "SendSETUP" )
  {
    SendSETUP();
    return;
  }else if( packet == "SendCALLSTART" )
  {
    SendCALLSTART();
    return;
  }else if( packet == "SendCALLSTOP" )
  {
    SendCALLSTOP();
    return;
  }else if( packet == "SendSTOP" )
  {
    SendSTOP();
    return;
  }else if( packet == "SendERROR" )
  {
    if( m_State > STOP )
      return;
    SendERROR(routeIndex);
    return;
  }else if( packet == "RETRY-TIMEOUT" )
  {
    OnReceived_TIMEOUT();
    return;
  }else if( packet == "RETRY" )
  {
    OnRetryTimer();
    return;
  }else if( packet == "ERROR-RETRY" )
  {
    OnErrorRetryTimer();
    return;
  }

  if( m_State == STOP )
    return;

  OString seq;
  if( !SolegyParser::ParseHeader( "SEQ", seq, packet ) )
    return;

  DWORD responseSeq = seq.AsUnsigned();
  if(  responseSeq <= m_Sequence )
    return;

  char method[256];
  memset( method, '\0', 256 );
  
  B2BUAConnection * conn = GetB2BUAConnection();
  if( conn != NULL && m_Socket != NULL )
  {
    PIPSocket::Address remoteAddress = m_Socket->GetRTTSSeverAddress();
    WORD remotePort = m_Socket->GetRTTSServerPort();

    PIPSocket::Address localAddress;
    WORD localPort = 0;
    m_Socket->GetSocket()->GetLocalAddress( localAddress, localPort );
    
    const char * bytes = packet.c_str();
    size_t len = packet.GetLength();
    for( size_t i = 0; i < len && i < 256 && bytes[i] != '\n' && bytes[i] != '\r'; i++ )
      method[i] = bytes[i];
    
    OStringStream traceStream;
    traceStream <<  "<<< RTTS: " 
      << method << " "; 
      
    traceStream  << remoteAddress << ":" << remotePort << "->";
    traceStream  << localAddress << ":" << localPort;
    traceStream  << " enc=0" << " bytes=" <<  (unsigned)packet.length();

    OStringStream strPacket;
    strPacket << packet;

    COMPOUND_LOG( conn->LogInfo(), traceStream.str(), conn->LogDebugHigh(), strPacket );
  }

  if( strcmp( method, "START" ) == 0 && m_State == START )
  {
    OnReceived_START( packet );
  }else if( strcmp( method, "AUTH" ) == 0 && m_State == AUTH )
  {
    OnReceived_AUTH( packet );
  }else if( strcmp( method, "SIGNIN" ) == 0 && m_State == SIGNIN )
  {
    OnReceived_SIGNIN( packet );
  }else if( strcmp( method, "SETUP" ) == 0 && m_State == SETUP )
  {
    OnReceived_SETUP( packet );
  }else if( strcmp( method, "CALLSTART" ) == 0 && m_State == CALLSTART )
  {
    OnReceived_CALLSTART( packet );
  }else if( strcmp( method, "CALLSTOP" ) == 0 && m_State == CALLSTOP )
  {
    OnReceived_CALLSTOP( packet );
  }else if( strcmp( method, "ERROR" ) == 0 )
  {
    OnReceived_ERROR( packet );
  }
}

BOOL SolegySession::CheckSequence( const OString & packet )
{
  OString seq;
  if( !SolegyParser::ParseHeader( "SEQ", seq, packet ) )
    return FALSE;
  WORD responseSeq = (WORD)seq.AsUnsigned();
  if(  responseSeq > m_Sequence )
    m_Sequence = responseSeq;
  else
  {
    RTTS_LOG( "SEQ ERROR. Got " << responseSeq << " while expecting " << m_Sequence + 1 << ". State=" << m_State  );
    return FALSE;
  }

  return TRUE;
}

BOOL SolegySession::OnReceived_START( const OString & packet )
{
  if( m_State == START )
  {
    if( CheckSequence( packet ) )
    {
      StopRetryTimer();
      if( ((SBCConnection*)m_B2BUAConnection)->m_IsAbandoned  || !m_B2BUAConnection->IsSafeReference() )
        return FALSE;

      m_HasReceivedSTART = TRUE;
      OString sessions, version;
      SolegyParser::ParseHeader( "RTTS.SESSIONS", sessions, packet );
      SolegyParser::ParseHeader( "RTTS.VERSION", version, packet );
      RTTS_LOG( "Session-ID=" << GetRemoteSessionId() );
      RTTS_LOG( "SERVER: " << GetSocket()->GetRTTSSeverAddress() << ":" << GetSocket()->GetRTTSServerPort() << " Version: " << version << " Server Load: " <<  sessions );       
      GetSocket()->SerServerSessionLoad( sessions.AsInteger() );
      m_SessionManager->EnqueueEvent( "SendAUTH", this );
      return TRUE;
    }
  }

  RTTS_LOG( "OnReceived_START FAILURE" );
  return FALSE;
}


BOOL SolegySession::OnReceived_AUTH( const OString & packet )
{
  if( CheckSequence( packet ) )
  {
    {
      SBCConnection * conn = dynamic_cast<SBCConnection*>(m_B2BUAConnection);
      if( conn != NULL && conn->m_IsAbandoned )
      {
        StopRetryTimer();
        return FALSE;
      }
    }

    StopRetryTimer();

    m_AUTHResponse = packet;
    SolegyParser::ParseHeader( "EnableAuth", m_EnableAuth, m_AUTHResponse );
    SolegyParser::ParseHeader( "EnableUserAuth", m_EnableUserAuth, m_AUTHResponse );
    SolegyParser::ParseHeader( "AUTHENTICATOR", m_DIGEST, m_AUTHResponse );
    
    return TRUE;
  }

  RTTS_LOG( "OnReceived_AUTH FAILURE" );
  return FALSE;
}

BOOL SolegySession::OnReceived_SIGNIN( const OString & packet )
{
  if( CheckSequence( packet ) )
  {
    {
      SBCConnection * conn = dynamic_cast<SBCConnection*>(m_B2BUAConnection);
      if( conn != NULL && conn->m_IsAbandoned )
      {
        StopRetryTimer();
        return FALSE;
      }
    }

    m_SIGNINResponse = packet;
    StopRetryTimer();
    return TRUE;
  }
  
  RTTS_LOG( "OnReceived_SIGNIN FAILURE" );
  return FALSE;
}

BOOL SolegySession::OnReceived_SETUP( const OString & packet )
{
  if( CheckSequence( packet ) )
  {
    {
      SBCConnection * conn = dynamic_cast<SBCConnection*>(m_B2BUAConnection);
      if( conn != NULL && conn->m_IsAbandoned )
      {
        StopRetryTimer();
        return FALSE;
      }
    }

    m_SETUPResponse = packet;
    StopRetryTimer();
    if( SolegyParser::ParseHeader( "ROUTING", m_ROUTING, m_SETUPResponse ) )
    {
      LOG( m_B2BUAConnection->LogInfo(),  "=== RTTS: SETUP " << m_ROUTING );
    }

    return TRUE;
  }

  RTTS_LOG( "OnReceived_SETUP FAILURE" );
  return FALSE;
}

BOOL SolegySession::OnReceived_CALLSTART( const OString & packet )
{
  if( CheckSequence( packet ) )
  {
    StopRetryTimer();
    return TRUE;
  }

  RTTS_LOG( "OnReceived_CALLSTART FAILURE" );
  return FALSE;
}

BOOL SolegySession::OnReceived_CALLSTOP( const OString & packet )
{
  //PWaitAndSignal lock( m_PacketQueueMutex );
  if( CheckSequence( packet ) )
  {
    m_IsCallStopPending = FALSE;
    m_CALLSTOPResponse = packet;
    StopRetryTimer();

    OString duration;
    OString brandBalance;
    OString brandCallCharge;
    SolegyParser::ParseHeader( "DURATION", duration, m_CALLSTOPResponse );
    SolegyParser::ParseHeader( "BRANDBALANCE", brandBalance, m_CALLSTOPResponse );
    SolegyParser::ParseHeader( "BRANDCALLCHARGE", brandCallCharge, m_CALLSTOPResponse );
    LOG( m_B2BUAConnection->LogInfo(),  "=== RTTS: CALLSTOP " << "Duration: " << duration << " Charges: " << brandCallCharge << "/" << brandBalance );
    if( m_SendStopOnCallStopEvent )
      m_SessionManager->EnqueueEvent( "SendSTOP", this );
    return TRUE;
  }

 

  RTTS_LOG( "OnReceived_CALLSTOP FAILURE" );
  return FALSE;
}

BOOL SolegySession::OnReceived_ERROR( const OString & packet )
{
  if( m_State == STOP ) /// ignore errors on STOP
    return TRUE;

  if( !CheckSequence( packet ) )
    return FALSE;

  StopRetryTimer();

  m_LastErrorState = m_State;

  switch( m_State )
  {
  case START:
    OnReceived_START_ERROR( packet );
    break;
  case AUTH:
    OnReceived_AUTH_ERROR( packet );
    break;
  case AUTHPENDING:
  case SIGNIN: 
    OnReceived_SIGNIN_ERROR( packet );
    break;
  case SETUP:
    OnReceived_SETUP_ERROR( packet );
    break;
  case CALLSTART: 
    OnReceived_CALLSTART_ERROR( packet );
    break;
  case CALLSTOP:
    OnReceived_CALLSTOP_ERROR( packet );
    break;
  default:
    break;
  }

  return TRUE;
}

void SolegySession::OnReceived_START_ERROR( const OString & /*packet*/ )
{
  if( !SendSTARTFailover() )
  {
    m_State = NO_RESOURCE;
    m_Socket = NULL;
    CallDisconnect( "RTTS-8888 No RTTS Resource" );
  }
}

void SolegySession::OnReceived_AUTH_ERROR( const OString & packet )
{
  if( m_B2BUAConnection != NULL && m_B2BUAConnection->IsSafeReference() )
  {
    const SIPMessage & invite = m_B2BUAConnection->GetCallArrivalQueue().GetMessage();
    SIPMessage response;
    OString error;
    if( SolegyParser::ParseHeader( "ERROR", error, packet ) )
    {
      OString errorLCase = error.ToLower();
      if( errorLCase.Find( "insufficient balance" ) )
      {
        /// ban this host for 15 minutes
        OString banId = m_HOST + invite.GetRequestURI().GetUser().Left(5);
        PWaitAndSignal lock(m_SessionManager->m_NoFundHostListMutex);
        m_SessionManager->m_NoFundHostList.SetAt( banId.c_str(), new PTime() );
      }
      error = "RTTS-" + error;
    }

    

    invite.CreateResponse( response, SIPMessage::Code403_Forbidden, error );
    m_B2BUAConnection->GetLeg1Call()->SendRequest( response );
    m_B2BUAConnection->DestroyConnection( response );
  }
}

void SolegySession::OnReceived_SIGNIN_ERROR( const OString & packet )
{
  if( m_B2BUAConnection != NULL && m_B2BUAConnection->IsSafeReference() )
  {
    const SIPMessage & invite = m_B2BUAConnection->GetCallArrivalQueue().GetMessage();
    SIPMessage response;
    OString error;
    if( SolegyParser::ParseHeader( "ERROR", error, packet ) )
      error = "RTTS-" + error;

    invite.CreateResponse( response, SIPMessage::Code403_Forbidden, error );
    m_B2BUAConnection->GetLeg1Call()->SendRequest( response );
    m_B2BUAConnection->DestroyConnection( response );
  }
}

void SolegySession::OnReceived_SETUP_ERROR( const OString & packet )
{
  if( m_B2BUAConnection != NULL && m_B2BUAConnection->IsSafeReference() )
  {
    const SIPMessage & invite = m_B2BUAConnection->GetCallArrivalQueue().GetMessage();
    SIPMessage response;
    OString error;
    if( SolegyParser::ParseHeader( "ERROR", error, packet ) )
      error = "RTTS-" + error;

    invite.CreateResponse( response, SIPMessage::Code403_Forbidden, error );
    m_B2BUAConnection->GetLeg1Call()->SendRequest( response );
    m_B2BUAConnection->DestroyConnection( response );
  }
}

void SolegySession::OnReceived_CALLSTART_ERROR( const OString & packet )
{
  if( m_B2BUAConnection != NULL && m_B2BUAConnection->IsSafeReference() )
  {
    const SIPMessage & invite = m_B2BUAConnection->GetCallArrivalQueue().GetMessage();
    SIPMessage response;
    OString error;
    if( SolegyParser::ParseHeader( "ERROR", error, packet ) )
      error = "RTTS-" + error;

    invite.CreateResponse( response, SIPMessage::Code403_Forbidden, error );
    m_B2BUAConnection->GetLeg1Call()->SendRequest( response );
    m_B2BUAConnection->DestroyConnection( response );
  }
}

void SolegySession::OnReceived_CALLSTOP_ERROR( const OString & /*packet*/ )
{
  //PWaitAndSignal lock( m_PacketQueueMutex );
  m_IsCallStopPending = FALSE;
  if( m_SendStopOnCallStopEvent )
     m_SessionManager->EnqueueEvent( "SendSTOP", this );
}

BOOL SolegySession::CallConnect()
{
  if( m_B2BUAConnection != NULL && m_B2BUAConnection->IsSafeReference() )
    m_B2BUAConnection->ProcessCallArrivalQueue();
  else
    return FALSE;
  return TRUE;
}

void SolegySession::OnCallStart()
{
#if 0
  m_SessionManager->EnqueueConnectionEvent( 
    new SolegySessionManager::ConnectionEvent( 
    SolegySessionManager::ConnectionEvent::CALLSTART,
    this ) );
#else
  if( m_B2BUAConnection != NULL )
  {
    m_B2BUAConnection->EnqueueSessionEvent(
      new SIPSessionEvent( *m_B2BUAConnection, SBCConnection::Event_OnSendAccountingCallStart )
    );
  }
#endif
}

void SolegySession::InternalOnCallStart()
{
  m_SessionManager->EnqueueEvent( "SendCALLSTART", this );
}

void SolegySession::OnCallStop()
{
#if 0
  m_SessionManager->EnqueueConnectionEvent( 
    new SolegySessionManager::ConnectionEvent( 
    SolegySessionManager::ConnectionEvent::CALLSTOP,
    this ) );
#else
  if( m_B2BUAConnection != NULL  )
  {
    m_B2BUAConnection->EnqueueSessionEvent(
      new SIPSessionEvent( *m_B2BUAConnection, SBCConnection::Event_OnSendAccountingCallStop )
    );
  }
#endif
}

void SolegySession::InternalOnCallStop()
{
  if( !m_CanSendCallStop || m_IsCallStopPending )
    return;

  m_CanSendCallStop = FALSE;
  m_IsCallStopPending = TRUE;

  m_SessionManager->EnqueueEvent( "SendCALLSTOP", this );
}


void SolegySession::OnTransferReject( const SIPMessage & reject )
{
#if 0
  m_SessionManager->EnqueueConnectionEvent( 
    new SolegySessionManager::ConnectionEvent( 
    SolegySessionManager::ConnectionEvent::TRANSFERREJECT,
    reject, this ) );
#else
  if( m_B2BUAConnection != NULL  )
  {
    m_B2BUAConnection->EnqueueSessionEvent(
      new SIPSessionEvent( *m_B2BUAConnection, SBCConnection::Event_OnTransferReject, reject )
    );
  }
#endif
}

void SolegySession::InternalOnTransferReject( const SIPMessage & /*reject*/ )
{
}

BOOL SolegySession::ProcessDigest( const OString & signin )
{
  if( m_B2BUAConnection != NULL && m_B2BUAConnection->IsSafeReference() )
  {
    const SIPMessage & invite = m_B2BUAConnection->GetCallArrivalQueue().GetMessage();
    ProxyAuthorization auth;
    if( !invite.GetProxyAuthorization( auth ) )
    {
      PTRACE( 1, "No Proxy Authorization Header in request" );
      CallDisconnect( "RTTS-8000 Invalid Authorization Header" );
      return FALSE;
    }

    OString newDigest;
    if( SolegyParser::ParseHeader( "DIGEST", newDigest, signin ) )
      m_DIGEST = newDigest;     
    
    if( m_DIGEST.IsEmpty() )
    {
      CallDisconnect( "8000-Unable To Parse MD5 DIGEST" );
      return FALSE;
    }else
    {
      OString userName;
      OString realm;
      OString uri;
      OString nonce;
      OString opaque;
      OString response;

      if( !auth.GetParameter( "username", userName ) )
      {
        PTRACE( 1, "No User Name specified in AUTHORIZATION" );
        CallDisconnect( "RTTS-8000 Invalid User" );
        return FALSE;
      }

      if( !auth.GetParameter( "realm", realm ) )
      {
        PTRACE( 1, "No Realm specified in AUTHORIZATION" );
        CallDisconnect( "RTTS-8000 Invalid Realm" );
        return FALSE;
      }

      if( !auth.GetParameter( "uri", uri ) )
      {
        PTRACE( 1, "No URI specified in AUTHORIZATION" );
        CallDisconnect( "RTTS-8000 Invalid Auhtorization URI" );
        return FALSE;
      }

      if( !auth.GetParameter( "nonce", nonce ) )
      {
        PTRACE( 1, "No NONCE specified in AUTHORIZATION" );
        CallDisconnect( "RTTS-8000 Invalid Nonce" );
        return FALSE;
      }

      if( !auth.GetParameter( "response", response ) )
      {
        PTRACE( 1, "No Authorization response in AUTHORIZATION" );
        CallDisconnect( "RTTS-8000 Invalid Authorization Response" );
        return FALSE;
      }

      OString a1 = m_DIGEST;
      MD5::A2Hash a2( invite.GetMethod(), uri );
      MD5::MD5Authorization localAuth = MD5::MD5Authorization( a1, ParserTools::UnQuote(nonce), a2 );
    
      OString md5Local =  localAuth.AsString();///MD5::MD5Authorization::Construct( a1.AsString(), ParserTools::UnQuote( nonce ), a2.AsString() );
    
      OString md5Remote = ParserTools::UnQuote( response ); 


      if( md5Local != md5Remote )
      {
        PTRACE( 1,  "Authorization token did not match: " 
          << " Local [" << md5Local << "]" << " Remote [" << md5Remote );

        LOG_IF_DEBUG( m_B2BUAConnection->LogWarning(), "Authorization token did not match: " 
          << " Local [" << md5Local << "]" << " Remote [" << md5Remote );
        
        m_ErrorString = SolegyParser::ConvertRTTSErrorToString( SolegyParser::ErrorAuthRejected );
        m_SessionManager->EnqueueEvent( "SendERROR", this );
        CallDisconnect( m_ErrorString );
        return FALSE;
      }else
      {
        return TRUE;
      }
    }
  }

  return TRUE;
}

BOOL SolegySession::OnPrepareCDRReconInfo( PMIMEInfo & sendMIME )
{
  PString duration( m_CallDuration );
  PString localAddress = m_SessionManager->GetRTTSClientAddress().AsString();
  sendMIME.SetAt( "X-CC-RTTS-Session-ID", m_RemoteSessionId.c_str() );
  sendMIME.SetAt( "X-CC-RTTS-Call-Duration", duration ); 
  sendMIME.SetAt( "X-CC-RTTS-Call-State", "CALLSTOP" ); 
  sendMIME.SetAt( "X-CC-RTTS-SBC-Address", localAddress );
  sendMIME.SetAt( "X-CC-RTTS-Recon-Index", "3" );
  return TRUE;
}

void SolegySession::DumpLog( const char * str )
{
  RTTS_LOG( str );
}

BOOL SolegySession::OnDumpCDRReconfInfo( const PFilePath & file )
{
  PString duration( m_CallDuration );
  PString localAddress = m_SessionManager->GetRTTSClientAddress().AsString();
  PTextFile reconfFile( file );
  reconfFile.WriteLine( PString("X-CC-RTTS-Session-ID=") +  m_RemoteSessionId.c_str() );
  reconfFile.WriteLine( PString("X-CC-RTTS-Call-Duration=") +  duration );
  reconfFile.WriteLine( PString("X-CC-RTTS-Call-State=") +  "CALLSTOP" );
  reconfFile.WriteLine( PString("X-CC-RTTS-SBC-Address=") +  localAddress );
  return TRUE;
}

void SolegySession::OnDumpCallAuditTrail()
{
#if 0
  m_SessionManager->EnqueueConnectionEvent( 
    new SolegySessionManager::ConnectionEvent( 
    SolegySessionManager::ConnectionEvent::DUMPCAT,
    this ) );
#else
  if( m_B2BUAConnection != NULL )
  {
    m_B2BUAConnection->EnqueueSessionEvent(
      new SIPSessionEvent( *m_B2BUAConnection, SBCConnection::Event_OnDumpAuditTrail )
    );
  }
#endif
}

void SolegySession::InternalOnDumpCallAuditTrail()
{
  if( m_B2BUAConnection != NULL && m_B2BUAConnection->IsSafeReference() )
  {
    B2BUACall * call_1 =  m_B2BUAConnection->GetLeg1Call();
    B2BUACall * call_2 =  m_B2BUAConnection->GetLeg2Call();

    PTime now;
    OStringStream strm;
    strm << now.AsString("yyyy/MM/dd hh:mm:ss.uuu");

    if( call_2 != NULL )
      strm << " [" << call_2->GetCallId().c_str() << "]";
    else if( call_1 != NULL ) 
      strm << " [" << call_1->GetCallId().c_str() << "]";

    if( m_B2BUAConnection->GetConnectionDestructCause() != 200 && m_B2BUAConnection->GetConnectionDestructCause() != 0 )
    {
      strm << " CS:" << m_B2BUAConnection->GetConnectionDestructCause();
    }else if( call_2 != NULL )
    {
      switch( call_2->GetCallEndReason() )
      {
        case CallSession::ICT_Recv3xx:
        case CallSession::ICT_Recv4xx:
        case CallSession::ICT_Recv5xx:
        case CallSession::ICT_Recv6xx:
          strm << " CS:" << call_2->GetCallEndStatusCode();
        default:
          strm << " CS:200";
      }
    }

    strm << " OC:" << m_CurrentInboundInvite.GetFromURI().GetUser().c_str();
    strm << "<" << m_CurrentInboundInvite.GetFromURI().GetHost().c_str() << ">";
    strm << " TC:" << m_DIALSTRING;
    if( m_CurrentOutboundInvite.IsValid() )
    {
      strm << "(" << m_CurrentOutboundInvite.GetRequestURI().GetUser().c_str() << ")";
      strm << "<" << m_CurrentOutboundInvite.GetRequestURI().GetHost().c_str() << ">";
    }else
    {
      strm << "()<>";
    }

    strm << " RT:" << m_RingDuration;
    strm << " CT:" << m_CallDuration;

    strm << " RS:" << m_RemoteSessionId;

    OString ds = m_CurrentInboundInvite.GetRequestURI().GetUser();
    if( m_DIALSTRING != ds )
       strm << " MS:" << ds;

    if( !m_ACCOUNTID.IsEmpty() )
      strm << " PN:" << m_ACCOUNTID;

    m_SessionManager->DumpCATLog( strm.str().c_str() );

  }
}


BOOL SolegySession::IsFailoverCandidate( int code )
{
  switch( code )
  {
    case SIPMessage::Code400_BadRequest:// = 400,
      return TRUE;
    case SIPMessage::Code401_Unauthorized:// = 401,
      return TRUE;
    case SIPMessage::Code402_PaymentRequired:// = 402,
      return TRUE;
    case SIPMessage::Code403_Forbidden:// = 403,
      return TRUE;
    case SIPMessage::Code404_NotFound:// = 404,
      return TRUE;
    case SIPMessage::Code405_MethodNotAllowed:// = 405,
      return TRUE;
    case SIPMessage::Code406_NotAcceptable:// = 406,
      return TRUE;
    case SIPMessage::Code407_ProxyAuthenticationRequired:// = 407,
      return TRUE;
    case SIPMessage::Code408_RequestTimeout:// = 408,
      return TRUE;
    case SIPMessage::Code409_Conflict:// = 409,
      return TRUE;
    case SIPMessage::Code410_Gone:// = 410,
      return TRUE;
    case SIPMessage::Code411_LengthRequired:// = 411,
      return TRUE;
    case SIPMessage::Code412_ConditionalRequestFailed:// = 412,
      return TRUE;
    case SIPMessage::Code413_RequestEntityTooLarge:// = 413,
      return TRUE;
    case SIPMessage::Code414_RequestURITooLarge:// = 414,
      return TRUE;
    case SIPMessage::Code415_UnsupportedMedia:// = 415,
      return TRUE;
    case SIPMessage::Code416_UnsupportedURIScheme:// = 416,
      return TRUE;
    case SIPMessage::Code420_BadExtension:// = 420,
      return TRUE;
    case SIPMessage::Code422_SessionIntervalTooSmall:// = 422,
      return TRUE;
    case SIPMessage::Code423_IntervalTooShort:// = 423,
      return TRUE;
    case SIPMessage::Code480_TemporarilyNotAvailable:// = 480,
      return TRUE;
    case SIPMessage::Code481_TransactionDoesNotExist:// = 481,
      return TRUE;
    case SIPMessage::Code482_LoopDetected:// = 482,
      return TRUE;
    case SIPMessage::Code483_TooManyHops:// = 483,
      return FALSE;
    case SIPMessage::Code484_AddressIncomplete:// = 484,
      return TRUE;
    case SIPMessage::Code485_Ambiguous:// = 485,
      return TRUE;
    case SIPMessage::Code486_BusyHere:// = 486,
      return FALSE;
    case SIPMessage::Code487_RequestCancelled:// = 487,
      return FALSE;
    case SIPMessage::Code488_NotAcceptableHere:// = 488,
      return TRUE;
    case SIPMessage::Code489_BadRequest:// = 489,
      return TRUE;
    case SIPMessage::Code491_RequestPending:// = 491,
      return FALSE;
    case SIPMessage::Code500_InternalServerError:// = 500,
      return TRUE;
    case SIPMessage::Code501_NotImplemented:// = 501,
      return TRUE;
    case SIPMessage::Code502_BadGateway:// = 502,
      return TRUE;
    case SIPMessage::Code503_ServiceUnavailable:// = 503,
      return TRUE;
    case SIPMessage::Code504_GatewayTimeout:// = 504,
      return TRUE;
    case SIPMessage::Code505_VersionNotSupported:// = 505,
      return TRUE;
    case SIPMessage::Code600_BusyEverywhere:// = 600,
      return TRUE;
    case SIPMessage::Code603_Decline:// = 603,
      return TRUE;
    case SIPMessage::Code604_DoesNotExistAnywhere:// = 604,
      return TRUE;
    case SIPMessage::Code606_NotAcceptable:// = 606,
      return TRUE;
    default:
      return FALSE;
  }
}



