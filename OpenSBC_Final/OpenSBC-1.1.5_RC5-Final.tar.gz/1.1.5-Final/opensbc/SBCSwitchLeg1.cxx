/*
 *
 * SBCSwitchLeg1.cxx
 *
 * Open SIP Stack ( OSS )
 *
 * Copyright (c) opensipstack.org.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either expressed or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is OpenSIPStack.
 *
 * The Initial Developer of the Original Code is opensipstack.org.
 *
 * The author of this code is Joegen E. Baclor
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * The OpenSIPStack Library includes some GPL/LGPL code libraries that MAY be 
 * enabled at compile time using the --enable-gpllibs configure switch.  If
 * enabled, the content of this file is published under the terms of GNU 
 * General Public License Version 2.  For a detailed list of the available
 * GPL code, see $(opensipstack)/gnu/README file.
 *
 * $Log: SBCSwitchLeg1.cxx,v $
 * Revision 1.7  2009/06/15 07:47:39  joegenbaclor
 * added *#98 to handle call queue rejection
 *
 * Revision 1.6  2009/06/15 06:38:15  joegenbaclor
 * implemented call queing
 *
 * Revision 1.5  2009/06/03 11:57:16  joegenbaclor
 * Checking in MOH feature
 *
 * Revision 1.4  2009/06/02 08:53:38  joegenbaclor
 * Marking first sucessful IVR stream
 *
 * Revision 1.3  2009/06/01 09:47:28  joegenbaclor
 * more IVR related work
 *
 * Revision 1.2  2009/05/29 09:31:32  joegenbaclor
 * Added Switch IVR Classes
 *
 * Revision 1.1  2009/05/27 12:40:34  joegenbaclor
 * Initial upload of switch related classes
 *
 *
 */


#include "SBCSwitchLeg1.h"
#include "SBCSwitchConnection.h"
#include "SDPLazyParser.h"
#include "OpenSBC.h"
#include "SBCSwitchFeatureCode.h"

#define new PNEW

using namespace SWITCH;

/// UAS constructor
SBCSwitchLeg1::SBCSwitchLeg1(
  B2BUAEndPoint & sessionManager,
  const SIPMessage & request,
  const OString & sessionId
) : SBCInboundCall( sessionManager, request, sessionId )
{
  m_FCodeHandler = NULL;
  m_IsInterceptedCall = FALSE;
}

SBCSwitchLeg1::~SBCSwitchLeg1()
{
}

void SBCSwitchLeg1::IST_OnReceivedInvite(
  const SIPMessage & msg
)
{
  m_InboundInvite = msg;
#if 0
  SBCSwitchConnection * conn = dynamic_cast<SBCSwitchConnection *>(m_Connection);
  OpenSBC & sbc = dynamic_cast<OpenSBC&>(GetSessionManager().GetUserAgent());
  SIPURI msURI( sbc.GetMediaServer()->GetListenerAddress(), sbc.GetMediaServer()->GetListenerPort() );
  msURI.SetUser( "0xMS" );
  conn->GetSwitchMedia()->SetupMediaServer( msURI, m_InboundInvite );
#endif
  
  ///check if the destination is in a call currently.
  B2BUAEndPoint & ep = dynamic_cast<B2BUAEndPoint&>(GetSessionManager());
  SIPSession::GCRef gcRef = ep.FindGCRefByRemoteURI( msg.GetToURI() );
  if( gcRef != NULL )
  {
    /// let the call decide what to do with this call
    SBCSwitchIVRInterface * interceptor = dynamic_cast<SBCSwitchIVRInterface *>(gcRef.GetObject());
    if( interceptor == NULL || !interceptor->InterceptCall( *this, msg ) )
      ProcessInvite();
    return;
  }else
  {
    ProcessInvite();
  }
}

BOOL SBCSwitchLeg1::InterceptCall( 
  SBCInboundCall & call, 
  const SIPMessage & invite
)
{
  SBCSwitchLeg1 * incomingCall = dynamic_cast<SBCSwitchLeg1 *>(&call);
  if( incomingCall == NULL )
    return FALSE;

  SIPMessage queued;
  if( !invite.CreateResponse( queued, SIPMessage::Code182_Queued, "Call Queued", TRUE ) )
    return FALSE;
  call.SendRequest( queued );

  SIPMessage msg;
  if( !CreateRequestWithinDialog( SIPMessage::Method_MESSAGE, msg ) )
    return FALSE;

  msg.SetContentType( "text/plain" );
  OStringStream body;
  body << "<incoming-call>" << invite.GetFromURI().AsString() << "</incoming-call>";
  msg.SetBody( body.str() );
  SendRequest( msg );

  m_InterceptedCallId = incomingCall->GetCallId();
  incomingCall->SetIntercepted( TRUE );

  return TRUE;
}

BOOL SBCSwitchLeg1::AnswerCallIntercept(
  BOOL proceed 
)
{
  if( m_InterceptedCallId.IsEmpty() )
    return FALSE;

  B2BUAEndPoint & ep = dynamic_cast<B2BUAEndPoint&>(GetSessionManager());
  SIPSession::GCRef gcRef = ep.FindGCRefByCallId( m_InterceptedCallId );
  if( gcRef == NULL )
    return FALSE;
 
  SBCSwitchLeg1 * inbound = dynamic_cast<SBCSwitchLeg1*>( gcRef.GetObject() );
  if( inbound != NULL  )
  {
    if( proceed )
    {
      if( !inbound->IsInterceptedCall() )
        return FALSE;
      inbound->ProcessInvite();
      return TRUE;
    }else
    {
      inbound->SetCallAnswerResponse( CallSession::DisconnectWithBusyHere );
      inbound->GetB2BUAConnection()->DestroyConnection();
      return TRUE;
    }
  }

  return FALSE;
}

void SBCSwitchLeg1::ProcessInvite()
{
  B2BUACall::IST_OnReceivedInvite( m_InboundInvite );
}


/// Overrides from SBCSwitchRTPInterface
void SBCSwitchLeg1::OnRTPMediaPayloadKnown(
  int mediaType,
  int mediaPayLoad, 
  const OString & formatName 
)
{
  SBCSwitchConnection * conn = dynamic_cast<SBCSwitchConnection *>(m_Connection);
  if( conn->GetSwitchMedia()->GetAudioRTPBridge() != NULL && mediaType == OpalMediaFormat::DefaultAudioSessionID )
    OnCreateIVRStream( formatName, this );
}

OString SBCSwitchLeg1::OnRTPGetRemoteSDP()const
{
  return GetRemoteSDP();
}

/// overrides from SBCSwitchDTMFInterface
void SBCSwitchLeg1::OnDTMFStartFCodeDetect()
{
  if( m_FCodeHandler != NULL )
  {
    m_DTMFQueue->AttachHandler( NULL );
    delete m_FCodeHandler;
  }
  
  SBCSwitchConnection * conn = dynamic_cast<SBCSwitchConnection *>(m_Connection);
  m_FCodeHandler = new SBCSwitchFeatureCode( conn, this, "*#", 2, m_DTMFQueue );
  m_DTMFQueue->AttachHandler(m_FCodeHandler);
}

void SBCSwitchLeg1::OnDTMFReceiveRFC2833Tone(
  const OpalRFC2833Info & tone 
)
{
  m_DTMFQueue->OnReceiveRFC2833Tone( tone );
}




