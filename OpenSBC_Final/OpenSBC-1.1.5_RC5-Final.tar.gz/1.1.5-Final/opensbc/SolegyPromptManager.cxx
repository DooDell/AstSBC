/*
 *
 * SolegyPromptManager.cxx
 *
 * Open SIP Stack ( OSS )
 *
 * Copyright (c) opensipstack.org.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either expressed or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is OpenSIPStack.
 *
 * The Initial Developer of the Original Code is opensipstack.org.
 *
 * The author of this code is Joegen E. Baclor
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * The OpenSIPStack Library includes some GPL/LGPL code libraries that MAY be 
 * enabled at compile time using the --enable-gpllibs configure switch.  If
 * enabled, the content of this file is published under the terms of GNU 
 * General Public License Version 2.  For a detailed list of the available
 * GPL code, see $(opensipstack)/gnu/README file.
 *
 * $Log: SolegyPromptManager.cxx,v $
 * Revision 1.19  2009/01/20 06:33:43  joegenbaclor
 * Delayed connection destruction until solegy session destructor.  Got rid of the connection mutex because we are assured of a valid pointer within the lifetime of
 *  solegy session object
 *
 * Revision 1.18  2009/01/14 07:47:28  joegenbaclor
 * Changed default welcome prompt from welcome.wav to hello.wav
 *
 * Revision 1.17  2009/01/03 12:14:24  joegenbaclor
 * Reimplemented DestroyConenction to enqueue a session event instead to avoid further race conditons and dead locks.
 * We also implemented B2BUAConnection::IsSafeReference() to further guaranty the integrity of connection pointers.
 *
 * Revision 1.16  2008/12/06 05:10:16  joegenbaclor
 * Fixed bug where premature call cancelation for IVR calls may result to the b2bua connection
 *  not getting destroyed.
 *
 * Revision 1.15  2008/11/02 14:48:57  joegenbaclor
 * Bug fixes for GCC make environment
 *
 * Revision 1.14  2008/10/22 05:06:25  joegenbaclor
 * Added MPL License Header
 *
 *
 */
#include "SolegyPromptManager.h"
#include "SolegySession.h"
#include "SolegyParser.h"

#define new PNEW

using namespace SOLEGY;

#define RTTS_LOG( detail ) \
{ \
  if( m_Session->m_B2BUAConnection != NULL && m_Session->m_B2BUAConnection->IsSafeReference() ) \
  LOG( m_Session->m_B2BUAConnection->LogInfo(), "RTTS: (MS) " << detail ); \
}

SolegyPromptManager::SolegyPromptManager( 
  SolegySession * session
)
{
  m_Config = NULL;
  m_Session = session;
  m_InputTimeout = 0;
  m_IsInitialized = FALSE;
  
  m_PromptPhraseDir = "prompts/english";
  m_PromptNumberDir = "prompts/english";
  m_PromptErrorDir = "prompts/english/error";
  m_PromptDateTimeDir = "prompts/english";
  m_PromptCurrencyDir = "prompts/english";

  m_Config = new PConfig( "prompts/prompts.ini", "Solegy-Prompt-Location" );
  m_PromptPhraseDir = m_Config->GetString( "Solegy-Prompt-Location", "MS-Debit-Prompt-Phrase-Dir", m_PromptPhraseDir );
  m_PromptNumberDir = m_Config->GetString( "Solegy-Prompt-Location", "MS-Debit-Prompt-Number-Dir", m_PromptNumberDir );
  m_PromptDateTimeDir = m_Config->GetString( "Solegy-Prompt-Location", "MS-Debit-Prompt-DateTime-Dir", m_PromptDateTimeDir );
  m_PromptCurrencyDir = m_Config->GetString( "Solegy-Prompt-Location", "MS-Debit-Prompt-Currency-Dir", m_PromptCurrencyDir );
  m_PromptErrorDir = m_Config->GetString( "Solegy-Prompt-Location", "MS-Debit-Prompt-Error-Dir", m_PromptErrorDir );
}

SolegyPromptManager::~SolegyPromptManager()
{
  delete  m_Config;
}

BOOL SolegyPromptManager::InitFromAUTH( const OString & auth )
{
  /**
  AUTH
  SESSION-ID=c0a800a1462a490ee8119eb74afc1810
  SEQ=2
  LENGTH=0
  VERSION=1.0
  DOMAIN=sip:msdebit.sqa.solegy.com
  EnableDurationPrompt=1
  BSID=17273
  EnableBalancePrompt=1
  EnableReset=1
  BRANDSERVICEID=DB:msdebit.sqa.solegy.com
  InputTimeout=5000
  DNIS=18007773456
  GreetingDelay=1500
  SeizeTimeout=60
  CriticalBalance=1
  PromptsLocation=file:prompts/
  LOCALID=1
  BRANDSERVICEDESCRIPTION=Calling Card 2nd Leg
  Language=spanish,english
  Host=msdebit.sqa.solegy.com
  EnableReconnect=1
  HOST=192.168.0.161
  GreetingPrompt=file:prompts/english/hello
  ANI=joegen
  */

  if( !PFile::Exists( "prompts/prompts.ini" ) )
  {
    if( !SolegyParser::ParseHeader( "PromptsLocation", m_PromptsLocation, auth ) )
      m_PromptsLocation = "file://prompts";

    PURL dir = m_PromptsLocation.c_str();
    PFilePath path = dir.GetPathStr() + "/prompts.ini";

    if( PFile::Exists( path ) )
    {
      if( m_Config != NULL )
        delete m_Config;

      m_Config = new PConfig( path, "Solegy-Prompt-Location" );
      m_PromptPhraseDir = m_Config->GetString( "Solegy-Prompt-Location", "MS-Debit-Prompt-Phrase-Dir", m_PromptPhraseDir );
      m_PromptNumberDir = m_Config->GetString( "Solegy-Prompt-Location", "MS-Debit-Prompt-Number-Dir", m_PromptNumberDir );
      m_PromptDateTimeDir = m_Config->GetString( "Solegy-Prompt-Location", "MS-Debit-Prompt-DateTime-Dir", m_PromptDateTimeDir );
      m_PromptCurrencyDir = m_Config->GetString( "Solegy-Prompt-Location", "MS-Debit-Prompt-Currency-Dir", m_PromptCurrencyDir );
      m_PromptErrorDir = m_Config->GetString( "Solegy-Prompt-Location", "MS-Debit-Prompt-Error-Dir", m_PromptErrorDir );
    }else if( !m_PromptsLocation.IsEmpty() )
    {
      PFilePath defaultPath = dir.GetPathStr() + "english";
      PFilePath defaultErrorPath = dir.GetPathStr() + "english/error";
      m_PromptPhraseDir = static_cast<const char *>(defaultPath);
      m_PromptNumberDir = static_cast<const char *>(defaultPath);
      m_PromptDateTimeDir = static_cast<const char *>(defaultPath);
      m_PromptCurrencyDir = static_cast<const char *>(defaultPath);
      m_PromptErrorDir = static_cast<const char *>(defaultErrorPath);
    }

    

    if( !m_GreetingPrompt.IsEmpty() && m_GreetingPrompt.Right( 4 ) != ".wav" )
    {
      PURL welcomePrompt = m_GreetingPrompt.c_str();
      m_GreetingPrompt = static_cast<const char *>(welcomePrompt.GetPathStr());
      m_GreetingPrompt = m_GreetingPrompt + ".wav";
    }
  }

  m_InputTimeout = SolegyParser::GetInteger( "InputTimeout", auth, 15000 );
  m_LanguageOptions = SolegyParser::GetString( "LanguageOptions", auth );
  m_GreetingPrompt = SolegyParser::GetString( "GreetingPrompt", auth );

  m_IsInitialized = TRUE;

  return m_IsInitialized;
}

BOOL SolegyPromptManager::GetWholeNumber(
  const OString & _whole, 
  OString &wHundredThousands,
  OString &wTenThousands,
  OString &wThousands,
  OString &wHundreds,
  OString &wTens,
  OString &wOnes
)
{
  OString whole = _whole;
  OStringArray tokens = whole.Tokenise( "." );
  if( tokens.GetSize() == 2 )
    whole = tokens[0];

  int wLen = (int)whole.GetLength();
  char c = whole[0];
    
  if( wLen == 6 )
  {
    switch( c )
    {
    case '1':
      GetNumber( SolegyPrompt::PR_NUM_ONE, wHundredThousands );
      break;
    case '2':
      GetNumber( SolegyPrompt::PR_NUM_TWO, wHundredThousands );
      break;
    case '3':
      GetNumber( SolegyPrompt::PR_NUM_THREE, wHundredThousands );
      break;
    case '4':
      GetNumber( SolegyPrompt::PR_NUM_FOUR, wHundredThousands );
      break;
    case '5':
      GetNumber( SolegyPrompt::PR_NUM_FIVE, wHundredThousands );
      break;
    case '6':
      GetNumber( SolegyPrompt::PR_NUM_SIX, wHundredThousands );
      break;
    case '7':
      GetNumber( SolegyPrompt::PR_NUM_SEVEN, wHundredThousands );
      break;
    case '8':
      GetNumber( SolegyPrompt::PR_NUM_EIGHT, wHundredThousands );
      break;
    case '9':
      GetNumber( SolegyPrompt::PR_NUM_NINE, wHundredThousands );
      break;
    }

    whole[0] = whole[1];
    whole[1] = whole[2];
    whole[2] = whole[3];
    whole[3] = whole[4];
    whole[4] = whole[5];
    whole[5] = '\0';
    c = whole[0];
    wLen = 5;
  }

  int tenThousands = 0;
  if( wLen == 5 )
  {
    tenThousands = c;
    switch( c )
    {
    case '1':
      GetNumber( SolegyPrompt::PR_NUM_TEN, wTenThousands );
      break;
    case '2':
      GetNumber( SolegyPrompt::PR_NUM_TWENTY, wTenThousands );
      break;
    case '3':
      GetNumber( SolegyPrompt::PR_NUM_THIRTY, wTenThousands );
      break;
    case '4':
      GetNumber( SolegyPrompt::PR_NUM_FORTY, wTenThousands );
      break;
    case '5':
      GetNumber( SolegyPrompt::PR_NUM_FIFTY, wTenThousands );
      break;
    case '6':
      GetNumber( SolegyPrompt::PR_NUM_SIXTY, wTenThousands );
      break;
    case '7':
      GetNumber( SolegyPrompt::PR_NUM_SEVENTY, wTenThousands );
      break;
    case '8':
      GetNumber( SolegyPrompt::PR_NUM_EIGHTY, wTenThousands );
      break;
    case '9':
      GetNumber( SolegyPrompt::PR_NUM_NINE, wTenThousands );
      break;
    }

    whole[0] = whole[1];
    whole[1] = whole[2];
    whole[2] = whole[3];
    whole[3] = whole[4];
    whole[4] = '\0';
    c = whole[0];
    wLen = 4;
  }

  int thousands = 0;
  if( wLen == 4 )
  {
    thousands = c;
    switch( c )
    {
    case '1':
      if( tenThousands != '0' && tenThousands != '1' )
        GetNumber( SolegyPrompt::PR_NUM_ONE, wThousands );
      else if( tenThousands == '1' )
        GetNumber( SolegyPrompt::PR_NUM_ELEVEN, wTenThousands );
      else
        GetNumber( SolegyPrompt::PR_NUM_ONE, wThousands );
      break;
    case '2':
      if( tenThousands != '0' && tenThousands != '1' )
        GetNumber( SolegyPrompt::PR_NUM_TWO, wThousands );
      else if( tenThousands == '1' )
        GetNumber( SolegyPrompt::PR_NUM_TWELVE, wTenThousands );
      else
        GetNumber( SolegyPrompt::PR_NUM_TWO, wThousands );
      break;
    case '3':
      if( tenThousands != '0' && tenThousands != '1' )
        GetNumber( SolegyPrompt::PR_NUM_THREE, wThousands );
      else if( tenThousands == '1' )
        GetNumber( SolegyPrompt::PR_NUM_THIRTEEN, wTenThousands );
      else
        GetNumber( SolegyPrompt::PR_NUM_THREE, wThousands );
      break;
    case '4':
      if( tenThousands != '0' && tenThousands != '1' )
        GetNumber( SolegyPrompt::PR_NUM_FOUR, wThousands );
      else if( tenThousands == '1' )
        GetNumber( SolegyPrompt::PR_NUM_FOURTEEN, wTenThousands );
      else
        GetNumber( SolegyPrompt::PR_NUM_FOUR, wThousands );
      break;
    case '5':
      if( tenThousands != '0' && tenThousands != '1' )
        GetNumber( SolegyPrompt::PR_NUM_FIVE, wThousands );
      else if( tenThousands == '1' )
        GetNumber( SolegyPrompt::PR_NUM_FIFTEEN, wTenThousands );
      else
        GetNumber( SolegyPrompt::PR_NUM_FIVE, wThousands );
      break;
    case '6':
      if( tenThousands != '0' && tenThousands != '1' )
        GetNumber( SolegyPrompt::PR_NUM_SIX, wThousands );
      else if( tenThousands == '1' )
        GetNumber( SolegyPrompt::PR_NUM_SIXTEEN, wTenThousands );
      else
        GetNumber( SolegyPrompt::PR_NUM_SIX, wThousands );
      break;
    case '7':
      if( tenThousands != '0' && tenThousands != '1' )
        GetNumber( SolegyPrompt::PR_NUM_SEVEN, wThousands );
      else if( tenThousands == '1' )
        GetNumber( SolegyPrompt::PR_NUM_SEVENTEEN, wTenThousands );
      else
        GetNumber( SolegyPrompt::PR_NUM_SEVEN, wThousands );
      break;
    case '8':
      if( tenThousands != '0' && tenThousands != '1' )
        GetNumber( SolegyPrompt::PR_NUM_EIGHT, wThousands );
      else if( tenThousands == '1' )
        GetNumber( SolegyPrompt::PR_NUM_EIGHTEEN, wTenThousands );
      else
        GetNumber( SolegyPrompt::PR_NUM_EIGHT, wThousands );
      break;
    case '9':
      if( tenThousands != '0' && tenThousands != '1' )
        GetNumber( SolegyPrompt::PR_NUM_NINE, wThousands );
      else if( tenThousands == '1' )
        GetNumber( SolegyPrompt::PR_NUM_NINETEEN, wTenThousands );
      else
        GetNumber( SolegyPrompt::PR_NUM_NINE, wThousands );
      break;
    }

    whole[0] = whole[1];
    whole[1] = whole[2];
    whole[2] = whole[3];
    whole[3] = '\0';
    c = whole[0];
    wLen = 3;
  }

  if( wLen == 3 )
  {
    switch( c )
    {
    case '1':
      GetNumber( SolegyPrompt::PR_NUM_ONE, wHundreds );
      break;
    case '2':
      GetNumber( SolegyPrompt::PR_NUM_TWO, wHundreds );
      break;
    case '3':
      GetNumber( SolegyPrompt::PR_NUM_THREE, wHundreds );
      break;
    case '4':
      GetNumber( SolegyPrompt::PR_NUM_FOUR, wHundreds );
      break;
    case '5':
      GetNumber( SolegyPrompt::PR_NUM_FIVE, wHundreds );
      break;
    case '6':
      GetNumber( SolegyPrompt::PR_NUM_SIX, wHundreds );
      break;
    case '7':
      GetNumber( SolegyPrompt::PR_NUM_SEVEN, wHundreds );
      break;
    case '8':
      GetNumber( SolegyPrompt::PR_NUM_EIGHT, wHundreds );
      break;
    case '9':
      GetNumber( SolegyPrompt::PR_NUM_NINE, wHundreds );
      break;
    }

    whole[0] = whole[1];
    whole[1] = whole[2];
    whole[2] = '\0';
    c = whole[0];
    wLen = 2;
  }

  int tens = 0;
  if( wLen == 2 )
  {
    tens = c;
    switch( c )
    {
    case '1':
      GetNumber( SolegyPrompt::PR_NUM_TEN, wTens );
      break;
    case '2':
      GetNumber( SolegyPrompt::PR_NUM_TWENTY, wTens );
      break;
    case '3':
      GetNumber( SolegyPrompt::PR_NUM_THIRTY, wTens );
      break;
    case '4':
      GetNumber( SolegyPrompt::PR_NUM_FORTY, wTens );
      break;
    case '5':
      GetNumber( SolegyPrompt::PR_NUM_FIFTY, wTens );
      break;
    case '6':
      GetNumber( SolegyPrompt::PR_NUM_SIXTY, wTens );
      break;
    case '7':
      GetNumber( SolegyPrompt::PR_NUM_SEVENTY, wTens );
      break;
    case '8':
      GetNumber( SolegyPrompt::PR_NUM_EIGHTY, wTens );
      break;
    case '9':
      GetNumber( SolegyPrompt::PR_NUM_NINETY, wTens );
      break;
    }

    whole[0] = whole[1];
    whole[1] = '\0';
    c = whole[0];
    wLen = 1;
  }

  if( wLen == 1 )
  {
    switch( c )
    {
    case '0':
      if( tens == 0 )
        GetNumber( SolegyPrompt::PR_NUM_ZERO, wOnes );
      break;
    case '1':
      if( tens != 0 && tens != '1' )
        GetNumber( SolegyPrompt::PR_NUM_ONE, wOnes );
      else if( tens == '1' )
        GetNumber( SolegyPrompt::PR_NUM_ELEVEN, wTens );
      else
        GetNumber( SolegyPrompt::PR_NUM_ONE, wOnes );
      break;
    case '2':
      if( tens != 0 && tens != '1' )
        GetNumber( SolegyPrompt::PR_NUM_TWO, wOnes );
      else if( tens == '1' )
        GetNumber( SolegyPrompt::PR_NUM_TWELVE, wTens );
      else
        GetNumber( SolegyPrompt::PR_NUM_TWO, wOnes );
      break;
    case '3':
      if( tens != 0 && tens != '1' )
        GetNumber( SolegyPrompt::PR_NUM_THREE, wOnes );
      else if( tens == '1' )
        GetNumber( SolegyPrompt::PR_NUM_THIRTEEN, wTens );
      else
        GetNumber( SolegyPrompt::PR_NUM_THREE, wOnes );
      break;
    case '4':
      if( tens != 0 && tens != '1' )
        GetNumber( SolegyPrompt::PR_NUM_FOUR, wOnes );
      else if( tens == '1' )
        GetNumber( SolegyPrompt::PR_NUM_FOURTEEN, wTens );
      else
        GetNumber( SolegyPrompt::PR_NUM_FOUR, wOnes );
      break;
    case '5':
      if( tens != 0 && tens != '1' )
        GetNumber( SolegyPrompt::PR_NUM_FIVE, wOnes );
      if( tens == '1' )
        GetNumber( SolegyPrompt::PR_NUM_FIFTEEN, wTens );
      else
        GetNumber( SolegyPrompt::PR_NUM_FIVE, wOnes );
      break;
    case '6':
      if( tens != 0 && tens != '1' )
        GetNumber( SolegyPrompt::PR_NUM_SIX, wOnes );
      else if( tens == '1' )
        GetNumber( SolegyPrompt::PR_NUM_SIXTEEN, wTens );
      else
        GetNumber( SolegyPrompt::PR_NUM_SIX, wOnes );
      break;
    case '7':
      if( tens != 0 && tens != '1' )
        GetNumber( SolegyPrompt::PR_NUM_SEVEN, wOnes );
      else if( tens == '1' )
        GetNumber( SolegyPrompt::PR_NUM_SEVENTEEN, wTens );
      else
        GetNumber( SolegyPrompt::PR_NUM_SEVEN, wOnes );
      break;
    case '8':
      if( tens != 0 && tens != '1' )
        GetNumber( SolegyPrompt::PR_NUM_EIGHT, wOnes );
      else if( tens == '1' )
        GetNumber( SolegyPrompt::PR_NUM_EIGHTEEN, wTens );
      else
        GetNumber( SolegyPrompt::PR_NUM_EIGHT, wOnes );
      break;
    case '9':
      if( tens != 0 && tens != '1' )
        GetNumber( SolegyPrompt::PR_NUM_NINE, wOnes );
      else if( tens == '1' )
        GetNumber( SolegyPrompt::PR_NUM_NINETEEN, wTens );
      else
        GetNumber( SolegyPrompt::PR_NUM_NINE, wOnes );
      break;
    }
  }

  return TRUE;
}
  
BOOL SolegyPromptManager::GetWholeNumber( const OString & whole, OStringArray &words)
{
  OString wHundredThousands;
  OString wTenThousands;
  OString wThousands;
  OString wHundreds;
  OString wTens;
  OString wOnes;

  if( !GetWholeNumber(
    whole, 
    wHundredThousands,
    wTenThousands,
    wThousands,
    wHundreds,
    wTens,
    wOnes
  )) return FALSE;

  bool hasThousands = false;
  bool hasHundreds = false;

  if( !wHundredThousands.IsEmpty() )
  {
    words.AppendString( wHundredThousands );
    words.AppendString( "hundred" );
    hasThousands = true;
  }

  if( !wTenThousands.IsEmpty() )
  {
    words.AppendString(wTenThousands);
    hasThousands = true;
  }

  if( !wThousands.IsEmpty() )
  {
    hasThousands = true;
    words.AppendString( wThousands );
  }

  if( hasThousands )
  {
    PDirectory dir = m_Config->GetString( "Solegy-Prompt-Location", "MS-Debit-Prompt-Number-Dir", m_PromptNumberDir );
    OStringStream path;
    path << dir << m_Config->GetString( "Solegy-Debit-Prompts", "PR_NUM_THOUSAND", "thousand.wav" );
    words.AppendString( path.str() );
  }

  if( !wHundreds.IsEmpty() )
  {
    words.AppendString( wHundreds );
    words.AppendString( "hundred" );
    hasHundreds = true;
  }

  if( hasHundreds )
  {
    PDirectory dir = m_Config->GetString( "Solegy-Prompt-Location", "MS-Debit-Prompt-Number-Dir", m_PromptNumberDir );
    OStringStream path;
    path << dir << m_Config->GetString( "Solegy-Debit-Prompts", "PR_NUM_HUNDRED", "hundred.wav" );
    words.AppendString( path.str() );
  }

  if( !wTens.IsEmpty() )
  {
      words.AppendString(wTens);
  }

  if( !wOnes.IsEmpty() )
    words.AppendString( wOnes );
  
  return TRUE;
}

BOOL SolegyPromptManager::GetNumber( SolegyPrompt::PromptNumType type, OString & file )
{
  if( type >= SolegyPrompt::NUM_PR_NUM )
    return FALSE;


  PDirectory dir = m_Config->GetString( "Solegy-Prompt-Location", "MS-Debit-Prompt-Number-Dir", m_PromptNumberDir );
  PString prompt;
  switch (type)
  {
  case SolegyPrompt::PR_NUM_ZERO:
    prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_NUM_ZERO", "zero.wav" );
    break;
  case SolegyPrompt::PR_NUM_ONE:
    prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_NUM_ONE", "one.wav" );
    break;
  case SolegyPrompt::PR_NUM_TWO:
    prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_NUM_TWO", "two.wav" );
    break;
  case SolegyPrompt::PR_NUM_THREE:
    prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_NUM_THREE", "three.wav" );
    break;
  case SolegyPrompt::PR_NUM_FOUR:
    prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_NUM_FOUR", "four.wav" );
    break;
  case SolegyPrompt::PR_NUM_FIVE:
    prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_NUM_FIVE", "five.wav" );
    break;
  case SolegyPrompt::PR_NUM_SIX:
    prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_NUM_SIX", "six.wav" );
    break;
  case SolegyPrompt::PR_NUM_SEVEN:
    prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_NUM_SEVEN", "seven.wav" );
    break;
  case SolegyPrompt::PR_NUM_EIGHT:
    prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_NUM_EIGHT", "eight.wav" );
    break;
  case SolegyPrompt::PR_NUM_NINE:
    prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_NUM_NINE", "nine.wav" );
    break;
  case SolegyPrompt::PR_NUM_TEN:
    prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_NUM_TEN", "ten.wav" );
    break;
  case SolegyPrompt::PR_NUM_ELEVEN:
    prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_NUM_ELEVEN", "eleven.wav" );
    break;
  case SolegyPrompt::PR_NUM_TWELVE:
    prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_NUM_TWELVE", "twelve.wav" );
    break;
  case SolegyPrompt::PR_NUM_THIRTEEN:
    prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_NUM_THIRTEEN", "thirteen.wav" );
    break;
  case SolegyPrompt::PR_NUM_FOURTEEN:
    prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_NUM_FOURTEEN", "fourteen.wav" );
    break;
  case SolegyPrompt::PR_NUM_FIFTEEN:
    prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_NUM_FIFTEEN", "fifteen.wav" );
    break;
  case SolegyPrompt::PR_NUM_SIXTEEN:
    prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_NUM_SIXTEEN", "sixteen.wav" );
    break;
  case SolegyPrompt::PR_NUM_SEVENTEEN:
    prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_NUM_SEVENTEEN", "seventeen.wav" );
    break;
  case SolegyPrompt::PR_NUM_EIGHTEEN:
    prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_NUM_EIGHTEEN", "eighteen.wav" );
    break;
  case SolegyPrompt::PR_NUM_NINETEEN:
    prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_NUM_NINETEEN", "nineteen.wav" );
    break;
  case SolegyPrompt::PR_NUM_TWENTY:
    prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_NUM_TWENTY", "twenty.wav" );
    break;
  case SolegyPrompt::PR_NUM_THIRTY:
    prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_NUM_THIRTY", "thirty.wav" );
    break;
  case SolegyPrompt::PR_NUM_FORTY:
    prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_NUM_FORTY", "forty.wav" );
    break;
  case SolegyPrompt::PR_NUM_FIFTY:
    prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_NUM_FIFTY", "fifty.wav" );
    break;
  case SolegyPrompt::PR_NUM_SIXTY:
    prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_NUM_SIXTY", "sixty.wav" );
    break;
  case SolegyPrompt::PR_NUM_SEVENTY:
    prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_NUM_SEVENTY", "seventy.wav" );
    break;
  case SolegyPrompt::PR_NUM_EIGHTY:
    prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_NUM_EIGHTY", "eighty.wav" );
    break;
  case SolegyPrompt::PR_NUM_NINETY:
    prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_NUM_NINETY", "ninety.wav" );
    break;
  case SolegyPrompt::PR_NUM_HUNDRED:
    prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_NUM_HUNDRED", "hundred.wav" );
    break;
  case SolegyPrompt::PR_NUM_THOUSAND:
    prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_NUM_THOUSAND", "thousand.wav" );
    break;
  case SolegyPrompt::PR_NUM_THOUSANDS:
    prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_NUM_THOUSANDS", "thousands.wav" );
    break;
  case SolegyPrompt::PR_NUM_MILLION:
    prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_NUM_MILLION", "million.wav" );
    break;
  case SolegyPrompt::PR_NUM_MILLIONS:
    prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_NUM_MILLIONS", "millions.wav" );
    break;
  case SolegyPrompt::PR_NUM_CUSTOM_1:
    prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_NUM_CUSTOM_1", "numcustom1.wav" );
    break;
  case SolegyPrompt::PR_NUM_CUSTOM_2:
    prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_NUM_CUSTOM_2", "numcustom2.wav" );
    break;
  case SolegyPrompt::PR_NUM_CUSTOM_3:
    prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_NUM_CUSTOM_3", "numcustom3.wav" );
    break;
  case SolegyPrompt::PR_NUM_CUSTOM_4:
    prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_NUM_CUSTOM_4", "numcustom4.wav" );
    break;
  case SolegyPrompt::PR_NUM_CUSTOM_5:
    prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_NUM_CUSTOM_5", "numcustom5.wav" );
    break;
  case SolegyPrompt::PR_NUM_CUSTOM_6:
    prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_NUM_CUSTOM_6", "numcustom6.wav" );
    break;
  case SolegyPrompt::PR_NUM_CUSTOM_7:
    prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_NUM_CUSTOM_7", "numcustom7.wav" );
    break;
  case SolegyPrompt::PR_NUM_CUSTOM_8:
    prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_NUM_CUSTOM_8", "numcustom8.wav" );
    break;
  case SolegyPrompt::PR_NUM_CUSTOM_9:
    prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_NUM_CUSTOM_9", "numcustom9.wav" );
    break;
  case SolegyPrompt::PR_NUM_CUSTOM_10:
    prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_NUM_CUSTOM_10", "numcustom10.wav" );
    break;
  default:
    return FALSE;
  };

  OStringStream path;
  path << dir << prompt;
  file = path.str();
  return TRUE;
}

BOOL SolegyPromptManager::GetPhrase( SolegyPrompt::PromptPhraseType type, OString & file )
{
  if( type >= SolegyPrompt::NUM_PR_PRH )
    return FALSE;

  PDirectory dir = m_Config->GetString( "Solegy-Prompt-Location", "MS-Debit-Prompt-Phrase-Dir", m_PromptPhraseDir );
  PString prompt;

  switch(type)
  {
  case SolegyPrompt::PR_PRH_WELCOME:
    prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_PRH_WELCOME", "hello.wav" );
    break;
  case SolegyPrompt::PR_PRH_AND:
    prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_PRH_AND", "and.wav" );
    break;
  case SolegyPrompt::PR_PRH_GOOD_BYE:
    prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_PRH_GOOD_BYE", "goodbye.wav" );
    break;
  case SolegyPrompt::PR_PRH_ENTER_PIN:
    prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_PRH_ENTER_PIN", "enter_pin.wav" );
    break;
  case SolegyPrompt::PR_PRH_INVALID_PIN:
    prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_PRH_INVALID_PIN", "invalid_pin.wav" );
    break;
  case SolegyPrompt::PR_PRH_ENTER_NUMBER:
    prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_PRH_ENTER_NUMBER", "enter_number.wav" );
    break;
  case SolegyPrompt::PR_PRH_INVALID_NUMBER:
    prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_PRH_INVALID_NUMBER", "invalid_number.wav" );
    break;
  case SolegyPrompt::PR_PRH_TRY_AGAIN:
    prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_PRH_TRY_AGAIN", "try_again.wav" );
    break;
  case SolegyPrompt::PR_PRH_INFORM_CALL_TRANSFER:
    prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_PRH_INFORM_CALL_TRANSFER", "hold_calling.wav" );
    break;
  case SolegyPrompt::PR_PRH_INFORM_BALANCE:
    prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_PRH_INFORM_BALANCE", "you_have.wav" );
    break;
  case SolegyPrompt::PR_PRH_INFORM_TALK_TIME:
    prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_PRH_INFORM_TALK_TIME", "you_have.wav" );
    break;
  case SolegyPrompt::PR_PRH_CUSTOM_1:
    prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_PRH_CUSTOM_1", "prhcustom1.wav" );
    break;
  case SolegyPrompt::PR_PRH_CUSTOM_2:
    prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_PRH_CUSTOM_2", "prhcustom2.wav" );
    break;
  case SolegyPrompt::PR_PRH_CUSTOM_3:
    prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_PRH_CUSTOM_3", "prhcustom3.wav" );
    break;
  case SolegyPrompt::PR_PRH_CUSTOM_4:
    prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_PRH_CUSTOM_4", "prhcustom4.wav" );
    break;
  case SolegyPrompt::PR_PRH_CUSTOM_5:
    prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_PRH_CUSTOM_5", "prhcustom5.wav" );
    break;
  case SolegyPrompt::PR_PRH_CUSTOM_6:
    prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_PRH_CUSTOM_6", "prhcustom6.wav" );
    break;
  case SolegyPrompt::PR_PRH_CUSTOM_7:
    prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_PRH_CUSTOM_7", "prhcustom7.wav" );
    break;
  case SolegyPrompt::PR_PRH_CUSTOM_8:
    prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_PRH_CUSTOM_8", "prhcustom8.wav" );
    break;
  case SolegyPrompt::PR_PRH_CUSTOM_9:
    prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_PRH_CUSTOM_9", "prhcustom9.wav" );
    break;
  case SolegyPrompt::PR_PRH_CUSTOM_10:
    prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_PRH_CUSTOM_10", "prhcustom10.wav" );
    break;
  default:
    break;
  };

  OStringStream path;
  path << dir << prompt;
  file = path.str();

  return TRUE;
}

BOOL SolegyPromptManager::GetError( SolegyPrompt::PromptErrorType type, OString & file )
{
  if( type >= SolegyPrompt::NUM_PR_ERROR )
    return FALSE;

  PDirectory dir = m_Config->GetString( "Solegy-Prompt-Location", "MS-Debit-Prompt-Error-Dir", m_PromptErrorDir );
  PString prompt;

  switch( type )
  {
    case SolegyPrompt::PR_ERROR_ACCOUNT_DEPLETED:
      prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_ERROR_ACCOUNT_DEPLETED", "account_depleted.wav" );
      break;
    case SolegyPrompt::PR_ERROR_CALL_FAILED:
      prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_ERROR_CALL_FAILED", "call_failed.wav" );
      break;
    case SolegyPrompt::PR_ERROR_MAX_CALL_DURATION_REACHED:
      prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_ERROR_MAX_CALL_DURATION_REACHED", "max_call_duration.wav" );
      break;
    case SolegyPrompt::PR_ERROR_MAX_SIMULTANEOUS_ACCESS_REACHED:
      prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_ERROR_MAX_SIMULTANEOUS_ACCESS_REACHED", "max_simultaneous_access.wav" );
      break;
    case SolegyPrompt::PR_ERROR_MEDIA_INACTIVE:
      prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_ERROR_MEDIA_INACTIVE", "media_inactive.wav" );
      break;
    case SolegyPrompt::PR_ERROR_NO_FUNDS:
      prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_ERROR_NO_FUNDS", "account_depleted.wav" );
      break;
    case SolegyPrompt::PR_ERROR_SERVICE_NOT_AVAILABLE:
      prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_ERROR_SERVICE_NOT_AVAILABLE", "service_not_available.wav" );
      break;
    case SolegyPrompt::PR_ERROR_BAD_NUMBER:
      prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_ERROR_BAD_NUMBER", "remote_bad_number.wav" );
      break;
    case SolegyPrompt::PR_ERROR_BUSY:
      prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_ERROR_BUSY", "remote_busy.wav" );
      break;
    case SolegyPrompt::PR_ERROR_FAST_BUSY:
      prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_ERROR_FAST_BUSY", "remote_fast_busy.wav" );
      break;
    case SolegyPrompt::PR_ERROR_CUSTOM_1:
     prompt =  m_Config->GetString( "Solegy-Debit-Prompts", "PR_ERROR_CUSTOM_1", "errcustom1.wav" );
      break;
    case SolegyPrompt::PR_ERROR_CUSTOM_2:
      prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_ERROR_CUSTOM_2", "errcustom2.wav" );
      break;
    case SolegyPrompt::PR_ERROR_CUSTOM_3:
      prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_ERROR_CUSTOM_3", "errcustom3.wav" );
      break;
    case SolegyPrompt::PR_ERROR_CUSTOM_4:
      prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_ERROR_CUSTOM_4", "errcustom4.wav" );
      break;
    case SolegyPrompt::PR_ERROR_CUSTOM_5:
      prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_ERROR_CUSTOM_5", "errcustom5.wav" );
      break;
    case SolegyPrompt::PR_ERROR_CUSTOM_6:
      prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_ERROR_CUSTOM_6", "errcustom6.wav" );
      break;
    case SolegyPrompt::PR_ERROR_CUSTOM_7:
      prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_ERROR_CUSTOM_7", "errcustom7.wav" );
      break;
    case SolegyPrompt::PR_ERROR_CUSTOM_8:
      prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_ERROR_CUSTOM_8", "errcustom8.wav" );
      break;
    case SolegyPrompt::PR_ERROR_CUSTOM_9:
      prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_ERROR_CUSTOM_9", "errcustom9.wav" );
      break;
    case SolegyPrompt::PR_ERROR_CUSTOM_10:
      prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_ERROR_CUSTOM_10", "errcustom10.wav" );
      break;
    default:
      break;
    
  };

  OStringStream path;
  path << dir << prompt;
  file = path.str();

  return TRUE;
}

BOOL SolegyPromptManager::GetDateTime( SolegyPrompt::PromptDateTimeType type, OString & file )
{
  if( type >= SolegyPrompt::NUM_PR_DTIME )
    return FALSE;

  PDirectory dir = m_Config->GetString( "Solegy-Prompt-Location", "MS-Debit-Prompt-DateTime-Dir", m_PromptDateTimeDir );
  PString prompt;

  switch (type)
  {
    case SolegyPrompt::PR_DTIME_SECOND:
      prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_DTIME_SECOND", "second.wav" );
      break;
    case SolegyPrompt::PR_DTIME_SECONDS:
      prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_DTIME_SECONDS", "seconds.wav" );
      break;
    case SolegyPrompt::PR_DTIME_MINUTE:
      prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_DTIME_MINUTE", "minute.wav" );
      break;
    case SolegyPrompt::PR_DTIME_MINUTES:
      prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_DTIME_MINUTES", "minutes.wav" );
      break;
    case SolegyPrompt::PR_DTIME_HOUR:
      prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_DTIME_HOUR", "hour.wav" );
      break;
    case SolegyPrompt::PR_DTIME_HOURS:
      prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_DTIME_HOURS", "hours.wav" );
      break;
    case SolegyPrompt::PR_DTIME_DAY:
      prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_DTIME_DAY", "day.wav" );
      break;
    case SolegyPrompt::PR_DTIME_DAYS:
      prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_DTIME_DAYS", "days.wav" );
      break;
    case SolegyPrompt::PR_DTIME_WEEK:
      prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_DTIME_WEEK", "week.wav" );
      break;
    case SolegyPrompt::PR_DTIME_WEEKS:
      prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_DTIME_WEEKS", "weeks.wav" );
      break;
    case SolegyPrompt::PR_DTIME_MONTH:
      prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_DTIME_MONTH", "month.wav" );
      break;
    case SolegyPrompt::PR_DTIME_MONTHS:
      prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_DTIME_MONTHS", "months.wav" );
      break;
    case SolegyPrompt::PR_DTIME_YEAR:
      prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_DTIME_YEAR", "year.wav" );
      break;
    case SolegyPrompt::PR_DTIME_YEARS:
      prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_DTIME_YEARS", "years.wav" );
      break;
    case SolegyPrompt::PR_DTIME_MONDAY:
      prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_DTIME_MONDAY", "monday.wav" );
      break;
    case SolegyPrompt::PR_DTIME_TUESDAY:
      prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_DTIME_TUESDAY", "tuesday.wav" );
      break;
    case SolegyPrompt::PR_DTIME_WEDNESDAY:
      prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_DTIME_WEDNESDAY", "wednesday.wav" );
      break;
    case SolegyPrompt::PR_DTIME_THURSDAY:
      prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_DTIME_THURSDAY", "thursday.wav" );
      break;
    case SolegyPrompt::PR_DTIME_FRIDAY:
      prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_DTIME_FRIDAY", "friday.wav" );
      break;
    case SolegyPrompt::PR_DTIME_SATURDAY:
      prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_DTIME_SATURDAY", "saturday.wav" );
      break;
    case SolegyPrompt::PR_DTIME_SUNDAY:
      prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_DTIME_SUNDAY", "sunday.wav" );
      break;
    case SolegyPrompt::PR_DTIME_JANUARY:
      prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_DTIME_JANUARY", "january.wav" );
      break;
    case SolegyPrompt::PR_DTIME_FEBRUARY:
      prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_DTIME_FEBRUARY", "february.wav" );
      break;
    case SolegyPrompt::PR_DTIME_MARCH:
      prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_DTIME_MARCH", "march.wav" );
      break;
    case SolegyPrompt::PR_DTIME_APRIL:
      prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_DTIME_APRIL", "april.wav" );
      break;
    case SolegyPrompt::PR_DTIME_MAY:
      prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_DTIME_MAY", "may.wav" );
      break;
    case SolegyPrompt::PR_DTIME_JUNE:
      prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_DTIME_JUNE", "june.wav" );
      break;
    case SolegyPrompt::PR_DTIME_JULY:
      prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_DTIME_JULY", "july.wav" );
      break;
    case SolegyPrompt::PR_DTIME_AUGUST:
      prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_DTIME_AUGUST", "august.wav" );
      break;
    case SolegyPrompt::PR_DTIME_SEPTEMBER:
      prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_DTIME_SEPTEMBER", "september.wav" );
      break;
    case SolegyPrompt::PR_DTIME_OCTOBER:
      prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_DTIME_OCTOBER", "october.wav" );
      break;
    case SolegyPrompt::PR_DTIME_NOVEMBER:
      prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_DTIME_NOVEMBER", "november.wav" );
      break;
    case SolegyPrompt::PR_DTIME_DECEMBER:
      prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_DTIME_DECEMBER", "december.wav" );
      break;
    default:
      break;
  };

  OStringStream path;
  path << dir << prompt;
  file = path.str();

  return TRUE;
}

BOOL SolegyPromptManager::GetCurrency( SolegyPrompt::PromptCurrencyType type, OString & file )
{
  if( type >= SolegyPrompt::NUM_PR_CUR )
    return FALSE;

  PDirectory dir = m_Config->GetString( "Solegy-Prompt-Location", "MS-Debit-Prompt-Currency-Dir", m_PromptCurrencyDir );
  PString prompt;

  switch(type) 
  {
    case SolegyPrompt::PR_CUR_DOLLAR:
      prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_CUR_DOLLAR", "dollar.wav" );
      break;
    case SolegyPrompt::PR_CUR_DOLLARS:
      prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_CUR_DOLLARS", "dollars.wav" );
      break;
    case SolegyPrompt::PR_CUR_POUND:
      prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_CUR_POUND", "pound.wav" );
      break;
    case SolegyPrompt::PR_CUR_POUNDS:
      prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_CUR_POUNDS", "pounds.wav" );
      break;
    case SolegyPrompt::PR_CUR_EURO:
      prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_CUR_EURO", "euro.wav" );
      break;
    case SolegyPrompt::PR_CUR_EUROS:
      m_Config->GetString( "Solegy-Debit-Prompts", "PR_CUR_EUROS", "euros.wav" );
      break;
    case SolegyPrompt::PR_CUR_CENT:
      prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_CUR_CENT", "cent.wav" );
      break;
    case SolegyPrompt::PR_CUR_CENTS:
      prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_CUR_CENTS", "cents.wav" );
      break;
    case SolegyPrompt::PR_CUR_CUSTOM_1:
      prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_CUR_CUSTOM_1", "currcustom1.wav" );
      break;
    case SolegyPrompt::PR_CUR_CUSTOM_2:
      prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_CUR_CUSTOM_2", "currcustom2.wav" );
      break;
    case SolegyPrompt::PR_CUR_CUSTOM_3:
      prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_CUR_CUSTOM_3", "currcustom3.wav" );
      break;
    case SolegyPrompt::PR_CUR_CUSTOM_4:
      prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_CUR_CUSTOM_4", "currcustom4.wav" );
      break;
    case SolegyPrompt::PR_CUR_CUSTOM_5:
      prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_CUR_CUSTOM_5", "currcustom5.wav" );
      break;
    case SolegyPrompt::PR_CUR_CUSTOM_6:
      prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_CUR_CUSTOM_6", "currcustom6.wav" );
      break;
    case SolegyPrompt::PR_CUR_CUSTOM_7:
      prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_CUR_CUSTOM_7", "currcustom7.wav" );
      break;
    case SolegyPrompt::PR_CUR_CUSTOM_8:
      prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_CUR_CUSTOM_8", "currcustom8.wav" );
      break;
    case SolegyPrompt::PR_CUR_CUSTOM_9:
      prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_CUR_CUSTOM_9", "currcustom9.wav" );
      break;
    case SolegyPrompt::PR_CUR_CUSTOM_10:
      prompt = m_Config->GetString( "Solegy-Debit-Prompts", "PR_CUR_CUSTOM_10", "currcustom10.wav" );
      break;
    default:
      break;
  };

  OStringStream path;
  path << dir << prompt;
  file = path.str();

  return TRUE;
}

BOOL SolegyPromptManager::GetCurrency( 
    const OString & whole, 
    OStringArray &words 
)
{
  PDirectory dir = m_Config->GetString( "Solegy-Prompt-Location", "MS-Debit-Prompt-Currency-Dir", m_PromptCurrencyDir );

  OStringArray tokens;
  whole.Tokenise( tokens, "." );
  BOOL isDecimalOnly = whole[0] == '.';
  
  int count = tokens.GetSize();
  if( count == 1 )
  {
    OString token =  tokens[0];
    if( isDecimalOnly )
      token = token.Left( 2 );
    GetWholeNumber( token, words );
    OString denom;
    if( token == "0" )
    {

      if( !isDecimalOnly )
        GetCurrency( SolegyPrompt::PR_CUR_DOLLARS, denom );
      else
        GetCurrency( SolegyPrompt::PR_CUR_CENTS, denom );

    } else {

      if( token == "1" )
      {
         if( !isDecimalOnly )
            GetCurrency( SolegyPrompt::PR_CUR_DOLLAR, denom );
         else
            GetCurrency( SolegyPrompt::PR_CUR_CENT, denom );

      } else
      {
         if( !isDecimalOnly )
           GetCurrency( SolegyPrompt::PR_CUR_DOLLARS, denom );
         else
           GetCurrency( SolegyPrompt::PR_CUR_CENTS, denom );
      }
    }
    words.AppendString( denom );
    return TRUE;
  }else if( count == 2 )
  {
    OString token =  tokens[0];
    GetWholeNumber( token, words );

    OString denom;
    if( token == "1" )
      GetCurrency( SolegyPrompt::PR_CUR_DOLLAR, denom );
    else
      GetCurrency( SolegyPrompt::PR_CUR_DOLLARS, denom );

    words.AppendString( denom );

    token =  tokens[1];
    if( token.AsInteger() > 0 )
    {
      OString concat;
      GetPhrase( SolegyPrompt::PR_PRH_AND, concat);
      words.AppendString( concat );
      
      if( token.GetLength() > 2 ) {
        token = token.Left(2);
        if ( token == "00" )
           token = "0";
      } else {
       if ( token.GetLength() == 1 ) {
           if (token == "1")
              token = "10";
           else if (token == "2")
              token = "20";
           else if (token == "3")
              token = "30";
           else if (token == "4")
              token = "40";
           else if (token == "5")
              token = "50";
           else if (token == "6")
              token = "60";
           else if (token == "7")
              token = "70";
           else if (token == "8")
              token = "80";
           else if (token == "9")
              token = "90";
        }
      }


      GetWholeNumber( token, words );

      if( token == "1" || token == "01" )
        GetCurrency( SolegyPrompt::PR_CUR_CENT, denom );
      else
        GetCurrency( SolegyPrompt::PR_CUR_CENTS, denom );

      words.AppendString( denom );
    }

    return TRUE;
  }
  return FALSE;
}


void SolegyPromptManager::OnPromptTimeout( PTimer &, INT )
{
  m_Session->OnIVRPromptTimeout();
}

void SolegyPromptManager::IVRCollect( const char * grammarId, int bufferSize, char termChar )
{
  B2BUAConnection * conn = m_Session->m_B2BUAConnection;
  if( conn != NULL && conn->IsSafeReference() )
  {
    conn->IVRSetDTMFGrammar( grammarId, bufferSize, termChar, TRUE, m_InputTimeout + 5000 );
  }
}

void SolegyPromptManager::IVRPlaySilence( int silence )
{
  if( silence > 0 )
  {
    B2BUAConnection * conn = m_Session->m_B2BUAConnection;
    if( conn != NULL && conn->IsSafeReference() )
    {
      PTimeInterval interval( silence );
      conn->IVRPlaySilence( interval );
    }
  }
}

BOOL SolegyPromptManager::IVRAnnounce( SolegyPrompt::Array & prompts, int silence )
{
  {
  if( m_Session->m_B2BUAConnection == NULL || !m_Session->m_B2BUAConnection->IsSafeReference() || m_Session->m_B2BUAConnection->GetIVRContext() == NULL )
    return FALSE;
  }

  IVRPlaySilence( silence );

  int count = prompts.GetSize();
  for( PINDEX i = 0; i < count; i++ )
    IVRAnnounce( prompts[i] );

  return TRUE;
}

BOOL SolegyPromptManager::IVRAnnounce( SolegyPrompt & prompt, int silence, int tailSilence )
{
  {
  if( m_Session->m_B2BUAConnection == NULL || !m_Session->m_B2BUAConnection->IsSafeReference() || m_Session->m_B2BUAConnection->GetIVRContext() == NULL )
    return FALSE;
  }

  IVRPlaySilence( silence );
  B2BUAConnection * conn = m_Session->m_B2BUAConnection;
  if( conn != NULL )
  {
    switch( prompt.m_PromptType )
    {
      case SolegyPrompt::TypeNum:
        GetNumber( static_cast<SolegyPrompt::PromptNumType>(prompt.m_PromptId), prompt.m_PromptFile );
        break;
      case SolegyPrompt::TypePhrase:
        if( static_cast<SolegyPrompt::PromptPhraseType>(prompt.m_PromptId) == SolegyPrompt::PR_PRH_WELCOME && !m_GreetingPrompt.IsEmpty() )
          prompt.m_PromptFile = m_GreetingPrompt;
        else
          GetPhrase( static_cast<SolegyPrompt::PromptPhraseType>(prompt.m_PromptId), prompt.m_PromptFile );
        break;
      case SolegyPrompt::TypeCurrency:
        GetCurrency( static_cast<SolegyPrompt::PromptCurrencyType>(prompt.m_PromptId), prompt.m_PromptFile );
        break;
      case SolegyPrompt::TypeDateTime:
        GetDateTime( static_cast<SolegyPrompt::PromptDateTimeType>(prompt.m_PromptId), prompt.m_PromptFile );
        break;
      case SolegyPrompt::TypeError:
        GetError( static_cast<SolegyPrompt::PromptErrorType>(prompt.m_PromptId), prompt.m_PromptFile );
        break;
      default:
        break;
    }

    RTTS_LOG( "Playing " << prompt.m_PromptFile );
    conn->IVRPlayFile( prompt.m_PromptName, prompt.m_PromptFile, tailSilence );
  }  

  return TRUE;
}

BOOL SolegyPromptManager::IVRAnnounce( const OString & id, const OString & path, int silence, int tailSilence )
{
  {
  if( m_Session->m_B2BUAConnection == NULL || !m_Session->m_B2BUAConnection->IsSafeReference() || m_Session->m_B2BUAConnection->GetIVRContext() == NULL )
    return FALSE;
  }

  IVRPlaySilence( silence );
  B2BUAConnection * conn = m_Session->m_B2BUAConnection;
  if( conn != NULL )
    conn->IVRPlayFile( id, path, tailSilence );

  return TRUE;
}

BOOL SolegyPromptManager::IVRAnnounceCurrency(const OString & id, const OString & currency, int silence, int tailSilence )
{
  {
  if( m_Session->m_B2BUAConnection == NULL || !m_Session->m_B2BUAConnection->IsSafeReference() || m_Session->m_B2BUAConnection->GetIVRContext() == NULL )
    return FALSE;
  }

  OStringArray tokens;
  currency.Tokenise( tokens, " " );
  OStringArray words;
  if( tokens.GetSize() == 1 )
    GetCurrency( tokens[0], words );
  else if( tokens.GetSize() == 2 )
    GetCurrency( tokens[1], words );

  int  count = words.GetSize();
  OString _id;
  int _silence = 0;
  int _tailSilence = 0;
  for( int i = 0; i < count; i ++ )
  {
    if( i == 0 )
      _silence = silence;
    else
      _silence = 0;

    if( i == count - 1 )
    {
      _id = id;
      _tailSilence = tailSilence;
    }

    IVRAnnounce( _id, words[i], _silence, _tailSilence );
  }

  return TRUE;
}

BOOL SolegyPromptManager::IVRAnnounceInterval( const OString & id, const PTimeInterval & interval, BOOL inMinutes, int silence, int tailSilence )
{
  {
  if( m_Session->m_B2BUAConnection == NULL || !m_Session->m_B2BUAConnection->IsSafeReference() || m_Session->m_B2BUAConnection->GetIVRContext() == NULL )
    return FALSE;
  }

  OStringArray words;
  if( inMinutes )
  {
    OString minutes( interval.GetMinutes() );
    GetWholeNumber( minutes, words );
  }else
  {
    OString seconds( interval.GetSeconds() );
    GetWholeNumber( seconds, words );
  }

  int count = words.GetSize();
  for( PINDEX i = 0; i < count; i++ )
  {
    if( i == 0 )
      IVRAnnounce( "", words[i], silence );
    else
      IVRAnnounce( "", words[i], 0 );
  }

  if( inMinutes )
  {
    if( interval.GetMinutes() == 1 )
    {
      SolegyPrompt prompt( SolegyPrompt::TypeDateTime, SolegyPrompt::PR_DTIME_MINUTE, id.c_str(), 0 );
      IVRAnnounce( prompt, 0, tailSilence ); 
    }else
    {
      SolegyPrompt prompt( SolegyPrompt::TypeDateTime, SolegyPrompt::PR_DTIME_MINUTES, id.c_str(), 0 );
      IVRAnnounce( prompt, 0, tailSilence ); 
    }
  }else
  {
    if( interval.GetSeconds() == 1 )
    {
      SolegyPrompt prompt( SolegyPrompt::TypeDateTime, SolegyPrompt::PR_DTIME_SECOND, id.c_str(), 0 );
      IVRAnnounce( prompt, 0, tailSilence ); 
    }else
    {
      SolegyPrompt prompt( SolegyPrompt::TypeDateTime, SolegyPrompt::PR_DTIME_SECONDS, id.c_str(), 0 );
      IVRAnnounce( prompt, 0, tailSilence ); 
    }
  }

  return TRUE;
}




  



