
#if ENABLE_CSCRIPT
#include "SBCConnectionScript.h"
#include "CScriptMessageGate.h"
using namespace AS;
using namespace B2BUA;

SBCConnection * SBCConnectionScript::m_SBCConnection = NULL;

BOOL SBCConnectionScript::LoadScriptModule(
  const PFilePath & module,
  BOOL autoReload
)
{
  PWaitAndSignal lock( CScript::m_ScriptMutex );
  return CScriptMessageGate::LoadScriptModule( module, autoReload );
}


BOOL SBCConnectionScript::Enter( 
  const char * eventData,
  SBCConnection * conn,
  SIPMessage * msg 
)
{
  PWaitAndSignal lock( CScript::m_ScriptMutex );
  SBCConnectionScript::m_SBCConnection = conn;
  return CScriptMessageGate::Enter( eventData, msg ) != NULL;
}


////////////////////

void oss_sbc_con_add_route( string & str )
{
  SIPURI route( str );
  SBCConnectionScript::m_SBCConnection->AddRoute( route );
}

void oss_sbc_con_remove_all_routes()
{
  SBCConnectionScript::m_SBCConnection->RemoveRoutes();
}


void SBCConnectionScript::RegisterModuleFuncs()
{
  PWaitAndSignal lock( CScript::m_ScriptMutex );
  CScriptMessageGate::RegisterModuleFuncs();

  CScript::GetScriptEngine()->RegisterGlobalFunction("void oss_sbc_con_add_route(string &str)", asFUNCTION(oss_sbc_con_add_route), asCALL_CDECL);
  CScript::GetScriptEngine()->RegisterGlobalFunction("void oss_sbc_con_remove_all_routes(string &str)", asFUNCTION(oss_sbc_con_remove_all_routes), asCALL_CDECL);
}

#endif //#if ENABLE_CSCRIPT
