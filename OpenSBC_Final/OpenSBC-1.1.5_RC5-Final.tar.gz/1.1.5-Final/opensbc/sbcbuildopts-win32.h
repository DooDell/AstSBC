#ifndef SBCBUILDOPTS_H
#define SBCBUILDOPTS_H

#include <ossbuildopts.h>

/// Python SAPI Support
#undef HAS_PYTHON_SAPI

/// PHP SAPI Support
#undef HAS_PHP_SAPI
#if HAS_PHP_SAPI
#ifdef WIN32
#define PHP_WIN32 1
#define ZEND_WIN32 1
#endif
#define ZTS 1
#define ZEND_DEBUG 0
#endif

#endif //SBCBUILDOPTS_H



